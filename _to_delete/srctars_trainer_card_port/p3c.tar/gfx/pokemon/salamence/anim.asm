	frame 1, 06
	frame 0, 06
	frame 1, 06
	frame 0, 12
	frame 2, 06
	frame 3, 12
	frame 4, 06
	frame 3, 06
	frame 4, 06
	frame 3, 06
	frame 4, 06
	frame 3, 06
	frame 2, 06
	frame 0, 06
	endanim