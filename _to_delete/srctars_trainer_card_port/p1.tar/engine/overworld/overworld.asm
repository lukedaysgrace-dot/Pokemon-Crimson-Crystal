GetEmote2bpp:
	ld a, $1
	ldh [rVBK], a
	call Get2bpp
	xor a
	ldh [rVBK], a
	ret

_ReplacePlayerSprite::
	call GetPlayerSprite
	call SetPlayerSpritePalette
	ld a, [wUsedSprites]
	ldh [hUsedSpriteIndex], a
	ld a, [wUsedSprites + 1]
	ldh [hUsedSpriteTile], a
	call GetUsedSprite
	call UpdateSprites
	ret

SetPlayerSpritePalette:
	ld a, [wPlayerSprite]
	call GetSpritePalette
	ld c, a
	or PAL_NPC_RED
	swap a
	and $f0
	ld d, a
	ld hl, wMapObjects + MAPOBJECT_COLOR
	ld a, [hl]
	and $f
	or d
	ld [hl], a
	ld hl, wPlayerStruct + OBJECT_PALETTE
	ld a, [hl]
	and $ff ^ PALETTE_MASK
	or c
	ld [hl], a
	ret

Function14146: ; mobile
	ld hl, wSpriteFlags
	ld a, [hl]
	push af
	res 7, [hl]
	set 6, [hl]
	call LoadUsedSpritesGFX
	pop af
	ld [wSpriteFlags], a
	ret

Function14157: ; mobile
	ld hl, wSpriteFlags
	ld a, [hl]
	push af
	set 7, [hl]
	res 6, [hl]
	call LoadUsedSpritesGFX
	pop af
	ld [wSpriteFlags], a
	ret

RefreshSprites::
	call .Refresh
	call LoadUsedSpritesGFX
	ret

.Refresh:
	xor a
	ld bc, wUsedSpritesEnd - wUsedSprites
	ld hl, wUsedSprites
	call ByteFill
	call GetPlayerSprite
	call AddMapSprites
	call LoadAndSortSprites
	ret

GetPlayerSprite:
; Get Gold or Lyra's sprite.
	ld hl, GoldStateSprites
	ld a, [wPlayerSpriteSetupFlags]
	bit PLAYERSPRITESETUP_FEMALE_TO_MALE_F, a
	jr nz, .go
	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	jr z, .go
	ld hl, LyraStateSprites

.go
	ld a, [wPlayerState]
	ld c, a
.loop
	ld a, [hli]
	cp c
	jr z, .good
	inc hl
	cp -1
	jr nz, .loop

; Any player state not in the array defaults to Gold's sprite.
	xor a ; ld a, PLAYER_NORMAL
	ld [wPlayerState], a
	ld a, SPRITE_GOLD
	jr .finish

.good
	ld a, [hl]

.finish
	ld [wUsedSprites + 0], a
	ld [wPlayerSprite], a
	ld [wPlayerObjectSprite], a
	ret

INCLUDE "data/sprites/player_sprites.asm"

AddMapSprites:
	call GetMapEnvironment
	call CheckOutdoorMap
	jr z, .outdoor
	call AddIndoorSprites
	ret

.outdoor
	call AddOutdoorSprites
	ret

AddIndoorSprites:
	ld hl, wMap1ObjectSprite
	ld a, 1
.loop
	push af
	ld a, [hl]
	and a
	jr z, .skip
	call AddSpriteGFX
.skip
	ld de, OBJECT_LENGTH
	add hl, de
	pop af
	inc a
	cp NUM_OBJECTS
	jr nz, .loop
	ret

AddOutdoorSprites:
	ld a, [wMapGroup]
	dec a
	ld c, a
	ld b, 0
	ld hl, OutdoorSprites
	add hl, bc
	add hl, bc
	ld a, [hli]
	ld h, [hl]
	ld l, a
	ld c, MAX_OUTDOOR_SPRITES
.loop
	push bc
	ld a, [hli]
	call AddSpriteGFX
	pop bc
	dec c
	jr nz, .loop
	ret

LoadUsedSpritesGFX:
	ld a, MAPCALLBACK_SPRITES
	call RunMapCallback
	call GetUsedSprites
	call .LoadMiscTiles
	farcall RefreshObjectSpriteTiles
	ret

.LoadMiscTiles:
	ld a, [wSpriteFlags]
	bit 6, a
	ret nz

	ld c, EMOTE_SHADOW
	farcall LoadEmote
	call GetMapEnvironment
	call CheckOutdoorMap
	ld c, EMOTE_GRASS_RUSTLE
	jr z, .outdoor
	ld c, EMOTE_BOULDER_DUST
.outdoor
	farcall LoadEmote
	ret

SafeGetSprite:
	push hl
	call GetSprite
	pop hl
	ret

GetSprite:
	call GetMonSprite
	ret c
	call GetIndigoPlayerSprite
	ret c

	ld hl, OverworldSprites + SPRITEDATA_ADDR
	dec a
	ld c, a
	ld b, 0
	ld a, NUM_SPRITEDATA_FIELDS
	call AddNTimes
	; load the address into de
	ld a, [hli]
	ld e, a
	ld a, [hli]
	ld d, a
	; load the length into c
	ld a, [hli]
	swap a
	ld c, a
	; load the sprite bank into both b and h
	ld b, [hl]
	ld a, [hli]
	; load the sprite type into l
	ld l, [hl]
	ld h, a
	ret

GetIndigoPlayerSprite:
	ld d, a
	ld a, [wPlayerGender]
	cp PLAYERGENDER_INDIGO
	jr nz, .not_indigo
	ld a, d
	cp SPRITE_GOLD
	jr z, .normal
	cp SPRITE_GOLD_BIKE
	jr z, .bike
	cp SPRITE_GOLD_SURF
	jr z, .surf
	cp SPRITE_GOLD_SKATEBOARD
	jr z, .skateboard

.not_indigo
	ld a, d
	and a
	ret

.normal
	ld de, IndigoSpriteGFX
	ld b, BANK(IndigoSpriteGFX)
	jr .done

.bike
	ld de, IndigoBikeSpriteGFX
	ld b, BANK(IndigoBikeSpriteGFX)
	jr .done

.surf
	ld de, IndigoSurfSpriteGFX
	ld b, BANK(IndigoSurfSpriteGFX)
	jr .done

.skateboard
	ld de, IndigoSkateboardSpriteGFX
	ld b, BANK(IndigoSkateboardSpriteGFX)

.done
	ld c, 12
	ld h, b
	ld l, WALKING_SPRITE
	scf
	ret

GetMonSprite:
; Return carry if a monster sprite was loaded.

	cp SPRITE_POKEMON
	jr c, .Normal
	cp SPRITE_DAY_CARE_MON_1
	jr z, .BreedMon1
	cp SPRITE_DAY_CARE_MON_2
	jr z, .BreedMon2
	cp SPRITE_VARS
	jr nc, .Variable
	jr .Icon

.Normal:
	and a
	ret

.Icon:
	sub SPRITE_POKEMON
	ld e, a
	ld d, 0
	ld hl, SpriteMons
	add hl, de
	add hl, de
	ld a, [hli]
	ld h, [hl]
	ld l, a
	call GetPokemonIDFromIndex
	jr .Mon

.BreedMon1
	ld a, [wBreedMon1Species]
	jr .Mon

.BreedMon2
	ld a, [wBreedMon2Species]

.Mon:
	ld e, a
	and a
	jr z, .NoBreedmon

	farcall LoadOverworldMonIcon

	ld l, MON_ICON_SPRITE
	ld h, 0
	scf
	ret

.Variable:
	sub SPRITE_VARS
	ld e, a
	ld d, 0
	ld hl, wVariableSprites
	add hl, de
	ld a, [hl]
	and a
	jp nz, GetMonSprite

.NoBreedmon:
	ld a, 1
	ld l, 1
	ld h, 0
	and a
	ret

_DoesSpriteHaveFacings::
; Checks to see whether we can apply a facing to a sprite.
; Returns carry unless the sprite is a Pokemon or a Still Sprite.
	cp SPRITE_POKEMON
	jr nc, .only_down

	push hl
	push bc
	ld hl, OverworldSprites + SPRITEDATA_TYPE
	dec a
	ld c, a
	ld b, 0
	ld a, NUM_SPRITEDATA_FIELDS
	call AddNTimes
	ld a, [hl]
	pop bc
	pop hl
	cp STILL_SPRITE
	jr z, .one_direction
	cp BIG_SPRITE
	jr nz, .only_down
.one_direction
	scf
	ret

.only_down
	and a
	ret

_GetSpritePalette::
	ld a, c
	call GetMonSprite
	jr c, .is_pokemon
	; a now holds the RESOLVED sprite id (variable sprites like
	; SPRITE_OLIVINE_RIVAL resolve to their real sprite, e.g. Silver).
	; Keep it in b: the Indigo check below clobbers a, and c still holds
	; the unresolved id - reloading that indexed OverworldSprites out of
	; bounds and painted the Olivine Gym rival barf green.
	ld b, a
	ld a, [wPlayerGender]
	cp PLAYERGENDER_INDIGO
	jr nz, .not_indigo
	ld a, c
	cp SPRITE_GOLD
	jr z, .indigo
	cp SPRITE_GOLD_BIKE
	jr z, .indigo
	cp SPRITE_GOLD_SURF
	jr z, .indigo
	cp SPRITE_GOLD_SKATEBOARD
	jr nz, .not_indigo

.indigo
	ld c, PAL_OW_PURPLE
	ret

.not_indigo
	ld a, b ; the resolved sprite id, NOT c (see above)

	ld hl, OverworldSprites + SPRITEDATA_PALETTE
	dec a
	ld c, a
	ld b, 0
	ld a, NUM_SPRITEDATA_FIELDS
	call AddNTimes
	ld c, [hl]
	ret

.is_pokemon
	xor a
	ld c, a
	ret

LoadAndSortSprites:
	call LoadSpriteGFX
	call SortUsedSprites
	call ArrangeUsedSprites
	ret

AddSpriteGFX:
; Add any new sprite ids to a list of graphics to be loaded.
; Return carry if the list is full.

	and a
	ret z

	push hl
	push bc
	ld b, a
	ld hl, wUsedSprites + 2
	ld c, SPRITE_GFX_LIST_CAPACITY - 1
.loop
	ld a, [hl]
	cp b
	jr z, .exists
	and a
	jr z, .new
	inc hl
	inc hl
	dec c
	jr nz, .loop

	pop bc
	pop hl
	scf
	ret

.exists
	pop bc
	pop hl
	and a
	ret

.new
	ld [hl], b
	pop bc
	pop hl
	and a
	ret

LoadSpriteGFX:
	ld hl, wUsedSprites
	ld b, SPRITE_GFX_LIST_CAPACITY
.loop
	ld a, [hli]
	and a
	jr z, .done
	push hl
	call .LoadSprite
	pop hl
	ld [hli], a
	dec b
	jr nz, .loop

.done
	ret

.LoadSprite:
	push bc
	call GetSprite
	pop bc
	ld a, l
	ret

SortUsedSprites:
; Bubble-sort sprites by type.

; Run backwards through wUsedSprites to find the last one.

	ld c, SPRITE_GFX_LIST_CAPACITY
	ld de, wUsedSprites + (SPRITE_GFX_LIST_CAPACITY - 1) * 2
.FindLastSprite:
	ld a, [de]
	and a
	jr nz, .FoundLastSprite
	dec de
	dec de
	dec c
	jr nz, .FindLastSprite
.FoundLastSprite:
	dec c
	jr z, .quit

; If the length of the current sprite is
; higher than a later one, swap them.

	inc de
	ld hl, wUsedSprites + 1

.CheckSprite:
	push bc
	push de
	push hl

.CheckFollowing:
	ld a, [de]
	cp [hl]
	jr nc, .loop

; Swap the two sprites.

	ld b, a
	ld a, [hl]
	ld [hl], b
	ld [de], a
	dec de
	dec hl
	ld a, [de]
	ld b, a
	ld a, [hl]
	ld [hl], b
	ld [de], a
	inc de
	inc hl

; Keep doing this until everything's in order.

.loop
	dec de
	dec de
	dec c
	jr nz, .CheckFollowing

	pop hl
	inc hl
	inc hl
	pop de
	pop bc
	dec c
	jr nz, .CheckSprite

.quit
	ret

ArrangeUsedSprites:
; Pack sprites into two independent VRAM banks. Tile ids below $80 select
; bank 1; ids with bit 7 set select bank 0 and use the low seven bits as their
; tile number. Keep a cursor for each bank so smaller sprites later in the
; type-sorted list can fill space that a walking sprite could not.
	ld hl, wUsedSprites
	ld c, SPRITE_GFX_LIST_CAPACITY
	ld d, 0    ; next tile in VRAM bank 1
	ld e, $80  ; bit-7-encoded next tile in VRAM bank 0
.next_sprite
	ld a, [hli]
	and a
	ret z

	ld a, [hl] ; unarranged sprite type
	call GetSpriteLength
	ld b, a

	; Animated sprites copy their additional facings at tile id + $80 in
	; bank 1, so their first frames must end before WEATHER_TILE. Still and
	; big sprites have no second copy and may use the rest of the lower table.
	ld a, [hl]
	cp STILL_SPRITE
	ld a, d
	jr nc, .try_static_bank1
	add b
	cp WEATHER_TILE - $80
	jr c, .assign_bank1
	jr z, .assign_bank1
	jr .try_bank0

.try_static_bank1
	add b
	cp $80
	jr c, .assign_bank1
	jr z, .assign_bank1
	jr .try_bank0

.assign_bank1
	ld [hl], d
	ld d, a
	jr .next

.try_bank0
	; Weather and emotes use VRAM bank 1, so they do not reduce this table.
	; e = 0 is the sentinel for an exactly full $80-tile bank.
	ld a, e
	and a
	jr z, .next
	add b
	jr nc, .assign_bank0
	and a
	jr nz, .next ; wrapped past $100
	; An endpoint of exactly $100 is valid; record the start and mark full.
	ld [hl], e
	ld e, a
	jr .next

.assign_bank0
	ld [hl], e
	ld e, a

.next
	; Entries that fit neither bank retain their sprite-type byte. The loaders
	; recognize that marker and safely fall back instead of using it as a tile.
	inc hl
	dec c
	jr nz, .next_sprite
	ret

GetSpriteLength:
; Return the length of sprite type a in tiles.

	cp WALKING_SPRITE
	jr z, .AnyDirection
	cp STANDING_SPRITE
	jr z, .AnyDirection
	cp STILL_SPRITE
	jr z, .OneDirection
	cp BIG_SPRITE
	jr z, .AnyDirection
	cp MON_ICON_SPRITE
	jr z, .MonIcon

	ld a, 12
	ret

.AnyDirection:
	ld a, 12
	ret

.OneDirection:
	ld a, 4
	ret

.MonIcon:
	ld a, 8
	ret

GetUsedSprites:
	ld hl, wUsedSprites
	ld c, SPRITE_GFX_LIST_CAPACITY

.loop
	ld a, [wSpriteFlags]
	res 5, a
	ld [wSpriteFlags], a

	ld a, [hli]
	and a
	jr z, .done
	ldh [hUsedSpriteIndex], a

	ld a, [hli]
	ldh [hUsedSpriteTile], a

; Skip sprites that failed VRAM assignment in ArrangeUsedSprites.
; Their tile byte is still a sprite type (1-5), which would overwrite
; the player if loaded at tiles 1-5.
	cp WALKING_SPRITE
	jr c, .load
	cp BIG_SPRITE + 1
	jr nc, .load
	dec c
	jr nz, .loop
	jr .done

.load
	bit 7, a
	jr z, .dont_set

	ld a, [wSpriteFlags]
	set 5, a ; load VBank0
	ld [wSpriteFlags], a

.dont_set
	push bc
	push hl
	call GetUsedSprite
	; Keep music ticking during LCD-off sprite reloads (no-op otherwise;
	; hl and af are dead here, so the farcall clobbers are harmless).
	farcall _PollSoundKeepalive
	pop hl
	pop bc
	dec c
	jr nz, .loop

.done
	ret

ReloadBank0SpriteFacings::
; Bank 0's second sprite table shares VRAM with the overworld font.
	ld hl, wSpriteFlags
	ld a, [hl]
	push af
	set 7, [hl] ; skip the first facing
	res 6, [hl]
	set 5, [hl] ; load VBank0

	ld hl, wUsedSprites
	ld c, SPRITE_GFX_LIST_CAPACITY
.loop
	ld a, [hli]
	and a
	jr z, .done
	ldh [hUsedSpriteIndex], a
	ld a, [hli]
	bit 7, a
	jr z, .next
	ldh [hUsedSpriteTile], a
	push bc
	push hl
	ldh a, [hUsedSpriteIndex]
	call .IsUsedByCurrentMap
	jr nc, .unused
	call GetUsedSprite
.unused
	pop hl
	pop bc
.next
	dec c
	jr nz, .loop

.done
	pop af
	ld [wSpriteFlags], a
	ret

.IsUsedByCurrentMap:
	ld b, a
	ld hl, wMap1ObjectSprite
	ld c, NUM_OBJECTS - 1
.find
	ld a, [hl]
	cp b
	jr z, .found
	ld de, OBJECT_LENGTH
	add hl, de
	dec c
	jr nz, .find
	and a
	ret
.found
	scf
	ret

GetUsedSprite:
	ldh a, [hUsedSpriteIndex]
	call SafeGetSprite
	ldh a, [hUsedSpriteTile]
	call .GetTileAddr
	push hl
	push de
	push bc
	ld a, [wSpriteFlags]
	bit 7, a
	jr nz, .skip
	call .CopyToVram

.skip
	pop bc
	ld l, c
	ld h, $0
rept 4
	add hl, hl
endr
	pop de
	add hl, de
	ld d, h
	ld e, l
	pop hl

	ld a, [wSpriteFlags]
	bit 6, a
	jr nz, .done

	ldh a, [hUsedSpriteIndex]
	call _DoesSpriteHaveFacings
	jr c, .done

	ld a, h
	add HIGH(vTiles1 - vTiles0)
	ld h, a
	call .CopyToVram

.done
	ret

.GetTileAddr:
; Return the address of tile (a) in (hl).
	and $7f
	ld l, a
	ld h, 0
rept 4
	add hl, hl
endr
	ld a, l
	add LOW(vTiles0)
	ld l, a
	ld a, h
	adc HIGH(vTiles0)
	ld h, a
	ret

.CopyToVram:
	ldh a, [rVBK]
	push af
	ld a, [wSpriteFlags]
	bit 5, a
	ld a, $1
	jr z, .bankswitch
	ld a, $0

.bankswitch
	ldh [rVBK], a
	call Get2bpp
	pop af
	ldh [rVBK], a
	ret

LoadEmote::
; Get the address of the pointer to emote c.
	ld a, c
	ld bc, 6 ; sizeof(emote)
	ld hl, Emotes
	call AddNTimes
; Load the emote address into de
	ld e, [hl]
	inc hl
	ld d, [hl]
; load the length of the emote (in tiles) into c
	inc hl
	ld c, [hl]
	swap c
; load the emote pointer bank into b
	inc hl
	ld b, [hl]
; load the VRAM destination into hl
	inc hl
	ld a, [hli]
	ld h, [hl]
	ld l, a
; if the emote has a length of 0, do not proceed (error handling)
	ld a, c
	and a
	ret z
	call GetEmote2bpp
	ret

INCLUDE "data/sprites/emotes.asm"

INCLUDE "data/sprites/sprite_mons.asm"

INCLUDE "data/maps/outdoor_sprites.asm"

INCLUDE "data/sprites/sprites.asm"
