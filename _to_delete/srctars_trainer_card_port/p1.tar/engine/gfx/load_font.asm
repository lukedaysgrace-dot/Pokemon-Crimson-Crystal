INCLUDE "gfx/font.asm"

; This and the following two functions are unreferenced.
; Debug, perhaps?
Unreferenced_fb434:
	db 0

Unreferenced_Functionfb435:
	ld a, [Unreferenced_fb434]
	and a
	jp nz, Get1bpp_2
	jp Get1bpp

Unreferenced_Functionfb43f:
	ld a, [Unreferenced_fb434]
	and a
	jp nz, Get2bpp_2
	jp Get2bpp
; End unreferenced block

_LoadStandardFont::
	ld de, Font
	ld hl, vTiles1
	lb bc, BANK(Font), 32 ; "A" to "]"
	call Get1bpp_2
	ld de, Font + 32 * LEN_1BPP_TILE
	ld hl, vTiles1 tile $20
	lb bc, BANK(Font), 26 ; "a" to "z" (skip "┌" to "┘")
	call Get1bpp_2
	ld de, Font + 64 * LEN_1BPP_TILE
	ld hl, vTiles1 tile $40
	lb bc, BANK(Font), 3 ; "+", "<BOLD_P>", "<PCT>"
	call Get1bpp_2
	; Skip $c3/$c4: those slots hold the "┃"/"━" frame-edge tiles (loaded by
	; LoadFrame). Blanketing them here made the textbox border blink while
	; the box was already on screen during OpenText's font load.
	ld de, Font + 69 * LEN_1BPP_TILE
	ld hl, vTiles1 tile $45
	lb bc, BANK(Font), 27 ; $c5 to "←"
	call Get1bpp_2
	ld de, Font + 96 * LEN_1BPP_TILE
	ld hl, vTiles1 tile $60
	lb bc, BANK(Font), 32 ; "'" to "9"
	call Get1bpp_2
	; The "+" glyph (charmap $c0) has no tile in font.png, so load a hardcoded
	; one over the blank $c0 slot. Used by the level-up stat-gain display.
	ld de, PlusFontGFX
	ld hl, vTiles1 tile $40 ; "+" ($c0)
	lb bc, BANK(PlusFontGFX), 1
	call Get1bpp_2
	ret

PlusFontGFX:
; 8x8 1bpp "+" glyph, left-aligned and centered to match the digit glyphs.
	db %00000000
	db %00100000
	db %00100000
	db %11111000
	db %00100000
	db %00100000
	db %00000000
	db %00000000

_LoadFontsExtra1::
; The ■/☎/bold glyphs formerly loaded here now live in the main font
; ($d7-$de), freeing tiles $60-$7e for map graphics.
	jr LoadFrame

_LoadFontsExtra2::
; The ▲ glyph formerly loaded here now lives in the main font ($d8).
	ret

_LoadFontsBattleExtra::
	ld de, FontBattleExtra
	ld hl, vTiles2 tile $60
	lb bc, BANK(FontBattleExtra), 25
	call Get2bpp_2
	jr LoadFrame

LoadFrame:
	ld a, [wTextboxFrame]
	cp NUM_FRAMES
	jr c, .valid
	xor a ; safety: out-of-range saves fall back to frame 1
.valid
	ld bc, 8 * LEN_1BPP_TILE ; 8 tiles per frame: "┌─┐│└┘" + "┃━"
	ld hl, Frames
	call AddNTimes
	ld d, h
	ld e, l
	push de
	ld hl, vTiles0 tile "┌" ; $ba
	lb bc, BANK(Frames), 6 ; "┌" to "┘"
	call Get1bpp_2
	pop de
	ld hl, 6 * LEN_1BPP_TILE
	add hl, de
	ld d, h
	ld e, l
	ld hl, vTiles0 tile "┃" ; $c3
	lb bc, BANK(Frames), 2 ; "┃" and "━" (Polished-style right/bottom edges)
	call Get1bpp_2
	ld hl, vTiles2 tile " " ; $7f
	ld de, TextboxSpaceGFX
	lb bc, BANK(TextboxSpaceGFX), 1
	call Get1bpp_2
	ret

LoadBattleFontsHPBar:
	ld de, FontBattleExtra
	ld hl, vTiles2 tile $60
	lb bc, BANK(FontBattleExtra), 12
	call Get2bpp_2
	ld hl, vTiles2 tile $70
	ld de, FontBattleExtra + 16 tiles ; "<DO>"
	lb bc, BANK(FontBattleExtra), 3 ; "<DO>" to "『"
	call Get2bpp_2
	call LoadFrame

LoadHPBar:
	ld de, EnemyHPBarBorderGFX
	ld hl, vTiles2 tile $6c
	lb bc, BANK(EnemyHPBarBorderGFX), 4
	call Get1bpp_2
	ld de, HPExpBarBorderGFX
	ld hl, vTiles2 tile $73
	lb bc, BANK(HPExpBarBorderGFX), 6
	call Get1bpp_2
	ld de, ExpBarGFX
	ld hl, vTiles2 tile $55
	lb bc, BANK(ExpBarGFX), 9
	call Get2bpp_2
	ld de, MobilePhoneTilesGFX + 7 tiles ; mobile phone icon
	ld hl, vTiles2 tile $5e
	lb bc, BANK(MobilePhoneTilesGFX), 2
	call Get2bpp_2
	; Shiny star icon: overwrite the unused "<DO>" glyph at tile $70 in battle
	; VRAM so the battle HUD can display it next to a shiny mon's level.
	ld de, ShinyStarGFX
	ld hl, vTiles2 tile $70
	lb bc, BANK(ShinyStarGFX), 1
	call Get2bpp_2
	ret

ShinyStarGFX:
; 8x8 shiny "asterism" icon in the vanilla Crystal style: three equal 4-point
; sparkles lined up along a diagonal (top-right, center, bottom-left). Drawn in
; color index 2, which is blue in the battle exp palette (PAL_BATTLE_BG_EXP) and
; in the dedicated stats-screen shiny palette. Each row is (bitplane0, bitplane1).
	db $00, $40
	db $00, $e2
	db $00, $47
	db $00, $02
	db $00, $10
	db $00, $38
	db $00, $10
	db $00, $00

StatsScreen_LoadFont:
	call _LoadFontsBattleExtra
	ld de, EnemyHPBarBorderGFX
	ld hl, vTiles2 tile $6c
	lb bc, BANK(EnemyHPBarBorderGFX), 4
	call Get1bpp_2
	ld de, HPExpBarBorderGFX
	ld hl, vTiles2 tile $78
	lb bc, BANK(HPExpBarBorderGFX), 1
	call Get1bpp_2
	ld de, HPExpBarBorderGFX + 3 * LEN_1BPP_TILE
	ld hl, vTiles2 tile $76
	lb bc, BANK(HPExpBarBorderGFX), 2
	call Get1bpp_2
	ld de, ExpBarGFX
	ld hl, vTiles2 tile $55
	lb bc, BANK(ExpBarGFX), 8
	call Get2bpp_2
LoadStatsScreenPageTilesGFX:
	ld de, StatsScreenPageTilesGFX
	ld hl, vTiles2 tile $31
	lb bc, BANK(StatsScreenPageTilesGFX), 17
	call Get2bpp_2
	; Replace the stats screen shiny icon ("⁂", tile $3f) with the same blue
	; asterism used in battle, so the two icons match. It is colored blue via
	; the exp palette in _CGB_StatsScreen.
	ld de, ShinyStarGFX
	ld hl, vTiles2 tile $3f
	lb bc, BANK(ShinyStarGFX), 1
	call Get2bpp_2
	ret
