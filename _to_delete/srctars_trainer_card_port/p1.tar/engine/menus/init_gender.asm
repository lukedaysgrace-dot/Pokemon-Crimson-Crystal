InitCrystalData:
	ld a, $1
	ld [wd474], a
	xor a
	ld [wd473], a
	ld [wPlayerGender], a
	ld [wd475], a
	ld [wd476], a
	ld [wd477], a
	ld [wd478], a
	ld [wd002], a
	ld [wd003], a
	; could have done "ld a, [wd479] \ and %11111100", saved four operations
	ld a, [wd479]
	res 0, a
	ld [wd479], a
	ld a, [wd479]
	res 1, a
	ld [wd479], a
	ret

INCLUDE "mobile/mobile_12.asm"

InitGender:
	call InitGenderScreen
	call LoadGenderScreenPal
	call LoadGenderScreenLightBlueTile
	call WaitBGMap2
	call SetPalettes
	ld hl, TextJump_AreYouABoyOrAreYouAGirl
	call PrintText
	ld hl, .MenuHeader
	call LoadMenuHeader
	call WaitBGMap2
	call VerticalMenu
	call CloseWindow
	ld a, [wMenuCursorY]
	dec a
	jr z, .got_choice
	cp 1
	jr nz, .girl
	ld a, PLAYERGENDER_INDIGO
	jr .got_choice
.girl
	ld a, 1 << PLAYERGENDER_FEMALE_F
.got_choice
	ld [wPlayerGender], a
	ld c, 10
	call DelayFrames
	ret

.MenuHeader:
	db MENU_BACKUP_TILES ; flags
	menu_coords 5, 4, 14, 11
	dw .MenuData
	db 1 ; default option

.MenuData:
	db STATICMENU_CURSOR | STATICMENU_WRAP | STATICMENU_DISABLE_B ; flags
	db 3 ; items
	db "Gold@"
	db "Indigo@"
	db "Lyra@"

TextJump_AreYouABoyOrAreYouAGirl:
	; Which trainer are you?
	text_far Text_AreYouABoyOrAreYouAGirl
	text_end

InitDifficulty:
	call InitGenderScreen
	call LoadGenderScreenPal
	call LoadGenderScreenLightBlueTile
	call WaitBGMap2
	call SetPalettes
	ld hl, TextJump_SelectDifficulty
	call PrintText
	ld hl, .MenuHeader
	call LoadMenuHeader
	call WaitBGMap2
	call VerticalMenu
	call CloseWindow
	ld a, [wMenuCursorY]
	dec a
	jr nz, .confirm_hard
	ld hl, TextJump_SelectDifficultyNormal
	call PrintText
	call YesNoBox
	jr c, InitDifficulty
	ld de, ENGINE_HARD_MODE
	ld b, RESET_FLAG
	farcall EngineFlagAction
	jr .done

.confirm_hard
	ld hl, TextJump_SelectDifficultyHard
	call PrintText
	call YesNoBox
	jr c, InitDifficulty
	ld de, ENGINE_HARD_MODE
	ld b, SET_FLAG
	farcall EngineFlagAction

.done
	ld c, 10
	call DelayFrames
	ret

.MenuHeader:
	db MENU_BACKUP_TILES ; flags
	menu_coords 5, 4, 14, 9
	dw .MenuData
	db 1 ; default option

.MenuData:
	db STATICMENU_CURSOR | STATICMENU_WRAP | STATICMENU_DISABLE_B ; flags
	db 2 ; items
	db "Normal@"
	db "Hard@"

TextJump_SelectDifficulty:
	text_far Text_SelectDifficulty
	text_end

TextJump_SelectDifficultyNormal:
	text_far Text_SelectDifficultyNormal
	text_end

TextJump_SelectDifficultyHard:
	text_far Text_SelectDifficultyHard
	text_end

InitGenderScreen:
	ld a, $10
	ld [wMusicFade], a
	ld a, MUSIC_NONE
	ld [wMusicFadeID], a
	ld a, $0
	ld [wMusicFadeID + 1], a
	ld c, 8
	call DelayFrames
	call ClearBGPalettes
	call InitCrystalData
	call LoadFontsExtra
	hlcoord 0, 0
	ld bc, SCREEN_HEIGHT * SCREEN_WIDTH
	ld a, $0
	call ByteFill
	hlcoord 0, 0, wAttrMap
	ld bc, SCREEN_HEIGHT * SCREEN_WIDTH
	xor a
	call ByteFill
	ret

LoadGenderScreenPal:
	ld hl, .Palette
	ld de, wBGPals1
	ld bc, 1 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	farcall ApplyPals
	ret

.Palette:
INCLUDE "gfx/new_game/gender_screen.pal"

LoadGenderScreenLightBlueTile:
	ld de, .LightBlueTile
	ld hl, vTiles2 tile $00
	lb bc, BANK(.LightBlueTile), 1
	call Get2bpp
	ret

.LightBlueTile:
INCBIN "gfx/new_game/gender_screen.2bpp"
