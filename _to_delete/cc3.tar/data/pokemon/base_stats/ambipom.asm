	db 0 ; species ID placeholder

	db  75, 100,  66, 115,  90,  66
	;  hp  atk  def  spd  sat  sdf

	db NORMAL, NORMAL ; type
	db 45 ; catch rate
	db 169 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/ambipom/front.dimensions"
	abilities_for AMBIPOM, TECHNICIAN, PICKUP, SKILL_LINK
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, WORK_UP, PROTECT, FACADE, RETURN, SWAGGER, KNOCK_OFF, NASTY_PLOT, REST, ATTRACT, HONE_CLAWS
	; end
