; base data struct members (see data/pokemon/base_stats/*.asm)
BASE_SPECIES     EQUS "(wBaseSpecies - wCurBaseData)"
BASE_STATS       EQUS "(wBaseStats - wCurBaseData)"
BASE_HP          EQUS "(wBaseHP - wCurBaseData)"
BASE_ATK         EQUS "(wBaseAttack - wCurBaseData)"
BASE_SPD         EQUS "(wBaseSpeed - wCurBaseData)"
BASE_SAT         EQUS "(wBaseSpecialAttack - wCurBaseData)"
BASE_SDF         EQUS "(wBaseSpecialDefense - wCurBaseData)"
BASE_TYPES       EQUS "(wBaseType - wCurBaseData)"
BASE_TYPE_1      EQUS "(wBaseType1 - wCurBaseData)"
BASE_TYPE_2      EQUS "(wBaseType2 - wCurBaseData)"
BASE_CATCH_RATE  EQUS "(wBaseCatchRate - wCurBaseData)"
BASE_EXP         EQUS "(wBaseExp - wCurBaseData)"
BASE_ITEMS       EQUS "(wBaseItems - wCurBaseData)"
BASE_ITEM_1      EQUS "(wBaseItem1 - wCurBaseData)"
BASE_ITEM_2      EQUS "(wBaseItem2 - wCurBaseData)"
BASE_GENDER      EQUS "(wBaseGender - wCurBaseData)"
BASE_UNKNOWN_1   EQUS "(wBaseUnknown1 - wCurBaseData)"
BASE_EGG_STEPS   EQUS "(wBaseEggSteps - wCurBaseData)"
BASE_UNKNOWN_2   EQUS "(wBaseUnknown2 - wCurBaseData)"
BASE_PIC_SIZE    EQUS "(wBasePicSize - wCurBaseData)"
BASE_PADDING     EQUS "(wBasePadding - wCurBaseData)"
BASE_GROWTH_RATE EQUS "(wBaseGrowthRate - wCurBaseData)"
BASE_EGG_GROUPS  EQUS "(wBaseEggGroups - wCurBaseData)"
BASE_TMHM        EQUS "(wBaseTMHM - wCurBaseData)"
BASE_DATA_SIZE   EQUS "(wCurBaseDataEnd - wCurBaseData)"
BASE_ABILITIES      EQUS "(wBaseAbility1 - wCurBaseData)"
BASE_ABILITY_1      EQUS "(wBaseAbility1 - wCurBaseData)"
BASE_ABILITY_2      EQUS "(wBaseAbility2 - wCurBaseData)"
BASE_HIDDEN_ABILITY EQUS "(wBaseHiddenAbility - wCurBaseData)"

; AbilityFlags values (see data/abilities/flags.asm)
ABILFLAG_NO_COPY       EQU %00000001
ABILFLAG_NO_TRACE      EQU %00000010
ABILFLAG_NO_SWAP       EQU %00000100
ABILFLAG_NO_SUPPRESS   EQU %00001000
ABILFLAG_IGNORABLE     EQU %00010000
ABILFLAG_NO_TRANSFORM  EQU %00100000
ABILFLAG_NO_INTIMIDATE EQU %01000000

; Personality byte bit masks (party/box/battle struct Personality)
; bits 5-6: ability slot; bits 0-4: caught ball; bit 7 reserved
ABILITY_MASK   EQU %01100000
ABILITY_1      EQU %00100000
ABILITY_2      EQU %01000000
HIDDEN_ABILITY EQU %01100000

; caught ball (Personality bits 0-4); indexes into CaughtBallItems,
; PartyMenuBallGFX and CaughtBallPalMap. 0 (Poke Ball) is the default
; for gift/traded/hatched mons, so new entries must only be appended.
CAUGHT_BALL_MASK EQU %00011111
	const_def
	const CAUGHTBALL_POKE_BALL   ; 0
	const CAUGHTBALL_GREAT_BALL  ; 1
	const CAUGHTBALL_ULTRA_BALL  ; 2
	const CAUGHTBALL_MASTER_BALL ; 3
	const CAUGHTBALL_HEAVY_BALL  ; 4
	const CAUGHTBALL_LEVEL_BALL  ; 5
	const CAUGHTBALL_LURE_BALL   ; 6
	const CAUGHTBALL_FAST_BALL   ; 7
	const CAUGHTBALL_FRIEND_BALL ; 8
	const CAUGHTBALL_MOON_BALL   ; 9
	const CAUGHTBALL_LOVE_BALL   ; a
	const CAUGHTBALL_PARK_BALL   ; b
NUM_CAUGHT_BALLS EQU const_value

; gender ratio constants
GENDER_F0      EQU 0 percent
GENDER_F12_5   EQU 12 percent + 1
GENDER_F25     EQU 25 percent
GENDER_F50     EQU 50 percent
GENDER_F75     EQU 75 percent
GENDER_F100    EQU 100 percent - 1
GENDER_UNKNOWN EQU -1

; wBaseGrowthRate values
; GrowthRates indexes (see data/growth_rates.asm)
	const_def
	const GROWTH_MEDIUM_FAST
	const GROWTH_SLIGHTLY_FAST
	const GROWTH_SLIGHTLY_SLOW
	const GROWTH_MEDIUM_SLOW
	const GROWTH_FAST
	const GROWTH_SLOW

; wBaseEggGroups values
	const_def 1
	const EGG_MONSTER       ; 1
	const EGG_WATER_1       ; 2 (Amphibian)
	const EGG_BUG           ; 3
	const EGG_FLYING        ; 4
	const EGG_GROUND        ; 5 (Field)
	const EGG_FAIRY         ; 6
	const EGG_PLANT         ; 7 (Grass)
	const EGG_HUMANSHAPE    ; 8 (Human-Like)
	const EGG_WATER_3       ; 9 (Invertebrate)
	const EGG_MINERAL       ; a
	const EGG_INDETERMINATE ; b (Amorphous)
	const EGG_WATER_2       ; c (Fish)
	const EGG_DITTO         ; d
	const EGG_DRAGON        ; e
	const EGG_NONE          ; f (Undiscovered)

; party_struct members (see macros/wram.asm)
MON_SPECIES            EQUS "(wPartyMon1Species - wPartyMon1)"
MON_ITEM               EQUS "(wPartyMon1Item - wPartyMon1)"
MON_MOVES              EQUS "(wPartyMon1Moves - wPartyMon1)"
MON_ID                 EQUS "(wPartyMon1ID - wPartyMon1)"
MON_EXP                EQUS "(wPartyMon1Exp - wPartyMon1)"
MON_STAT_EXP           EQUS "(wPartyMon1StatExp - wPartyMon1)"
MON_HP_EXP             EQUS "(wPartyMon1HPExp - wPartyMon1)"
MON_ATK_EXP            EQUS "(wPartyMon1AtkExp - wPartyMon1)"
MON_DEF_EXP            EQUS "(wPartyMon1DefExp - wPartyMon1)"
MON_SPD_EXP            EQUS "(wPartyMon1SpdExp - wPartyMon1)"
MON_SPC_EXP            EQUS "(wPartyMon1SpcExp - wPartyMon1)"
MON_DVS                EQUS "(wPartyMon1DVs - wPartyMon1)"
MON_PERSONALITY        EQUS "(wPartyMon1Personality - wPartyMon1)"

; perfect DVs (15 in every stat)
PERFECT_ATKDEF_DV EQU $ff
PERFECT_SPDSPC_DV EQU $ff

; shiny/gender flags (party: Unused byte; box: PokerusStatus bits 6-7)
MON_SHINY_FLAG EQU %10000000
MON_MALE_FLAG  EQU %01000000
SHINY_PROBABILITY EQU 10 percent
POKERUS_PROBABILITY EQU 5 percent
PKRUS_OFFSET_FROM_DVS EQU 2 + NUM_MOVES + 1
MON_DVs                          EQUS "(wPartyMon1DVs - wPartyMon1)"
MON_SHINY_GENDER_OFFSET_FROM_DVS EQUS "(MON_UNUSED - MON_DVs)"
MON_PP                 EQUS "(wPartyMon1PP - wPartyMon1)"
MON_HAPPINESS          EQUS "(wPartyMon1Happiness - wPartyMon1)"
MON_PKRUS              EQUS "(wPartyMon1PokerusStatus - wPartyMon1)"
MON_CAUGHTDATA         EQUS "(wPartyMon1CaughtData - wPartyMon1)"
MON_CAUGHTLEVEL        EQUS "(wPartyMon1CaughtLevel - wPartyMon1)"
MON_CAUGHTTIME         EQUS "(wPartyMon1CaughtTime - wPartyMon1)"
MON_CAUGHTGENDER       EQUS "(wPartyMon1CaughtGender - wPartyMon1)"
MON_CAUGHTLOCATION     EQUS "(wPartyMon1CaughtLocation - wPartyMon1)"
MON_LEVEL              EQUS "(wPartyMon1Level - wPartyMon1)"
MON_STATUS             EQUS "(wPartyMon1Status - wPartyMon1)"
MON_UNUSED             EQUS "(wPartyMon1Unused - wPartyMon1)"
MON_HP                 EQUS "(wPartyMon1HP - wPartyMon1)"
MON_MAXHP              EQUS "(wPartyMon1MaxHP - wPartyMon1)"
MON_ATK                EQUS "(wPartyMon1Attack - wPartyMon1)"
MON_DEF                EQUS "(wPartyMon1Defense - wPartyMon1)"
MON_SPD                EQUS "(wPartyMon1Speed - wPartyMon1)"
MON_SAT                EQUS "(wPartyMon1SpclAtk - wPartyMon1)"
MON_SDF                EQUS "(wPartyMon1SpclDef - wPartyMon1)"
BOXMON_STRUCT_LENGTH   EQUS "(wPartyMon1End - wPartyMon1)"
PARTYMON_STRUCT_LENGTH EQUS "(wPartyMon1StatsEnd - wPartyMon1)"

NICKNAMED_MON_STRUCT_LENGTH EQUS "(PARTYMON_STRUCT_LENGTH + MON_NAME_LENGTH)"
REDMON_STRUCT_LENGTH EQU 44

; caught data

CAUGHT_TIME_MASK  EQU %11000000
CAUGHT_LEVEL_MASK EQU %00111111

CAUGHT_GENDER_MASK   EQU %10000000
CAUGHT_LOCATION_MASK EQU %01111111

CAUGHT_BY_UNKNOWN EQU 0
CAUGHT_BY_GIRL    EQU 1
CAUGHT_BY_BOY     EQU 2

CAUGHT_EGG_LEVEL EQU 1

; maximum number of party pokemon
PARTY_LENGTH EQU 6

; boxes
MONS_PER_BOX EQU 20
NUM_BOXES    EQU 14

; hall of fame
HOF_MON_LENGTH EQU 2 + 2 + 2 + 1 + (MON_NAME_LENGTH + -1) ; species, id, dvs, level, nick
HOF_LENGTH EQU 1 + HOF_MON_LENGTH * PARTY_LENGTH + 2 ; win count, party, terminator
NUM_HOF_TEAMS EQU 30

; evolution types (used in data/pokemon/evos_attacks.asm)
	const_def 1
	const EVOLVE_LEVEL
	const EVOLVE_LEVEL_MALE
	const EVOLVE_LEVEL_FEMALE
	const EVOLVE_ITEM
	const EVOLVE_TRADE
	const EVOLVE_HAPPINESS
	const EVOLVE_STAT
	const EVOLVE_MOVE
	const EVOLVE_HOLDING
	const EVOLVE_PARTY

; EVOLVE_HAPPINESS triggers
	const_def 1
	const TR_ANYTIME
	const TR_MORNDAY
	const TR_NITE

; EVOLVE_STAT triggers
	const_def 1
	const ATK_GT_DEF
	const ATK_LT_DEF
	const ATK_EQ_DEF

; wild data

NUM_GRASSMON EQU 7 ; data/wild/*_grass.asm table size
NUM_WATERMON EQU 3 ; data/wild/*_water.asm table size

GRASS_WILDDATA_LENGTH EQU 2 + (1 + NUM_GRASSMON * 3) * 3

; The SAFARI ZONE is split into three encounter areas.
; Boundaries are in map tile coordinates (the same numbers
; Polished Map shows for events) - tweak to fit the layout:
; - ice area:   y < SAFARI_ZONE_LEFT_AREAS_Y and x < SAFARI_ZONE_ICE_RIGHT_X
; - rocky area: y >= SAFARI_ZONE_LEFT_AREAS_Y and x < SAFARI_ZONE_ROCKY_RIGHT_X
;   (cave-style encounters on bare ground; see CheckSafariZoneRockyArea)
; - everywhere else uses the normal SAFARI_ZONE table in johto_grass.asm
SAFARI_ZONE_ICE_RIGHT_X   EQU 28
SAFARI_ZONE_ROCKY_RIGHT_X EQU 16
SAFARI_ZONE_LEFT_AREAS_Y  EQU 14
WATER_WILDDATA_LENGTH EQU 2 + (1 + NUM_WATERMON * 3) * 1
FISHGROUP_DATA_LENGTH EQU 1 + 2 * 3

NUM_ROAMMON_MAPS EQU 16 ; RoamMaps table size (see data/wild/roammon_maps.asm)

; treemon sets
; TreeMons indexes (see data/wild/treemons.asm)
	const_def
	const TREEMON_SET_CITY
	const TREEMON_SET_CANYON
	const TREEMON_SET_TOWN
	const TREEMON_SET_ROUTE
	const TREEMON_SET_KANTO
	const TREEMON_SET_LAKE
	const TREEMON_SET_FOREST
	const TREEMON_SET_ROCK
NUM_TREEMON_SETS EQU const_value

; treemon scores
	const_def
	const TREEMON_SCORE_BAD  ; 0
	const TREEMON_SCORE_GOOD ; 1
	const TREEMON_SCORE_RARE ; 2

; ChangeHappiness arguments (see data/happiness_changes.asm)
const_value = 1
	const HAPPINESS_GAINLEVEL         ; 01
	const HAPPINESS_USEDITEM          ; 02
	const HAPPINESS_USEDXITEM         ; 03
	const HAPPINESS_GYMBATTLE         ; 04
	const HAPPINESS_LEARNMOVE         ; 05
	const HAPPINESS_FAINTED           ; 06
	const HAPPINESS_POISONFAINT       ; 07
	const HAPPINESS_BEATENBYSTRONGFOE ; 08
	const HAPPINESS_OLDERCUT1         ; 09
	const HAPPINESS_OLDERCUT2         ; 0a
	const HAPPINESS_OLDERCUT3         ; 0b
	const HAPPINESS_YOUNGCUT1         ; 0c
	const HAPPINESS_YOUNGCUT2         ; 0d
	const HAPPINESS_YOUNGCUT3         ; 0e
	const HAPPINESS_BITTERPOWDER      ; 0f
	const HAPPINESS_ENERGYROOT        ; 10
	const HAPPINESS_REVIVALHERB       ; 11
	const HAPPINESS_GROOMING          ; 12
	const HAPPINESS_GAINLEVELATHOME   ; 13

; significant happiness values
BASE_HAPPINESS        EQU 70
FRIEND_BALL_HAPPINESS EQU 200
HAPPINESS_TO_EVOLVE   EQU 220
HAPPINESS_THRESHOLD_1 EQU 100
HAPPINESS_THRESHOLD_2 EQU 200

; PP
PP_UP_MASK EQU %11000000
PP_UP_ONE  EQU %01000000
PP_MASK    EQU %00111111
