	db 0 ; species ID placeholder

	db  38,  47,  35,  57,  33,  35
	;   hp  atk  def  spd  sat  sdf

	db FLYING, FLYING ; type
	db 255 ; catch rate
	db 49 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 15 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/rookidee/front.dimensions"
	abilities_for ROOKIDEE, KEEN_EYE, UNNERVE, BIG_PECKS
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_FLYING, EGG_FLYING ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, WORK_UP, PROTECT, FACADE, RETURN, MUD_SLAP, SWAGGER, SWIFT, NASTY_PLOT, REST, ATTRACT, THIEF, STEEL_WING, HONE_CLAWS, FLY
	; end
