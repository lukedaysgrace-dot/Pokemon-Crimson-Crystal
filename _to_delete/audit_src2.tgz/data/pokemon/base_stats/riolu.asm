	db 0 ; species ID placeholder

	db  40,  70,  40,  60,  35,  40
	;  hp  atk  def  spd  sat  sdf

	db FIGHTING, FIGHTING ; type
	db 75 ; catch rate
	db 57 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F12_5 ; gender ratio
	db 100 ; unknown 1
	db 25 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/riolu/front.dimensions"
	abilities_for RIOLU, STEADFAST, INNER_FOCUS, PRANKSTER
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_NONE, EGG_NONE ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, SUNNY_DAY, WORK_UP, PROTECT, FACADE, RETURN, MUD_SLAP, SWAGGER, SWIFT, BULK_UP, NASTY_PLOT, REST, ATTRACT, ZEN_HEADBUTT, STRENGTH
	; end
