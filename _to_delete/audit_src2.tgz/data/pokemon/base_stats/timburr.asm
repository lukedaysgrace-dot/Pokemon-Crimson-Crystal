	db 0 ; species ID placeholder

	db  75,  80,  55,  35,  25,  35
	;  hp  atk  def  spd  sat  sdf

	db FIGHTING, FIGHTING ; type
	db 180 ; catch rate
	db 61 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F25 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/timburr/front.dimensions"
	abilities_for TIMBURR, GUTS, SHEER_FORCE, IRON_FIST
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, WORK_UP, PROTECT, FACADE, RETURN, SWAGGER, KNOCK_OFF, BULK_UP, REST, ATTRACT
	; end
