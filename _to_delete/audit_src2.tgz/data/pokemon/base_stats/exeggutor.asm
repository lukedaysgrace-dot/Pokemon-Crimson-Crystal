	db 0 ; species ID placeholder

	db  95,  95,  85,  55, 125,  75
	;   hp  atk  def  spd  sat  sdf

	db GRASS, PSYCHIC ; type
	db 45 ; catch rate
	db 186 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/exeggutor/front.dimensions"
	abilities_for EXEGGUTOR, CHLOROPHYLL, NO_ABILITY, HARVEST
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_PLANT, EGG_PLANT ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, ROCK_TOMB, TOXIC, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, ENERGY_BALL, FACADE, SOLARBEAM, RETURN, PSYCHIC_M, SWAGGER, SLUDGE_BOMB, REST, ATTRACT, THIEF, ZEN_HEADBUTT, STRENGTH, FLASH
	; end
