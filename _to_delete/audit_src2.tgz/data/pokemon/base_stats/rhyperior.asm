	db 0 ; species ID placeholder

	db 115, 140, 130,  40,  55,  55
	;  hp  atk  def  spd  sat  sdf

	db GROUND, ROCK ; type
	db 30 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/rhyperior/front.dimensions"
	abilities_for RHYPERIOR, SOLID_ROCK, RECKLESS, SHEER_FORCE
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, PROTECT, FACADE, RETURN, SWAGGER, FLASH_CANNON, REST, ATTRACT
	; end
