	db 0 ; species ID placeholder

	db  75, 105,  60,  90,  35, 110
	;   hp  atk  def  spd  sat  sdf

	db BUG, FIGHTING ; type
	db 90 ; catch rate
	db 137 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 15 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/ledian/front.dimensions"
	abilities_for LEDIAN, TECHNICIAN, IRON_FIST, DEFIANT
	db 0 ; padding
	db GROWTH_FAST ; growth rate
	dn EGG_BUG, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, HEADBUTT, CURSE, ROCK_TOMB, TOXIC, HIDDEN_POWER, SUNNY_DAY, SWEET_SCENT, HYPER_BEAM, PROTECT, ENERGY_BALL, FACADE, SOLARBEAM, RETURN, DIG, SWAGGER, ICE_PUNCH, KNOCK_OFF, SWIFT, THUNDERPUNCH, REST, ATTRACT, THIEF, FLASH
	; end
