	db 0 ; species ID placeholder

	db  65,  75, 105,  85,  35,  65
	;   hp  atk  def  spd  sat  sdf

	db GROUND, FLYING ; type
	db 60 ; catch rate
	db 86 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/gligar/front.dimensions"
	abilities_for GLIGAR, IMMUNITY, HYPER_CUTTER, SAND_VEIL
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_BUG, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, SUNNY_DAY, PROTECT, FACADE, IRON_HEAD, RETURN, SWAGGER, KNOCK_OFF, SLUDGE_BOMB, SANDSTORM, SWIFT, REST, ATTRACT, THIEF, BUG_BITE, HONE_CLAWS, NIGHT_SLASH, CUT, STRENGTH
	; end
