	db 0 ; species ID placeholder

	db 100, 125,  52,  71, 115,  52
	;  hp  atk  def  spd  sat  sdf

	db DARK, FLYING ; type
	db 30 ; catch rate
	db 177 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/honchkrow/front.dimensions"
	abilities_for HONCHKROW, SUPER_LUCK, INSOMNIA, MOXIE
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_FLYING, EGG_FLYING ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, FACADE, RETURN, SHADOW_BALL, MUD_SLAP, SWAGGER, SWIFT, NASTY_PLOT, REST, ATTRACT, THIEF, STEEL_WING, NIGHT_SLASH, FLY
	; end
