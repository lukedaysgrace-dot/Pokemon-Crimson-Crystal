	db 0 ; species ID placeholder

	db  40,  70, 130,  25,  60, 130
	;  hp  atk  def  spd  sat  sdf

	db GHOST, GHOST ; type
	db 90 ; catch rate
	db 159 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 25 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/dusclops/front.dimensions"
	abilities_for DUSCLOPS, LEVITATE, PRANKSTER, REGENERATOR
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_INDETERMINATE, EGG_INDETERMINATE ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, PROTECT, WILL_O_WISP, FACADE, RETURN, SWAGGER, REST, ATTRACT
	; end
