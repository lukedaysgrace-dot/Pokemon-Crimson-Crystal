	db 0 ; species ID placeholder

	db  80,  45,  65,  80, 100, 110
	;  hp  atk  def  spd  sat  sdf

	db PSYCHIC, PSYCHIC ; type
	db 60 ; catch rate
	db 165 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/grumpig/front.dimensions"
	abilities_for GRUMPIG, THICK_FAT, OWN_TEMPO, PRANKSTER
	db 0 ; padding
	db GROWTH_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, PROTECT, FACADE, RETURN, SWAGGER, FLASH_CANNON, NASTY_PLOT, REST, ATTRACT, ZEN_HEADBUTT, POWER_GEM
	; end
