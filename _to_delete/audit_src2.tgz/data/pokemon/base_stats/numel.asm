	db 0 ; species ID placeholder

	db  60,  60,  40,  35,  65,  45
	;  hp  atk  def  spd  sat  sdf

	db FIRE, GROUND ; type
	db 255 ; catch rate
	db 61 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/numel/front.dimensions"
	abilities_for NUMEL, OBLIVIOUS, DROUGHT, OWN_TEMPO
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, SUNNY_DAY, PROTECT, WILL_O_WISP, FACADE, EARTHQUAKE, RETURN, DIG, SWAGGER, FLASH_CANNON, SANDSTORM, REST, ATTRACT, ZEN_HEADBUTT, STRENGTH
	; end
