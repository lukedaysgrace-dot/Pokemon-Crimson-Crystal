	db 0 ; species ID placeholder

	db  70,  77,  60, 108, 107,  60
	;   hp  atk  def  spd  sat  sdf

	db BUG, ELECTRIC ; type
	db 75 ; catch rate
	db 165 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/galvantula/front.dimensions"
	abilities_for GALVANTULA, COMPOUND_EYES, UNNERVE, SWARM
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_BUG, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm TOXIC, ZAP_CANNON, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, RAIN_DANCE, ENERGY_BALL, FACADE, THUNDER, RETURN, SWAGGER, SWIFT, REST, ATTRACT, THIEF, FLASH, THUNDERBOLT
	; end
