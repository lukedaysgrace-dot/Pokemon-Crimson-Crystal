	db 0 ; species ID placeholder

	db  65, 105,  70, 115,  80,  80
	;  hp  atk  def  spd  sat  sdf

	db FAIRY, FIRE ; type
	db 60 ; catch rate
	db 175 ; base exp
	db NO_ITEM, MIRACLEBERRY ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/rapidash_galarian/front.dimensions"
	abilities_for RAPIDASH_GALARIAN, FLASH_FIRE, PASTEL_VEIL, ANTICIPATION
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, HYPER_BEAM, PROTECT, IRON_HEAD, RETURN, SWAGGER, SWIFT, REST, ATTRACT, ZEN_HEADBUTT, STRENGTH
	; end
