	db 0 ; species ID placeholder

	db  45,  60,  60,  50,  60,  75
	;  hp  atk  def  spd  sat  sdf

	db FAIRY, FLYING ; type
	db 255 ; catch rate
	db 62 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/swablu/front.dimensions"
	abilities_for SWABLU, CLOUD_NINE, NATURAL_CURE, PIXILATE
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_FLYING, EGG_DRAGON ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, PROTECT, FACADE, RETURN, SWAGGER, REST, ATTRACT, STEEL_WING, FLY
	; end
