	db 0 ; species ID placeholder

	db  80,  80,  50,  25,  40,  50
	;  hp  atk  def  spd  sat  sdf

	db POISON, DARK ; type
	db 190 ; catch rate
	db 65 ; base exp
	db NUGGET, NUGGET ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/grimer_alolan/front.dimensions"
	abilities_for GRIMER_ALOLAN, POISON_TOUCH, GLUTTONY, NO_ABILITY
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_INDETERMINATE, EGG_INDETERMINATE ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, PROTECT, RAIN_DANCE, ENERGY_BALL, RETURN, DIG, SHADOW_BALL, SWAGGER, ICE_PUNCH, KNOCK_OFF, SLUDGE_BOMB, FIRE_BLAST, THUNDERPUNCH, REST, ATTRACT, THIEF, FIRE_PUNCH, ZEN_HEADBUTT, STRENGTH, FLAMETHROWER
	; end
