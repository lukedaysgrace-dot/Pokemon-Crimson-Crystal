	db 0 ; species ID placeholder

	db  90,  65,  65,  15,  40,  40
	;  hp  atk  def  spd  sat  sdf

	db PSYCHIC, PSYCHIC ; type
	db 190 ; catch rate
	db 63 ; base exp
	db NO_ITEM, KINGS_ROCK ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/slowpoke_galarian/front.dimensions"
	abilities_for SLOWPOKE_GALARIAN, OWN_TEMPO, UNAWARE, REGENERATOR
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_MONSTER, EGG_WATER_1 ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, ZAP_CANNON, HIDDEN_POWER, SUNNY_DAY, BLIZZARD, PROTECT, RAIN_DANCE, IRON_HEAD, EARTHQUAKE, RETURN, DIG, SHADOW_BALL, SWAGGER, FIRE_BLAST, SWIFT, REST, ATTRACT, ZEN_HEADBUTT, SURF, STRENGTH, FLASH, WHIRLPOOL, WATERFALL, FLAMETHROWER, ICE_BEAM
	; end
