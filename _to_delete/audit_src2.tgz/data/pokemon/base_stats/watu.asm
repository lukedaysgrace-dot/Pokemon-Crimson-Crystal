	db 0 ; species ID placeholder

	db  55,  60,  55,  82,  82,  55
	;   hp  atk  def  spd  sat  sdf

	db PSYCHIC, FLYING ; type
	db 120 ; catch rate
	db 124 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/watu/front.dimensions"
	abilities_for WATU, SYNCHRONIZE, EARLY_BIRD, MAGIC_BOUNCE
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_FLYING, EGG_FLYING ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, PROTECT, ENERGY_BALL, FACADE, SOLARBEAM, RETURN, PSYCHIC_M, SWAGGER, SWIFT, REST, ATTRACT, THIEF, FLY, FLASH
	; end
