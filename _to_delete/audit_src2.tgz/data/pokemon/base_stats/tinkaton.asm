	db 0 ; species ID placeholder

	db  85,  75,  77,  94,  70, 105
	;  hp  atk  def  spd  sat  sdf

	db FAIRY, STEEL ; type
	db 45 ; catch rate
	db 253 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F100 ; gender ratio (female only)
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/tinkaton/front.dimensions"
	abilities_for TINKATON, MOLD_BREAKER, OWN_TEMPO, PICKPOCKET
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_FAIRY, EGG_FAIRY ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, PROTECT, FACADE, RETURN, SWAGGER, FLASH_CANNON, KNOCK_OFF, REST, ATTRACT
	; end
