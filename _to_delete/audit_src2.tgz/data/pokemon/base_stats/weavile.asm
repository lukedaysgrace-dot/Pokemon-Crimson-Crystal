	db 0 ; species ID placeholder

	db  70, 120,  65, 125,  45,  85
	;  hp  atk  def  spd  sat  sdf

	db DARK, ICE ; type
	db 45 ; catch rate
	db 179 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/weavile/front.dimensions"
	abilities_for WEAVILE, TECHNICIAN, PRESSURE, PICKPOCKET
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, ICICLE_CRASH, PROTECT, FACADE, RETURN, SWAGGER, KNOCK_OFF, NASTY_PLOT, REST, ATTRACT, HONE_CLAWS, NIGHT_SLASH
	; end
