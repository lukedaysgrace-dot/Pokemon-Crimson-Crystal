	db 0 ; species ID placeholder

	db 110,  80,  90,  65,  95,  90
	;  hp  atk  def  spd  sat  sdf

	db ICE, WATER ; type
	db 45 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/walrein/front.dimensions"
	abilities_for WALREIN, THICK_FAT, ICE_BODY, SLUSH_RUSH
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_WATER_1, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, PROTECT, FACADE, RETURN, SWAGGER, REST, ATTRACT, SURF, WHIRLPOOL, WATERFALL
	; end
