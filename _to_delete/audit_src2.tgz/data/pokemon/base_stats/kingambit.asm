	db 0 ; species ID placeholder

	db 100, 135, 120,  50,  60,  85
	;  hp  atk  def  spd  sat  sdf

	db DARK, STEEL ; type
	db 25 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/kingambit/front.dimensions"
	abilities_for KINGAMBIT, DEFIANT, SUPREME_OVERLORD, SHARPNESS
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, PROTECT, FACADE, EARTHQUAKE, RETURN, DIG, SWAGGER, FLASH_CANNON, SANDSTORM, REST, ATTRACT, NIGHT_SLASH, ZEN_HEADBUTT, STRENGTH
	; end
