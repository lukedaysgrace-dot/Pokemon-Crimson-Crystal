	db 0 ; species ID placeholder

	db  25,  35,  40,  80,  20,  30
	;  hp  atk  def  spd  sat  sdf

	db BUG, WATER ; type
	db 90 ; catch rate
	db 46 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/wimpod/front.dimensions"
	abilities_for WIMPOD, RATTLED, NO_ABILITY, NO_ABILITY
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_BUG, EGG_WATER_3 ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, PROTECT, FACADE, RETURN, SWAGGER, REST, ATTRACT, SURF, WHIRLPOOL, WATERFALL
	; end
