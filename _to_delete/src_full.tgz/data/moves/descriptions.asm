MoveDescriptions::
; entries correspond to move ids (see constants/move_constants.asm)
	indirect_table 2, 1
	indirect_entries NUM_ATTACKS, MoveDescriptions1
	indirect_table_end

MoveDescriptions1:
	dw PoundDescription
	dw KarateChopDescription
	dw DoubleslapDescription
	dw CometPunchDescription
	dw MegaPunchDescription
	dw PayDayDescription
	dw FirePunchDescription
	dw IcePunchDescription
	dw ThunderpunchDescription
	dw ScratchDescription
	dw VicegripDescription
	dw GuillotineDescription
	dw RazorWindDescription
	dw SwordsDanceDescription
	dw CutDescription
	dw GustDescription
	dw WingAttackDescription
	dw WhirlwindDescription
	dw FlyDescription
	dw BindDescription
	dw SlamDescription
	dw VineWhipDescription
	dw StompDescription
	dw DoubleKickDescription
	dw MegaKickDescription
	dw JumpKickDescription
	dw RollingKickDescription
	dw SandAttackDescription
	dw HeadbuttDescription
	dw HornAttackDescription
	dw FuryAttackDescription
	dw HornDrillDescription
	dw TackleDescription
	dw BodySlamDescription
	dw WrapDescription
	dw TakeDownDescription
	dw ThrashDescription
	dw DoubleEdgeDescription
	dw TailWhipDescription
	dw PoisonStingDescription
	dw TwineedleDescription
	dw PinMissileDescription
	dw LeerDescription
	dw BiteDescription
	dw GrowlDescription
	dw RoarDescription
	dw SingDescription
	dw SupersonicDescription
	dw SonicboomDescription
	dw DisableDescription
	dw AcidDescription
	dw EmberDescription
	dw FlamethrowerDescription
	dw MistDescription
	dw WaterGunDescription
	dw HydroPumpDescription
	dw SurfDescription
	dw IceBeamDescription
	dw BlizzardDescription
	dw PsybeamDescription
	dw BubblebeamDescription
	dw AuroraBeamDescription
	dw HyperBeamDescription
	dw PeckDescription
	dw DrillPeckDescription
	dw SubmissionDescription
	dw LowKickDescription
	dw CounterDescription
	dw SeismicTossDescription
	dw StrengthDescription
	dw AbsorbDescription
	dw MegaDrainDescription
	dw LeechSeedDescription
	dw GrowthDescription
	dw RazorLeafDescription
	dw SolarbeamDescription
	dw PoisonpowderDescription
	dw StunSporeDescription
	dw SleepPowderDescription
	dw PetalDanceDescription
	dw StringShotDescription
	dw DragonRageDescription
	dw FireSpinDescription
	dw ThundershockDescription
	dw ThunderboltDescription
	dw ThunderWaveDescription
	dw ThunderDescription
	dw RockThrowDescription
	dw EarthquakeDescription
	dw FissureDescription
	dw DigDescription
	dw ToxicDescription
	dw ConfusionDescription
	dw PsychicMDescription
	dw HypnosisDescription
	dw MeditateDescription
	dw AgilityDescription
	dw QuickAttackDescription
	dw RageDescription
	dw TeleportDescription
	dw NightShadeDescription
	dw MimicDescription
	dw ScreechDescription
	dw DoubleTeamDescription
	dw RecoverDescription
	dw HardenDescription
	dw MinimizeDescription
	dw SmokescreenDescription
	dw ConfuseRayDescription
	dw WithdrawDescription
	dw DefenseCurlDescription
	dw BarrierDescription
	dw LightScreenDescription
	dw HazeDescription
	dw ReflectDescription
	dw FocusEnergyDescription
	dw BideDescription
	dw MetronomeDescription
	dw MirrorMoveDescription
	dw SelfdestructDescription
	dw EggBombDescription
	dw LickDescription
	dw SmogDescription
	dw SludgeDescription
	dw BoneClubDescription
	dw FireBlastDescription
	dw WaterfallDescription
	dw ClampDescription
	dw SwiftDescription
	dw SkullBashDescription
	dw SpikeCannonDescription
	dw ConstrictDescription
	dw AmnesiaDescription
	dw KinesisDescription
	dw SoftboiledDescription
	dw HiJumpKickDescription
	dw GlareDescription
	dw DreamEaterDescription
	dw PoisonGasDescription
	dw BarrageDescription
	dw LeechLifeDescription
	dw LovelyKissDescription
	dw SkyAttackDescription
	dw TransformDescription
	dw BubbleDescription
	dw DizzyPunchDescription
	dw SporeDescription
	dw FlashDescription
	dw PsywaveDescription
	dw SplashDescription
	dw AcidArmorDescription
	dw CrabhammerDescription
	dw ExplosionDescription
	dw FurySwipesDescription
	dw BonemerangDescription
	dw RestDescription
	dw RockSlideDescription
	dw HyperFangDescription
	dw SharpenDescription
	dw ConversionDescription
	dw TriAttackDescription
	dw SuperFangDescription
	dw SlashDescription
	dw SubstituteDescription
	dw StruggleDescription
	dw SketchDescription
	dw TripleKickDescription
	dw ThiefDescription
	dw SpiderWebDescription
	dw MindReaderDescription
	dw NightmareDescription
	dw FlameWheelDescription
	dw SnoreDescription
	dw CurseDescription
	dw FlailDescription
	dw Conversion2Description
	dw AeroblastDescription
	dw CottonSporeDescription
	dw ReversalDescription
	dw SpiteDescription
	dw PowderSnowDescription
	dw ProtectDescription
	dw MachPunchDescription
	dw ScaryFaceDescription
	dw FaintAttackDescription
	dw SweetKissDescription
	dw BellyDrumDescription
	dw SludgeBombDescription
	dw MudSlapDescription
	dw OctazookaDescription
	dw SpikesDescription
	dw ZapCannonDescription
	dw ForesightDescription
	dw DestinyBondDescription
	dw PerishSongDescription
	dw IcyWindDescription
	dw DetectDescription
	dw BoneRushDescription
	dw LockOnDescription
	dw OutrageDescription
	dw SandstormDescription
	dw GigaDrainDescription
	dw EndureDescription
	dw CharmDescription
	dw RolloutDescription
	dw FalseSwipeDescription
	dw SwaggerDescription
	dw MilkDrinkDescription
	dw SparkDescription
	dw FuryCutterDescription
	dw SteelWingDescription
	dw MeanLookDescription
	dw AttractDescription
	dw SleepTalkDescription
	dw HealBellDescription
	dw ReturnDescription
	dw PresentDescription
	dw FrustrationDescription
	dw SafeguardDescription
	dw PainSplitDescription
	dw SacredFireDescription
	dw MagnitudeDescription
	dw DynamicpunchDescription
	dw MegahornDescription
	dw DragonbreathDescription
	dw BatonPassDescription
	dw EncoreDescription
	dw PursuitDescription
	dw RapidSpinDescription
	dw SweetScentDescription
	dw IronTailDescription
	dw MetalClawDescription
	dw VitalThrowDescription
	dw MorningSunDescription
	dw SynthesisDescription
	dw MoonlightDescription
	dw HiddenPowerDescription
	dw CrossChopDescription
	dw TwisterDescription
	dw RainDanceDescription
	dw SunnyDayDescription
	dw CrunchDescription
	dw MirrorCoatDescription
	dw PsychUpDescription
	dw ExtremespeedDescription
	dw AncientpowerDescription
	dw ShadowBallDescription
	dw FutureSightDescription
	dw RockSmashDescription
	dw WhirlpoolDescription
	dw BeatUpDescription
	dw GigaHammerDescription
	dw DazzlingGleamDescription
	dw DisarmingVoiceDescription
	dw DrainingKissDescription
	dw PlayRoughDescription
	dw SpiritBreakDescription
	dw FairyWindDescription
	dw SuckerPunchDescription
	dw DarkPulseDescription
	dw FireFangDescription
	dw IceFangDescription
	dw ThunderFangDescription
	dw AquaJetDescription
	dw WildChargeDescription
	dw BitterBladeDescription
	dw HeatCrashDescription
	dw IceShardDescription
	dw TripleAxelDescription
	dw IcicleCrashDescription
	dw StruggleBugDescription
	dw InfestationDescription
	dw BugBuzzDescription
	dw AccelrockDescription
	dw StoneEdgeDescription
	dw AirSlashDescription
	dw PoisonFangDescription
	dw VenoshockDescription
	dw HailDescription
	dw LeafBladeDescription
	dw ShadowSneakDescription
	dw ShadowPunchDescription
	dw ShadowClawDescription
	dw PoisonJabDescription
	dw LungeDescription
	dw BugBiteDescription
	dw XScissorDescription
	dw UTurnDescription
	dw DragonClawDescription
	dw DracoMeteorDescription
	dw MoonblastDescription
	dw PixiePunchDescription
	dw BloodMoonDescription
	dw BulletPunchDescription
	dw DrainPunchDescription
	dw SolarBladeDescription
	dw CloseCombatDescription
	dw AcrobaticsDescription
	dw AerialAceDescription
	dw AquaTailDescription
	dw AstonishDescription
	dw AerialAceDescription
	dw AvalancheDescription
	dw BraveBirdDescription
	dw BulkUpDescription
	dw BulldozeDescription
	dw CalmMindDescription
	dw DragonDanceDescription
	dw DragonPulseDescription
	dw EarthPowerDescription
	dw EarthPowerDescription
	dw AstonishDescription
	dw FacadeDescription
	dw FlameChargeDescription
	dw BraveBirdDescription
	dw EarthPowerDescription
	dw EarthPowerDescription
	dw GigaImpactDescription
	dw GunkShotDescription
	dw GyroBallDescription
	dw HexDescription
	dw HoneClawsDescription
	dw HurricaneDescription
	dw HyperVoiceDescription
	dw IcicleSpearDescription
	dw AstonishDescription
	dw KnockOffDescription
	dw NastyPlotDescription
	dw NightSlashDescription
	dw PowerGemDescription
	dw PowerWhipDescription
	dw PsystrikeDescription
	dw RockBlastDescription
	dw RoostDescription
	dw ScaldDescription
	dw SeedBombDescription
	dw ShellSmashDescription
	dw SkillSwapDescription
	dw ToxicSpikesDescription
	dw TrickDescription
	dw TrickRoomDescription
	dw VoltSwitchDescription
	dw HurricaneDescription
	dw WillOWispDescription
	dw AstonishDescription
	dw TropKickDescription
	dw MortalSpinDescription
	dw FirstImpressionDescription
	dw LiquidationDescription
	dw SlackOffDescription
	dw VoltTackleDescription
	dw OverheatDescription
	dw LeafStormDescription
	dw FakeOutDescription
	dw FlipTurnDescription
	dw IronDefenseDescription
	dw RockPolishDescription
	dw WoodHammerDescription
	dw HeadSmashDescription
	dw DrillRunDescription
	dw PsychoCutDescription
	dw SacredSwordDescription
	dw BrickBreakDescription
	dw HeatWaveDescription
	dw SnarlDescription
	dw NuzzleDescription
	dw BulletSeedDescription
	dw DualWingbeatDescription
	dw RockTombDescription
	dw LowSweepDescription
	dw MudShotDescription
	dw AirCutterDescription
	dw CrossPoisonDescription
	dw MagicalLeafDescription
	dw SignalBeamDescription
	dw ScaleShotDescription
	dw PhantomForceDescription
	dw HeadlongRushDescription
	dw ShadowBoneDescription
	dw DireClawDescription
	dw BarbBarrageDescription
	dw InfernalParadeDescription
	dw KowtowCleaveDescription
	dw ArmorCannonDescription
	dw ShellSideArmDescription
	dw GlaiveRushDescription
	dw DragonDartsDescription
	dw AppleAcidDescription
	dw GravAppleDescription
	dw PsyshieldBashDescription
	dw RagingFuryDescription
	dw StrangeSteamDescription
	dw EerieSpellDescription
	dw BanefulBunkerDescription
	dw RagingBullDescription
	dw FickleBeamDescription
	dw StoneAxeDescription
	dw QuiverDanceDescription
	dw StealthRockDescription
	dw DefogDescription
	dw BodyPressDescription
	dw WorkUpDescription
	dw SuperpowerDescription
	dw FieryDanceDescription
	dw FoulPlayDescription
	dw RageFistDescription
	dw CrushClawDescription
	dw ForcePalmDescription
	dw HammerArmDescription
	dw CircleThrowDescription
	dw FreezeDryDescription
	dw BounceDescription
	dw DragonTailDescription
	dw LuminaCrashDescription
	dw TormentDescription
	dw TauntDescription
	dw YawnDescription
	dw WishDescription
	dw StickyWebDescription

InvalidMoveDescription:
	db "?@"

TropKickDescription:
	db   "Kicks up. Lowers"
	next "foe's ATTACK.@"

MortalSpinDescription:
	db   "Poisons foes and"
	next "frees the user.@"

FirstImpressionDescription:
	db   "Priority hit only"
	next "on the first turn.@"

LiquidationDescription:
	db   "A watery blow that"
	next "may lower DEFENSE.@"

SlackOffDescription:
	db   "Slacks off and re-"
	next "stores half of HP.@"

VoltTackleDescription:
	db   "Dangerous tackle"
	next "that hurts user.@"

OverheatDescription:
	db   "Huge blast. Cuts"
	next "own SPCL.ATK.@"

LeafStormDescription:
	db   "Leaf storm. Cuts"
	next "own SPCL.ATK.@"

FakeOutDescription:
	db   "1st-turn hit that"
	next "makes foe flinch.@"

FlipTurnDescription:
	db   "Switches out after"
	next "making its attack.@"

IronDefenseDescription:
	db   "Hardens body to"
	next "sharply up DEF.@"

RockPolishDescription:
	db   "Polishes body to"
	next "sharply up SPD.@"

WoodHammerDescription:
	db   "Timber slam that"
	next "hurts user too.@"

HeadSmashDescription:
	db   "Reckless headbutt"
	next "with awful recoil.@"

DrillRunDescription:
	db   "Drill stab. High"
	next "critical rate.@"

PsychoCutDescription:
	db   "Psychic blades."
	next "High crit rate.@"

SacredSwordDescription:
	db   "Slash that cuts"
	next "thru stat boosts.@"

BrickBreakDescription:
	db   "Attack that busts"
	next "barriers.@"

HeatWaveDescription:
	db   "Hot breath that"
	next "may cause a burn.@"

SnarlDescription:
	db   "Yelling that cuts"
	next "foe's SPCL.ATK.@"

NuzzleDescription:
	db   "Cheek rub that al-"
	next "ways paralyzes.@"

BulletSeedDescription:
	db   "Fires seeds in a"
	next "row 2-5 times.@"

DualWingbeatDescription:
	db   "Slams the foe with"
	next "wings, twice.@"

RockTombDescription:
	db   "Drops rocks that"
	next "cut the foe's SPD.@"

LowSweepDescription:
	db   "A swift kick that"
	next "cuts foe's SPEED.@"

MudShotDescription:
	db   "Mud blast that"
	next "cuts foe's SPEED.@"

AirCutterDescription:
	db   "Razor wind. High"
	next "critical rate.@"

CrossPoisonDescription:
	db   "High-crit slash"
	next "that may poison.@"

MagicalLeafDescription:
	db   "Homing leaves that"
	next "never miss.@"

SignalBeamDescription:
	db   "Odd beam that may"
	next "confuse the foe.@"

ScaleShotDescription:
	db   "2-5 hits. Ups SPD,"
	next "cuts DEFENSE.@"

PhantomForceDescription:
	db   "Vanishes, then"
	next "hits thru PROTECT.@"

PoundDescription:
	db   "Pounds with fore-"
	next "legs or tail.@"

KarateChopDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

DoubleslapDescription:
	db   "Repeatedly slaps"
	next "2-5 times.@"

CometPunchDescription:
	db   "Repeatedly punches"
	next "2-5 times.@"

MegaPunchDescription:
	db   "A powerful punch"
	next "thrown very hard.@"

PayDayDescription:
	db   "Throws coins. Gets"
	next "them back later.@"

FirePunchDescription:
	db   "A fiery punch. May"
	next "cause a burn.@"

IcePunchDescription:
	db   "An icy punch. May"
	next "cause freezing.@"

ThunderpunchDescription:
	db   "An electric punch."
	next "It may paralyze.@"

ScratchDescription:
	db   "Scratches with"
	next "sharp claws.@"

VicegripDescription:
	db   "Grips with power-"
	next "ful pincers.@"

GuillotineDescription:
	db   "A one-hit KO,"
	next "pincer attack.@"

RazorWindDescription:
	db   "1st turn: Prepare"
	next "2nd turn: Attack@"

SwordsDanceDescription:
	db   "A dance that in-"
	next "creases ATTACK.@"

CutDescription:
	db   "Cuts using claws,"
	next "scythes, etc.@"

GustDescription:
	db   "Whips up a strong"
	next "gust of wind.@"

WingAttackDescription:
	db   "Strikes the target"
	next "with wings.@"

WhirlwindDescription:
	db   "Blows away the foe"
	next "& ends battle.@"

FlyDescription:
	db   "1st turn: Fly"
	next "2nd turn: Attack@"

BindDescription:
	db   "Binds the target"
	next "for 2-5 turns.@"

SlamDescription:
	db   "Slams the foe with"
	next "a tail, vine, etc.@"

VineWhipDescription:
	db   "Whips the foe with"
	next "slender vines.@"

StompDescription:
	db   "An attack that may"
	next "cause flinching.@"

DoubleKickDescription:
	db   "A double kicking"
	next "attack.@"

MegaKickDescription:
	db   "A powerful kicking"
	next "attack.@"

JumpKickDescription:
	db   "May miss, damaging"
	next "the user.@"

RollingKickDescription:
	db   "A fast, spinning"
	next "kick.@"

SandAttackDescription:
	db   "Reduces accuracy"
	next "by throwing sand.@"

HeadbuttDescription:
	db   "An attack that may"
	next "make foe flinch.@"

HornAttackDescription:
	db   "An attack using a"
	next "horn to jab.@"

FuryAttackDescription:
	db   "Jabs the target"
	next "2-5 times.@"

HornDrillDescription:
	db   "A one-hit KO,"
	next "drill attack.@"

TackleDescription:
	db   "A full-body charge"
	next "attack.@"

BodySlamDescription:
	db   "An attack that may"
	next "cause paralysis.@"

WrapDescription:
	db   "Squeezes the foe"
	next "for 2-5 turns.@"

TakeDownDescription:
	db   "A tackle that also"
	next "hurts the user.@"

ThrashDescription:
	db   "Works 2-3 turns"
	next "and confuses user.@"

DoubleEdgeDescription:
	db   "A tackle that also"
	next "hurts the user.@"

TailWhipDescription:
	db   "Lowers the foe's"
	next "DEFENSE.@"

PoisonStingDescription:
	db   "An attack that may"
	next "poison the target.@"

TwineedleDescription:
	db   "Jabs the foe twice"
	next "using stingers.@"

PinMissileDescription:
	db   "Fires pins that"
	next "strike 2-5 times.@"

LeerDescription:
	db   "Reduces the foe's"
	next "DEFENSE.@"

BiteDescription:
	db   "An attack that may"
	next "cause flinching.@"

GrowlDescription:
	db   "Reduces the foe's"
	next "ATTACK.@"

RoarDescription:
	db   "Scares wild foes"
	next "to end battle.@"

SingDescription:
	db   "May cause the foe"
	next "to fall asleep.@"

SupersonicDescription:
	db   "Sound waves that"
	next "cause confusion.@"

SonicboomDescription:
	db   "Always inflicts"
	next "20HP damage.@"

DisableDescription:
	db   "Disables the foe's"
	next "most recent move.@"

AcidDescription:
	db   "An attack that may"
	next "lower DEFENSE.@"

EmberDescription:
	db   "An attack that may"
	next "inflict a burn.@"

FlamethrowerDescription:
	db   "An attack that may"
	next "inflict a burn.@"

MistDescription:
	db   "Prevents stat"
	next "reduction.@"

WaterGunDescription:
	db   "Squirts water to"
	next "attack.@"

HydroPumpDescription:
	db   "A powerful water-"
	next "type attack.@"

SurfDescription:
	db   "A strong water-"
	next "type attack.@"

IceBeamDescription:
	db   "An attack that may"
	next "freeze the foe.@"

BlizzardDescription:
	db   "An attack that may"
	next "freeze the foe.@"

PsybeamDescription:
	db   "An attack that may"
	next "confuse the foe.@"

BubblebeamDescription:
	db   "An attack that may"
	next "lower SPEED.@"

AuroraBeamDescription:
	db   "An attack that may"
	next "lower ATTACK.@"

HyperBeamDescription:
	db   "1st turn: Attack"
	next "2nd turn: Rest@"

PeckDescription:
	db   "Jabs the foe with"
	next "a beak, etc.@"

DrillPeckDescription:
	db   "A strong, spin-"
	next "ning-peck attack.@"

SubmissionDescription:
	db   "An attack that al-"
	next "so hurts the user.@"

LowKickDescription:
	db   "An attack that may"
	next "cause flinching.@"

CounterDescription:
	db   "Returns a physical"
	next "blow double.@"

SeismicTossDescription:
	db   "The user's level"
	next "equals damage HP.@"

StrengthDescription:
	db   "A powerful physi-"
	next "cal attack.@"

AbsorbDescription:
	db   "Steals 1/2 of the"
	next "damage inflicted.@"

MegaDrainDescription:
	db   "Steals 1/2 of the"
	next "damage inflicted.@"

LeechSeedDescription:
	db   "Steals HP from the"
	next "foe on every turn.@"

GrowthDescription:
	db   "Raises the SPCL."
	next "ATK rating.@"

RazorLeafDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

SolarbeamDescription:
	db   "1st turn: Prepare"
	next "2nd turn: Attack@"

PoisonpowderDescription:
	db   "A move that may"
	next "poison the foe.@"

StunSporeDescription:
	db   "A move that may"
	next "paralyze the foe.@"

SleepPowderDescription:
	db   "May cause the foe"
	next "to fall asleep.@"

PetalDanceDescription:
	db   "Works 2-3 turns"
	next "and confuses user.@"

StringShotDescription:
	db   "A move that lowers"
	next "the foe's SPEED.@"

DragonRageDescription:
	db   "Always inflicts"
	next "40HP damage.@"

FireSpinDescription:
	db   "Traps foe in fire"
	next "for 2-5 turns.@"

ThundershockDescription:
	db   "An attack that may"
	next "cause paralysis.@"

ThunderboltDescription:
	db   "An attack that may"
	next "cause paralysis.@"

ThunderWaveDescription:
	db   "A move that may"
	next "cause paralysis.@"

ThunderDescription:
	db   "An attack that may"
	next "cause paralysis.@"

RockThrowDescription:
	db   "Drops rocks on the"
	next "enemy.@"

EarthquakeDescription:
	db   "Tough but useless"
	next "vs. flying foes.@"

FissureDescription:
	db   "A ground-type,"
	next "one-hit KO attack.@"

DigDescription:
	db   "1st turn: Burrow"
	next "2nd turn: Attack@"

ToxicDescription:
	db   "A poison move with"
	next "increasing damage.@"

ConfusionDescription:
	db   "An attack that may"
	next "cause confusion.@"

PsychicMDescription:
	db   "An attack that may"
	next "lower SPCL.DEF.@"

HypnosisDescription:
	db   "May put the foe to"
	next "sleep.@"

MeditateDescription:
	db   "Raises the user's"
	next "ATTACK.@"

AgilityDescription:
	db   "Sharply increases"
	next "the user's SPEED.@"

QuickAttackDescription:
	db   "Lets the user get"
	next "in the first hit.@"

RageDescription:
	db   "Raises ATTACK if"
	next "the user is hit.@"

TeleportDescription:
	db   "A move for fleeing"
	next "from battle.@"

NightShadeDescription:
	db   "The user's level"
	next "equals damage HP.@"

MimicDescription:
	db   "Copies a move used"
	next "by the foe.@"

ScreechDescription:
	db   "Sharply reduces"
	next "the foe's DEFENSE.@"

DoubleTeamDescription:
	db   "Heightens evasive-"
	next "ness.@"

RecoverDescription:
	db   "Restores HP by 1/2"
	next "the max HP.@"

HardenDescription:
	db   "Raises the user's"
	next "DEFENSE.@"

MinimizeDescription:
	db   "Heightens evasive-"
	next "ness.@"

SmokescreenDescription:
	db   "Lowers the foe's"
	next "accuracy.@"

ConfuseRayDescription:
	db   "A move that causes"
	next "confusion.@"

WithdrawDescription:
	db   "Heightens the"
	next "user's DEFENSE.@"

DefenseCurlDescription:
	db   "Heightens the"
	next "user's DEFENSE.@"

BarrierDescription:
	db   "Sharply increases"
	next "user's DEFENSE.@"

LightScreenDescription:
	db   "Ups SPCL.DEF with"
	next "a wall of light.@"

HazeDescription:
	db   "Eliminates all"
	next "stat changes.@"

ReflectDescription:
	db   "Raises DEFENSE"
	next "with a barrier.@"

FocusEnergyDescription:
	db   "Raises the criti-"
	next "cal hit ratio.@"

BideDescription:
	db   "Waits 2-3 turns &"
	next "hits back double.@"

MetronomeDescription:
	db   "Randomly uses any"
	next "#MON move.@"

MirrorMoveDescription:
	db   "Counters with the"
	next "same move.@"

SelfdestructDescription:
	db   "Powerful but makes"
	next "the user faint.@"

EggBombDescription:
	db   "Eggs are hurled at"
	next "the foe.@"

LickDescription:
	db   "An attack that may"
	next "cause paralysis.@"

SmogDescription:
	db   "An attack that may"
	next "poison the foe.@"

SludgeDescription:
	db   "An attack that may"
	next "poison the foe.@"

BoneClubDescription:
	db   "An attack that may"
	next "cause flinching.@"

FireBlastDescription:
	db   "An attack that"
	next "may cause a burn.@"

WaterfallDescription:
	db   "An aquatic charge"
	next "attack.@"

ClampDescription:
	db   "Traps the foe for"
	next "2-5 turns.@"

SwiftDescription:
	db   "An attack that"
	next "never misses.@"

SkullBashDescription:
	db   "1st turn: Prepare"
	next "2nd turn: Attack@"

SpikeCannonDescription:
	db   "Fires spikes to"
	next "hit 2-5 times.@"

ConstrictDescription:
	db   "An attack that may"
	next "lower SPEED.@"

AmnesiaDescription:
	db   "Sharply raises the"
	next "user's SPCL.DEF.@"

KinesisDescription:
	db   "Reduces the foe's"
	next "accuracy.@"

SoftboiledDescription:
	db   "Restores HP by 1/2"
	next "the user's max HP.@"

HiJumpKickDescription:
	db   "May miss and hurt"
	next "the user.@"

GlareDescription:
	db   "A move that may"
	next "cause paralysis.@"

DreamEaterDescription:
	db   "Steals HP from a"
	next "sleeping victim.@"

PoisonGasDescription:
	db   "A move that may"
	next "poison the foe.@"

BarrageDescription:
	db   "Throws orbs to hit"
	next "2-5 times.@"

LeechLifeDescription:
	db   "Steals 1/2 of the"
	next "damage inflicted.@"

LovelyKissDescription:
	db   "May cause the foe"
	next "to fall asleep.@"

SkyAttackDescription:
	db   "1st turn: Prepare"
	next "2nd turn: Attack@"

TransformDescription:
	db   "The user assumes"
	next "the foe's guise.@"

BubbleDescription:
	db   "An attack that may"
	next "reduce SPEED.@"

DizzyPunchDescription:
	db   "An attack that may"
	next "cause confusion.@"

SporeDescription:
	db   "A move that"
	next "induces sleep.@"

FlashDescription:
	db   "Blinds the foe to"
	next "reduce accuracy.@"

PsywaveDescription:
	db   "An attack with"
	next "variable power.@"

SplashDescription:
	db   "Has no effect"
	next "whatsoever.@"

AcidArmorDescription:
	db   "Sharply raises the"
	next "user's DEFENSE.@"

CrabhammerDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

ExplosionDescription:
	db   "Very powerful but"
	next "makes user faint.@"

FurySwipesDescription:
	db   "Quickly scratches"
	next "2-5 times.@"

BonemerangDescription:
	db   "An attack that"
	next "strikes twice.@"

RestDescription:
	db   "Sleep for 2 turns"
	next "to fully recover.@"

RockSlideDescription:
	db   "An attack that may"
	next "cause flinching.@"

HyperFangDescription:
	db   "An attack that may"
	next "cause flinching.@"

SharpenDescription:
	db   "A move that raises"
	next "the user's ATTACK.@"

ConversionDescription:
	db   "Change user's type"
	next "to a move's type.@"

TriAttackDescription:
	db   "Fires three kinds"
	next "of beams at once.@"

SuperFangDescription:
	db   "Cuts the foe's HP"
	next "by 1/2.@"

SlashDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

SubstituteDescription:
	db   "Makes a decoy with"
	next "1/4 user's max HP.@"

StruggleDescription:
	db   "Used only if all"
	next "PP are exhausted.@"

SketchDescription:
	db   "Copies the foe's"
	next "move permanently.@"

TripleKickDescription:
	db   "Hits three times"
	next "with rising power.@"

ThiefDescription:
	db   "An attack that may"
	next "steal a held item.@"

SpiderWebDescription:
	db   "Prevents fleeing"
	next "or switching.@"

MindReaderDescription:
	db   "Ensures the next"
	next "attack will hit.@"

NightmareDescription:
	db   "A sleeper loses"
	next "1/4 HP every turn.@"

FlameWheelDescription:
	db   "An attack that may"
	next "cause a burn.@"

SnoreDescription:
	db   "An attack useable"
	next "only while asleep.@"

CurseDescription:
	db   "Works differently"
	next "for ghost-types.@"

FlailDescription:
	db   "Stronger if the"
	next "user's HP is low.@"

Conversion2Description:
	db   "The user's type is"
	next "made resistant.@"

AeroblastDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

CottonSporeDescription:
	db   "Sharply reduces"
	next "the foe's SPEED.@"

ReversalDescription:
	db   "Stronger if the"
	next "user's HP is low.@"

SpiteDescription:
	db   "Cuts the PP of the"
	next "foe's last move.@"

PowderSnowDescription:
	db   "An attack that may"
	next "cause freezing.@"

ProtectDescription:
	db   "Foils attack that"
	next "turn. It may fail.@"

MachPunchDescription:
	db   "A fast punch that"
	next "lands first.@"

ScaryFaceDescription:
	db   "Sharply reduces"
	next "the foe's SPEED.@"

FaintAttackDescription:
	db   "An attack that"
	next "never misses.@"

SweetKissDescription:
	db   "A move that causes"
	next "confusion.@"

BellyDrumDescription:
	db   "Reduces own HP to"
	next "maximize ATTACK.@"

SludgeBombDescription:
	db   "An attack that may"
	next "poison the foe.@"

MudSlapDescription:
	db   "Reduces the foe's"
	next "accuracy.@"

OctazookaDescription:
	db   "An attack that may"
	next "reduce accuracy.@"

SpikesDescription:
	db   "Hurts foes when"
	next "they switch out.@"

ZapCannonDescription:
	db   "An attack that"
	next "always paralyzes.@"

ForesightDescription:
	db   "Negates accuracy"
	next "reduction moves.@"

DestinyBondDescription:
	db   "The foe faints if"
	next "the user does.@"

PerishSongDescription:
	db   "Both user and foe"
	next "faint in 3 turns.@"

IcyWindDescription:
	db   "An icy attack that"
	next "lowers SPEED.@"

DetectDescription:
	db   "Evades attack that"
	next "turn. It may fail.@"

BoneRushDescription:
	db   "An attack that"
	next "hits 2-5 times.@"

LockOnDescription:
	db   "Ensures the next"
	next "attack will hit.@"

OutrageDescription:
	db   "Works 2-3 turns"
	next "and confuses user.@"

SandstormDescription:
	db   "Inflicts damage"
	next "every turn.@"

GigaDrainDescription:
	db   "Steals 1/2 of the"
	next "damage inflicted.@"

EndureDescription:
	db   "Always leaves at"
	next "least 1HP.@"

CharmDescription:
	db   "Sharply lowers the"
	next "foe's ATTACK.@"

RolloutDescription:
	db   "Attacks 5 turns"
	next "with rising power.@"

FalseSwipeDescription:
	db   "Leaves the foe"
	next "with at least 1HP.@"

SwaggerDescription:
	db   "Causes confusion"
	next "and raises ATTACK.@"

MilkDrinkDescription:
	db   "Restores HP by 1/2"
	next "the max HP.@"

SparkDescription:
	db   "An attack that may"
	next "cause paralysis.@"

FuryCutterDescription:
	db   "Successive hits"
	next "raise power.@"

SteelWingDescription:
	db   "Stiff wings strike"
	next "the foe.@"

MeanLookDescription:
	db   "Prevents fleeing"
	next "or switching.@"

AttractDescription:
	db   "Makes the opposite"
	next "gender infatuated.@"

SleepTalkDescription:
	db   "Randomly attacks"
	next "while asleep.@"

HealBellDescription:
	db   "Eliminates all"
	next "status problems.@"

ReturnDescription:
	db   "An attack that is"
	next "based on loyalty.@"

PresentDescription:
	db   "A bomb that may"
	next "restore HP.@"

FrustrationDescription:
	db   "An attack based on"
	next "lack of loyalty.@"

SafeguardDescription:
	db   "Prevents all"
	next "status problems.@"

PainSplitDescription:
	db   "Adds user & foe's"
	next "HPs. Shares total.@"

SacredFireDescription:
	db   "An attack that may"
	next "inflict a burn.@"

MagnitudeDescription:
	db   "A ground attack"
	next "with random power.@"

DynamicpunchDescription:
	db   "An attack that"
	next "always confuses.@"

MegahornDescription:
	db   "A powerful charge"
	next "attack.@"

DragonbreathDescription:
	db   "A strong breath"
	next "attack.@"

BatonPassDescription:
	db   "Switches while"
	next "keeping effects.@"

EncoreDescription:
	db   "Makes the foe re-"
	next "peat 2-6 times.@"

PursuitDescription:
	db   "Heavily strikes"
	next "switching #MON.@"

RapidSpinDescription:
	db   "A high-speed"
	next "spinning attack.@"

SweetScentDescription:
	db   "Reduces the foe's"
	next "evasiveness.@"

IronTailDescription:
	db   "An attack that may"
	next "reduce DEFENSE.@"

MetalClawDescription:
	db   "An attack that may"
	next "up user's ATTACK.@"

VitalThrowDescription:
	db   "A 2nd-strike move"
	next "that never misses.@"

MorningSunDescription:
	db   "Restores HP"
	next "(varies by time).@"

SynthesisDescription:
	db   "Restores HP"
	next "(varies by time).@"

MoonlightDescription:
	db   "Restores HP"
	next "(varies by time).@"

HiddenPowerDescription:
	db   "The power varies"
	next "with the #MON.@"

CrossChopDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

TwisterDescription:
	db   "Whips up a tornado"
	next "to attack.@"

RainDanceDescription:
	db   "Boosts water-type"
	next "moves for 5 turns.@"

SunnyDayDescription:
	db   "Boosts fire-type"
	next "moves for 5 turns.@"

CrunchDescription:
	db   "An attack that may"
	next "lower SPCL.DEF.@"

MirrorCoatDescription:
	db   "Counters a SPCL."
	next "ATK move double.@"

PsychUpDescription:
	db   "Copies the foe's"
	next "stat changes.@"

ExtremespeedDescription:
	db   "A powerful first-"
	next "strike move.@"

AncientpowerDescription:
	db   "An attack that may"
	next "raise all stats.@"

ShadowBallDescription:
	db   "An attack that may"
	next "lower SPCL.DEF.@"

FutureSightDescription:
	db   "An attack that"
	next "hits on 3rd turn.@"

RockSmashDescription:
	db   "An attack that may"
	next "lower DEFENSE.@"

WhirlpoolDescription:
	db   "Traps the foe for"
	next "2-5 turns.@"

BeatUpDescription:
	db   "Party #MON join"
	next "in the attack.@"

GigaHammerDescription:
	db   "Can't be used"
	next "twice in a row.@"

DazzlingGleamDescription:
	db   "Fairy light hits"
	next "the target.@"

DisarmingVoiceDescription:
	db   "A cry that always"
	next "hits the target.@"

DrainingKissDescription:
	db   "A life-stealing"
	next "kiss heals user.@"

PlayRoughDescription:
	db   "Roughly attacks."
	next "May lower ATTACK.@"

SpiritBreakDescription:
	db   "Shatters spirit."
	next "Lowers SPCL.ATK.@"

FairyWindDescription:
	db   "A sparkling wind"
	next "hits the target.@"

SuckerPunchDescription:
	db   "A quick punch that"
	next "strikes first.@"

DarkPulseDescription:
	db   "An aura pulse may"
	next "cause flinching.@"

FireFangDescription:
	db   "A fiery bite. May"
	next "burn the target.@"

IceFangDescription:
	db   "An icy bite. May"
	next "freeze the target.@"

ThunderFangDescription:
	db   "A charged bite may"
	next "paralyze the foe.@"

AquaJetDescription:
	db   "A water jet that"
	next "strikes first.@"

WildChargeDescription:
	db   "An electric charge"
	next "that may paralyze.@"

BitterBladeDescription:
	db   "A life-stealing"
	next "fiery slash.@"

HeatCrashDescription:
	db   "A hot body slam"
	next "that may burn.@"

IceShardDescription:
	db   "Strikes first with"
	next "sharp ice.@"

TripleAxelDescription:
	db   "Hits 3 times with"
	next "rising power.@"

IcicleCrashDescription:
	db   "Hurls icicles. May"
	next "cause flinching.@"

StruggleBugDescription:
	db   "A weak bug wave."
	next "May lower SP.ATK.@"

InfestationDescription:
	db   "Swarming bugs may"
	next "poison the target.@"

BugBuzzDescription:
	db   "An attack that may"
	next "lower SPCL.DEF.@"

AccelrockDescription:
	db   "Strikes first with"
	next "a stone shard.@"

StoneEdgeDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

AirSlashDescription:
	db   "Wind blades may"
	next "cause flinching.@"

PoisonFangDescription:
	db   "A toxic bite may"
	next "badly poison.@"

VenoshockDescription:
	db   "Power doubles if"
	next "foe is poisoned.@"

HailDescription:
	db   "Summons a hail-"
	next "storm for 5 turns.@"

LeafBladeDescription:
	db   "A sharp leaf slash"
	next "High crit rate.@"

ShadowSneakDescription:
	db   "Extends a shadow"
	next "to strike first.@"

ShadowPunchDescription:
	db   "A shadowy punch"
	next "that never misses.@"

ShadowClawDescription:
	db   "A shadowy claw."
	next "High crit rate.@"

PoisonJabDescription:
	db   "A poisonous jab."
	next "May poison target.@"

LungeDescription:
	db   "A quick lunge"
	next "that hits first.@"

BugBiteDescription:
	db   "Bites the foe with"
	next "its sturdy jaws.@"

XScissorDescription:
	db   "Claws cross to cut"
	next "like scissors.@"

UTurnDescription:
	db   "Attacks, then"
	next "switches out.@"

DragonClawDescription:
	db   "Slashes the foe"
	next "with sharp claws.@"

DracoMeteorDescription:
	db   "Calls down comets."
	next "Harsh SP.ATK drop.@"

MoonblastDescription:
	db   "Moon power may"
	next "lower SP.ATK.@"

PixiePunchDescription:
	db   "A fairy punch may"
	next "lower SPEED.@"

BloodMoonDescription:
	db   "Can't be used"
	next "twice in a row.@"

BulletPunchDescription:
	db   "A bullet punch."
	next "It strikes first.@"

DrainPunchDescription:
	db   "A draining punch."
	next "Heals half damage.@"

SolarBladeDescription:
	db   "Charges to slash."
	next "No charge in sun.@"

CloseCombatDescription:
	db   "A fierce attack."
	next "Lowers DEF/SP.DEF.@"

AcrobaticsDescription:
	db   "Damage doubles if"
	next "user has no item.@"

AerialAceDescription:
	db   "An attack that"
	next "never misses.@"

AquaTailDescription:
	db   "Swings its tail"
	next "like a wave.@"

AstonishDescription:
	db   "An attack that may"
	next "cause flinching.@"

AvalancheDescription:
	db   "Damage doubles if"
	next "user is hit first.@"

BraveBirdDescription:
	db   "A charge that also"
	next "hurts the user.@"

BulkUpDescription:
	db   "Raises the user's"
	next "Atk and Def.@"

BulldozeDescription:
	db   "A Ground attack"
	next "that lowers Speed.@"

CalmMindDescription:
	db   "Raises the user's"
	next "Sp.Atk and Sp.Def.@"

DragonDanceDescription:
	db   "Raises the user's"
	next "Attack and Speed.@"

DragonPulseDescription:
	db   "Attacks foe with"
	next "a shock wave.@"

EarthPowerDescription:
	db   "An attack that may"
	next "lower Sp.Def.@"

FacadeDescription:
	db   "Double damage with"
	next "Psn, Brn, or Prz.@"

FlameChargeDescription:
	db   "An attack that may"
	next "up user's Speed.@"

GigaImpactDescription:
	db   "1st turn: Attack"
	next "2nd turn: Rest@"

GunkShotDescription:
	db   "An attack that may"
	next "poison the foe.@"

GyroBallDescription:
	db   "Does more damage"
	next "at lower speed.@"

HexDescription:
	db   "Damage doubles if"
	next "foe has status.@"

HoneClawsDescription:
	db   "Raises the user's"
	next "Atk and accuracy.@"

HurricaneDescription:
	db   "An attack that may"
	next "confuse the foe.@"

HyperVoiceDescription:
	db   "Attack the foe"
	next "with sound waves.@"

IcicleSpearDescription:
	db   "Fires icicles to"
	next "hit 2-5 times.@"

KnockOffDescription:
	db   "Slaps down the"
	next "foe's held item.@"

NastyPlotDescription:
	db   "Sharply raises the"
	next "user's Sp.Atk.@"

NightSlashDescription:
	db   "Has a high criti-"
	next "cal hit ratio.@"

PowerGemDescription:
	db   "Attacks with a"
	next "gem-light ray.@"

PowerWhipDescription:
	db   "A violent lash"
	next "attack.@"

PsystrikeDescription:
	db   "A wave that does"
	next "physical damage.@"

RockBlastDescription:
	db   "Hurls boulders to"
	next "hit 2-5 times.@"

RoostDescription:
	db   "Lands to restore"
	next "1/2 the max HP.@"

ScaldDescription:
	db   "An attack that may"
	next "inflict a burn.@"

SeedBombDescription:
	db   "Slams a barrage of"
	next "seeds at the foe.@"

ShellSmashDescription:
	db   "Lowers defenses,"
	next "raises offenses.@"

SkillSwapDescription:
	db   "Swaps abilities"
	next "with the foe.@"

ToxicSpikesDescription:
	db   "Poisons foes when"
	next "they switch in.@"

TrickDescription:
	db   "Swaps held items"
	next "with the foe.@"

TrickRoomDescription:
	db   "Slow #mon move"
	next "first for 5 turns.@"

VoltSwitchDescription:
	db   "Switches out after"
	next "making its attack.@"

WillOWispDescription:
	db   "A move that may"
	next "burn the foe.@"

HeadlongRushDescription:
	db   "Reckless charge"
	next "that cuts own DEF.@"

ShadowBoneDescription:
	db   "Spectral bone hit."
	next "May lower DEFENSE.@"

DireClawDescription:
	db   "May poison, numb"
	next "or drop asleep.@"

BarbBarrageDescription:
	db   "2x on poisoned"
	next "foes. May poison.@"

InfernalParadeDescription:
	db   "2x on statused"
	next "foes. May burn.@"

KowtowCleaveDescription:
	db   "A feinting slash"
	next "that never misses.@"

ArmorCannonDescription:
	db   "Fires own armor."
	next "Cuts own defenses.@"

ShellSideArmDescription:
	db   "Picks its stronger"
	next "mode. May poison.@"

GlaiveRushDescription:
	db   "All-out charge but"
	next "foe hits back 2x.@"

DragonDartsDescription:
	db   "Fires Dreepy darts"
	next "twice in a row.@"

AppleAcidDescription:
	db   "Sour acid that"
	next "cuts SPCL.DEF.@"

GravAppleDescription:
	db   "Dropped apple that"
	next "cuts foe DEFENSE.@"

PsyshieldBashDescription:
	db   "Barrier bash that"
	next "ups own DEFENSE.@"

RagingFuryDescription:
	db   "Rampages with fire"
	next "for 2-3 turns.@"

StrangeSteamDescription:
	db   "Odd steam that may"
	next "confuse the foe.@"

EerieSpellDescription:
	db   "Saps 3 PP from the"
	next "foe's last move.@"

BanefulBunkerDescription:
	db   "Protects, poisons"
	next "on contact.@"

RagingBullDescription:
	db   "A wild charge that"
	next "breaks barriers.@"

FickleBeamDescription:
	db   "Sometimes fires at"
	next "double power.@"

StoneAxeDescription:
	db   "Leaves floating"
	next "stones on hit.@"

QuiverDanceDescription:
	db   "Ups SPCL. stats"
	next "and SPEED.@"

StealthRockDescription:
	db   "Floating rocks"
	next "hurt switch-ins.@"

DefogDescription:
	db   "Clears hazards and"
	next "cuts foe evasion.@"

BodyPressDescription:
	db   "Attacks with its"
	next "DEFENSE stat.@"

WorkUpDescription:
	db   "Ups both ATTACK"
	next "and SPCL.ATK.@"

SuperpowerDescription:
	db   "Mighty blow that"
	next "cuts own ATK/DEF.@"

FieryDanceDescription:
	db   "Fire dance. May up"
	next "own SPCL.ATK.@"

FoulPlayDescription:
	db   "Uses the foe's own"
	next "ATTACK stat.@"

RageFistDescription:
	db   "Grows by 50 power"
	next "per hit taken.@"

CrushClawDescription:
	db   "Slashing claws."
	next "May lower DEFENSE.@"

ForcePalmDescription:
	db   "A blow that may"
	next "paralyze the foe.@"

HammerArmDescription:
	db   "Heavy blow that"
	next "cuts own SPEED.@"

CircleThrowDescription:
	db   "Throws the foe out"
	next "to force a switch.@"

FreezeDryDescription:
	db   "Freezes even WATER"
	next "types. May freeze.@"

BounceDescription:
	db   "Bounces up, hits"
	next "2nd turn. May par.@"

DragonTailDescription:
	db   "Bats the foe away"
	next "to force a switch.@"

LuminaCrashDescription:
	db   "Harsh light that"
	next "cuts SP.DEF by 2.@"

TormentDescription:
	db   "Bars using the"
	next "same move twice.@"

TauntDescription:
	db   "Goads the foe out"
	next "of status moves.@"

YawnDescription:
	db   "Makes the foe fall"
	next "asleep next turn.@"

WishDescription:
	db   "Heals the spot on"
	next "the next turn.@"

StickyWebDescription:
	db   "Web that slows"
	next "foes switching in.@"
