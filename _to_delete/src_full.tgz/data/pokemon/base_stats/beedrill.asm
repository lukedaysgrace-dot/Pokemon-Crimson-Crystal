	db 0 ; species ID placeholder

	db  65, 115,  40,  95,  40,  95
	;   hp  atk  def  spd  sat  sdf

	db BUG, POISON ; type
	db 45 ; catch rate
	db 198 ; base exp
	db NO_ITEM, POISON_BARB ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 15 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/beedrill/front.dimensions"
	abilities_for BEEDRILL, ADAPTABILITY, SNIPER, POISON_TOUCH
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_BUG, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, SWEET_SCENT, HYPER_BEAM, PROTECT, ENERGY_BALL, FACADE, RETURN, SWAGGER, KNOCK_OFF, SLUDGE_BOMB, SWIFT, REST, ATTRACT, BUG_BITE, CUT
	; end
