	db 0 ; species ID placeholder

	db 100, 115,  90,  65,  65,  90
	;  hp  atk  def  spd  sat  sdf

	db FIRE, BUG ; type
	db 75 ; catch rate
	db 184 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/centiskorch/front.dimensions"
	abilities_for CENTISKORCH, FLASH_FIRE, WHITE_SMOKE, FLAME_BODY
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_BUG, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, PROTECT, WILL_O_WISP, FACADE, RETURN, SWAGGER, KNOCK_OFF, REST, ATTRACT
	; end
