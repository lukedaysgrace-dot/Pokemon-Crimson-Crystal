	db 0 ; species ID placeholder

	db  42,  30,  38,  32,  30,  38
	;   hp  atk  def  spd  sat  sdf

	db GRASS, GRASS ; type
	db 235 ; catch rate
	db 42 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F100 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/bounsweet/front.dimensions"
	abilities_for BOUNSWEET, LEAF_GUARD, OBLIVIOUS, NO_ABILITY
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_PLANT, EGG_PLANT ; egg groups

	; tm/hm learnset
	tmhm TOXIC, HIDDEN_POWER, SUNNY_DAY, SWEET_SCENT, PROTECT, ENERGY_BALL, FACADE, SOLARBEAM, RETURN, SWAGGER, REST, ATTRACT, ZEN_HEADBUTT
	; end
