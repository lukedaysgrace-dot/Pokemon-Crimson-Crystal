; Per-species OVERWORLD icons (walking/follower sprites, daycare, etc).
; Each icon is 8 tiles (two 16x16 frames side by side in a 32x16 png).
; The in-menu party/PC icons use gfx/menu_icons.asm instead.
; Species without their own art yet fall back to the old class icons;
; to give one its own icon, add gfx/icons/<species>.png and update the
; INCBIN filename on its line below.

SECTION "Mon Icons 1", ROMX

BulbasaurIcon:   INCBIN "gfx/icons/bulbasaur.2bpp"
IvysaurIcon:     INCBIN "gfx/icons/ivysaur.2bpp"
VenusaurIcon:    INCBIN "gfx/icons/venusaur.2bpp"
CharmanderIcon:  INCBIN "gfx/icons/charmander.2bpp"
CharmeleonIcon:  INCBIN "gfx/icons/charmeleon.2bpp"
CharizardIcon:   INCBIN "gfx/icons/charizard.2bpp"
SquirtleIcon:    INCBIN "gfx/icons/squirtle.2bpp"
WartortleIcon:   INCBIN "gfx/icons/wartortle.2bpp"
BlastoiseIcon:   INCBIN "gfx/icons/blastoise.2bpp"
CaterpieIcon:    INCBIN "gfx/icons/caterpie.2bpp"
MetapodIcon:     INCBIN "gfx/icons/metapod.2bpp"
ButterfreeIcon:  INCBIN "gfx/icons/butterfree.2bpp"
WeedleIcon:      INCBIN "gfx/icons/weedle.2bpp"
KakunaIcon:      INCBIN "gfx/icons/kakuna.2bpp"
BeedrillIcon:    INCBIN "gfx/icons/beedrill.2bpp"
PidgeyIcon:      INCBIN "gfx/icons/pidgey.2bpp"
PidgeottoIcon:   INCBIN "gfx/icons/pidgeotto.2bpp"
PidgeotIcon:     INCBIN "gfx/icons/pidgeot.2bpp"
RattataIcon:     INCBIN "gfx/icons/rattata.2bpp"
RaticateIcon:    INCBIN "gfx/icons/raticate.2bpp"
SpearowIcon:     INCBIN "gfx/icons/spearow.2bpp"
FearowIcon:      INCBIN "gfx/icons/fearow.2bpp"
EkansIcon:       INCBIN "gfx/icons/ekans.2bpp"
ArbokIcon:       INCBIN "gfx/icons/arbok.2bpp"
PikachuIcon:     INCBIN "gfx/icons/pikachu.2bpp"
RaichuIcon:      INCBIN "gfx/icons/raichu.2bpp"
SandshrewIcon:   INCBIN "gfx/icons/sandshrew.2bpp"
SandslashIcon:   INCBIN "gfx/icons/sandslash.2bpp"
NidoranFIcon:    INCBIN "gfx/icons/nidoran_f.2bpp"
NidorinaIcon:    INCBIN "gfx/icons/nidorina.2bpp"
NidoqueenIcon:   INCBIN "gfx/icons/nidoqueen.2bpp"
NidoranMIcon:    INCBIN "gfx/icons/nidoran_m.2bpp"
NidorinoIcon:    INCBIN "gfx/icons/nidorino.2bpp"
NidokingIcon:    INCBIN "gfx/icons/nidoking.2bpp"
ClefairyIcon:    INCBIN "gfx/icons/clefairy.2bpp"
ClefableIcon:    INCBIN "gfx/icons/clefable.2bpp"
VulpixIcon:      INCBIN "gfx/icons/vulpix.2bpp"
NinetalesIcon:   INCBIN "gfx/icons/ninetales.2bpp"
JigglypuffIcon:  INCBIN "gfx/icons/jigglypuff.2bpp"
WigglytuffIcon:  INCBIN "gfx/icons/wigglytuff.2bpp"
ZubatIcon:       INCBIN "gfx/icons/zubat.2bpp"
GolbatIcon:      INCBIN "gfx/icons/golbat.2bpp"
OddishIcon:      INCBIN "gfx/icons/oddish.2bpp"
GloomIcon:       INCBIN "gfx/icons/gloom.2bpp"
VileplumeIcon:   INCBIN "gfx/icons/vileplume.2bpp"
ParasIcon:       INCBIN "gfx/icons/paras.2bpp"
ParasectIcon:    INCBIN "gfx/icons/parasect.2bpp"
VenonatIcon:     INCBIN "gfx/icons/venonat.2bpp"
VenomothIcon:    INCBIN "gfx/icons/venomoth.2bpp"
DiglettIcon:     INCBIN "gfx/icons/diglett.2bpp"
DugtrioIcon:     INCBIN "gfx/icons/dugtrio.2bpp"
MeowthIcon:      INCBIN "gfx/icons/meowth.2bpp"
PersianIcon:     INCBIN "gfx/icons/persian.2bpp"
PsyduckIcon:     INCBIN "gfx/icons/psyduck.2bpp"
GolduckIcon:     INCBIN "gfx/icons/golduck.2bpp"
MankeyIcon:      INCBIN "gfx/icons/mankey.2bpp"
PrimeapeIcon:    INCBIN "gfx/icons/primeape.2bpp"
GrowlitheIcon:   INCBIN "gfx/icons/growlithe.2bpp"
ArcanineIcon:    INCBIN "gfx/icons/arcanine.2bpp"
PoliwagIcon:     INCBIN "gfx/icons/poliwag.2bpp"

SECTION "Mon Icons 2", ROMX

PoliwhirlIcon:   INCBIN "gfx/icons/poliwhirl.2bpp"
PoliwrathIcon:   INCBIN "gfx/icons/poliwrath.2bpp"
AbraIcon:        INCBIN "gfx/icons/abra.2bpp"
KadabraIcon:     INCBIN "gfx/icons/kadabra.2bpp"
AlakazamIcon:    INCBIN "gfx/icons/alakazam.2bpp"
MachopIcon:      INCBIN "gfx/icons/machop.2bpp"
MachokeIcon:     INCBIN "gfx/icons/machoke.2bpp"
MachampIcon:     INCBIN "gfx/icons/machamp.2bpp"
BellsproutIcon:  INCBIN "gfx/icons/bellsprout.2bpp"
WeepinbellIcon:  INCBIN "gfx/icons/weepinbell.2bpp"
VictreebelIcon:  INCBIN "gfx/icons/victreebel.2bpp"
TentacoolIcon:   INCBIN "gfx/icons/tentacool.2bpp"
TentacruelIcon:  INCBIN "gfx/icons/tentacruel.2bpp"
GeodudeIcon:     INCBIN "gfx/icons/geodude.2bpp"
GravelerIcon:    INCBIN "gfx/icons/graveler.2bpp"
GolemIcon:       INCBIN "gfx/icons/golem.2bpp"
PonytaIcon:      INCBIN "gfx/icons/ponyta.2bpp"
RapidashIcon:    INCBIN "gfx/icons/rapidash.2bpp"
SlowpokeIcon:    INCBIN "gfx/icons/slowpoke.2bpp"
SlowbroIcon:     INCBIN "gfx/icons/slowbro.2bpp"
MagnemiteIcon:   INCBIN "gfx/icons/magnemite.2bpp"
MagnetonIcon:    INCBIN "gfx/icons/magneton.2bpp"
FarfetchDIcon: INCBIN "gfx/icons/farfetch_d.2bpp"
DoduoIcon:       INCBIN "gfx/icons/doduo.2bpp"
DodrioIcon:      INCBIN "gfx/icons/dodrio.2bpp"
SeelIcon:        INCBIN "gfx/icons/seel.2bpp"
DewgongIcon:     INCBIN "gfx/icons/dewgong.2bpp"
GrimerIcon:      INCBIN "gfx/icons/grimer.2bpp"
MukIcon:         INCBIN "gfx/icons/muk.2bpp"
ShellderIcon:    INCBIN "gfx/icons/shellder.2bpp"
CloysterIcon:    INCBIN "gfx/icons/cloyster.2bpp"
GastlyIcon:      INCBIN "gfx/icons/gastly.2bpp"
HaunterIcon:     INCBIN "gfx/icons/haunter.2bpp"
GengarIcon:      INCBIN "gfx/icons/gengar.2bpp"
OnixIcon:        INCBIN "gfx/icons/onix.2bpp"
DrowzeeIcon:     INCBIN "gfx/icons/drowzee.2bpp"
HypnoIcon:       INCBIN "gfx/icons/hypno.2bpp"
KrabbyIcon:      INCBIN "gfx/icons/krabby.2bpp"
KinglerIcon:     INCBIN "gfx/icons/kingler.2bpp"
VoltorbIcon:     INCBIN "gfx/icons/voltorb.2bpp"
ElectrodeIcon:   INCBIN "gfx/icons/electrode.2bpp"
ExeggcuteIcon:   INCBIN "gfx/icons/exeggcute.2bpp"
ExeggutorIcon:   INCBIN "gfx/icons/exeggutor.2bpp"
CuboneIcon:      INCBIN "gfx/icons/cubone.2bpp"
MarowakIcon:     INCBIN "gfx/icons/marowak.2bpp"
HitmonleeIcon:   INCBIN "gfx/icons/hitmonlee.2bpp"
HitmonchanIcon:  INCBIN "gfx/icons/hitmonchan.2bpp"
LickitungIcon:   INCBIN "gfx/icons/lickitung.2bpp"
KoffingIcon:     INCBIN "gfx/icons/koffing.2bpp"
WeezingIcon:     INCBIN "gfx/icons/weezing.2bpp"
RhyhornIcon:     INCBIN "gfx/icons/rhyhorn.2bpp"
RhydonIcon:      INCBIN "gfx/icons/rhydon.2bpp"
ChanseyIcon:     INCBIN "gfx/icons/chansey.2bpp"
TangelaIcon:     INCBIN "gfx/icons/tangela.2bpp"
KangaskhanIcon:  INCBIN "gfx/icons/kangaskhan.2bpp"
HorseaIcon:      INCBIN "gfx/icons/horsea.2bpp"
SeadraIcon:      INCBIN "gfx/icons/seadra.2bpp"
GoldeenIcon:     INCBIN "gfx/icons/goldeen.2bpp"
SeakingIcon:     INCBIN "gfx/icons/seaking.2bpp"
StaryuIcon:      INCBIN "gfx/icons/staryu.2bpp"

SECTION "Mon Icons 3", ROMX

StarmieIcon:     INCBIN "gfx/icons/starmie.2bpp"
MrMimeIcon: INCBIN "gfx/icons/mr__mime.2bpp"
ScytherIcon:     INCBIN "gfx/icons/scyther.2bpp"
JynxIcon:        INCBIN "gfx/icons/jynx.2bpp"
ElectabuzzIcon:  INCBIN "gfx/icons/electabuzz.2bpp"
MagmarIcon:      INCBIN "gfx/icons/magmar.2bpp"
PinsirIcon:      INCBIN "gfx/icons/pinsir.2bpp"
TaurosIcon:      INCBIN "gfx/icons/tauros.2bpp"
MagikarpIcon:    INCBIN "gfx/icons/magikarp.2bpp"
GyaradosIcon:    INCBIN "gfx/icons/gyarados.2bpp"
LaprasIcon:      INCBIN "gfx/icons/lapras.2bpp"
DittoIcon:       INCBIN "gfx/icons/ditto.2bpp"
EeveeIcon:       INCBIN "gfx/icons/eevee.2bpp"
VaporeonIcon:    INCBIN "gfx/icons/vaporeon.2bpp"
JolteonIcon:     INCBIN "gfx/icons/jolteon.2bpp"
FlareonIcon:     INCBIN "gfx/icons/flareon.2bpp"
PorygonIcon:     INCBIN "gfx/icons/porygon.2bpp"
OmanyteIcon:     INCBIN "gfx/icons/omanyte.2bpp"
OmastarIcon:     INCBIN "gfx/icons/omastar.2bpp"
KabutoIcon:      INCBIN "gfx/icons/kabuto.2bpp"
KabutopsIcon:    INCBIN "gfx/icons/kabutops.2bpp"
AerodactylIcon:  INCBIN "gfx/icons/aerodactyl.2bpp"
SnorlaxIcon:     INCBIN "gfx/icons/snorlax.2bpp"
ArticunoIcon:    INCBIN "gfx/icons/articuno.2bpp"
ZapdosIcon:      INCBIN "gfx/icons/zapdos.2bpp"
MoltresIcon:     INCBIN "gfx/icons/moltres.2bpp"
DratiniIcon:     INCBIN "gfx/icons/dratini.2bpp"
DragonairIcon:   INCBIN "gfx/icons/dragonair.2bpp"
DragoniteIcon:   INCBIN "gfx/icons/dragonite.2bpp"
MewtwoIcon:      INCBIN "gfx/icons/mewtwo.2bpp"
MewIcon:         INCBIN "gfx/icons/mew.2bpp"
ChikoritaIcon:   INCBIN "gfx/icons/chikorita.2bpp"
BayleefIcon:     INCBIN "gfx/icons/bayleef.2bpp"
MeganiumIcon:    INCBIN "gfx/icons/meganium.2bpp"
CyndaquilIcon:   INCBIN "gfx/icons/cyndaquil.2bpp"
QuilavaIcon:     INCBIN "gfx/icons/quilava.2bpp"
TyphlosionIcon:  INCBIN "gfx/icons/typhlosion.2bpp"
TotodileIcon:    INCBIN "gfx/icons/totodile.2bpp"
CroconawIcon:    INCBIN "gfx/icons/croconaw.2bpp"
FeraligatrIcon:  INCBIN "gfx/icons/feraligatr.2bpp"
SentretIcon:     INCBIN "gfx/icons/sentret.2bpp"
FurretIcon:      INCBIN "gfx/icons/furret.2bpp"
HoothootIcon:    INCBIN "gfx/icons/hoothoot.2bpp"
NoctowlIcon:     INCBIN "gfx/icons/noctowl.2bpp"
LedybaIcon:      INCBIN "gfx/icons/ledyba.2bpp"
LedianIcon:      INCBIN "gfx/icons/ledian.2bpp"
SpinarakIcon:    INCBIN "gfx/icons/spinarak.2bpp"
AriadosIcon:     INCBIN "gfx/icons/ariados.2bpp"
CrobatIcon:      INCBIN "gfx/icons/crobat.2bpp"
ChinchouIcon:    INCBIN "gfx/icons/chinchou.2bpp"
LanturnIcon:     INCBIN "gfx/icons/lanturn.2bpp"
PichuIcon:       INCBIN "gfx/icons/pichu.2bpp"
CleffaIcon:      INCBIN "gfx/icons/cleffa.2bpp"
IgglybuffIcon:   INCBIN "gfx/icons/igglybuff.2bpp"
TogepiIcon:      INCBIN "gfx/icons/togepi.2bpp"
TogeticIcon:     INCBIN "gfx/icons/togetic.2bpp"
NatuIcon:        INCBIN "gfx/icons/natu.2bpp"
XatuIcon:        INCBIN "gfx/icons/xatu.2bpp"
MareepIcon:      INCBIN "gfx/icons/mareep.2bpp"
FlaaffyIcon:     INCBIN "gfx/icons/flaaffy.2bpp"

SECTION "Mon Icons 4", ROMX

AmpharosIcon:    INCBIN "gfx/icons/ampharos.2bpp"
BellossomIcon:   INCBIN "gfx/icons/bellossom.2bpp"
MarillIcon:      INCBIN "gfx/icons/marill.2bpp"
AzumarillIcon:   INCBIN "gfx/icons/azumarill.2bpp"
SudowoodoIcon:   INCBIN "gfx/icons/sudowoodo.2bpp"
PolitoedIcon:    INCBIN "gfx/icons/politoed.2bpp"
HoppipIcon:      INCBIN "gfx/icons/hoppip.2bpp"
SkiploomIcon:    INCBIN "gfx/icons/skiploom.2bpp"
JumpluffIcon:    INCBIN "gfx/icons/jumpluff.2bpp"
AipomIcon:       INCBIN "gfx/icons/aipom.2bpp"
SunkernIcon:     INCBIN "gfx/icons/sunkern.2bpp"
SunfloraIcon:    INCBIN "gfx/icons/sunflora.2bpp"
YanmaIcon:       INCBIN "gfx/icons/yanma.2bpp"
WooperIcon:      INCBIN "gfx/icons/wooper.2bpp"
QuagsireIcon:    INCBIN "gfx/icons/quagsire.2bpp"
EspeonIcon:      INCBIN "gfx/icons/espeon.2bpp"
UmbreonIcon:     INCBIN "gfx/icons/umbreon.2bpp"
MurkrowIcon:     INCBIN "gfx/icons/murkrow.2bpp"
SlowkingIcon:    INCBIN "gfx/icons/slowking.2bpp"
MisdreavusIcon:  INCBIN "gfx/icons/misdreavus.2bpp"
UnownIcon:       INCBIN "gfx/icons/unown.2bpp"
WobbuffetIcon:   INCBIN "gfx/icons/wobbuffet.2bpp"
GirafarigIcon:   INCBIN "gfx/icons/girafarig.2bpp"
PinecoIcon:      INCBIN "gfx/icons/pineco.2bpp"
ForretressIcon:  INCBIN "gfx/icons/forretress.2bpp"
DunsparceIcon:   INCBIN "gfx/icons/dunsparce.2bpp"
GligarIcon:      INCBIN "gfx/icons/gligar.2bpp"
SteelixIcon:     INCBIN "gfx/icons/steelix.2bpp"
SnubbullIcon:    INCBIN "gfx/icons/snubbull.2bpp"
GranbullIcon:    INCBIN "gfx/icons/granbull.2bpp"
QwilfishIcon:    INCBIN "gfx/icons/qwilfish.2bpp"
ScizorIcon:      INCBIN "gfx/icons/scizor.2bpp"
ShuckleIcon:     INCBIN "gfx/icons/shuckle.2bpp"
HeracrossIcon:   INCBIN "gfx/icons/heracross.2bpp"
SneaselIcon:     INCBIN "gfx/icons/sneasel.2bpp"
TeddiursaIcon:   INCBIN "gfx/icons/teddiursa.2bpp"
UrsaringIcon:    INCBIN "gfx/icons/ursaring.2bpp"
SlugmaIcon:      INCBIN "gfx/icons/slugma.2bpp"
MagcargoIcon:    INCBIN "gfx/icons/magcargo.2bpp"
SwinubIcon:      INCBIN "gfx/icons/swinub.2bpp"
PiloswineIcon:   INCBIN "gfx/icons/piloswine.2bpp"
CorsolaIcon:     INCBIN "gfx/icons/corsola.2bpp"
RemoraidIcon:    INCBIN "gfx/icons/remoraid.2bpp"
OctilleryIcon:   INCBIN "gfx/icons/octillery.2bpp"
DelibirdIcon:    INCBIN "gfx/icons/delibird.2bpp"
MantineIcon:     INCBIN "gfx/icons/mantine.2bpp"
SkarmoryIcon:    INCBIN "gfx/icons/skarmory.2bpp"
HoundourIcon:    INCBIN "gfx/icons/houndour.2bpp"
HoundoomIcon:    INCBIN "gfx/icons/houndoom.2bpp"
KingdraIcon:     INCBIN "gfx/icons/kingdra.2bpp"
PhanpyIcon:      INCBIN "gfx/icons/phanpy.2bpp"
DonphanIcon:     INCBIN "gfx/icons/donphan.2bpp"
Porygon2Icon:    INCBIN "gfx/icons/porygon2.2bpp"
StantlerIcon:    INCBIN "gfx/icons/stantler.2bpp"
SmeargleIcon:    INCBIN "gfx/icons/smeargle.2bpp"
TyrogueIcon:     INCBIN "gfx/icons/tyrogue.2bpp"
HitmontopIcon:   INCBIN "gfx/icons/hitmontop.2bpp"
SmoochumIcon:    INCBIN "gfx/icons/smoochum.2bpp"
ElekidIcon:      INCBIN "gfx/icons/elekid.2bpp"
MagbyIcon:       INCBIN "gfx/icons/magby.2bpp"

SECTION "Mon Icons 5", ROMX

MiltankIcon:     INCBIN "gfx/icons/miltank.2bpp"
BlisseyIcon:     INCBIN "gfx/icons/blissey.2bpp"
RaikouIcon:      INCBIN "gfx/icons/raikou.2bpp"
EnteiIcon:       INCBIN "gfx/icons/entei.2bpp"
SuicuneIcon:     INCBIN "gfx/icons/suicune.2bpp"
LarvitarIcon:    INCBIN "gfx/icons/larvitar.2bpp"
PupitarIcon:     INCBIN "gfx/icons/pupitar.2bpp"
TyranitarIcon:   INCBIN "gfx/icons/tyranitar.2bpp"
LugiaIcon:       INCBIN "gfx/icons/lugia.2bpp"
HoOhIcon: INCBIN "gfx/icons/ho_oh.2bpp"
CelebiIcon:      INCBIN "gfx/icons/celebi.2bpp"
HonchkrowIcon:   INCBIN "gfx/icons/honchkrow.2bpp"
AmbipomIcon: INCBIN "gfx/icons/ambipom.2bpp"
AnnihilapeIcon:  INCBIN "gfx/icons/annihilape.2bpp"
BagonIcon:       INCBIN "gfx/icons/bagon.2bpp"
DrunsparceIcon: INCBIN "gfx/icons/drunsparce.2bpp"
ElectivireIcon:  INCBIN "gfx/icons/electivire.2bpp"
FarigirafIcon: INCBIN "gfx/icons/farigiraf.2bpp"
GardevoirIcon:   INCBIN "gfx/icons/gardevoir.2bpp"
GlaceonIcon:     INCBIN "gfx/icons/glaceon.2bpp"
GliscorIcon: INCBIN "gfx/icons/gliscor.2bpp"
KirliaIcon:      INCBIN "gfx/icons/kirlia.2bpp"
LeafeonIcon:     INCBIN "gfx/icons/leafeon.2bpp"
LickilickyIcon:  INCBIN "gfx/icons/lickilicky.2bpp"
MagmortarIcon:   INCBIN "gfx/icons/magmortar.2bpp"
MagnezoneIcon:   INCBIN "gfx/icons/magnezone.2bpp"
MamoswineIcon:   INCBIN "gfx/icons/mamoswine.2bpp"
MesmeriaIcon:    INCBIN "gfx/icons/mesmeria.2bpp"
MismagiusIcon:   INCBIN "gfx/icons/mismagius.2bpp"
PorygonZIcon:    INCBIN "gfx/icons/porygon_z.2bpp"
RaltsIcon:       INCBIN "gfx/icons/ralts.2bpp"
RhyperiorIcon:   INCBIN "gfx/icons/rhyperior.2bpp"
SalamenceIcon:   INCBIN "gfx/icons/salamence.2bpp"
ScolipedeIcon:   INCBIN "gfx/icons/scolipede.2bpp"
ShelgonIcon:     INCBIN "gfx/icons/shelgon.2bpp"
TangrowthIcon:   INCBIN "gfx/icons/tangrowth.2bpp"
TogekissIcon: INCBIN "gfx/icons/togekiss.2bpp"
UrsalunaIcon: INCBIN "gfx/icons/ursaluna.2bpp"
VenipedeIcon:    INCBIN "gfx/icons/venipede.2bpp"
WeavileIcon:     INCBIN "gfx/icons/weavile.2bpp"
WhirlipedeIcon:  INCBIN "gfx/icons/whirlipede.2bpp"
WyrdeerIcon: INCBIN "gfx/icons/wyrdeer.2bpp"
YanmegaIcon: INCBIN "gfx/icons/yanmega.2bpp"
LileepIcon:      INCBIN "gfx/icons/lileep.2bpp"
CradilyIcon:     INCBIN "gfx/icons/cradily.2bpp"
ArmaldoIcon:     INCBIN "gfx/icons/armaldo.2bpp"
GolettIcon:      INCBIN "gfx/icons/golett.2bpp"
GolurkIcon:      INCBIN "gfx/icons/golurk.2bpp"
DuskullIcon:     INCBIN "gfx/icons/duskull.2bpp"
DusclopsIcon:    INCBIN "gfx/icons/dusclops.2bpp"
DusknoirIcon:    INCBIN "gfx/icons/dusknoir.2bpp"
TimburrIcon:     INCBIN "gfx/icons/fighter.2bpp" ; TODO: gfx/icons/timburr.png
GurdurrIcon:     INCBIN "gfx/icons/fighter.2bpp" ; TODO: gfx/icons/gurdurr.png
ConkeldurrIcon:  INCBIN "gfx/icons/fighter.2bpp" ; TODO: gfx/icons/conkeldurr.png
LarvestaIcon:    INCBIN "gfx/icons/caterpillar.2bpp" ; TODO: gfx/icons/larvesta.png
VolcaronaIcon:   INCBIN "gfx/icons/moth.2bpp" ; TODO: gfx/icons/volcarona.png
DeinoIcon: INCBIN "gfx/icons/deino.2bpp"
ZweilousIcon: INCBIN "gfx/icons/zweilous.2bpp"
HydreigonIcon: INCBIN "gfx/icons/hydreigon.2bpp"
DreepyIcon:      INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/dreepy.png
DrakloakIcon:    INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/drakloak.png
DragapultIcon:   INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/dragapult.png
ImpidimpIcon:    INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/impidimp.png
MorgremIcon:     INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/morgrem.png
GrimmsnarlIcon:  INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/grimmsnarl.png
TinkatinkIcon:   INCBIN "gfx/icons/tinkatink.2bpp"
TinkatuffIcon:   INCBIN "gfx/icons/tinkatuff.2bpp"
TinkatonIcon:    INCBIN "gfx/icons/tinkaton.2bpp"
FrigibaxIcon:    INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/frigibax.png
ArctibaxIcon:    INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/arctibax.png
BaxcaliburIcon:  INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/baxcalibur.png
CharcadetIcon:   INCBIN "gfx/icons/charmander.2bpp" ; TODO: gfx/icons/charcadet.png
ArmarougeIcon:   INCBIN "gfx/icons/charmander.2bpp" ; TODO: gfx/icons/armarouge.png
CeruledgeIcon:   INCBIN "gfx/icons/charmander.2bpp" ; TODO: gfx/icons/ceruledge.png
SylveonIcon: INCBIN "gfx/icons/sylveon.2bpp"
RookideeIcon:    INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/rookidee.png
CorvisquireIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/corvisquire.png
CorviknightIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/corviknight.png
AbomasnowIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/abomasnow.png
AltariaIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/altaria.png
AnorithIcon: INCBIN "gfx/icons/anorith.2bpp" ; TODO: gfx/icons/anorith.png
ArchaludonIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/archaludon.png
BunearyIcon: INCBIN "gfx/icons/buneary.2bpp" ; TODO: gfx/icons/buneary.png
CentiskorchIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/centiskorch.png
CharjabugIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/charjabug.png
CroagunkIcon: INCBIN "gfx/icons/croagunk.2bpp" ; TODO: gfx/icons/croagunk.png
DrifblimIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/drifblim.png
DrifloonIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/drifloon.png
DrilburIcon: INCBIN "gfx/icons/drilbur.2bpp"
DuraludonIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/duraludon.png
ExcadrillIcon: INCBIN "gfx/icons/excadrill.2bpp"
FletchinderIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/fletchinder.png
FletchlingIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/fletchling.png
FlygonIcon: INCBIN "gfx/icons/dragonite.2bpp" ; TODO: gfx/icons/flygon.png
FroslassIcon: INCBIN "gfx/icons/froslass.2bpp"
GolisopodIcon: INCBIN "gfx/icons/golisopod.2bpp" ; TODO: gfx/icons/golisopod.png
GrubbinIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/grubbin.png
KingambitIcon: INCBIN "gfx/icons/humanshape.2bpp" ; TODO: gfx/icons/kingambit.png
LopunnyIcon: INCBIN "gfx/icons/lopunny.2bpp" ; TODO: gfx/icons/lopunny.png
OverqwilIcon: INCBIN "gfx/icons/overqwil.2bpp"
ScraftyIcon: INCBIN "gfx/icons/scrafty.2bpp"
ScraggyIcon: INCBIN "gfx/icons/scraggy.2bpp"
SealeoIcon: INCBIN "gfx/icons/seel.2bpp" ; TODO: gfx/icons/sealeo.png
SizzlipedeIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/sizzlipede.png
SnoruntIcon: INCBIN "gfx/icons/snorunt.2bpp"
SphealIcon: INCBIN "gfx/icons/seel.2bpp" ; TODO: gfx/icons/spheal.png
SwabluIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/swablu.png
TalonflameIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/talonflame.png
ToxicroakIcon: INCBIN "gfx/icons/toxicroak.2bpp" ; TODO: gfx/icons/toxicroak.png
TrapinchIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/trapinch.png
UrsalunabmIcon: INCBIN "gfx/icons/ursaring.2bpp" ; TODO: gfx/icons/ursalunabm.png
VibravaIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/vibrava.png
VikavoltIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/vikavolt.png
WalreinIcon: INCBIN "gfx/icons/dewgong.2bpp" ; TODO: gfx/icons/walrein.png
WimpodIcon: INCBIN "gfx/icons/wimpod.2bpp" ; TODO: gfx/icons/wimpod.png
TeddiursabmIcon: INCBIN "gfx/icons/teddiursa.2bpp"
UrsaringbmIcon: INCBIN "gfx/icons/ursaring.2bpp"

; These legacy class icons contain one 16x16 frame (four tiles). Followers
; always load two frames, so repeat the frame instead of reading through into
; whichever icon happens to be linked next.
PlantIcon:
	INCBIN "gfx/icons/plant.2bpp"
	INCBIN "gfx/icons/plant.2bpp"
QuadrupedIcon:
	INCBIN "gfx/icons/quadruped.2bpp"
	INCBIN "gfx/icons/quadruped.2bpp"


SECTION "Mon Icons 6", ROMX

AxewIcon: INCBIN "gfx/icons/axew.2bpp"
FraxureIcon: INCBIN "gfx/icons/fraxure.2bpp"
HaxorusIcon: INCBIN "gfx/icons/haxorus.2bpp"
CranidosIcon: INCBIN "gfx/icons/cranidos.2bpp"
RampardosIcon: INCBIN "gfx/icons/rampardos.2bpp"
ShieldonIcon: INCBIN "gfx/icons/shieldon.2bpp"
BastiodonIcon: INCBIN "gfx/icons/bastiodon.2bpp"
PawniardIcon: INCBIN "gfx/icons/pawniard.2bpp"
BisharpIcon: INCBIN "gfx/icons/bisharp.2bpp"
MimikyuIcon: INCBIN "gfx/icons/mimikyu.2bpp"
CursolaIcon: INCBIN "gfx/icons/cursola.2bpp"
MrRimeIcon: INCBIN "gfx/icons/mr__rime.2bpp"
SirfetchDIcon: INCBIN "gfx/icons/sirfetch_d.2bpp"
RioluIcon: INCBIN "gfx/icons/riolu.2bpp"
LucarioIcon: INCBIN "gfx/icons/lucario.2bpp"
TyruntIcon: INCBIN "gfx/icons/tyrunt.2bpp"
TyrantrumIcon: INCBIN "gfx/icons/tyrantrum.2bpp"
AmauraIcon: INCBIN "gfx/icons/amaura.2bpp"
AurorusIcon: INCBIN "gfx/icons/aurorus.2bpp"
MunchlaxIcon: INCBIN "gfx/icons/munchlax.2bpp"
TorkoalIcon:  INCBIN "gfx/icons/shell.2bpp" ; TODO: gfx/icons/torkoal.png



SECTION "Mon Icons 7", ROMX

RattataAlolanIcon: INCBIN "gfx/icons/rattata_alolan.2bpp"
RaticateAlolanIcon: INCBIN "gfx/icons/raticate_alolan.2bpp"
RaichuAlolanIcon: INCBIN "gfx/icons/raichu_alolan.2bpp"
SandshrewAlolanIcon: INCBIN "gfx/icons/sandshrew_alolan.2bpp"
SandslashAlolanIcon: INCBIN "gfx/icons/sandslash_alolan.2bpp"
VulpixAlolanIcon: INCBIN "gfx/icons/vulpix_alolan.2bpp"
NinetalesAlolanIcon: INCBIN "gfx/icons/ninetales_alolan.2bpp"
DiglettAlolanIcon: INCBIN "gfx/icons/diglett_alolan.2bpp"
DugtrioAlolanIcon: INCBIN "gfx/icons/dugtrio_alolan.2bpp"
MeowthAlolanIcon: INCBIN "gfx/icons/meowth_alolan.2bpp"
PersianAlolanIcon: INCBIN "gfx/icons/persian_alolan.2bpp"
GeodudeAlolanIcon: INCBIN "gfx/icons/geodude_alolan.2bpp"
GravelerAlolanIcon: INCBIN "gfx/icons/graveler_alolan.2bpp"
GolemAlolanIcon: INCBIN "gfx/icons/golem_alolan.2bpp"
GrimerAlolanIcon: INCBIN "gfx/icons/grimer_alolan.2bpp"
MukAlolanIcon: INCBIN "gfx/icons/muk_alolan.2bpp"
ExeggutorAlolanIcon: INCBIN "gfx/icons/exeggutor_alolan.2bpp"
MarowakAlolanIcon: INCBIN "gfx/icons/marowak_alolan.2bpp"
MeowthGalarianIcon: INCBIN "gfx/icons/meowth_galarian.2bpp"
PerrserkerIcon: INCBIN "gfx/icons/perrserker.2bpp"
PonytaGalarianIcon: INCBIN "gfx/icons/ponyta_galarian.2bpp"
RapidashGalarianIcon: INCBIN "gfx/icons/rapidash_galarian.2bpp"
SlowpokeGalarianIcon: INCBIN "gfx/icons/slowpoke_galarian.2bpp"
SlowbroGalarianIcon: INCBIN "gfx/icons/slowbro_galarian.2bpp"
WeezingGalarianIcon: INCBIN "gfx/icons/weezing_galarian.2bpp"
SlowkingGalarianIcon: INCBIN "gfx/icons/slowking_galarian.2bpp"
CorsolaGalarianIcon: INCBIN "gfx/icons/corsola_galarian.2bpp"
GrowlitheHisuianIcon: INCBIN "gfx/icons/growlithe_hisuian.2bpp"
ArcanineHisuianIcon: INCBIN "gfx/icons/arcanine_hisuian.2bpp"
VoltorbHisuianIcon: INCBIN "gfx/icons/voltorb_hisuian.2bpp"
ElectrodeHisuianIcon: INCBIN "gfx/icons/electrode_hisuian.2bpp"
TyphlosionHisuianIcon: INCBIN "gfx/icons/typhlosion_hisuian.2bpp"
SneaselHisuianIcon: INCBIN "gfx/icons/sneasel_hisuian.2bpp"
WooperPaldeanIcon: INCBIN "gfx/icons/wooper_paldean.2bpp"
ClodsireIcon: INCBIN "gfx/icons/clodsire.2bpp"
TaurosPaldeanFireIcon: INCBIN "gfx/icons/tauros_paldean_fire.2bpp"
TaurosPaldeanWaterIcon: INCBIN "gfx/icons/tauros_paldean_water.2bpp"
SneaslerIcon: INCBIN "gfx/icons/sneasler.2bpp"
WatuIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/watu.png
BounsweetIcon: INCBIN "gfx/icons/oddish.2bpp" ; TODO: gfx/icons/bounsweet.png
SteeneeIcon: INCBIN "gfx/icons/oddish.2bpp" ; TODO: gfx/icons/steenee.png
TsareenaIcon: INCBIN "gfx/icons/humanshape.2bpp" ; TODO: gfx/icons/tsareena.png
AronIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/aron.png
LaironIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/lairon.png
AggronIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/aggron.png
KleavorIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/kleavor.png
GlimmetIcon: INCBIN "gfx/icons/geodude.2bpp" ; TODO: gfx/icons/glimmet.png
MareanieIcon: INCBIN "gfx/icons/jellyfish.2bpp" ; TODO: gfx/icons/mareanie.png
ToxapexIcon: INCBIN "gfx/icons/jellyfish.2bpp" ; TODO: gfx/icons/toxapex.png
ZangooseIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/zangoose.png
SeviperIcon: INCBIN "gfx/icons/serpent.2bpp" ; TODO: gfx/icons/seviper.png
GlimmoraIcon: INCBIN "gfx/icons/geodude.2bpp" ; TODO: gfx/icons/glimmora.png

SECTION "Mon Icons 8", ROMX

ShuppetIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/shuppet.png
BanetteIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/banette.png
ArchenIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/archen.png
ArcheopsIcon: INCBIN "gfx/icons/bird.2bpp" ; TODO: gfx/icons/archeops.png
TirtougaIcon: INCBIN "gfx/icons/shell.2bpp" ; TODO: gfx/icons/tirtouga.png
CarracostaIcon: INCBIN "gfx/icons/shell.2bpp" ; TODO: gfx/icons/carracosta.png
LitwickIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/litwick.png
LampentIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/lampent.png
ChandelureIcon: INCBIN "gfx/icons/ghost.2bpp" ; TODO: gfx/icons/chandelure.png
JoltikIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/joltik.png
GalvantulaIcon: INCBIN "gfx/icons/bug.2bpp" ; TODO: gfx/icons/galvantula.png
MawileIcon: INCBIN "gfx/icons/monster.2bpp" ; TODO: gfx/icons/mawile.png
NoibatIcon: INCBIN "gfx/icons/bat.2bpp" ; TODO: gfx/icons/noibat.png
NoivernIcon: INCBIN "gfx/icons/bat.2bpp" ; TODO: gfx/icons/noivern.png
SalanditIcon: INCBIN "gfx/icons/serpent.2bpp" ; TODO: gfx/icons/salandit.png
SalazzleIcon: INCBIN "gfx/icons/serpent.2bpp" ; TODO: gfx/icons/salazzle.png
FlittleIcon: INCBIN "gfx/icons/flittle.2bpp"
EspathraIcon: INCBIN "gfx/icons/espathra.2bpp"
FinizenIcon: INCBIN "gfx/icons/fish.2bpp" ; TODO: gfx/icons/finizen.png
PalafinIcon: INCBIN "gfx/icons/dewgong.2bpp" ; TODO: gfx/icons/palafin.png

SECTION "Mon Icons 9", ROMX

AzurillIcon: INCBIN "gfx/icons/azurill.2bpp"
WynautIcon:  INCBIN "gfx/icons/wynaut.2bpp"
BonslyIcon:  INCBIN "gfx/icons/bonsly.2bpp"
MimeJrIcon:  INCBIN "gfx/icons/mime_jr_.2bpp"
HappinyIcon: INCBIN "gfx/icons/happiny.2bpp"
MantykeIcon: INCBIN "gfx/icons/mantyke.2bpp"

EggIcon:         INCBIN "gfx/icons/egg.2bpp"
