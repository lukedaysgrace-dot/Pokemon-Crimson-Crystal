	object_const_def ; object_event constants
	const TRADECENTER_GOLD1
	const TRADECENTER_GOLD2

TradeCenter_MapScripts:
	db 2 ; scene scripts
	scene_script .InitializeTradeCenter ; SCENE_DEFAULT
	scene_script .DummyScene ; SCENE_FINISHED

	db 1 ; callbacks
	callback MAPCALLBACK_OBJECTS, .SetWhichGold

.InitializeTradeCenter:
	prioritysjump .InitializeAndPreparePokecenter2F
	end

.DummyScene:
	end

.SetWhichGold:
	special CableClubCheckWhichPlayer
	iffalse .Gold2
	disappear TRADECENTER_GOLD2
	appear TRADECENTER_GOLD1
	return

.Gold2:
	disappear TRADECENTER_GOLD1
	appear TRADECENTER_GOLD2
	return

.InitializeAndPreparePokecenter2F:
	setscene SCENE_FINISHED
	setmapscene POKECENTER_2F, SCENE_POKECENTER2F_LEAVE_TRADE_CENTER
	end

TradeCenterConsoleScript:
	special TradeCenter
	newloadmap MAPSETUP_LINKRETURN
	end

TradeCenterFriendScript:
; unreferenced
	opentext
	writetext .FriendReadyText
	waitbutton
	closetext
	end

.FriendReadyText:
	text "Your friend is"
	line "ready."
	done

TradeCenter_MapEvents:
	db 0, 0 ; filler

	db 2 ; warp events
	warp_event  4,  7, POKECENTER_2F, 2
	warp_event  5,  7, POKECENTER_2F, 2

	db 0 ; coord events

	db 2 ; bg events
	bg_event  4,  4, BGEVENT_RIGHT, TradeCenterConsoleScript
	bg_event  5,  4, BGEVENT_LEFT, TradeCenterConsoleScript

	db 2 ; object events
	object_event  3,  4, SPRITE_GOLD, SPRITEMOVEDATA_STANDING_RIGHT, 0, 0, -1, -1, 0, OBJECTTYPE_SCRIPT, 0, CableClubFriendScript, EVENT_TEMPORARY_UNTIL_MAP_RELOAD_1
	object_event  6,  4, SPRITE_GOLD, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, 0, OBJECTTYPE_SCRIPT, 0, CableClubFriendScript, EVENT_TEMPORARY_UNTIL_MAP_RELOAD_2
