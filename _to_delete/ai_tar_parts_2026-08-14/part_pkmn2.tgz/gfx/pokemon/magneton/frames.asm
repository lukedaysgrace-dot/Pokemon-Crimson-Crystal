	dw .frame1
	dw .frame2
	dw .frame3
	dw .frame4
	dw .frame5
	dw .frame6
.frame1
	db $00 ; bitmask
	db $24, $25, $26, $27
.frame2
	db $01 ; bitmask
	db $28, $29, $2a, $2b
.frame3
	db $02 ; bitmask
	db $2c, $2d, $2e, $2f
.frame4
	db $03 ; bitmask
	db $30, $31
.frame5
	db $04 ; bitmask
	db $32, $33, $34, $35
.frame6
	db $05 ; bitmask
	db $36, $37, $38, $39
