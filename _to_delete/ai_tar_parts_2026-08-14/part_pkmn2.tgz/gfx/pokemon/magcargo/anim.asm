	setrepeat 2
	frame 1, 08
	frame 2, 08
	frame 3, 08
	frame 4, 08
	dorepeat 1
	frame 1, 08
	endanim
