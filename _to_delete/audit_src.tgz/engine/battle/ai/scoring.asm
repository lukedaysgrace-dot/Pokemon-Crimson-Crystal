AIScoring: ; used only for BANK(AIScoring)

AI_Basic:
; Don't do anything redundant:
;  -Using status-only moves if the player can't be statused
;  -Using moves that fail if they've already been used

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	ld c, a

; Dismiss moves with special effects if they are
; useless or not a good choice right now.
; For example, healing moves, weather moves, Dream Eater...
	push hl
	push de
	push bc
	farcall AI_Redundant
	pop bc
	pop de
	pop hl
	jr nz, .discourage

; Dismiss status-only moves if the player can't be statused.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	push hl
	push de
	push bc
	ld hl, StatusOnlyEffects
	ld de, 1
	call IsInArray

	pop bc
	pop de
	pop hl
	jr nc, .checkmove

	ld a, [wBattleMonStatus]
	and a
	jr nz, .discourage

; Dismiss Safeguard if it's already active...
	ld a, [wPlayerScreens]
	bit SCREENS_SAFEGUARD, a
	jr z, .checkmove
; ...unless our Infiltrator goes straight through it.
	call AIGetEnemyAbility
	cp INFILTRATOR
	jr z, .checkmove

.discourage
	call AIDiscourageMove
	jr .checkmove

INCLUDE "data/battle/ai/status_only_effects.asm"


AI_Setup:
; Use stat-modifying moves on turn 1.

; 50% chance to greatly encourage stat-up moves during the first turn of enemy's Pokemon.
; 50% chance to greatly encourage stat-down moves during the first turn of player's Pokemon.
; Almost 90% chance to greatly discourage stat-modifying moves otherwise.

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]

	cp EFFECT_ATTACK_UP
	jr c, .checkmove
	cp EFFECT_EVASION_UP + 1
	jr c, .statup

;	cp EFFECT_ATTACK_DOWN - 1
	jr z, .checkmove
	cp EFFECT_EVASION_DOWN + 1
	jr c, .statdown

	cp EFFECT_ATTACK_UP_2
	jr c, .checkmove
	cp EFFECT_EVASION_UP_2 + 1
	jr c, .statup

;	cp EFFECT_ATTACK_DOWN_2 - 1
	jr z, .checkmove
	cp EFFECT_EVASION_DOWN_2 + 1
	jr c, .statdown

; Newer setup effects are not contiguous; check them in a list.
	push hl
	push de
	push bc
	ld hl, .SetupEffects
	ld de, 1
	call IsInArray
	pop bc
	pop de
	pop hl
	jr c, .statup
	jr .checkmove

.SetupEffects:
; new-generation effects that raise the user's own stats
	db EFFECT_DEFENSE_CURL
	db EFFECT_BULK_UP
	db EFFECT_CALM_MIND
	db EFFECT_DRAGON_DANCE
	db EFFECT_HONE_CLAWS
	db EFFECT_SHELL_SMASH
	db EFFECT_QUIVER_DANCE
	db EFFECT_WORK_UP
	db -1 ; end

.statup
	ld a, [wEnemyTurnsTaken]
	and a
	jr nz, .discourage

; Don't waste a turn setting up while at low HP; attack instead.
	call AICheckEnemyHalfHP
	jr nc, .discourage

	jr .encourage

.statdown
	ld a, [wPlayerTurnsTaken]
	and a
	jr nz, .discourage

.encourage
	call AI_50_50
	jr c, .checkmove

	dec [hl]
	dec [hl]
	jr .checkmove

.discourage
	call BattleRandom
	cp 12 percent
	jr c, .checkmove
	inc [hl]
	inc [hl]
	jr .checkmove


AI_Types:
; Dismiss any move that the player is immune to.
; Encourage super-effective moves.
; Discourage not very effective moves unless
; all damaging moves are of the same type.

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	call AIGetEnemyMove

	push hl
	push bc
	push de
	ld a, 1
	ldh [hBattleTurn], a
	callfar BattleCheckTypeMatchup
	pop de
	pop bc
	pop hl

	ld a, [wTypeMatchup]
	and a
	jr z, .immune
	cp EFFECTIVE
	jr z, .checkmove
	jr c, .noteffective

; effective
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .checkmove
	dec [hl]
	jr .checkmove

.noteffective
; Discourage this move if there are any moves
; that do damage of a different type.
	push hl
	push de
	push bc
	ld a, [wEnemyMoveStruct + MOVE_TYPE]
	ld d, a
	ld hl, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
	ld c, 0
.checkmove2
	dec b
	jr z, .asm_38693

	ld a, [hli]
	and a
	jr z, .asm_38693

	call AIGetEnemyMove
	ld a, [wEnemyMoveStruct + MOVE_TYPE]
	cp d
	jr z, .checkmove2
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr nz, .asm_38692
	jr .checkmove2

.asm_38692
	ld c, a
.asm_38693
	ld a, c
	pop bc
	pop de
	pop hl
	and a
	jr z, .checkmove
	inc [hl]
	jr .checkmove

.immune
; Our Corrosion poisons Steel-types straight through the type immunity.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_TOXIC
	jr z, .poison_status
	cp EFFECT_POISON
	jr nz, .really_immune
.poison_status
	call AIGetEnemyAbility
	cp CORROSION
	jp z, .checkmove
.really_immune
	call AIDiscourageMove
	jp .checkmove


AI_Offensive:
; Greatly discourage non-damaging moves.

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr nz, .checkmove

	inc [hl]
	inc [hl]
	jr .checkmove


AI_Smart:
; Context-specific scoring.

	ld hl, wBuffer1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	ld a, [de]
	inc de
	and a
	ret z

	push de
	push bc
	push hl
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	ld hl, .table_386f2
	ld de, 3
	call IsInArray

	inc hl
	jr nc, .nextmove

	ld a, [hli]
	ld e, a
	ld d, [hl]

	pop hl
	push hl

	ld bc, .nextmove
	push bc

	push de
	ret

.nextmove
	pop hl
	pop bc
	pop de
	inc hl
	jr .checkmove

.table_386f2
	dbw EFFECT_SLEEP,            AI_Smart_Sleep
	dbw EFFECT_LEECH_HIT,        AI_Smart_LeechHit
	dbw EFFECT_SELFDESTRUCT,     AI_Smart_Selfdestruct
	dbw EFFECT_DREAM_EATER,      AI_Smart_DreamEater
	dbw EFFECT_MIRROR_MOVE,      AI_Smart_MirrorMove
	dbw EFFECT_EVASION_UP,       AI_Smart_EvasionUp
	dbw EFFECT_ALWAYS_HIT,       AI_Smart_AlwaysHit
	dbw EFFECT_ACCURACY_DOWN,    AI_Smart_AccuracyDown
	dbw EFFECT_RESET_STATS,      AI_Smart_ResetStats
	dbw EFFECT_BIDE,             AI_Smart_Bide
	dbw EFFECT_FORCE_SWITCH,     AI_Smart_ForceSwitch
	dbw EFFECT_HEAL,             AI_Smart_Heal
	dbw EFFECT_TOXIC,            AI_Smart_Toxic
	dbw EFFECT_LIGHT_SCREEN,     AI_Smart_LightScreen
	dbw EFFECT_OHKO,             AI_Smart_Ohko
	dbw EFFECT_RAZOR_WIND,       AI_Smart_RazorWind
	dbw EFFECT_SUPER_FANG,       AI_Smart_SuperFang
	dbw EFFECT_TRAP_TARGET,      AI_Smart_TrapTarget
	dbw EFFECT_UNUSED_2B,        AI_Smart_Unused2B
	dbw EFFECT_CONFUSE,          AI_Smart_Confuse
	dbw EFFECT_SP_DEF_UP_2,      AI_Smart_SpDefenseUp2
	dbw EFFECT_REFLECT,          AI_Smart_Reflect
	dbw EFFECT_PARALYZE,         AI_Smart_Paralyze
	dbw EFFECT_SPEED_DOWN_HIT,   AI_Smart_SpeedDownHit
	dbw EFFECT_SUBSTITUTE,       AI_Smart_Substitute
	dbw EFFECT_HYPER_BEAM,       AI_Smart_HyperBeam
	dbw EFFECT_RAGE,             AI_Smart_Rage
	dbw EFFECT_MIMIC,            AI_Smart_Mimic
	dbw EFFECT_LEECH_SEED,       AI_Smart_LeechSeed
	dbw EFFECT_DISABLE,          AI_Smart_Disable
	dbw EFFECT_COUNTER,          AI_Smart_Counter
	dbw EFFECT_ENCORE,           AI_Smart_Encore
	dbw EFFECT_PAIN_SPLIT,       AI_Smart_PainSplit
	dbw EFFECT_SNORE,            AI_Smart_Snore
	dbw EFFECT_CONVERSION2,      AI_Smart_Conversion2
	dbw EFFECT_LOCK_ON,          AI_Smart_LockOn
	dbw EFFECT_DEFROST_OPPONENT, AI_Smart_DefrostOpponent
	dbw EFFECT_SLEEP_TALK,       AI_Smart_SleepTalk
	dbw EFFECT_DESTINY_BOND,     AI_Smart_DestinyBond
	dbw EFFECT_REVERSAL,         AI_Smart_Reversal
	dbw EFFECT_SPITE,            AI_Smart_Spite
	dbw EFFECT_HEAL_BELL,        AI_Smart_HealBell
	dbw EFFECT_PRIORITY_HIT,     AI_Smart_PriorityHit
	dbw EFFECT_FIRST_IMPRESSION, AI_Smart_FirstImpression
	dbw EFFECT_THIEF,            AI_Smart_Thief
	dbw EFFECT_MEAN_LOOK,        AI_Smart_MeanLook
	dbw EFFECT_NIGHTMARE,        AI_Smart_Nightmare
	dbw EFFECT_FLAME_WHEEL,      AI_Smart_FlameWheel
	dbw EFFECT_CURSE,            AI_Smart_Curse
	dbw EFFECT_PROTECT,          AI_Smart_Protect
	dbw EFFECT_FORESIGHT,        AI_Smart_Foresight
	dbw EFFECT_PERISH_SONG,      AI_Smart_PerishSong
	dbw EFFECT_SANDSTORM,        AI_Smart_Sandstorm
	dbw EFFECT_ENDURE,           AI_Smart_Endure
	dbw EFFECT_ROLLOUT,          AI_Smart_Rollout
	dbw EFFECT_SWAGGER,          AI_Smart_Swagger
	dbw EFFECT_FURY_CUTTER,      AI_Smart_FuryCutter
	dbw EFFECT_ATTRACT,          AI_Smart_Attract
	dbw EFFECT_SAFEGUARD,        AI_Smart_Safeguard
	dbw EFFECT_MAGNITUDE,        AI_Smart_Magnitude
	dbw EFFECT_BATON_PASS,       AI_Smart_BatonPass
	dbw EFFECT_PURSUIT,          AI_Smart_Pursuit
	dbw EFFECT_RAPID_SPIN,       AI_Smart_RapidSpin
	dbw EFFECT_MORNING_SUN,      AI_Smart_MorningSun
	dbw EFFECT_SYNTHESIS,        AI_Smart_Synthesis
	dbw EFFECT_MOONLIGHT,        AI_Smart_Moonlight
	dbw EFFECT_HIDDEN_POWER,     AI_Smart_HiddenPower
	dbw EFFECT_RAIN_DANCE,       AI_Smart_RainDance
	dbw EFFECT_SUNNY_DAY,        AI_Smart_SunnyDay
	dbw EFFECT_BELLY_DRUM,       AI_Smart_BellyDrum
	dbw EFFECT_PSYCH_UP,         AI_Smart_PsychUp
	dbw EFFECT_MIRROR_COAT,      AI_Smart_MirrorCoat
	dbw EFFECT_SKULL_BASH,       AI_Smart_SkullBash
	dbw EFFECT_TWISTER,          AI_Smart_Twister
	dbw EFFECT_EARTHQUAKE,       AI_Smart_Earthquake
	dbw EFFECT_FUTURE_SIGHT,     AI_Smart_FutureSight
	dbw EFFECT_GUST,             AI_Smart_Gust
	dbw EFFECT_STOMP,            AI_Smart_Stomp
	dbw EFFECT_SOLARBEAM,        AI_Smart_Solarbeam
	dbw EFFECT_THUNDER,          AI_Smart_Thunder
	dbw EFFECT_FLY,              AI_Smart_Fly
	dbw EFFECT_HAIL,             AI_Smart_Hail
	dbw EFFECT_BANEFUL_BUNKER,   AI_Smart_Protect
	dbw EFFECT_SPIKES,           AI_Smart_Spikes
	dbw EFFECT_TOXIC_SPIKES,     AI_Smart_ToxicSpikes
	dbw EFFECT_STEALTH_ROCK,     AI_Smart_StealthRock
	dbw EFFECT_STICKY_WEB,       AI_Smart_StickyWeb
	dbw EFFECT_TORMENT,          AI_Smart_Torment
	dbw EFFECT_TAUNT,            AI_Smart_Taunt
	dbw EFFECT_YAWN,             AI_Smart_Yawn
	dbw EFFECT_WISH,             AI_Smart_Wish
	dbw EFFECT_DEFOG,            AI_Smart_Defog
	dbw EFFECT_U_TURN,           AI_Smart_UTurn
	dbw EFFECT_TRICK_ROOM,       AI_Smart_TrickRoom
	dbw EFFECT_KNOCK_OFF,        AI_Smart_KnockOff
	dbw EFFECT_FOUL_PLAY,        AI_Smart_FoulPlay
	dbw EFFECT_FREEZE_DRY,       AI_Smart_FreezeDry
	dbw EFFECT_FAKE_OUT,         AI_Smart_FakeOut
	dbw EFFECT_VENOSHOCK,        AI_Smart_Venoshock
	dbw EFFECT_HEX,              AI_Smart_Hex
	dbw EFFECT_FACADE,           AI_Smart_Facade
	dbw EFFECT_CIRCLE_THROW,     AI_Smart_CircleThrow
	dbw EFFECT_ROOST,            AI_Smart_Heal
	db -1 ; end

AI_Smart_Sleep:
; Greatly encourage sleep inducing moves if the enemy has either Dream Eater or Nightmare.
; 50% chance to greatly encourage sleep inducing moves otherwise.

	ld b, EFFECT_DREAM_EATER
	call AIHasMoveEffect
	jr c, .asm_387f0

	ld b, EFFECT_NIGHTMARE
	call AIHasMoveEffect
	ret nc

.asm_387f0
	call AI_50_50
	ret c
	dec [hl]
	dec [hl]
	ret

AI_Smart_LeechHit:
	push hl
	ld a, 1
	ldh [hBattleTurn], a
	callfar BattleCheckTypeMatchup
	pop hl

; 60% chance to discourage this move if not very effective.
	ld a, [wTypeMatchup]
	cp EFFECTIVE
	jr c, .asm_38815

; Do nothing if effectiveness is neutral.
	ret z

; Do nothing if enemy's HP is full.
	call AICheckEnemyMaxHP
	ret c

; 80% chance to encourage this move otherwise.
	call AI_80_20
	ret c

	dec [hl]
	ret

.asm_38815
	call BattleRandom
	cp 39 percent + 1
	ret c

	inc [hl]
	ret

AI_Smart_LockOn:
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_LOCK_ON, a
	jr nz, .asm_38882

	push hl
	call AICheckEnemyQuarterHP
	jr nc, .asm_38877

	call AICheckEnemyHalfHP
	jr c, .asm_38834

	call AICompareSpeed
	jr nc, .asm_38877

.asm_38834
	ld a, [wPlayerEvaLevel]
	cp $a
	jr nc, .asm_3887a
	cp $8
	jr nc, .asm_38875

	ld a, [wEnemyAccLevel]
	cp $5
	jr c, .asm_3887a
	cp $7
	jr c, .asm_38875

	ld hl, wEnemyMonMoves
	ld c, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.asm_3884f
	dec c
	jr z, .asm_38877

	ld a, [hli]
	and a
	jr z, .asm_38877

	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_ACC]
	cp 180
	jr nc, .asm_3884f

	ld a, $1
	ldh [hBattleTurn], a

	push hl
	push bc
	farcall BattleCheckTypeMatchup
	ld a, [wTypeMatchup]
	cp EFFECTIVE
	pop bc
	pop hl
	jr c, .asm_3884f

.asm_38875
	pop hl
	ret

.asm_38877
	pop hl
	inc [hl]
	ret

.asm_3887a
	pop hl
	call AI_50_50
	ret c

	dec [hl]
	dec [hl]
	ret

.asm_38882
	push hl
	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld c, wEnemyMonMovesEnd - wEnemyMonMoves + 1

.asm_3888b
	inc hl
	dec c
	jr z, .asm_388a2

	ld a, [de]
	and a
	jr z, .asm_388a2

	inc de
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_ACC]
	cp 180
	jr nc, .asm_3888b

	dec [hl]
	dec [hl]
	jr .asm_3888b

.asm_388a2
	pop hl
	jp AIDiscourageMove

AI_Smart_Selfdestruct:
; Selfdestruct, Explosion

; Unless this is the enemy's last Pokemon...
	push hl
	farcall FindAliveEnemyMons
	pop hl
	jr nc, .asm_388b7

; ...greatly discourage this move unless this is the player's last Pokemon too.
	push hl
	call AICheckLastPlayerMon
	pop hl
	jr nz, .asm_388c6

.asm_388b7
; Greatly discourage this move if enemy's HP is above 50%.
	call AICheckEnemyHalfHP
	jr c, .asm_388c6

; Do nothing if enemy's HP is below 25%.
	call AICheckEnemyQuarterHP
	ret nc

; If enemy's HP is between 25% and 50%,
; over 90% chance to greatly discourage this move.
	call BattleRandom
	cp 9 percent - 2
	ret c

.asm_388c6
	inc [hl]
	inc [hl]
	inc [hl]
	ret

AI_Smart_DreamEater:
; 90% chance to greatly encourage this move.
; The AI_Basic layer will make sure that
; Dream Eater is only used against sleeping targets.
	call BattleRandom
	cp 10 percent
	ret c
	dec [hl]
	dec [hl]
	dec [hl]
	ret

AI_Smart_EvasionUp:
; Dismiss this move if enemy's evasion can't raise anymore.
	ld a, [wEnemyEvaLevel]
	cp $d
	jp nc, AIDiscourageMove

; If enemy's HP is full...
	call AICheckEnemyMaxHP
	jr nc, .asm_388f2

; ...greatly encourage this move if player is badly poisoned.
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_388ef

; ...70% chance to greatly encourage this move if player is not badly poisoned.
	call BattleRandom
	cp 70 percent
	jr nc, .asm_38911

.asm_388ef
	dec [hl]
	dec [hl]
	ret

.asm_388f2

; Greatly discourage this move if enemy's HP is below 25%.
	call AICheckEnemyQuarterHP
	jr nc, .asm_3890f

; If enemy's HP is above 25% but not full, 4% chance to greatly encourage this move.
	call BattleRandom
	cp 4 percent
	jr c, .asm_388ef

; If enemy's HP is between 25% and 50%,...
	call AICheckEnemyHalfHP
	jr nc, .asm_3890a

; If enemy's HP is above 50% but not full, 20% chance to greatly encourage this move.
	call AI_80_20
	jr c, .asm_388ef
	jr .asm_38911

.asm_3890a
; ...50% chance to greatly discourage this move.
	call AI_50_50
	jr c, .asm_38911

.asm_3890f
	inc [hl]
	inc [hl]

; 30% chance to end up here if enemy's HP is full and player is not badly poisoned.
; 77% chance to end up here if enemy's HP is above 50% but not full.
; 96% chance to end up here if enemy's HP is between 25% and 50%.
; 100% chance to end up here if enemy's HP is below 25%.
; In other words, we only end up here if the move has not been encouraged or dismissed.
.asm_38911
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_38938

	ld a, [wPlayerSubStatus4]
	bit SUBSTATUS_LEECH_SEED, a
	jr nz, .asm_38941

; Discourage this move if enemy's evasion level is higher than player's accuracy level.
	ld a, [wEnemyEvaLevel]
	ld b, a
	ld a, [wPlayerAccLevel]
	cp b
	jr c, .asm_38936

; Greatly encourage this move if the player is in the middle of Fury Cutter or Rollout.
	ld a, [wPlayerFuryCutterCount]
	and a
	jr nz, .asm_388ef

	ld a, [wPlayerSubStatus1]
	bit SUBSTATUS_ROLLOUT, a
	jr nz, .asm_388ef

.asm_38936
	inc [hl]
	ret

; Player is badly poisoned.
; 70% chance to greatly encourage this move.
; This would counter any previous discouragement.
.asm_38938
	call BattleRandom
	cp 31 percent + 1
	ret c
	dec [hl]
	dec [hl]
	ret

; Player is seeded.
; 50% chance to encourage this move.
; This would partly counter any previous discouragement.
.asm_38941
	call AI_50_50
	ret c

	dec [hl]
	ret

AI_Smart_AlwaysHit:
; 80% chance to greatly encourage this move if either...

; ...enemy's accuracy level has been lowered three or more stages
	ld a, [wEnemyAccLevel]
	cp $5
	jr c, .asm_38954

; ...or player's evasion level has been raised three or more stages.
	ld a, [wPlayerEvaLevel]
	cp $a
	ret c

.asm_38954
	call AI_80_20
	ret c

	dec [hl]
	dec [hl]
	ret

AI_Smart_MirrorMove:
; If the player did not use any move last turn...
	ld a, [wLastPlayerCounterMove]
	and a
	jr nz, .asm_38968

; ...do nothing if enemy is slower than player
	call AICompareSpeed
	ret nc

; ...or dismiss this move if enemy is faster than player.
	jp AIDiscourageMove

; If the player did use a move last turn...
.asm_38968
	push hl
	ld hl, UsefulMoves
	call AI_CheckMoveInList
	pop hl

; ...do nothing if he didn't use a useful move.
	ret nc

; If he did, 50% chance to encourage this move...
	call AI_50_50
	ret c

	dec [hl]

; ...and 90% chance to encourage this move again if the enemy is faster.
	call AICompareSpeed
	ret nc

	call BattleRandom
	cp 10 percent
	ret c

	dec [hl]
	ret

AI_Smart_AccuracyDown:
; If player's HP is full...
	call AICheckPlayerMaxHP
	jr nc, .asm_389a0

; ...and enemy's HP is above 50%...
	call AICheckEnemyHalfHP
	jr nc, .asm_389a0

; ...greatly encourage this move if player is badly poisoned.
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_3899d

; ...70% chance to greatly encourage this move if player is not badly poisoned.
	call BattleRandom
	cp 70 percent
	jr nc, .asm_389bf

.asm_3899d
	dec [hl]
	dec [hl]
	ret

.asm_389a0

; Greatly discourage this move if player's HP is below 25%.
	call AICheckPlayerQuarterHP
	jr nc, .asm_389bd

; If player's HP is above 25% but not full, 4% chance to greatly encourage this move.
	call BattleRandom
	cp 4 percent
	jr c, .asm_3899d

; If player's HP is between 25% and 50%,...
	call AICheckPlayerHalfHP
	jr nc, .asm_389b8

; If player's HP is above 50% but not full, 20% chance to greatly encourage this move.
	call AI_80_20
	jr c, .asm_3899d
	jr .asm_389bf

; ...50% chance to greatly discourage this move.
.asm_389b8
	call AI_50_50
	jr c, .asm_389bf

.asm_389bd
	inc [hl]
	inc [hl]

; We only end up here if the move has not been already encouraged.
.asm_389bf
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_389e6

	ld a, [wPlayerSubStatus4]
	bit SUBSTATUS_LEECH_SEED, a
	jr nz, .asm_389ef

; Discourage this move if enemy's evasion level is higher than player's accuracy level.
	ld a, [wEnemyEvaLevel]
	ld b, a
	ld a, [wPlayerAccLevel]
	cp b
	jr c, .asm_389e4

; Greatly encourage this move if the player is in the middle of Fury Cutter or Rollout.
	ld a, [wPlayerFuryCutterCount]
	and a
	jr nz, .asm_3899d

	ld a, [wPlayerSubStatus1]
	bit SUBSTATUS_ROLLOUT, a
	jr nz, .asm_3899d

.asm_389e4
	inc [hl]
	ret

; Player is badly poisoned.
; 70% chance to greatly encourage this move.
; This would counter any previous discouragement.
.asm_389e6
	call BattleRandom
	cp 31 percent + 1
	ret c
	dec [hl]
	dec [hl]
	ret

; Player is seeded.
; 50% chance to encourage this move.
; This would partly counter any previous discouragement.
.asm_389ef
	call AI_50_50
	ret c

	dec [hl]
	ret

AI_Smart_ResetStats:
; 85% chance to encourage this move if any of enemy's stat levels is lower than -2.
	push hl
	ld hl, wEnemyAtkLevel
	ld c, $8
.asm_389fb
	dec c
	jr z, .asm_38a05
	ld a, [hli]
	cp $5
	jr c, .asm_38a12
	jr .asm_389fb

; 85% chance to encourage this move if any of player's stat levels is higher than +2.
.asm_38a05
; An Unaware user ignores the player's Atk/Def/SpA/SpD stages both ways,
; so only their Speed, accuracy and evasion boosts are worth resetting.
	call AIGetEnemyAbility
	cp UNAWARE
	jr nz, .all_stats
	ld a, [wPlayerSpdLevel]
	cp $a
	jr nc, .asm_38a12
	ld a, [wPlayerAccLevel]
	cp $a
	jr nc, .asm_38a12
	ld a, [wPlayerEvaLevel]
	cp $a
	jr nc, .asm_38a12
	jr .asm_38a1b
.all_stats
	ld hl, wPlayerAtkLevel
	ld c, $8
.asm_38a0a
	dec c
	jr z, .asm_38a1b
	ld a, [hli]
	cp $a
	jr c, .asm_38a0a

.asm_38a12
	pop hl
	call BattleRandom
	cp 16 percent
	ret c
	dec [hl]
	ret

; Discourage this move if neither:
; Any of enemy's stat levels is	lower than -2.
; Any of player's stat levels is higher than +2.
.asm_38a1b
	pop hl
	inc [hl]
	ret

AI_Smart_Bide:
; 90% chance to discourage this move unless enemy's HP is full.

	call AICheckEnemyMaxHP
	ret c
	call BattleRandom
	cp 10 percent
	ret c
	inc [hl]
	ret

AI_Smart_ForceSwitch:
; Whirlwind, Roar.

; Discourage this move if the player has not shown
; a super-effective move against the enemy.
; Consider player's type(s) if its moves are unknown.

	push hl
	callfar CheckPlayerMoveTypeMatchups
	ld a, [wEnemyAISwitchScore]
	cp 10 ; neutral
	pop hl
	ret c
	inc [hl]
	ret

AI_Smart_Heal:
AI_Smart_MorningSun:
AI_Smart_Synthesis:
AI_Smart_Moonlight:
; 90% chance to greatly encourage this move if enemy's HP is below 25%.
; Discourage this move if enemy's HP is higher than 50%.
; Do nothing otherwise.

	call AICheckEnemyQuarterHP
	jr nc, .asm_38a45
	call AICheckEnemyHalfHP
	ret nc
	inc [hl]
	ret

.asm_38a45
	call BattleRandom
	cp 10 percent
	ret c
	dec [hl]
	dec [hl]
	ret

AI_Smart_Toxic:
AI_Smart_LeechSeed:
; Discourage this move if player's HP is below 50%.

	call AICheckPlayerHalfHP
	ret c
	inc [hl]
	ret

AI_Smart_LightScreen:
AI_Smart_Reflect:
; Over 90% chance to discourage this move unless enemy's HP is full.
; Dismiss it if the player's Infiltrator attacks straight through screens.

	call AIGetPlayerAbility
	cp INFILTRATOR
	jp z, AIDiscourageMove
	call AICheckEnemyMaxHP
	ret c
	call BattleRandom
	cp 8 percent
	ret c
	inc [hl]
	ret

AI_Smart_Ohko:
; Dismiss this move if player's level is higher than enemy's level.
; Else, discourage this move is player's HP is below 50%.

	ld a, [wBattleMonLevel]
	ld b, a
	ld a, [wEnemyMonLevel]
	cp b
	jp c, AIDiscourageMove
	call AICheckPlayerHalfHP
	ret c
	inc [hl]
	ret

AI_Smart_TrapTarget:
; Bind, Wrap, Fire Spin, Clamp

; 50% chance to discourage this move if the player is already trapped.
	ld a, [wPlayerWrapCount]
	and a
	jr nz, .asm_38a8b

; 50% chance to greatly encourage this move if player is either
; badly poisoned, in love, identified, stuck in Rollout, or has a Nightmare.
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_38a91

	ld a, [wPlayerSubStatus1]
	and 1 << SUBSTATUS_IN_LOVE | 1 << SUBSTATUS_ROLLOUT | 1 << SUBSTATUS_IDENTIFIED | 1 << SUBSTATUS_NIGHTMARE
	jr nz, .asm_38a91

; Else, 50% chance to greatly encourage this move if it's the player's Pokemon first turn.
	ld a, [wPlayerTurnsTaken]
	and a
	jr z, .asm_38a91

; 50% chance to discourage this move otherwise.
.asm_38a8b
	call AI_50_50
	ret c
	inc [hl]
	ret

.asm_38a91
	call AICheckEnemyQuarterHP
	ret nc
	call AI_50_50
	ret c
	dec [hl]
	dec [hl]
	ret

AI_Smart_RazorWind:
AI_Smart_Unused2B:
	ld a, [wEnemySubStatus1]
	bit SUBSTATUS_PERISH, a
	jr z, .asm_38aaa

	ld a, [wEnemyPerishCount]
	cp 3
	jr c, .asm_38ad3

.asm_38aaa
	push hl
	ld hl, wPlayerUsedMoves
	ld c, 4

.asm_38ab0
	ld a, [hli]
	and a
	jr z, .asm_38ac1

	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_PROTECT
	jr z, .asm_38ad5
	dec c
	jr nz, .asm_38ab0

.asm_38ac1
	pop hl
	ld a, [wEnemySubStatus3]
	bit SUBSTATUS_CONFUSED, a
	jr nz, .asm_38acd

	call AICheckEnemyHalfHP
	ret c

.asm_38acd
	call BattleRandom
	cp 79 percent - 1
	ret c

.asm_38ad3
	inc [hl]
	ret

.asm_38ad5
	pop hl
	ld a, [hl]
	add 6
	ld [hl], a
	ret

AI_Smart_Confuse:
; 90% chance to discourage this move if player's HP is between 25% and 50%.
	call AICheckPlayerHalfHP
	ret c
	call BattleRandom
	cp 10 percent
	jr c, .asm_38ae7
	inc [hl]

.asm_38ae7
; Discourage again if player's HP is below 25%.
	call AICheckPlayerQuarterHP
	ret c
	inc [hl]
	ret

AI_Smart_SpDefenseUp2:
; Discourage this move if enemy's HP is lower than 50%.
	call AICheckEnemyHalfHP
	jr nc, .asm_38b10

; Discourage this move if enemy's special defense level is higher than +3.
	ld a, [wEnemySDefLevel]
	cp $b
	jr nc, .asm_38b10

; 80% chance to greatly encourage this move if
; enemy's Special Defense level is lower than +2, and the player is of a special type.
	cp $9
	ret nc

	ld a, [wBattleMonType1]
	cp SPECIAL
	jr nc, .asm_38b09
	ld a, [wBattleMonType2]
	cp SPECIAL
	ret c

.asm_38b09
	call AI_80_20
	ret c
	dec [hl]
	dec [hl]
	ret

.asm_38b10
	inc [hl]
	ret

AI_Smart_Fly:
; Fly, Dig

; Greatly encourage this move if the player is
; flying or underground, and slower than the enemy.

	ld a, [wPlayerSubStatus3]
	and 1 << SUBSTATUS_FLYING | 1 << SUBSTATUS_UNDERGROUND
	ret z

	call AICompareSpeed
	ret nc

	dec [hl]
	dec [hl]
	dec [hl]
	ret

AI_Smart_SuperFang:
; Discourage this move if player's HP is below 25%.

	call AICheckPlayerQuarterHP
	ret c
	inc [hl]
	ret

AI_Smart_Paralyze:
; 50% chance to discourage this move if player's HP is below 25%.
	call AICheckPlayerQuarterHP
	jr nc, .asm_38b3a

; 80% chance to greatly encourage this move
; if enemy is slower than player and its HP is above 25%.
	call AICompareSpeed
	ret c
	call AICheckEnemyQuarterHP
	ret nc
	call AI_80_20
	ret c
	dec [hl]
	dec [hl]
	ret

.asm_38b3a
	call AI_50_50
	ret c
	inc [hl]
	ret

AI_Smart_SpeedDownHit:
; Icy Wind

; Almost 90% chance to greatly encourage this move if the following conditions all meet:
; Enemy's HP is higher than 25%.
; It's the first turn of player's Pokemon.
; Player is faster than enemy.

	ld a, [wEnemyMoveStruct + MOVE_ANIM]
	push hl
	call GetMoveIndexFromID ; was GetMoveIDFromIndex: wrong direction, ran on the score pointer
	ld a, h
	if HIGH(ICY_WIND)
		cp HIGH(ICY_WIND)
	else
		and a
	endc
	ld a, l
	pop hl
	ret nz
	cp LOW(ICY_WIND)
	ret nz
; Shield Dust swallows the Speed drop, which is the whole reason to use it.
	call AIGetPlayerAbility
	cp SHIELD_DUST
	ret z
	call AICheckEnemyQuarterHP
	ret nc
	ld a, [wPlayerTurnsTaken]
	and a
	ret nz
	call AICompareSpeed
	ret c
	call BattleRandom
	cp 12 percent
	ret c
	dec [hl]
	dec [hl]
	ret

AI_Smart_Substitute:
; Dismiss this move if enemy's HP is below 50%, or if the player's
; Infiltrator hits straight through the doll.

	call AIGetPlayerAbility
	cp INFILTRATOR
	jp z, AIDiscourageMove
	call AICheckEnemyHalfHP
	ret c
	jp AIDiscourageMove

AI_Smart_HyperBeam:
	call AICheckEnemyHalfHP
	jr c, .asm_38b72

; 50% chance to encourage this move if enemy's HP is below 25%.
	call AICheckEnemyQuarterHP
	ret c
	call AI_50_50
	ret c
	dec [hl]
	ret

.asm_38b72
; If enemy's HP is above 50%, discourage this move at random
	call BattleRandom
	cp 16 percent
	ret c
	inc [hl]
	call AI_50_50
	ret c
	inc [hl]
	ret

AI_Smart_Rage:
	ld a, [wEnemySubStatus4]
	bit SUBSTATUS_RAGE, a
	jr z, .asm_38b9b

; If enemy's Rage is building, 50% chance to encourage this move.
	call AI_50_50
	jr c, .asm_38b8c

	dec [hl]

; Encourage this move based on Rage's counter.
.asm_38b8c
	ld a, [wEnemyRageCounter]
	cp $2
	ret c
	dec [hl]
	ld a, [wEnemyRageCounter]
	cp $3
	ret c
	dec [hl]
	ret

.asm_38b9b
; If enemy's Rage is not building, discourage this move if enemy's HP is below 50%.
	call AICheckEnemyHalfHP
	jr nc, .asm_38ba6

; 50% chance to encourage this move otherwise.
	call AI_80_20
	ret nc
	dec [hl]
	ret

.asm_38ba6
	inc [hl]
	ret

AI_Smart_Mimic:
	ld a, [wLastPlayerCounterMove]
	and a
	jr z, .asm_38be9

	call AICheckEnemyHalfHP
	jr nc, .asm_38bef

	push hl
	ld a, [wLastPlayerCounterMove]
	call AIGetEnemyMove

	ld a, $1
	ldh [hBattleTurn], a
	callfar BattleCheckTypeMatchup

	ld a, [wTypeMatchup]
	cp EFFECTIVE
	pop hl
	jr c, .asm_38bef
	jr z, .asm_38bd4

	call AI_50_50
	jr c, .asm_38bd4

	dec [hl]

.asm_38bd4
	ld a, [wLastPlayerCounterMove]
	push hl
	ld hl, UsefulMoves
	call AI_CheckMoveInList

	pop hl
	ret nc
	call AI_50_50
	ret c
	dec [hl]
	ret

.asm_38be9
	call AICompareSpeed
	jp c, AIDiscourageMove

.asm_38bef
	inc [hl]
	ret

AI_Smart_Counter:
	push hl
	ld hl, wPlayerUsedMoves
	ld c, 4
	ld b, 0

.asm_38bf9
	ld a, [hli]
	and a
	jr z, .asm_38c0e

	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .asm_38c0e

	ld a, [wEnemyMoveStruct + MOVE_CATEGORY]
	cp CATEGORIZE_PHYSICAL
	jr nz, .asm_38c0e

	inc b

.asm_38c0e
	dec c
	jr nz, .asm_38bf9

	pop hl
	ld a, b
	and a
	jr z, .asm_38c39

	cp $3
	jr nc, .asm_38c30

	ld a, [wLastPlayerCounterMove]
	and a
	jr z, .asm_38c38

	call AIGetEnemyMove
	farcall HiddenPowerPatchPlayerLastMoveCategory

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .asm_38c38

	ld a, [wEnemyMoveStruct + MOVE_CATEGORY]
	cp CATEGORIZE_PHYSICAL
	jr nz, .asm_38c38

.asm_38c30
	call BattleRandom
	cp 39 percent + 1
	jr c, .asm_38c38

	dec [hl]

.asm_38c38
	ret

.asm_38c39
	inc [hl]
	ret

AI_Smart_Encore:
	call AICompareSpeed
	jr nc, .asm_38c81

	ld a, [wLastPlayerMove]
	and a
	jp z, AIDiscourageMove

	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .asm_38c68

	push hl
	ld a, [wEnemyMoveStruct + MOVE_TYPE]
	ld hl, wEnemyMonType1
	predef CheckTypeMatchup

	pop hl
	ld a, [wTypeMatchup]
	cp EFFECTIVE
	jr nc, .asm_38c68

	and a
	ret nz
	jr .asm_38c78

.asm_38c68
	push hl
	ld a, [wLastPlayerCounterMove]
	ld hl, EncoreMoves
	call AI_CheckMoveInList
	pop hl
	jr nc, .asm_38c81

.asm_38c78
	call BattleRandom
	cp 28 percent - 1
	ret c
	dec [hl]
	dec [hl]
	ret

.asm_38c81
	inc [hl]
	inc [hl]
	inc [hl]
	ret

INCLUDE "data/battle/ai/encore_moves.asm"

AI_Smart_PainSplit:
; Discourage this move if [enemy's current HP * 2 > player's current HP].

	push hl
	ld hl, wEnemyMonHP
	ld b, [hl]
	inc hl
	ld c, [hl]
	sla c
	rl b
	ld hl, wBattleMonHP + 1
	ld a, [hld]
	cp c
	ld a, [hl]
	sbc b
	pop hl
	ret nc
	inc [hl]
	ret

AI_Smart_Snore:
AI_Smart_SleepTalk:
; Greatly encourage this move if enemy is fast asleep.
; Greatly discourage this move otherwise.

	ld a, [wEnemyMonStatus]
	and $7
	cp $1
	jr z, .asm_38cc7

	dec [hl]
	dec [hl]
	dec [hl]
	ret

.asm_38cc7
	inc [hl]
	inc [hl]
	inc [hl]
	ret

AI_Smart_DefrostOpponent:
; Greatly encourage this move if enemy is frozen.
; No move has EFFECT_DEFROST_OPPONENT, so this layer is unused.

	ld a, [wEnemyMonStatus]
	and 1 << FRZ
	ret z
	dec [hl]
	dec [hl]
	dec [hl]
	ret

AI_Smart_Spite:
	ld a, [wLastPlayerCounterMove]
	and a
	jr nz, .asm_38ce7

	call AICompareSpeed
	jp c, AIDiscourageMove

	call AI_50_50
	ret c
	inc [hl]
	ret

.asm_38ce7
	push hl
	ld b, a
	ld c, 4
	ld hl, wBattleMonMoves
	ld de, wBattleMonPP

.asm_38cf1
	ld a, [hli]
	cp b
	jr z, .asm_38cfb

	inc de
	dec c
	jr nz, .asm_38cf1

	pop hl
	ret

.asm_38cfb
	pop hl
	ld a, [de]
	cp $6
	jr c, .asm_38d0d
	cp $f
	jr nc, .asm_38d0b

	call BattleRandom
	cp 39 percent + 1
	ret nc

.asm_38d0b
	inc [hl]
	ret

.asm_38d0d
	call BattleRandom
	cp 39 percent + 1
	ret c
	dec [hl]
	dec [hl]
	ret

Function_0x38d16:
	jp AIDiscourageMove

AI_Smart_DestinyBond:
AI_Smart_Reversal:
AI_Smart_SkullBash:
; Discourage this move if enemy's HP is above 25%.

	call AICheckEnemyQuarterHP
	ret nc
	inc [hl]
	ret

AI_Smart_HealBell:
; Dismiss this move if none of the opponent's Pokemon is statused.
; Encourage this move if the enemy is statused.
; 50% chance to greatly encourage this move if the enemy is fast asleep or frozen.

	push hl
	ld a, [wOTPartyCount]
	ld b, a
	ld c, 0
	ld hl, wOTPartyMon1HP
	ld de, PARTYMON_STRUCT_LENGTH

.loop
	push hl
	ld a, [hli]
	or [hl]
	jr z, .next

	; status
	dec hl
	dec hl
	dec hl
	ld a, [hl]
	or c
	ld c, a

.next
	pop hl
	add hl, de
	dec b
	jr nz, .loop

	pop hl
	ld a, c
	and a
	jr z, .no_status

	ld a, [wEnemyMonStatus]
	and a
	jr z, .ok
	dec [hl]
.ok
	and SLP ; frostbite isn't incapacitating; treat like a normal status
	ret z
	call AI_50_50
	ret c
	dec [hl]
	dec [hl]
	ret

.no_status
	ld a, [wEnemyMonStatus]
	and a
	ret nz
	jp AIDiscourageMove


AI_Smart_PriorityHit:
	call AICompareSpeed
	ret c

; Dismiss this move if the player is flying or underground.
	ld a, [wPlayerSubStatus3]
	and 1 << SUBSTATUS_FLYING | 1 << SUBSTATUS_UNDERGROUND
	jp nz, AIDiscourageMove

; Greatly encourage this move if it will KO the player.
	ld a, $1
	ldh [hBattleTurn], a
	push hl
	callfar EnemyAttackDamage
	callfar BattleCommand_DamageCalc
	ld a, 1
	ld [wAIDamagePrediction], a
	callfar BattleCommand_Stab
	xor a
	ld [wAIDamagePrediction], a
	pop hl
	ld a, [wCurDamage + 1]
	ld c, a
	ld a, [wCurDamage]
	ld b, a
	ld a, [wBattleMonHP + 1]
	cp c
	ld a, [wBattleMonHP]
	sbc b
	ret nc
	dec [hl]
	dec [hl]
	dec [hl]
	ret

AI_Smart_FirstImpression:
; Never select it after the enemy's one post-entry opportunity has passed.
	ld a, [wEnemyFirstImpressionFresh]
	and a
	jp z, AIDiscourageMove
	jp AI_Smart_PriorityHit

AI_Smart_Thief:
; Don't use Thief unless it's the only move available.

	ld a, [hl]
	add $1e
	ld [hl], a
	ret

AI_Smart_Conversion2:
	ld a, [wLastPlayerMove]
	and a
	jr z, .asm_38dc9

	push hl
	ld l, a
	ld a, MOVE_TYPE
	call GetMoveAttribute
	ld [wPlayerMoveStruct + MOVE_TYPE], a

	xor a
	ldh [hBattleTurn], a

	callfar BattleCheckTypeMatchup

	ld a, [wTypeMatchup]
	cp EFFECTIVE
	pop hl
	jr c, .asm_38dc9
	ret z

	call AI_50_50
	ret c

	dec [hl]
	ret

.asm_38dc9
	call BattleRandom
	cp 10 percent
	ret c
	inc [hl]
	ret

AI_Smart_Disable:
	call AICompareSpeed
	jr nc, .asm_38df3

	push hl
	ld a, [wLastPlayerCounterMove]
	ld hl, UsefulMoves
	call AI_CheckMoveInList

	pop hl
	jr nc, .asm_38dee

	call BattleRandom
	cp 39 percent + 1
	ret c
	dec [hl]
	ret

.asm_38dee
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	ret nz

.asm_38df3
	call BattleRandom
	cp 8 percent
	ret c
	inc [hl]
	ret

AI_Smart_MeanLook:
	call AICheckEnemyHalfHP
	jr nc, .asm_38e24

	push hl
	call AICheckLastPlayerMon
	pop hl
	jp z, AIDiscourageMove

; 80% chance to greatly encourage this move if the player is badly poisoned.
	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_38e26

; 80% chance to greatly encourage this move if the player is either
; in love, identified, stuck in Rollout, or has a Nightmare.
	ld a, [wPlayerSubStatus1]
	and 1 << SUBSTATUS_IN_LOVE | 1 << SUBSTATUS_ROLLOUT | 1 << SUBSTATUS_IDENTIFIED | 1 << SUBSTATUS_NIGHTMARE
	jr nz, .asm_38e26

; Otherwise, discourage this move unless the player only has not very effective moves against the enemy.
	push hl
	callfar CheckPlayerMoveTypeMatchups
	ld a, [wEnemyAISwitchScore]
	cp $b ; not very effective
	pop hl
	ret nc

.asm_38e24
	inc [hl]
	ret

.asm_38e26
	call AI_80_20
	ret c
	dec [hl]
	dec [hl]
	dec [hl]
	ret

AICheckLastPlayerMon:
	ld a, [wPartyCount]
	ld b, a
	ld c, 0
	ld hl, wPartyMon1HP
	ld de, PARTYMON_STRUCT_LENGTH

.loop
	ld a, [wCurBattleMon]
	cp c
	jr z, .asm_38e44

	ld a, [hli]
	or [hl]
	ret nz
	dec hl

.asm_38e44
	add hl, de
	inc c
	dec b
	jr nz, .loop

	ret

AI_Smart_Nightmare:
; 50% chance to encourage this move.
; The AI_Basic layer will make sure that
; Dream Eater is only used against sleeping targets.

	call AI_50_50
	ret c
	dec [hl]
	ret

AI_Smart_FlameWheel:
; Frostbite no longer freezes the target solid and Fire moves don't cure it,
; so don't specially favor Flame Wheel against a frostbitten foe.
	ret

AI_Smart_Curse:
	ld a, [wEnemyMonType1]
	cp GHOST
	jr z, .ghostcurse
	ld a, [wEnemyMonType2]
	cp GHOST
	jr z, .ghostcurse

	call AICheckEnemyHalfHP
	jr nc, .asm_38e93

	ld a, [wEnemyAtkLevel]
	cp $b
	jr nc, .asm_38e93
	cp $9
	ret nc

	ld a, [wBattleMonType1]
	cp GHOST
	jr z, .asm_38e92
	cp SPECIAL
	ret nc
	ld a, [wBattleMonType2]
	cp SPECIAL
	ret nc
	call AI_80_20
	ret c
	dec [hl]
	dec [hl]
	ret

.asm_38e90
	inc [hl]
	inc [hl]
.asm_38e92
	inc [hl]
.asm_38e93
	inc [hl]
	ret

.ghostcurse
	ld a, [wPlayerSubStatus1]
	bit SUBSTATUS_CURSE, a
	jp nz, AIDiscourageMove

	push hl
	farcall FindAliveEnemyMons
	pop hl
	jr nc, .asm_38eb0

	push hl
	call AICheckLastPlayerMon
	pop hl
	jr nz, .asm_38e90

	jr .asm_38eb7

.asm_38eb0
	push hl
	call AICheckLastPlayerMon
	pop hl
	jr z, .asm_38ecb

.asm_38eb7
	call AICheckEnemyQuarterHP
	jp nc, .asm_38e90

	call AICheckEnemyHalfHP
	jr nc, .asm_38e92

	call AICheckEnemyMaxHP
	ret nc

	ld a, [wPlayerTurnsTaken]
	and a
	ret nz

.asm_38ecb
	call AI_50_50
	ret c

	dec [hl]
	dec [hl]
	ret

AI_Smart_Protect:
	ld a, [wEnemyProtectCount]
	and a
	jr nz, .asm_38f13

	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_LOCK_ON, a
	jr nz, .asm_38f14

	ld a, [wPlayerFuryCutterCount]
	cp 3
	jr nc, .asm_38f0d

	ld a, [wPlayerSubStatus3]
	bit SUBSTATUS_CHARGED, a
	jr nz, .asm_38f0d

	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_TOXIC, a
	jr nz, .asm_38f0d
	ld a, [wPlayerSubStatus4]
	bit SUBSTATUS_LEECH_SEED, a
	jr nz, .asm_38f0d
	ld a, [wPlayerSubStatus1]
	bit SUBSTATUS_CURSE, a
	jr nz, .asm_38f0d

	bit SUBSTATUS_ROLLOUT, a
	jr z, .asm_38f14

	ld a, [wPlayerRolloutCount]
	cp 3
	jr c, .asm_38f14

.asm_38f0d
	call AI_80_20
	ret c
	dec [hl]
	ret

.asm_38f13
	inc [hl]

.asm_38f14
	call BattleRandom
	cp 8 percent
	ret c
	inc [hl]
	inc [hl]
	ret

AI_Smart_Foresight:
	ld a, [wEnemyAccLevel]
	cp $5
	jr c, .asm_38f41
	ld a, [wPlayerEvaLevel]
	cp $a
	jr nc, .asm_38f41

	ld a, [wBattleMonType1]
	cp GHOST
	jr z, .asm_38f41
	ld a, [wBattleMonType2]
	cp GHOST
	jr z, .asm_38f41

	call BattleRandom
	cp 8 percent
	ret c
	inc [hl]
	ret

.asm_38f41
	call BattleRandom
	cp 39 percent + 1
	ret c
	dec [hl]
	dec [hl]
	ret

AI_Smart_PerishSong:
	push hl
	callfar FindAliveEnemyMons
	pop hl
	jr c, .no

	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_CANT_RUN, a
	jr nz, .yes

	push hl
	callfar CheckPlayerMoveTypeMatchups
	ld a, [wEnemyAISwitchScore]
	cp 10 ; 1.0
	pop hl
	ret c

	call AI_50_50
	ret c

	inc [hl]
	ret

.yes
	call AI_50_50
	ret c

	dec [hl]
	ret

.no
	ld a, [hl]
	add 5
	ld [hl], a
	ret

AI_Smart_Sandstorm:
; Greatly discourage this move if the player is immune to Sandstorm damage.
	ld a, [wBattleMonType1]
	push hl
	ld hl, .SandstormImmuneTypes
	ld de, 1
	call IsInArray
	pop hl
	jr c, .asm_38fa5

	ld a, [wBattleMonType2]
	push hl
	ld hl, .SandstormImmuneTypes
	ld de, 1
	call IsInArray
	pop hl
	jr c, .asm_38fa5

; Discourage this move if player's HP is below 50%.
	call AICheckPlayerHalfHP
	jr nc, .asm_38fa6

; 50% chance to encourage this move otherwise.
	call AI_50_50
	ret c

	dec [hl]
	ret

.asm_38fa5
	inc [hl]

.asm_38fa6
	inc [hl]
	ret

.SandstormImmuneTypes:
	db ROCK
	db GROUND
	db STEEL
	db -1 ; end

AI_Smart_Hail:
; Greatly discourage this move if the player is immune to Hail damage.
	ld a, [wBattleMonType1]
	cp ICE
	jr z, .greatly_discourage

	ld a, [wBattleMonType2]
	cp ICE
	jr z, .greatly_discourage

; Discourage this move if player's HP is below 50%.
	call AICheckPlayerHalfHP
	jr nc, .discourage

; Encourage this move if the enemy has a good Hail move.
	push hl
	ld hl, .GoodHailMoves
	call AIHasMoveInArray
	pop hl
	jr c, .encourage

; 50% chance to encourage this move otherwise.
	call AI_50_50
	ret c

.encourage
	dec [hl]
	ret

.greatly_discourage
	inc [hl]
.discourage
	inc [hl]
	ret

.GoodHailMoves:
	dw BLIZZARD
	dw -1 ; end

AI_Smart_Endure:
	ld a, [wEnemyProtectCount]
	and a
	jr nz, .asm_38fd8

	call AICheckEnemyMaxHP
	jr c, .asm_38fd8

	call AICheckEnemyQuarterHP
	jr c, .asm_38fd9

	ld b, EFFECT_REVERSAL
	call AIHasMoveEffect
	jr nc, .asm_38fcb

	call AI_80_20
	ret c

	dec [hl]
	dec [hl]
	dec [hl]
	ret

.asm_38fcb
	ld a, [wEnemySubStatus5]
	bit SUBSTATUS_LOCK_ON, a
	ret z

	call AI_50_50
	ret c

	dec [hl]
	dec [hl]
	ret

.asm_38fd8
	inc [hl]

.asm_38fd9
	inc [hl]
	ret

AI_Smart_FuryCutter:
; Encourage this move based on Fury Cutter's count.

	ld a, [wEnemyFuryCutterCount]
	and a
	jr z, .end
	dec [hl]

	cp 2
	jr c, .end
	dec [hl]
	dec [hl]

	cp 3
	jr c, .end
	dec [hl]
	dec [hl]
	dec [hl]

.end

	; fallthrough

AI_Smart_Rollout:
; Rollout, Fury Cutter

; 80% chance to discourage this move if the enemy is in love, confused, or paralyzed.
	ld a, [wEnemySubStatus1]
	bit SUBSTATUS_IN_LOVE, a
	jr nz, .asm_39020

	ld a, [wEnemySubStatus3]
	bit SUBSTATUS_CONFUSED, a
	jr nz, .asm_39020

	ld a, [wEnemyMonStatus]
	bit PAR, a
	jr nz, .asm_39020

; 80% chance to discourage this move if the enemy's HP is below 25%,
; or if accuracy or evasion modifiers favour the player.
	call AICheckEnemyQuarterHP
	jr nc, .asm_39020

	ld a, [wEnemyAccLevel]
	cp 7
	jr c, .asm_39020
	ld a, [wPlayerEvaLevel]
	cp 8
	jr nc, .asm_39020

; Otherwise, 80% chance to greatly encourage this move.
	call BattleRandom
	cp 79 percent - 1
	ret nc
	dec [hl]
	dec [hl]
	ret

.asm_39020
	call AI_80_20
	ret c
	inc [hl]
	ret

AI_Smart_Swagger:
AI_Smart_Attract:
; 80% chance to encourage this move during the first turn of player's Pokemon.
; 80% chance to discourage this move otherwise.

	ld a, [wPlayerTurnsTaken]
	and a
	jr z, .first_turn

	call AI_80_20
	ret c
	inc [hl]
	ret

.first_turn
	call BattleRandom
	cp 79 percent - 1
	ret nc
	dec [hl]
	ret

AI_Smart_Safeguard:
; 80% chance to discourage this move if player's HP is below 50%.
; Dismiss it if the player's Infiltrator ignores Safeguard anyway.

	call AIGetPlayerAbility
	cp INFILTRATOR
	jp z, AIDiscourageMove
	call AICheckPlayerHalfHP
	ret c
	call AI_80_20
	ret c
	inc [hl]
	ret

AI_Smart_Magnitude:
AI_Smart_Earthquake:
; Greatly encourage this move if the player is underground and the enemy is faster.
	ld a, [wLastPlayerCounterMove]
	push hl
	call GetMoveIndexFromID
	ld a, h
	if HIGH(DIG)
		cp HIGH(DIG)
	else
		and a
	endc
	ld a, l
	pop hl
	ret nz
	cp LOW(DIG)
	ret nz

	ld a, [wPlayerSubStatus3]
	bit SUBSTATUS_UNDERGROUND, a
	jr z, .could_dig

	call AICompareSpeed
	ret nc
	dec [hl]
	dec [hl]
	ret

.could_dig
	; Try to predict if the player will use Dig this turn.

	; 50% chance to encourage this move if the enemy is slower than the player.
	call AICompareSpeed
	ret c

	call AI_50_50
	ret c

	dec [hl]
	ret

AI_Smart_BatonPass:
; Discourage this move if the player hasn't shown super-effective moves against the enemy.
; Consider player's type(s) if its moves are unknown.

	push hl
	callfar CheckPlayerMoveTypeMatchups
	ld a, [wEnemyAISwitchScore]
	cp 10 ; neutral
	pop hl
	ret c
	inc [hl]
	ret

AI_Smart_Pursuit:
; 50% chance to greatly encourage this move if player's HP is below 25%.
; 80% chance to discourage this move otherwise.

	call AICheckPlayerQuarterHP
	jr nc, .asm_3907d
	call AI_80_20
	ret c
	inc [hl]
	ret

.asm_3907d
	call AI_50_50
	ret c
	dec [hl]
	dec [hl]
	ret

AI_Smart_RapidSpin:
; 80% chance to greatly encourage this move if the enemy is
; trapped (Bind effect), seeded, or scattered with spikes.

	ld a, [wEnemyWrapCount]
	and a
	jr nz, .asm_39097

	ld a, [wEnemySubStatus4]
	bit SUBSTATUS_LEECH_SEED, a
	jr nz, .asm_39097

	ld a, [wEnemyScreens]
	bit SCREENS_SPIKES, a
	ret z

.asm_39097
	call AI_80_20
	ret c

	dec [hl]
	dec [hl]
	ret

AI_Smart_HiddenPower:
	push hl
	ld a, 1
	ldh [hBattleTurn], a

; wEnemyMoveStruct already holds this mon's own Hidden Power type, its fixed
; power and its current category (AIGetEnemyMove patches them in), so the
; type matchup below uses the real type.
	callfar BattleCheckTypeMatchup
	pop hl

; Discourage Hidden Power if not very effective.
	ld a, [wTypeMatchup]
	cp EFFECTIVE
	jr c, .bad

; Encourage Hidden Power otherwise (its power is always
; HIDDEN_POWER_BASE_POWER; super-effective is covered too).
	dec [hl]
	ret

.bad
	inc [hl]
	ret

AI_Smart_RainDance:
; Greatly discourage this move if it would favour the player type-wise.
; Particularly, if the player is a Water-type.
	ld a, [wBattleMonType1]
	cp WATER
	jr z, AIBadWeatherType
	cp FIRE
	jr z, AIGoodWeatherType

	ld a, [wBattleMonType2]
	cp WATER
	jr z, AIBadWeatherType
	cp FIRE
	jr z, AIGoodWeatherType

	push hl
	ld hl, RainDanceMoves
	jr AI_Smart_WeatherMove

INCLUDE "data/battle/ai/rain_dance_moves.asm"

AI_Smart_SunnyDay:
; Greatly discourage this move if it would favour the player type-wise.
; Particularly, if the player is a Fire-type.
	ld a, [wBattleMonType1]
	cp FIRE
	jr z, AIBadWeatherType
	cp WATER
	jr z, AIGoodWeatherType

	ld a, [wBattleMonType2]
	cp FIRE
	jr z, AIBadWeatherType
	cp WATER
	jr z, AIGoodWeatherType

	push hl
	ld hl, SunnyDayMoves

	; fallthrough

AI_Smart_WeatherMove:
; Rain Dance, Sunny Day

; Greatly discourage this move if the enemy doesn't have
; one of the useful Rain Dance or Sunny Day moves.
	call AIHasMoveInArray
	pop hl
	jr nc, AIBadWeatherType

; Greatly discourage this move if player's HP is below 50%.
	call AICheckPlayerHalfHP
	jr nc, AIBadWeatherType

; 50% chance to encourage this move otherwise.
	call AI_50_50
	ret c

	dec [hl]
	ret

AIBadWeatherType:
	inc [hl]
	inc [hl]
	inc [hl]
	ret

AIGoodWeatherType:
; Rain Dance, Sunny Day

; Greatly encourage this move if it would disfavour the player type-wise and player's HP is above 50%...
	call AICheckPlayerHalfHP
	ret nc

; ...as long as one of the following conditions meet:
; It's the first turn of the player's Pokemon.
	ld a, [wPlayerTurnsTaken]
	and a
	jr z, .good

; Or it's the first turn of the enemy's Pokemon.
	ld a, [wEnemyTurnsTaken]
	and a
	ret nz

.good
	dec [hl]
	dec [hl]
	ret

INCLUDE "data/battle/ai/sunny_day_moves.asm"

AI_Smart_BellyDrum:
; Dismiss this move if enemy's attack is higher than +2 or if enemy's HP is below 50%.
; Else, discourage this move if enemy's HP is not full.

	ld a, [wEnemyAtkLevel]
	cp $a
	jr nc, .asm_3914d

	call AICheckEnemyMaxHP
	ret c

	inc [hl]

	call AICheckEnemyHalfHP
	ret c

.asm_3914d
	ld a, [hl]
	add $5
	ld [hl], a
	ret

AI_Smart_PsychUp:
	push hl
	ld hl, wEnemyAtkLevel
	ld b, $8
	ld c, 100

; Calculate the sum of all enemy's stat level modifiers. Add 100 first to prevent underflow.
; Put the result in c. c will range between 58 and 142.
.asm_3915a
	ld a, [hli]
	sub $7
	add c
	ld c, a
	dec b
	jr nz, .asm_3915a

; Calculate the sum of all player's stat level modifiers. Add 100 first to prevent underflow.
; Put the result in d. d will range between 58 and 142.
	ld hl, wPlayerAtkLevel
	ld b, $8
	ld d, 100

.asm_39169
	ld a, [hli]
	sub $7
	add d
	ld d, a
	dec b
	jr nz, .asm_39169

; Greatly discourage this move if enemy's stat levels are higher than player's (if c>=d).
	ld a, c
	sub d
	pop hl
	jr nc, .asm_39188

; Else, 80% chance to encourage this move unless player's accuracy level is lower than -1...
	ld a, [wPlayerAccLevel]
	cp $6
	ret c

; ...or enemy's evasion level is higher than +0.
	ld a, [wEnemyEvaLevel]
	cp $8
	ret nc

	call AI_80_20
	ret c

	dec [hl]
	ret

.asm_39188
	inc [hl]
	inc [hl]
	ret

AI_Smart_MirrorCoat:
	push hl
	ld hl, wPlayerUsedMoves
	ld c, $4
	ld b, $0

.asm_39193
	ld a, [hli]
	and a
	jr z, .asm_391a8

	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .asm_391a8

	ld a, [wEnemyMoveStruct + MOVE_CATEGORY]
	cp CATEGORIZE_SPECIAL
	jr nz, .asm_391a8

	inc b

.asm_391a8
	dec c
	jr nz, .asm_39193

	pop hl
	ld a, b
	and a
	jr z, .asm_391d3

	cp $3
	jr nc, .asm_391ca

	ld a, [wLastPlayerCounterMove]
	and a
	jr z, .asm_391d2

	call AIGetEnemyMove
	farcall HiddenPowerPatchPlayerLastMoveCategory

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .asm_391d2

	ld a, [wEnemyMoveStruct + MOVE_CATEGORY]
	cp CATEGORIZE_SPECIAL
	jr nz, .asm_391d2

.asm_391ca
	call BattleRandom
	cp 100
	jr c, .asm_391d2
	dec [hl]

.asm_391d2
	ret

.asm_391d3
	inc [hl]
	ret

AI_Smart_Twister:
AI_Smart_Gust:
; Greatly encourage this move if the player is flying and the enemy is faster.
	ld a, [wLastPlayerCounterMove]
	push hl
	call GetMoveIndexFromID
	ld a, h
	if HIGH(FLY)
		cp HIGH(FLY)
	else
		and a
	endc
	ld a, l
	pop hl
	ret nz
	cp LOW(FLY)
	ret nz

	ld a, [wPlayerSubStatus3]
	bit SUBSTATUS_FLYING, a
	jr z, .couldFly

	call AICompareSpeed
	ret nc

	dec [hl]
	dec [hl]
	ret

; Try to predict if the player will use Fly this turn.
.couldFly

; 50% chance to encourage this move if the enemy is slower than the player.
	call AICompareSpeed
	ret c
	call AI_50_50
	ret c
	dec [hl]
	ret

AI_Smart_FutureSight:
; Greatly encourage this move if the player is
; flying or underground, and slower than the enemy.

	call AICompareSpeed
	ret nc

	ld a, [wPlayerSubStatus3]
	and 1 << SUBSTATUS_FLYING | 1 << SUBSTATUS_UNDERGROUND
	ret z

	dec [hl]
	dec [hl]
	ret

AI_Smart_Stomp:
; 80% chance to encourage this move if the player has used Minimize.

	ld a, [wPlayerMinimized]
	and a
	ret z

	call AI_80_20
	ret c

	dec [hl]
	ret

AI_Smart_Solarbeam:
; 80% chance to encourage this move when it's sunny.
; 90% chance to discourage this move when it's raining.

	ld a, [wBattleWeather]
	and WEATHER_TYPE_MASK
	cp WEATHER_SUN
	jr z, .asm_3921e

	cp WEATHER_RAIN
	ret nz

	call BattleRandom
	cp 10 percent
	ret c

	inc [hl]
	inc [hl]
	ret

.asm_3921e
	call AI_80_20
	ret c

	dec [hl]
	dec [hl]
	ret

AI_Smart_Thunder:
; 90% chance to discourage this move when it's sunny.

	ld a, [wBattleWeather]
	and WEATHER_TYPE_MASK
	cp WEATHER_SUN
	ret nz

	call BattleRandom
	cp 10 percent
	ret c

	inc [hl]
	ret

AICompareSpeed:
; Return carry if enemy is faster than player.
; Elite trainers compare true effective speeds - Choice Scarf, Quick
; Feet/weather abilities, Unburden, paralysis and Trick Room - via the
; same routine the engine uses for real move order. Everyone else keeps
; the classic raw-stat comparison.

	push bc
	ld a, [wEnemyTrainerAIFlags + 1]
	bit AI_ELITE_F - 8, a
	jr z, .raw
	push hl
	push de
	farcall CompareSpeedsWithAbilities
	pop de
	pop hl
	pop bc
	ret

.raw
	ld a, [wEnemyMonSpeed + 1]
	ld b, a
	ld a, [wBattleMonSpeed + 1]
	cp b
	ld a, [wEnemyMonSpeed]
	ld b, a
	ld a, [wBattleMonSpeed]
	sbc b
	pop bc
	ret

AICheckPlayerMaxHP:
	push hl
	push de
	push bc
	ld de, wBattleMonHP
	ld hl, wBattleMonMaxHP
	jr AICheckMaxHP

AICheckEnemyMaxHP:
	push hl
	push de
	push bc
	ld de, wEnemyMonHP
	ld hl, wEnemyMonMaxHP
	; fallthrough

AICheckMaxHP:
; Return carry if hp at de matches max hp at hl.

	ld a, [de]
	inc de
	cp [hl]
	jr nz, .asm_39269

	inc hl
	ld a, [de]
	cp [hl]
	jr nz, .asm_39269

	pop bc
	pop de
	pop hl
	scf
	ret

.asm_39269
	pop bc
	pop de
	pop hl
	and a
	ret

AICheckPlayerHalfHP:
	push hl
	ld hl, wBattleMonHP
	ld b, [hl]
	inc hl
	ld c, [hl]
	sla c
	rl b
	inc hl
	inc hl
	ld a, [hld]
	cp c
	ld a, [hl]
	sbc b
	pop hl
	ret

AICheckEnemyHalfHP:
	push hl
	push de
	push bc
	ld hl, wEnemyMonHP
	ld b, [hl]
	inc hl
	ld c, [hl]
	sla c
	rl b
	inc hl
	inc hl
	ld a, [hld]
	cp c
	ld a, [hl]
	sbc b
	pop bc
	pop de
	pop hl
	ret

AICheckEnemyQuarterHP:
	push hl
	push de
	push bc
	ld hl, wEnemyMonHP
	ld b, [hl]
	inc hl
	ld c, [hl]
	sla c
	rl b
	sla c
	rl b
	inc hl
	inc hl
	ld a, [hld]
	cp c
	ld a, [hl]
	sbc b
	pop bc
	pop de
	pop hl
	ret

AICheckPlayerQuarterHP:
	push hl
	ld hl, wBattleMonHP
	ld b, [hl]
	inc hl
	ld c, [hl]
	sla c
	rl b
	sla c
	rl b
	inc hl
	inc hl
	ld a, [hld]
	cp c
	ld a, [hl]
	sbc b
	pop hl
	ret

AIHasMoveEffect:
; Return carry if the enemy has move b.

	push hl
	ld hl, wEnemyMonMoves
	ld c, wEnemyMonMovesEnd - wEnemyMonMoves

.checkmove
	ld a, [hli]
	and a
	jr z, .no

	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp b
	jr z, .yes

	dec c
	jr nz, .checkmove

.no
	pop hl
	and a
	ret

.yes
	pop hl
	scf
	ret

AIHasMoveInArray:
; Return carry if the enemy has a move in array hl.

	push de
	push bc
	push hl
	ld b, NUM_MOVES
	ld de, wEnemyMonMoves
.loop
	ld a, [de]
	inc de
	and a
	jr z, .next
	call GetMoveIndexFromID
	ld a, h
	ld c, l
	pop hl
	push hl
	push bc
	push de
	ld b, a
	ld de, 2
	call IsInHalfwordArray
	pop de
	pop bc
	jr c, .done
.next
	dec b
	jr nz, .loop
.done
	pop hl
	pop bc
	pop de
	ret

INCLUDE "data/battle/ai/useful_moves.asm"

AI_Opportunist:
; Discourage stall moves when the enemy's HP is low.

; Do nothing if enemy's HP is above 50%.
	call AICheckEnemyHalfHP
	ret c

; Discourage stall moves if enemy's HP is below 25%.
	call AICheckEnemyQuarterHP
	jr nc, .asm_39322

; 50% chance to discourage stall moves if enemy's HP is between 25% and 50%.
	call AI_50_50
	ret c

.asm_39322
	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld c, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	inc hl
	dec c
	jr z, .asm_39347

	ld a, [de]
	inc de
	and a
	jr z, .asm_39347

	push hl
	push de
	push bc
	ld hl, StallMoves
	call AI_CheckMoveInList

	pop bc
	pop de
	pop hl
	jr nc, .checkmove

	inc [hl]
	jr .checkmove

.asm_39347
	ret

INCLUDE "data/battle/ai/stall_moves.asm"


AI_Aggressive:
; Use whatever does the most damage.

; Discourage all damaging moves but the one that does the most damage.
; If no damaging move deals damage to the player (immune),
; no move will be discouraged

; Figure out which attack does the most damage and put it in c.
	ld hl, wEnemyMonMoves
	ld bc, 0
	ld de, 0
.checkmove
	inc b
	ld a, b
	cp wEnemyMonMovesEnd - wEnemyMonMoves + 1
	jr z, .gotstrongestmove

	ld a, [hli]
	and a
	jr z, .gotstrongestmove

	push hl
	push de
	push bc
	call AIGetEnemyMove
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .nodamage
	call AIDamageCalc
	pop bc
	pop de
	pop hl

; Update current move if damage is highest so far
	ld a, [wCurDamage + 1]
	cp e
	ld a, [wCurDamage]
	sbc d
	jr c, .checkmove

	ld a, [wCurDamage + 1]
	ld e, a
	ld a, [wCurDamage]
	ld d, a
	ld c, b
	jr .checkmove

.nodamage
	pop bc
	pop de
	pop hl
	jr .checkmove

.gotstrongestmove
; Nothing we can do if no attacks did damage.
	ld a, c
	and a
	ret z

; Discourage moves that do less damage unless they're reckless too.
	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, 0
.checkmove2
	inc b
	ld a, b
	cp wEnemyMonMovesEnd - wEnemyMonMoves + 1
	ret z

; Ignore this move if it is the highest damaging one.
	cp c
	ld a, [de]
	inc de
	inc hl
	jr z, .checkmove2

	call AIGetEnemyMove

; Ignore this move if its power is 0 or 1.
; Moves such as Seismic Toss, Hidden Power,
; Counter and Fissure have a base power of 1.
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	cp 2
	jr c, .checkmove2

; Ignore this move if it is reckless.
	push hl
	push de
	push bc
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	ld hl, RecklessMoves
	ld de, 1
	call IsInArray
	pop bc
	pop de
	pop hl
	jr c, .checkmove2

; If we made it this far, discourage this move.
	inc [hl]
	jr .checkmove2

INCLUDE "data/battle/ai/reckless_moves.asm"

AIDamageCalc:
	ld a, 1
	ldh [hBattleTurn], a
	ld [wAIDamagePrediction], a
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	ld de, 1
	ld hl, ConstantDamageEffects
	call IsInArray
	jr nc, .formula
	callfar BattleCommand_ConstantDamage
	jr .done

.formula
	callfar AIPredictVariableMoveCategory_Core
	callfar EnemyAttackDamage
	callfar AIPredictVariableMovePower_Core
	callfar BattleCommand_DamageCalc
	callfar BattleCommand_Stab
	callfar AIPredictVariableMoveDamage_Core
.done
	xor a
	ld [wAIDamagePrediction], a
	ret

INCLUDE "data/battle/ai/constant_damage_effects.asm"

AI_SmartDamageKO:
; Universal layer applied to all trainers (called from AIChooseMove).
; Uses the real damage formula:
; - If the strongest damaging move is guaranteed to KO the player
;   (even on a minimum damage roll), greatly encourage it.
; - Otherwise, encourage the strongest damaging move and discourage
;   damaging moves that deal less than half as much.

; Pass 1: find the usable attack that does the most damage; index in c.
	ld hl, wEnemyMonMoves
	ld bc, 0
	ld de, 0
.checkmove
	inc b
	ld a, b
	cp NUM_MOVES + 1
	jr z, .gotstrongestmove

	ld a, [hli]
	and a
	jr z, .gotstrongestmove

	push hl
	push de
	push bc

; Skip moves that other layers have dismissed as unusable (score 50+).
	ld e, a
	ld hl, wBuffer1 - 1
	ld c, b
	ld b, 0
	add hl, bc
	ld a, [hl]
	cp 50
	jr nc, .nodamage

	ld a, e
	call AIGetEnemyMove

; Skip non-damaging moves and self-destructive moves.
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .nodamage
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_SELFDESTRUCT
	jr z, .nodamage

	call AIDamageCalc
	pop bc
	pop de
	pop hl

; Update the best move if this damage is the highest so far.
	ld a, [wCurDamage + 1]
	cp e
	ld a, [wCurDamage]
	sbc d
	jr c, .checkmove

	ld a, [wCurDamage + 1]
	ld e, a
	ld a, [wCurDamage]
	ld d, a
	ld c, b
	jr .checkmove

.nodamage
	pop bc
	pop de
	pop hl
	jr .checkmove

.gotstrongestmove
; Nothing to do if no move does damage.
	ld a, c
	and a
	ret z
; Nothing to do if the best damage is zero (player is immune to everything).
	ld a, d
	or e
	ret z

; Estimate the minimum damage roll as roughly 13/16 of max damage.
	push de
	ld h, d
	ld l, e
	srl h
	rr l
	srl h
	rr l
	srl h
	rr l
; hl = max damage / 8
	ld a, e
	sub l
	ld e, a
	ld a, d
	sbc h
	ld d, a
	srl h
	rr l
; hl = max damage / 16
	ld a, e
	sub l
	ld e, a
	ld a, d
	sbc h
	ld d, a
; de = 13/16 of max damage

; Is that enough to KO the player?
	ld a, [wBattleMonHP + 1]
	ld l, a
	ld a, [wBattleMonHP]
	ld h, a
	ld a, e
	sub l
	ld a, d
	sbc h
	pop de
	jr c, .no_ko

; Elite trainers know that a full-HP Focus Sash or Sturdy denies the KO.
	call AIElitePlayerDeniesKO
	jr c, .no_ko

; Guaranteed KO: greatly encourage the strongest move.
	ld hl, wBuffer1 - 1
	ld b, 0
	add hl, bc
	dec [hl]
	dec [hl]
	dec [hl]
	ret

.no_ko
; Encourage the strongest damaging move.
	ld hl, wBuffer1 - 1
	ld b, 0
	add hl, bc
	dec [hl]

; Pass 2: discourage damaging moves that deal
; less than half as much as the strongest move.
	srl d
	rr e
	ld hl, wEnemyMonMoves
	ld b, 0
.checkmove2
	inc b
	ld a, b
	cp NUM_MOVES + 1
	ret z

	ld a, [hli]
	and a
	ret z

	push hl
	push de
	push bc

; Skip the strongest move itself.
	ld e, a
	ld a, b
	cp c
	jr z, .skip2

; Skip dismissed moves.
	ld hl, wBuffer1 - 1
	ld c, b
	ld b, 0
	add hl, bc
	ld a, [hl]
	cp 50
	jr nc, .skip2

	ld a, e
	call AIGetEnemyMove

; Ignore status moves and moves with variable base power
; (Seismic Toss, Hidden Power, Counter, etc. have base power 0 or 1).
	ld a, [wEnemyMoveStruct + MOVE_POWER]
	cp 2
	jr c, .skip2

	call AIDamageCalc
	pop bc
	pop de
	pop hl

; Carry if this move's damage is less than half the best move's.
	ld a, [wCurDamage + 1]
	cp e
	ld a, [wCurDamage]
	sbc d
	jr nc, .checkmove2

	push hl
	push bc
	ld hl, wBuffer1 - 1
	ld c, b
	ld b, 0
	add hl, bc
	inc [hl]
	pop bc
	pop hl
	jr .checkmove2

.skip2
	pop bc
	pop de
	pop hl
	jr .checkmove2

AI_Cautious:
; 90% chance to discourage moves with residual effects after the first turn.

	ld a, [wEnemyTurnsTaken]
	and a
	ret z

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld c, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.asm_39425
	inc hl
	dec c
	ret z

	ld a, [de]
	inc de
	and a
	ret z

	push hl
	push de
	push bc
	ld hl, ResidualMoves
	call AI_CheckMoveInList

	pop bc
	pop de
	pop hl
	jr nc, .asm_39425

	call BattleRandom
	cp 90 percent + 1
	jr nc, .asm_39425

	inc [hl]
	jr .asm_39425

INCLUDE "data/battle/ai/residual_moves.asm"


AI_Status:
; Dismiss status moves that don't affect the player.

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_TOXIC
	jr z, .poisonimmunity
	cp EFFECT_POISON
	jr z, .poisonimmunity
	cp EFFECT_SLEEP
	jr z, .typeimmunity
	cp EFFECT_PARALYZE
	jr z, .typeimmunity
	cp EFFECT_BURN
	jr z, .burnimmunity

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .checkmove

	jr .typeimmunity

.poisonimmunity
; Our own Corrosion poisons Poison- and Steel-types regardless.
	call AIGetEnemyAbility
	cp CORROSION
	jr z, .checkmove
	ld a, [wBattleMonType1]
	cp POISON
	jr z, .immune
	ld a, [wBattleMonType2]
	cp POISON
	jr z, .immune
	jr .typeimmunity

.burnimmunity
	ld a, [wBattleMonType1]
	cp FIRE
	jr z, .immune
	ld a, [wBattleMonType2]
	cp FIRE
	jr z, .immune

.typeimmunity
	push hl
	push bc
	push de
	ld a, 1
	ldh [hBattleTurn], a
	callfar BattleCheckTypeMatchup
	pop de
	pop bc
	pop hl

	ld a, [wTypeMatchup]
	and a
	jr nz, .checkmove

.immune
	call AIDiscourageMove
	jr .checkmove


AI_Risky:
; Use any move that will KO the target.
; Risky moves will often be an exception (see below).

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld c, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	inc hl
	dec c
	ret z

	ld a, [de]
	inc de
	and a
	ret z

	push de
	push bc
	push hl
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .nextmove

; Don't use risky moves at max hp.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	ld de, 1
	ld hl, RiskyEffects
	call IsInArray
	jr nc, .checkko

	call AICheckEnemyMaxHP
	jr c, .nextmove

; Else, 80% chance to exclude them.
	call BattleRandom
	cp 79 percent - 1
	jr c, .nextmove

.checkko
	call AIDamageCalc

	ld a, [wCurDamage + 1]
	ld e, a
	ld a, [wCurDamage]
	ld d, a
	ld a, [wBattleMonHP + 1]
	cp e
	ld a, [wBattleMonHP]
	sbc d
	jr nc, .nextmove

	pop hl
rept 5
	dec [hl]
endr
	push hl

.nextmove
	pop hl
	pop bc
	pop de
	jr .checkmove

INCLUDE "data/battle/ai/risky_effects.asm"


; ==== AI_Smart handlers for the newer (Gen 4-9) move effects ==============

AI_Smart_Spikes:
; Dismiss once all three layers are down or the player is on their last
; mon. Otherwise encourage strongly during the first couple of turns.
	ld a, [wPlayerSpikesLayers]
	cp 3
	jr c, .none_yet
	jp AIDiscourageMove
.none_yet
	ld a, [wPartyCount]
	cp 2
	ret c ; no point vs the player's last mon
	ld a, [wEnemyTurnsTaken]
	cp 2
	ret nc
	dec [hl]
	dec [hl]
	ret

AI_Smart_ToxicSpikes:
; Same idea, but two layers can be set.
	ld a, [wPlayerScreens]
	and SCREENS_TOXIC_SPIKES_MASK
	cp SCREENS_TOXIC_SPIKES_MASK
	jp z, AIDiscourageMove ; both layers already down
	ld a, [wPartyCount]
	cp 2
	ret c
	ld a, [wEnemyTurnsTaken]
	cp 2
	ret nc
	dec [hl]
	dec [hl]
	ret

AI_Smart_StealthRock:
	ld a, [wPlayerScreens]
	bit SCREENS_STEALTH_ROCK, a
	jr z, .none_yet
	jp AIDiscourageMove
.none_yet
	ld a, [wPartyCount]
	cp 2
	ret c
	ld a, [wEnemyTurnsTaken]
	cp 2
	ret nc
	dec [hl]
	dec [hl]
	ret

AI_Smart_StickyWeb:
; Dismiss once a web is already down or the player is on their last mon.
	ld a, [wPlayerScreens]
	bit SCREENS_STICKY_WEB, a
	jr z, .none_yet
	jp AIDiscourageMove
.none_yet
	ld a, [wPartyCount]
	cp 2
	ret c
	ld a, [wEnemyTurnsTaken]
	cp 2
	ret nc
	dec [hl]
	dec [hl]
	ret

AI_Smart_Torment:
; Useless against an already tormented target.
	ld a, [wPlayerSubStatus2]
	bit SUBSTATUS_TORMENTED, a
	ret z
	jp AIDiscourageMove

AI_Smart_Taunt:
; Useless against an already taunted target; mildly encourage early.
	ld a, [wPlayerTauntCount]
	and a
	jr z, .not_taunted
	jp AIDiscourageMove
.not_taunted
	ld a, [wEnemyTurnsTaken]
	cp 2
	ret nc
	dec [hl]
	ret

AI_Smart_Yawn:
; Useless if the player is statused or already drowsy.
	ld a, [wBattleMonStatus]
	and a
	jr nz, .useless
	ld a, [wPlayerYawnCount]
	and a
	ret z
.useless
	jp AIDiscourageMove

AI_Smart_Wish:
; Useless if a Wish is already pending; encourage when hurt.
	ld a, [wEnemyWishCount]
	and a
	jr z, .no_wish_yet
	jp AIDiscourageMove
.no_wish_yet
	call AICheckEnemyHalfHP
	ret c ; healthy: leave the default score
	dec [hl]
	ret

AI_Smart_Defog:
; Defog clears hazards on BOTH sides plus the target's screens.
; Encourage if our side has hazards or the player has screens up;
; discourage if it would only blow away our own hazards.
	ld a, [wEnemyScreens]
	and SCREENS_HAZARDS_MASK
	jr nz, .useful
	ld a, [wPlayerScreens]
	and (1 << SCREENS_LIGHT_SCREEN) | (1 << SCREENS_REFLECT)
	jr nz, .useful
	ld a, [wPlayerScreens]
	and SCREENS_HAZARDS_MASK
	ret z ; nothing anywhere: leave the default score
	jp AIDiscourageMove
.useful
	ld a, [wPlayerScreens]
	and SCREENS_HAZARDS_MASK
	jr nz, .mild ; we'd also clear our own hazards off the player's side
	dec [hl]
	dec [hl]
	ret
.mild
	dec [hl]
	ret

AI_Smart_UTurn:
; Pivot out when weakened, if there is a teammate to pivot to.
	ld a, [wOTPartyCount]
	cp 2
	ret c
	call AICheckEnemyHalfHP
	ret c ; above half HP: treat as a normal attack
	dec [hl]
	ret

AI_Smart_TrickRoom:
	ld a, [wTrickRoomTimer]
	and a
	jp nz, AIDiscourageMove ; would switch our own Trick Room off
	call AICompareSpeed
	jp c, AIDiscourageMove ; we're faster; don't invert the speed order
	dec [hl]
	dec [hl]
	ret

AI_Smart_KnockOff:
; Encourage if the player is actually holding something.
; - Sticky Hold keeps the item on: no bonus (Mold Breaker pierces it).
; - Unburden: knocking the item off doubles their Speed. Discourage.
; - Berry abilities (Gluttony, Ripen, Harvest, Cud Chew) make a held
;   Berry worth a lot more to the player: extra encouragement to remove it.
	ld a, [wBattleMonItem]
	and a
	ret z
	call AIGetPlayerAbility ; as our moves experience it (Mold Breaker pierces)
	cp STICKY_HOLD
	ret z
	cp UNBURDEN
	jr z, .unburden
	dec [hl]
; Is the item a Berry the player's ability leans on?
	cp GLUTTONY
	jr z, .berry_ability
	cp RIPEN
	jr z, .berry_ability
	cp HARVEST
	jr z, .berry_ability
	cp CUD_CHEW
	ret nz
.berry_ability
	call AIPlayerHoldsBerry
	ret nc
	dec [hl]
	ret
.unburden
	inc [hl]
	inc [hl]
	ret

AI_Smart_FoulPlay:
; Encourage when the player's Attack has been boosted.
	ld a, [wPlayerAtkLevel]
	cp BASE_STAT_LEVEL + 1
	ret c
	dec [hl]
	ret

AI_Smart_FreezeDry:
; Freeze-Dry is super effective against Water, which AI_Types cannot know.
	ld a, [wBattleMonType1]
	cp WATER
	jr z, .water
	ld a, [wBattleMonType2]
	cp WATER
	ret nz
.water
	dec [hl]
	dec [hl]
	ret

AI_Smart_FakeOut:
	ld a, [wEnemyTurnsTaken]
	and a
	jr z, .first_turn
	jp AIDiscourageMove ; fails after the user's first turn
.first_turn
; The flinch is the whole point: Shield Dust and Inner Focus block it.
	call AIGetPlayerAbility
	cp SHIELD_DUST
	jr z, .no_flinch
	cp INNER_FOCUS
	jr z, .no_flinch
	dec [hl]
	ret
.no_flinch
	inc [hl]
	ret

AI_Smart_Venoshock:
; Doubled power against a poisoned target.
	ld a, [wBattleMonStatus]
	bit PSN, a
	ret z
	dec [hl]
	dec [hl]
	ret

AI_Smart_Hex:
; Doubled power against a statused target.
	ld a, [wBattleMonStatus]
	and a
	ret z
	dec [hl]
	dec [hl]
	ret

AI_Smart_Facade:
; Doubled power while we are burned, poisoned or paralyzed.
	ld a, [wEnemyMonStatus]
	and (1 << PSN) | (1 << BRN) | (1 << PAR)
	ret z
	dec [hl]
	dec [hl]
	ret

AI_Smart_CircleThrow:
; Phazing is worth more with hazards on the player's side of the field.
; (Not against Suction Cups: the drag-out part fails.)
	ld a, [wPartyCount]
	cp 2
	ret c
	call AIGetPlayerAbility
	cp SUCTION_CUPS
	ret z
	ld a, [wPlayerScreens]
	and SCREENS_HAZARDS_MASK
	ret z
	dec [hl]
	ret


AI_Abilities:
; Ability and held-item awareness (AI_ABILITIES flag; given to every class
; that has AI_SMART):
; - While Choice-locked, dismiss every move except the locked one.
; - Dismiss damaging moves whose predicted damage is zero: the player's
;   ability (Levitate, Flash Fire, Water/Volt Absorb, Dry Skin, Sap Sipper,
;   Lightning Rod, Storm Drain, Motor Drive, Soundproof, Bulletproof,
;   Wind Rider), Air Balloon or Disguise nullifies them. The prediction
;   reuses the real damage formula, so Mold Breaker and Neutralizing Gas
;   are respected automatically.
; - Dismiss self-KO moves that the player's Damp would block.
; - Dismiss Roar/Whirlwind into Suction Cups.
; - Discourage status moves aimed at a Magic Bounce user, or at a player
;   protected by a Substitute (unless our Infiltrator pierces it).
; - Mildly discourage contact moves when the player's ability or held
;   Rocky Helmet punishes contact (a Klutz holder's Helmet is inert), or
;   when an empty-handed Pickpocket would take our item.

	ld a, 1
	ldh [hBattleTurn], a

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	push de
	push bc
	ld c, a ; c = current move id

; While Choice-locked, dismiss every move except the locked one.
	ld a, [wEnemyChoiceLockedMove]
	and a
	jr z, .no_choice_lock
	cp c
	jr z, .no_choice_lock
	ld a, [hl]
	add 30
	ld [hl], a
	jp .done
.no_choice_lock

	ld a, c
	call AIGetEnemyMove

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .status_move

; Damaging move: predict the real damage. RunNullificationAbilities runs
; inside this calc and zeroes wCurDamage when the player's ability or item
; nullifies the move.
	push hl
	push bc
	call AIDamageCalc
	pop bc
	pop hl
	ld a, [wCurDamage]
	ld d, a
	ld a, [wCurDamage + 1]
	or d
	jr nz, .not_nullified
	ld a, [hl]
	add 30
	ld [hl], a
	jp .done

.not_nullified
; Damp blocks self-KO moves outright.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_SELFDESTRUCT
	jr nz, .no_boom
	ld a, [wEnemyAbility]
	cp MOLD_BREAKER
	jr z, .no_boom
	call AIGetPlayerAbilityEffective
	cp DAMP
	jr nz, .no_boom
	ld a, [hl]
	add 30
	ld [hl], a
	jr .done
.no_boom

; Contact punishment: Rocky Helmet and on-contact abilities.
	push hl
	push bc
	farcall CheckContactMoveID ; c = move id
	pop bc
	pop hl
	jr nc, .done
	call .PlayerPunishesContact
	jr nc, .done
	inc [hl]
	inc [hl]
	jr .done

.status_move
; Suction Cups anchors the player: Roar and Whirlwind fail outright.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_FORCE_SWITCH
	jr nz, .no_anchor
	call AIGetPlayerAbility ; as our moves experience it (Mold Breaker pierces)
	cp SUCTION_CUPS
	jr nz, .no_anchor
	ld a, [hl]
	add 30
	ld [hl], a
	jr .done
.no_anchor

; Magic Bounce reflects status moves aimed at the player or their side.
	ld a, [wEnemyAbility]
	cp MOLD_BREAKER
	jr z, .no_bounce
	call AIGetPlayerAbilityEffective
	cp MAGIC_BOUNCE
	jr nz, .no_bounce
	call .TargetsPlayerStatus
	jr nc, .done
	call AIDiscourageMove
	jr .done

.no_bounce
; A Substitute blocks direct status and stat-drop moves (hazards still
; work) - unless our Infiltrator goes straight through it.
	ld a, [wPlayerSubStatus4]
	bit SUBSTATUS_SUBSTITUTE, a
	jr z, .done
	call AIGetEnemyAbility
	cp INFILTRATOR
	jr z, .done
	call .TargetsPlayerDirect
	jr nc, .done
	call AIDiscourageMove

.done
	pop bc
	pop de
	jp .checkmove

.TargetsPlayerStatus:
; carry if the scored move is a status/stat-drop/hazard move aimed at the
; player's side, i.e. something Magic Bounce would reflect.
	call .TargetsPlayerDirect
	ret c
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	push hl
	push de
	push bc
	ld hl, AIHazardEffects
	ld de, 1
	call IsInArray
	pop bc
	pop de
	pop hl
	ret

.TargetsPlayerDirect:
; carry if the scored move inflicts status, stat drops or other direct
; conditions on the player (the class of moves a Substitute blocks).
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_ATTACK_DOWN
	jr c, .direct_not_range1
	cp EFFECT_EVASION_DOWN + 1
	jr c, .direct_yes
.direct_not_range1
	cp EFFECT_ATTACK_DOWN_2
	jr c, .direct_list
	cp EFFECT_EVASION_DOWN_2 + 1
	jr c, .direct_yes
.direct_list
	push hl
	push de
	push bc
	ld hl, AIDirectStatusEffects
	ld de, 1
	call IsInArray
	pop bc
	pop de
	pop hl
	ret
.direct_yes
	scf
	ret

.PlayerPunishesContact:
; carry if the player's held item or ability punishes contact moves.
	ld a, [wBattleMonItem]
	cp ROCKY_HELMET
	jr nz, .no_helmet
; A Klutz holder's Rocky Helmet does nothing.
	call AIGetPlayerAbility
	cp KLUTZ
	jr nz, .punish_yes
.no_helmet
	call AIGetPlayerAbilityEffective
	cp IRON_BARBS
	jr z, .punish_yes
	cp TANGLING_HAIR
	jr z, .punish_yes
	cp PERISH_BODY
	jr z, .punish_yes
; Pickpocket steals our held item on contact if the player holds nothing.
	cp PICKPOCKET
	jr nz, .not_pickpocket
	ld a, [wBattleMonItem]
	and a
	jr nz, .not_pickpocket_no ; their hands are full: nothing to fear
	ld a, [wEnemyMonItem]
	and a
	jr nz, .punish_yes ; we'd lose our item
.not_pickpocket_no
	and a ; nc
	ret
.not_pickpocket
; Status-inflicting contact abilities only matter if we can be afflicted.
	ld d, a
	ld a, [wEnemyMonStatus]
	and a
	ret nz ; nc: already statused, nothing to fear
	ld a, d
	cp STATIC
	jr z, .punish_yes
	cp FLAME_BODY
	jr z, .punish_yes
	cp POISON_POINT
	jr z, .punish_yes
	cp EFFECT_SPORE
	jr z, .punish_yes
	cp CUTE_CHARM
	jr z, .punish_yes
	and a ; nc
	ret
.punish_yes
	scf
	ret

AIDirectStatusEffects:
; status moves that directly afflict the player: reflected by Magic Bounce
; and blocked by a Substitute
	db EFFECT_SLEEP
	db EFFECT_TOXIC
	db EFFECT_POISON
	db EFFECT_PARALYZE
	db EFFECT_BURN
	db EFFECT_CONFUSE
	db EFFECT_ATTRACT
	db EFFECT_LEECH_SEED
	db EFFECT_MEAN_LOOK
	db EFFECT_SWAGGER
	db -1 ; end

AIHazardEffects:
; entry hazards: reflected by Magic Bounce, but NOT blocked by a Substitute
	db EFFECT_SPIKES
	db EFFECT_TOXIC_SPIKES
	db EFFECT_STEALTH_ROCK
	db -1 ; end


AIElitePlayerDeniesKO:
; carry if an elite trainer should assume the player survives a move
; that would otherwise KO: full HP with a Focus Sash, or full HP with
; Sturdy (as our moves experience it, so Mold Breaker pierces).
; Returns nc for non-elite trainers. Preserves bc, de, hl.
; Assumes hBattleTurn is the enemy's (every AI caller sets it).
	ld a, [wEnemyTrainerAIFlags + 1]
	bit AI_ELITE_F - 8, a
	jr z, .no
	call AICheckPlayerMaxHP
	jr nc, .no
	call AIGetPlayerAbility ; as our moves experience it (Mold Breaker pierces)
	cp STURDY
	jr z, .yes
	ld a, [wBattleMonItem]
	cp FOCUS_SASH
	jr nz, .no
; A Klutz holder's Focus Sash never triggers.
	call AIGetPlayerAbility
	cp KLUTZ
	jr nz, .yes
.no
	and a
	ret
.yes
	scf
	ret

AIElitePlayerLockedHarmless:
; carry if the player is Choice-locked into a damaging move that cannot
; touch the active enemy mon (type immunity, or an ability from the
; nullification table). The lock is established state from previous
; turns - this never reads the player's pending action, so a predicted
; switch-out still beats us. Preserves bc, de, hl.
	push hl
	push de
	push bc
	ld a, [wPlayerChoiceLockedMove]
	and a
	jr z, .no
	call GetPlayerMoveTypeIfDamaging
	jr z, .no ; locked into a status move: it can still cripple us
	ld d, a ; d = locked move's type
; Does our own ability swallow it? (Not if the player's Mold Breaker
; ignores it.)
	ld a, [wPlayerAbility]
	cp MOLD_BREAKER
	jr z, .type_only
	push de
	farcall GetEnemyAbilityEffective_b ; b = our effective ability
	pop de
	ld c, d
	push de
	farcall AbilityNullifiesType ; in: b = ability, c = type
	pop de
	jr c, .yes
.type_only
; Is the locked move's type simply immune against our typing?
	ld a, d
	ld hl, wEnemyMonType1
	call AISwitch_CheckTypeMatchup
	ld a, [wTypeMatchup]
	and a
	jr nz, .no
.yes
	pop bc
	pop de
	pop hl
	scf
	ret
.no
	pop bc
	pop de
	pop hl
	and a
	ret

AI_Elite:
; Boss-trainer intelligence (AI_ELITE flag): gym leaders, rivals, the
; Elite Four, Rocket executives, Red, and Battle Tower trainers.
; Full knowledge of the player's ACTIVE mon - its real ability, held
; item and typing - but NEVER the player's pending action this turn,
; and never the player's bench. Predictions stay rewarded: switching an
; immune mon into a telegraphed move always works.
; - Dismiss status moves the player's ability or typing makes fail
;   (sleep vs Insomnia, T-Wave vs Ground/Electric/Limber, Toxic vs
;   Steel/Immunity, Will-O-Wisp vs Fire/Water Veil/Flash Fire, ...).
; - Dismiss stat-drop moves that Clear Body-style abilities block, that
;   Contrary inverts, or that Defiant/Competitive would exploit.
; - Dismiss OHKO moves into Sturdy; don't Explode into a full-HP Focus
;   Sash / Sturdy holder (a Klutz holder's Sash never triggers).
; - Sleep is worth less against Early Bird (wakes in half the time).
; - Dismiss Atk/Def/SpA/SpD/evasion setup against Unaware (it ignores
;   those stages both ways); only discourage mixed Speed boosts.
; - If the player is Choice-locked into a move that cannot touch us,
;   the turn is free: greatly encourage setup moves and Substitute.

	ld a, 1
	ldh [hBattleTurn], a

	ld hl, wBuffer1 - 1
	ld de, wEnemyMonMoves
	ld b, wEnemyMonMovesEnd - wEnemyMonMoves + 1
.checkmove
	dec b
	ret z

	inc hl
	ld a, [de]
	and a
	ret z

	inc de
	push de
	push bc
	call AIGetEnemyMove

; OHKO moves first: Guillotine has 0 listed power (Horn Drill and
; Fissure have 1), so the power test below would misroute it.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_OHKO
	jr z, .ohko

	ld a, [wEnemyMoveStruct + MOVE_POWER]
	and a
	jr z, .status_move

; --- Damaging moves ---
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_SELFDESTRUCT
	jp nz, .done
; Don't trade the mon into a target a full-HP Sash/Sturdy keeps alive.
	call AIElitePlayerDeniesKO
	jp nc, .done
	call AIDiscourageMove
	jp .done

.ohko
; Sturdy blocks OHKO moves outright; a full-HP Sash survives at 1 HP.
	call .GetPlayerAbility
	ld a, e
	cp STURDY
	jp z, .dismiss
	call AIElitePlayerDeniesKO
	jp nc, .done
	call AIDiscourageMove
	jp .done

.status_move
	call .GetPlayerAbility ; e = player ability as our moves experience it

; Sap Sipper absorbs Grass-type status moves (Spore, Stun Spore, ...).
	ld a, [wEnemyMoveStruct + MOVE_TYPE]
	cp GRASS
	jr nz, .grass_ok
	ld a, e
	cp SAP_SIPPER
	jp z, .dismiss
.grass_ok

	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_SLEEP
	jr z, .sleep
	cp EFFECT_PARALYZE
	jr z, .paralyze
	cp EFFECT_TOXIC
	jr z, .poison
	cp EFFECT_POISON
	jr z, .poison
	cp EFFECT_BURN
	jp z, .burn
	cp EFFECT_CONFUSE
	jp z, .confuse
	cp EFFECT_SWAGGER
	jp z, .confuse
	cp EFFECT_ATTRACT
	jp z, .attract
	cp EFFECT_LEECH_SEED
	jp z, .leech_seed
	call .IsStatDown
	jp c, .stat_down
	jp .setup_check

.sleep
	ld a, e
	cp INSOMNIA
	jp z, .dismiss
	cp VITAL_SPIRIT
	jp z, .dismiss
; Early Bird sleeps half as long: still worth it, but less so.
	cp EARLY_BIRD
	jp nz, .leaf_guard
	inc [hl]
	inc [hl]
	jp .leaf_guard

.paralyze
	ld a, [wBattleMonType1]
	cp ELECTRIC
	jp z, .dismiss
	ld a, [wBattleMonType2]
	cp ELECTRIC
	jp z, .dismiss
	call .MoveTypeImmune
	jp c, .dismiss
	ld a, e
	cp LIMBER
	jp z, .dismiss
	jp .leaf_guard

.poison
	ld a, e
	cp IMMUNITY
	jp z, .dismiss
	cp PASTEL_VEIL
	jp z, .dismiss
; Our own Corrosion poisons straight through Poison/Steel typing
; (effective ability, so Neutralizing Gas suppression is respected).
	push hl
	push de
	push bc
	farcall GetEnemyAbilityEffective_b
	ld a, b
	pop bc
	pop de
	pop hl
	cp CORROSION
	jp z, .leaf_guard
	ld a, [wBattleMonType1]
	cp POISON
	jp z, .dismiss
	cp STEEL
	jp z, .dismiss
	ld a, [wBattleMonType2]
	cp POISON
	jp z, .dismiss
	cp STEEL
	jp z, .dismiss
	jp .leaf_guard

.burn
	ld a, e
	cp WATER_VEIL
	jp z, .dismiss
	cp THERMAL_EXCHANGE
	jp z, .dismiss
	ld a, [wBattleMonType1]
	cp FIRE
	jp z, .dismiss
	ld a, [wBattleMonType2]
	cp FIRE
	jp z, .dismiss
	ld a, [wEnemyMoveStruct + MOVE_TYPE]
	cp FIRE
	jr nz, .leaf_guard
	ld a, e
	cp FLASH_FIRE
	jp z, .dismiss
	jr .leaf_guard

.confuse
	ld a, e
	cp OWN_TEMPO
	jp z, .dismiss
	jp .done

.attract
	ld a, e
	cp OBLIVIOUS
	jp z, .dismiss
	jp .done

.leech_seed
	ld a, [wBattleMonType1]
	cp GRASS
	jp z, .dismiss
	ld a, [wBattleMonType2]
	cp GRASS
	jp z, .dismiss
	jp .done

.leaf_guard
; Leaf Guard blocks major status while the sun is out.
	ld a, e
	cp LEAF_GUARD
	jp nz, .done
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jp nz, .done
.dismiss
	ld a, [hl]
	add 30
	ld [hl], a
	jr .done

.stat_down
; Clear Body/White Smoke/Mirror Armor block stat drops, Contrary inverts
; them, and Defiant/Competitive punish them with free boosts.
	ld a, e
	cp CLEAR_BODY
	jr z, .dismiss
	cp WHITE_SMOKE
	jr z, .dismiss
	cp MIRROR_ARMOR
	jr z, .dismiss
	cp CONTRARY
	jr z, .dismiss
	cp DEFIANT
	jr z, .dismiss
	cp COMPETITIVE
	jr z, .dismiss
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_ATTACK_DOWN
	jr z, .atk_down
	cp EFFECT_ATTACK_DOWN_2
	jr z, .atk_down
	cp EFFECT_DEFENSE_DOWN
	jr z, .def_down
	cp EFFECT_DEFENSE_DOWN_2
	jr z, .def_down
	cp EFFECT_ACCURACY_DOWN
	jr z, .acc_down
	cp EFFECT_ACCURACY_DOWN_2
	jr z, .acc_down
	jr .done
.atk_down
	ld a, e
	cp HYPER_CUTTER
	jr z, .dismiss
	jr .done
.def_down
	ld a, e
	cp BIG_PECKS
	jr z, .dismiss
	jr .done
.acc_down
	ld a, e
	cp KEEN_EYE
	jr z, .dismiss
	cp MINDS_EYE
	jr z, .dismiss
	jr .done

.setup_check
; Unaware ignores our Atk/Def/SpA/SpD stages both ways and sees through
; raised evasion, so boosting those is wasted against it. Pure boosts are
; dismissed; mixed boosts that also raise Speed (Dragon Dance, Shell
; Smash, Quiver Dance) are merely discouraged.
	ld a, e
	cp UNAWARE
	jr nz, .not_unaware
	call .IsUnawareWastedSetup
	jr nc, .not_unaware
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_DRAGON_DANCE
	jr z, .mixed_setup
	cp EFFECT_SHELL_SMASH
	jr z, .mixed_setup
	cp EFFECT_QUIVER_DANCE
	jr z, .mixed_setup
	call AIDiscourageMove
	jr .done
.mixed_setup
	inc [hl]
	inc [hl]
	inc [hl]
	jr .done
.not_unaware

; Free turn: the player is locked into a move that can't touch us.
	call .IsSetupMove
	jr nc, .done
	call AIElitePlayerLockedHarmless
	jr nc, .done
	dec [hl]
	dec [hl]
	dec [hl]
.done
	pop bc
	pop de
	jp .checkmove

.IsUnawareWastedSetup:
; carry if the scored move's boosts are ones an Unaware player ignores:
; any Atk/Def/SpA/SpD raise, or evasion. (Speed and accuracy still count.)
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_CURSE
	jr z, .curse
	cp EFFECT_ATTACK_UP
	jr c, .wasted_list
	cp EFFECT_EVASION_UP + 1
	jr c, .wasted_range
	cp EFFECT_ATTACK_UP_2
	jr c, .wasted_list
	cp EFFECT_EVASION_UP_2 + 1
	jr c, .wasted_range
.wasted_list
	push hl
	push de
	push bc
	ld hl, .UnawareWastedEffects
	ld de, 1
	call IsInArray
	pop bc
	pop de
	pop hl
	ret
.wasted_range
; Speed and accuracy raises still work against Unaware.
	cp EFFECT_SPEED_UP
	jr z, .wasted_no
	cp EFFECT_ACCURACY_UP
	jr z, .wasted_no
	cp EFFECT_SPEED_UP_2
	jr z, .wasted_no
	cp EFFECT_ACCURACY_UP_2
	jr z, .wasted_no
	scf
	ret
.curse
; A non-Ghost's Curse is an Atk/Def boost; a Ghost's Curse is not setup.
	ld a, [wEnemyMonType1]
	cp GHOST
	jr z, .wasted_no
	ld a, [wEnemyMonType2]
	cp GHOST
	jr z, .wasted_no
	scf
	ret
.wasted_no
	and a
	ret

.UnawareWastedEffects:
; new-generation boosts an Unaware player ignores
	db EFFECT_DEFENSE_CURL
	db EFFECT_BULK_UP
	db EFFECT_CALM_MIND
	db EFFECT_DRAGON_DANCE
	db EFFECT_HONE_CLAWS
	db EFFECT_SHELL_SMASH
	db EFFECT_QUIVER_DANCE
	db EFFECT_WORK_UP
	db EFFECT_BELLY_DRUM
	db -1 ; end

.GetPlayerAbility:
; e = the player's effective ability as the enemy's moves experience it
; (Mold Breaker, Neutralizing Gas and suppression applied).
	push hl
	push bc
	farcall GetOppIgnorableAbility_b
	ld e, b
	pop bc
	pop hl
	ret

.MoveTypeImmune:
; carry if the player's typing makes it immune to the scored status
; move's type (the engine fails these, e.g. Thunder Wave vs Ground).
	push hl
	push de
	push bc
	ld a, [wEnemyMoveStruct + MOVE_TYPE]
	ld hl, wBattleMonType1
	call AISwitch_CheckTypeMatchup
	ld a, [wTypeMatchup]
	pop bc
	pop de
	pop hl
	and a
	ret nz ; nc
	scf
	ret

.IsStatDown:
; carry if the effect in a is a pure stat-drop.
	cp EFFECT_ATTACK_DOWN
	jr c, .not_stat_down
	cp EFFECT_EVASION_DOWN + 1
	jr c, .stat_down_yes
	cp EFFECT_ATTACK_DOWN_2
	jr c, .not_stat_down
	cp EFFECT_EVASION_DOWN_2 + 1
	jr c, .stat_down_yes
.not_stat_down
	and a
	ret
.stat_down_yes
	scf
	ret

.IsSetupMove:
; carry if the scored move raises our own stats or sets a Substitute.
	ld a, [wEnemyMoveStruct + MOVE_EFFECT]
	cp EFFECT_SUBSTITUTE
	jr z, .setup_yes
	cp EFFECT_ATTACK_UP
	jr c, .setup_list
	cp EFFECT_EVASION_UP + 1
	jr c, .setup_yes
	cp EFFECT_ATTACK_UP_2
	jr c, .setup_list
	cp EFFECT_EVASION_UP_2 + 1
	jr c, .setup_yes
.setup_list
	push hl
	push de
	push bc
	ld hl, .SetupEffects
	ld de, 1
	call IsInArray
	pop bc
	pop de
	pop hl
	ret
.setup_yes
	scf
	ret

.SetupEffects:
; new-generation effects that raise the user's own stats
	db EFFECT_DEFENSE_CURL
	db EFFECT_BULK_UP
	db EFFECT_CALM_MIND
	db EFFECT_DRAGON_DANCE
	db EFFECT_HONE_CLAWS
	db EFFECT_SHELL_SMASH
	db EFFECT_QUIVER_DANCE
	db EFFECT_WORK_UP
	db -1 ; end


AI_None:
	ret

AIDiscourageMove:
	ld a, [hl]
	add 10
	ld [hl], a
	ret

AIGetPlayerAbility:
; a = the player's effective ability as the enemy's moves experience it
; (Mold Breaker, Neutralizing Gas and suppression applied). Preserves
; bc, de, hl and hBattleTurn (the AI_Smart layer runs before the layers
; that set the enemy's turn, so it is forced here for the lookup).
	push hl
	push de
	push bc
	ldh a, [hBattleTurn]
	push af
	ld a, 1
	ldh [hBattleTurn], a
	farcall GetOppIgnorableAbility_b
	pop af
	ldh [hBattleTurn], a
	ld a, b
	pop bc
	pop de
	pop hl
	ret

AIGetPlayerAbilityEffective:
; a = the player's effective ability (Neutralizing Gas and suppression
; applied, but NOT Mold Breaker - callers that care test it themselves).
; Preserves bc, de, hl.
; (farcall returns with a clobbered - ReturnFarCall leaves a = c - so the
; _b wrapper is mandatory here; the old inline farcalls compared garbage.)
	push hl
	push de
	push bc
	farcall GetPlayerAbilityEffective_b
	ld a, b
	pop bc
	pop de
	pop hl
	ret

AIGetEnemyAbility:
; a = the enemy's own effective ability (Neutralizing Gas and suppression
; applied). Preserves bc, de, hl.
	push hl
	push de
	push bc
	farcall GetEnemyAbilityEffective_b
	ld a, b
	pop bc
	pop de
	pop hl
	ret

AIPlayerHoldsBerry:
; carry if the player's held item is an HP-restoring Berry (the kind
; Gluttony, Ripen, Harvest and Cud Chew feed on). Preserves bc, de, hl.
	push hl
	push de
	push bc
	ld a, [wBattleMonItem]
	ld b, a
	callfar GetItemHeldEffect
	ld a, b
	pop bc
	pop de
	pop hl
	cp HELD_BERRY
	jr z, .berry
	and a ; nc
	ret
.berry
	scf
	ret

AIGetEnemyMove:
; Load attributes of move a into ram

	push hl
	push de
	push bc

	ld de, wEnemyMoveStruct
	call GetMoveData
	; Hidden Power: this mon's own type, fixed power, and the category its
	; current stats give (so every type/category/damage check below is right)
	farcall HiddenPowerPatchEnemyMoveStruct

	pop bc
	pop de
	pop hl
	ret

AI_80_20:
; Was 80/20; now the AI takes the smart branch 95% of the time.
	call BattleRandom
	cp 5 percent
	ret

AI_50_50:
; Was a coin flip; now the AI takes the smart branch 85% of the time.
	call BattleRandom
	cp 15 percent
	ret

AI_CheckMoveInList:
	push hl
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	pop hl
	ld de, 2
	jp IsInHalfwordArray
