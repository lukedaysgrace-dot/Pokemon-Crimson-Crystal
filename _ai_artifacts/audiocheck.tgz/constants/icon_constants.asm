; IconPointers indexes (see data/icon_pointers.asm)
	const_def
	const ICON_NULL
	const ICON_POLIWAG
	const ICON_JIGGLYPUFF
	const ICON_DIGLETT
	const ICON_PIKACHU
	const ICON_STARYU
	const ICON_FISH
	const ICON_BIRD
	const ICON_MONSTER
	const ICON_CLEFAIRY
	const ICON_ODDISH
	const ICON_BUG
	const ICON_GHOST
	const ICON_LAPRAS
	const ICON_HUMANSHAPE
	const ICON_FOX
	const ICON_EQUINE
	const ICON_SHELL
	const ICON_BLOB
	const ICON_SERPENT
	const ICON_VOLTORB
	const ICON_SQUIRTLE
	const ICON_BULBASAUR
	const ICON_CHARMANDER
	const ICON_CATERPILLAR
	const ICON_UNOWN
	const ICON_GEODUDE
	const ICON_FIGHTER
	const ICON_EGG
	const ICON_JELLYFISH
	const ICON_MOTH
	const ICON_BAT
	const ICON_SNORLAX
	const ICON_HO_OH
	const ICON_LUGIA
	const ICON_GYARADOS
	const ICON_SLOWPOKE
	const ICON_SUDOWOODO
	const ICON_BIGMON

; LoadMenuMonIcon.Jumptable indexes (see engine/gfx/mon_icons.asm)
	const_def
	const MONICON_PARTYMENU
	const MONICON_NAMINGSCREEN
	const MONICON_MOVES
	const MONICON_TRADE
	const MONICON_MOBILE1
	const MONICON_MOBILE2
	const MONICON_UNUSED

; menu icon palettes (entries correspond to PartyMenuOBPals)
	const_def
	const PAL_ICON_RED    ; 0
	const PAL_ICON_BLUE   ; 1
	const PAL_ICON_GREEN  ; 2
	const PAL_ICON_BROWN  ; 3
	const PAL_ICON_PINK   ; 4
	const PAL_ICON_GRAY   ; 5
	const PAL_ICON_TEAL   ; 6
	const PAL_ICON_PURPLE ; 7

; party menu caught ball icons (BG tiles in vTiles2; see PartyMenuBallGFX)
PARTYMENU_BALL_TILE EQU $40
