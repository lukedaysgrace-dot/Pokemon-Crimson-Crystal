; Replaces the functionality of sgb.asm to work with CGB hardware.

CheckCGB:
	ldh a, [hCGB]
	and a
	ret

LoadSGBLayoutCGB:
	ld a, b
	cp SCGB_RAM
	jr nz, .not_ram
	ld a, [wSGBPredef]
.not_ram
	cp SCGB_PARTY_MENU_HP_PALS
	jp z, CGB_ApplyPartyMenuHPPals
	call ResetBGPals
	ld l, a
	ld h, 0
	add hl, hl
	ld de, .dw
	add hl, de
	ld a, [hli]
	ld h, [hl]
	ld l, a
	ld de, .ReturnFromJumpTable
	push de
	jp hl

.ReturnFromJumpTable:
	ret

.dw
	dw _CGB_BattleGrayscale
	dw _CGB_BattleColors
	dw _CGB_PokegearPals
	dw _CGB_StatsScreenHPPals
	dw _CGB_Pokedex
	dw _CGB_SlotMachine
	dw _CGB_BetaTitleScreen
	dw _CGB_GSIntro
	dw _CGB_Diploma
	dw _CGB_MapPals
	dw _CGB_PartyMenu
	dw _CGB_Evolution
	dw _CGB_GSTitleScreen
	dw _CGB0d
	dw _CGB_MoveList
	dw _CGB_BetaPikachuMinigame
	dw _CGB_PokedexSearchOption
	dw _CGB_BetaPoker
	dw _CGB_Pokepic
	dw _CGB_MagnetTrain
	dw _CGB_PackPals
	dw _CGB_TrainerCard
	dw _CGB_PokedexUnownMode
	dw _CGB_BillsPC
	dw _CGB_UnownPuzzle
	dw _CGB_GamefreakLogo
	dw _CGB_PlayerOrMonFrontpicPals
	dw _CGB_TradeTube
	dw _CGB_TrainerOrMonFrontpicPals
	dw _CGB_MysteryGift
	dw _CGB1e
	dw _CGB_TrainerCardKanto

_CGB_BattleGrayscale:
	call LoadAllDefaultBattlePalettes ; anim object pals + text pal
	ld hl, PalPacket_BattleGrayscale + 1
	ld de, wBGPals1
	ld c, 4
	call CopyPalettes
	ld hl, PalPacket_BattleGrayscale + 1
	ld de, wBGPals1 palette PAL_BATTLE_BG_EXP
	ld c, 3 ; leave PAL_BATTLE_BG_TEXT as loaded above
	call CopyPalettes
	ld hl, PalPacket_BattleGrayscale + 1
	ld de, wOBPals1
	ld c, 2
	call CopyPalettes
	jr _CGB_FinishBattleScreenLayout

_CGB_BattleColors:
	call LoadAllDefaultBattlePalettes
	ld a, SCGB_BATTLE_COLORS
	ld [wSGBPredef], a
	call ApplyPals
_CGB_FinishBattleScreenLayout:
	hlcoord 0, 0, wAttrMap
	ld bc, SCREEN_WIDTH * SCREEN_HEIGHT
	ld a, PAL_BATTLE_BG_ENEMY_HP
	call ByteFill
	hlcoord 0, 4, wAttrMap
	lb bc, 8, 10
	ld a, PAL_BATTLE_BG_PLAYER
	call FillBoxCGB
	hlcoord 10, 0, wAttrMap
	lb bc, 7, 10
	ld a, PAL_BATTLE_BG_ENEMY
	call FillBoxCGB
	; (Removed a redundant re-fill of rows 0-3, cols 0-9 with PAL_BATTLE_BG_ENEMY_HP;
	;  the full-screen ByteFill above already set that region to ENEMY_HP, and nothing
	;  overwrites it in between. Freed space keeps bank2 within its 0x4000 limit.)
	hlcoord 10, 7, wAttrMap
	lb bc, 5, 10
	ld a, PAL_BATTLE_BG_PLAYER_HP
	call FillBoxCGB
	hlcoord 10, 11, wAttrMap
	lb bc, 1, 9
	ld a, PAL_BATTLE_BG_EXP
	call FillBoxCGB
	hlcoord 1, 9, wAttrMap
	lb bc, 1, 6
	ld a, PAL_BATTLE_BG_TYPE_CAT
	call FillBoxCGB
	hlcoord 0, 12, wAttrMap
	ld bc, 6 * SCREEN_WIDTH
	ld a, PAL_BATTLE_BG_TEXT
	call ByteFill
	; Recolor the two shiny star icon tiles blue (exp bar palette). These tiles
	; are blank unless the mon is shiny, so this is invisible for normal mons.
	ld a, PAL_BATTLE_BG_EXP
	ld [wAttrMap + 1 * SCREEN_WIDTH + 4], a
	ld [wAttrMap + 8 * SCREEN_WIDTH + 12], a
	call ApplyAttrMap
	ret

InitPartyMenuBGPal7:
	farcall Function100dc0
Mobile_InitPartyMenuBGPal7:
	ld hl, PartyMenuBGPalette
	jr nc, .not_mobile
	ld hl, PartyMenuBGMobilePalette
.not_mobile
	ld de, wBGPals1 palette 7
	ld bc, 1 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	ret

InitPartyMenuBGPal0:
	farcall Function100dc0
	ld hl, PartyMenuBGPalette
	jr nc, .not_mobile
	ld hl, PartyMenuBGMobilePalette
.not_mobile
	ld de, wBGPals1 palette 0
	ld bc, 1 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	ret

ReloadBattleAnimColors::
; Reload every default battle palette. Used to undo the custom palettes set
; by anim_setobjpal/anim_setbgpal (ported from polishedcrystal) once a move
; animation finishes.
	call LoadAllDefaultBattlePalettes
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

LoadAllDefaultBattlePalettes:
; Load every battle palette's default colors into wBGPals1/wOBPals1.
	ld c, 8 + 8
.loop
	push bc
	dec c
	call LoadDefaultBattlePalette
	pop bc
	dec c
	jr nz, .loop
	ret

LoadDefaultBattlePalette::
; c = palette slot: 0-7 = wBGPals1 slot, 8-15 = wOBPals1 slot (wOBPals1
; directly follows wBGPals1).
; Loads just that slot's default battle colors into the base palette buffer.
; Shared by the battle screen setup, the end-of-animation reload, and
; anim_setbgpal/anim_setobjpal with PAL_BTLCUSTOM_DEFAULT, which (like
; polishedcrystal) restores only the slot it names so other custom palettes
; set earlier in the same animation script survive.
; Expects the main WRAM bank (it reads the battlers' species and DVs).
	ld hl, wBGPals1
	ld a, c
	push bc
	ld bc, 1 palettes
	call AddNTimes
	pop bc
	ld d, h
	ld e, l
	ld hl, .Jumptable
	ld b, 0
	add hl, bc
	add hl, bc
	ld a, [hli]
	ld h, [hl]
	ld l, a
	jp hl

.Jumptable:
	dw .Player   ; PAL_BATTLE_BG_PLAYER
	dw .Enemy    ; PAL_BATTLE_BG_ENEMY
	dw .EnemyHP  ; PAL_BATTLE_BG_ENEMY_HP
	dw .PlayerHP ; PAL_BATTLE_BG_PLAYER_HP
	dw .Exp      ; PAL_BATTLE_BG_EXP
	dw .Text     ; PAL_BATTLE_BG_5 (unused in battle)
	dw .Player   ; PAL_BATTLE_BG_TYPE_CAT (mirrors the player mon's palette)
	dw .Text     ; PAL_BATTLE_BG_TEXT
	dw .Enemy    ; PAL_BATTLE_OB_ENEMY
	dw .Player   ; PAL_BATTLE_OB_PLAYER
	dw .Object   ; PAL_BATTLE_OB_GRAY
	dw .Object   ; PAL_BATTLE_OB_YELLOW
	dw .Object   ; PAL_BATTLE_OB_RED
	dw .Object   ; PAL_BATTLE_OB_GREEN
	dw .Object   ; PAL_BATTLE_OB_BLUE
	dw .Object   ; PAL_BATTLE_OB_BROWN

.Player:
	call GetBattlemonBackpicPalettePointer
	jp LoadPalette_White_Col1_Col2_Black

.Enemy:
	call GetEnemyFrontpicPalettePointer
	jp LoadPalette_White_Col1_Col2_Black

.EnemyHP:
	ld a, [wEnemyHPPal]
	jr .hp_bar
.PlayerHP:
	ld a, [wPlayerHPPal]
.hp_bar
	ld l, a
	ld h, $0
	add hl, hl
	add hl, hl
	ld bc, HPBarPals
	add hl, bc
	jp LoadPalette_White_Col1_Col2_Black

.Exp:
	ld hl, ExpBarPalette
	jp LoadPalette_White_Col1_Col2_Black

.Text:
	push de
	farcall Function100dc0
	pop de
	ld hl, PartyMenuBGPalette
	jr nc, .copy
	ld hl, PartyMenuBGMobilePalette
	jr .copy

.Object:
	; BattleObjectPals holds the six anim object palettes, starting at
	; PAL_BATTLE_OB_GRAY (the slots are contiguous and fit within one page).
	ld a, e
	sub LOW(wOBPals1 palette PAL_BATTLE_OB_GRAY)
	ld c, a
	ld b, 0
	ld hl, BattleObjectPals
	add hl, bc
.copy
	ld bc, 1 palettes
	ld a, BANK(wBGPals1)
	jp FarCopyWRAM

_CGB_PokegearPals:
	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	jr z, .male
	ld hl, FemalePokegearPals
	jr .got_pals

.male
	ld hl, MalePokegearPals
.got_pals
	ld de, wBGPals1
	ld bc, 6 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_StatsScreenHPPals:
	ld de, wBGPals1
	ld a, [wCurHPPal]
	ld l, a
	ld h, $0
	add hl, hl
	add hl, hl
	ld bc, HPBarPals
	add hl, bc
	call LoadPalette_White_Col1_Col2_Black ; hp palette
	ld a, [wCurPartySpecies]
	ld bc, wTempMonDVs
	call GetPlayerOrMonPalettePointer
	call LoadPalette_White_Col1_Col2_Black ; mon palette
	ld hl, ExpBarPalette
	call LoadPalette_White_Col1_Col2_Black ; exp palette
	call WipeAttrMap

	; The Polished-style summary screen colors everything else per page
	; (see engine/gfx/summary_screen_pals.asm). Only the pokepic area
	; keeps the mon palette here, so the egg screen also works.
	hlcoord 0, 0, wAttrMap
	lb bc, 7, 7
	ld a, $1 ; mon palette
	call FillBoxCGB

	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

StatsScreenPagePals:
INCLUDE "gfx/stats/pages.pal"

StatsScreenPals:
INCLUDE "gfx/stats/stats.pal"

_CGB_Pokedex:
	ld de, wBGPals1
	ld a, PREDEFPAL_POKEDEX
	call GetPredefPal
	call LoadHLPaletteIntoDE ; dex interface palette
	ld a, [wCurPartySpecies]
	cp $ff
	jr nz, .is_pokemon
	ld hl, .PokedexQuestionMarkPalette
	call LoadHLPaletteIntoDE ; green question mark palette
	jr .got_palette

.is_pokemon
	call GetMonPalettePointer
	call LoadPalette_White_Col1_Col2_Black ; mon palette
.got_palette
	call WipeAttrMap
	hlcoord 1, 1, wAttrMap
	lb bc, 7, 7
	ld a, $1 ; green question mark palette
	call FillBoxCGB
	call InitPartyMenuOBPals
	ld hl, .PokedexCursorPalette
	ld de, wOBPals1 palette 7 ; green cursor palette
	ld bc, 1 palettes
	ld a, BANK(wOBPals1)
	call FarCopyWRAM
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

.PokedexQuestionMarkPalette:
INCLUDE "gfx/pokedex/question_mark.pal"

.PokedexCursorPalette:
INCLUDE "gfx/pokedex/cursor.pal"

_CGB_BillsPC:
; The graphical storage system manages its own palettes (engine/pc/bills_pc_ui.asm).
	farcall BillsPC_LoadPalettes
	ret

_CGB_PokedexUnownMode:
	ld de, wBGPals1
	ld a, PREDEFPAL_POKEDEX
	call GetPredefPal
	call LoadHLPaletteIntoDE
	ld a, [wCurPartySpecies]
	call GetMonPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	call WipeAttrMap
	hlcoord 7, 5, wAttrMap
	lb bc, 7, 7
	ld a, $1
	call FillBoxCGB
	call InitPartyMenuOBPals
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_SlotMachine:
	ld hl, SlotMachinePals
	ld de, wBGPals1
	ld bc, 16 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	call WipeAttrMap
	hlcoord 0, 2, wAttrMap
	lb bc, 10, 3
	ld a, $2
	call FillBoxCGB
	hlcoord 17, 2, wAttrMap
	lb bc, 10, 3
	ld a, $2
	call FillBoxCGB
	hlcoord 0, 4, wAttrMap
	lb bc, 6, 3
	ld a, $3
	call FillBoxCGB
	hlcoord 17, 4, wAttrMap
	lb bc, 6, 3
	ld a, $3
	call FillBoxCGB
	hlcoord 0, 6, wAttrMap
	lb bc, 2, 3
	ld a, $4
	call FillBoxCGB
	hlcoord 17, 6, wAttrMap
	lb bc, 2, 3
	ld a, $4
	call FillBoxCGB
	hlcoord 4, 2, wAttrMap
	lb bc, 2, 12
	ld a, $1
	call FillBoxCGB
	hlcoord 3, 2, wAttrMap
	lb bc, 10, 1
	ld a, $1
	call FillBoxCGB
	hlcoord 16, 2, wAttrMap
	lb bc, 10, 1
	ld a, $1
	call FillBoxCGB
	hlcoord 0, 12, wAttrMap
	ld bc, $78
	ld a, $7
	call ByteFill
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_BetaTitleScreen:
	ld hl, PalPacket_BetaTitleScreen + 1
	call CopyFourPalettes
	call WipeAttrMap
	ld de, wOBPals1
	ld a, PREDEFPAL_PACK
	call GetPredefPal
	call LoadHLPaletteIntoDE
	hlcoord 0, 6, wAttrMap
	lb bc, 12, SCREEN_WIDTH
	ld a, $1
	call FillBoxCGB
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_GSIntro:
	ld b, 0
	ld hl, .Jumptable
	add hl, bc
	add hl, bc
	ld a, [hli]
	ld h, [hl]
	ld l, a
	jp hl

.Jumptable:
	dw .ShellderLaprasScene
	dw .JigglypuffPikachuScene
	dw .StartersCharizardScene

.ShellderLaprasScene:
	ld hl, .ShellderLaprasBGPalette
	ld de, wBGPals1
	call LoadHLPaletteIntoDE
	ld hl, .ShellderLaprasOBPals
	ld de, wOBPals1
	ld bc, 2 palettes
	ld a, BANK(wOBPals1)
	call FarCopyWRAM
	call WipeAttrMap
	ret

.ShellderLaprasBGPalette:
	RGB 19, 31, 19
	RGB 18, 23, 31
	RGB 11, 21, 28
	RGB 04, 16, 24

.ShellderLaprasOBPals:
	RGB 29, 29, 29
	RGB 20, 19, 20
	RGB 19, 06, 04
	RGB 03, 04, 06

	RGB 31, 31, 31
	RGB 31, 31, 31
	RGB 31, 00, 00
	RGB 03, 04, 06

.JigglypuffPikachuScene:
	ld de, wBGPals1
	ld a, PREDEFPAL_GS_INTRO_JIGGLYPUFF_PIKACHU_BG
	call GetPredefPal
	call LoadHLPaletteIntoDE

	ld de, wOBPals1
	ld a, PREDEFPAL_GS_INTRO_JIGGLYPUFF_PIKACHU_OB
	call GetPredefPal
	call LoadHLPaletteIntoDE
	call WipeAttrMap
	ret

.StartersCharizardScene:
	ld hl, PalPacket_Pack + 1
	call CopyFourPalettes
	ld de, wOBPals1
	ld a, PREDEFPAL_GS_INTRO_STARTERS_TRANSITION
	call GetPredefPal
	call LoadHLPaletteIntoDE
	call WipeAttrMap
	ret

_CGB_BetaPoker:
	ld hl, BetaPokerPals
	ld de, wBGPals1
	ld bc, 5 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	call ApplyPals
	call WipeAttrMap
	call ApplyAttrMap
	ret

_CGB_Diploma:
	ld hl, DiplomaPalettes
	ld de, wBGPals1
	ld bc, 16 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM

	ld hl, PalPacket_Diploma + 1
	call CopyFourPalettes
	call InitPartyMenuOBPals ; for mon icon colors on the naming screen
	call WipeAttrMap
	call ApplyAttrMap
	ret

_CGB_MapPals:
	call LoadMapPals
	ld a, SCGB_MAPPALS
	ld [wSGBPredef], a
	ret

_CGB_PartyMenu:
	ld hl, PalPacket_PartyMenu + 1
	call CopyFourPalettes
	call InitPartyMenuBGPal0
	call InitPartyMenuBGPal7
	call InitPartyMenuOBPals
	call LoadPartyMenuMonPals ; also loads the caught ball BG pals
	call ApplyAttrMap
	ret

_CGB_Evolution:
	ld de, wBGPals1
	ld a, c
	and a
	jr z, .pokemon
	ld a, PREDEFPAL_BLACKOUT
	call GetPredefPal
	call LoadHLPaletteIntoDE
	jr .got_palette

.pokemon
	ld hl, wPartyMon1DVs
	ld bc, PARTYMON_STRUCT_LENGTH
	ld a, [wCurPartyMon]
	call AddNTimes
	ld c, l
	ld b, h
	ld a, [wPlayerHPPal]
	call GetPlayerOrMonPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld hl, BattleObjectPals
	ld de, wOBPals1 palette PAL_BATTLE_OB_GRAY
	ld bc, 6 palettes
	ld a, BANK(wOBPals1)
	call FarCopyWRAM

.got_palette
	call WipeAttrMap
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_GSTitleScreen:
	ld hl, UnusedGSTitleBGPals
	ld de, wBGPals1
	ld bc, 5 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	ld hl, UnusedGSTitleOBPals
	ld de, wOBPals1
	ld bc, 2 palettes
	ld a, BANK(wOBPals1)
	call FarCopyWRAM
	ld a, SCGB_DIPLOMA
	ld [wSGBPredef], a
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB0d:
	ld hl, PalPacket_Diploma + 1
	call CopyFourPalettes
	call WipeAttrMap
	call ApplyAttrMap
	ret

_CGB_UnownPuzzle:
	ld hl, PalPacket_UnownPuzzle + 1
	call CopyFourPalettes
	ld de, wOBPals1
	ld a, PREDEFPAL_UNOWN_PUZZLE
	call GetPredefPal
	call LoadHLPaletteIntoDE
	ldh a, [rSVBK]
	push af
	ld a, BANK(wOBPals1)
	ldh [rSVBK], a
	ld hl, wOBPals1
	ld a, LOW(palred 31 + palgreen 0 + palblue 0)
	ld [hli], a
	ld a, HIGH(palred 31 + palgreen 0 + palblue 0)
	ld [hl], a
	pop af
	ldh [rSVBK], a
	call WipeAttrMap
	call ApplyAttrMap
	ret

_CGB_TrainerCard:
	ld de, wBGPals1
	ld a, [wPlayerGender]
	cp PLAYERGENDER_INDIGO
	jr nz, .gold_palette
	ld hl, IndigoPlayerPalette
	jr .got_player_palette
.gold_palette
	xor a ; GOLD
	call GetTrainerPalettePointer
.got_player_palette
	call LoadPalette_White_Col1_Col2_Black
	ld a, FALKNER ; LYRA
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, BUGSY
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, WHITNEY
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, MORTY
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, CHUCK
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, JASMINE
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, PRYCE
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	; each badge has its own OBJ palette (Polished Crystal style)
	ld hl, JohtoBadgePalettes
	ld c, 8
.badge_pal_loop
	push bc
	call LoadHLPaletteIntoDE
	pop bc
	dec c
	jr nz, .badge_pal_loop

	; fill screen with opposite-gender palette for the card border
	hlcoord 0, 0, wAttrMap
	ld bc, SCREEN_WIDTH * SCREEN_HEIGHT
	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	ld a, $1 ; lyra
	jr z, .got_gender
	ld a, $0 ; gold
.got_gender
	call ByteFill
	; fill trainer sprite area with the player's own palette
	hlcoord 14, 1, wAttrMap
	lb bc, 7, 5
	ld a, [wPlayerGender]
	cp PLAYERGENDER_INDIGO
	jr z, .pic_pal_player
	bit PLAYERGENDER_FEMALE_F, a
	ld a, $1 ; lyra
	jr nz, .got_pic_pal
.pic_pal_player
	xor a ; gold/indigo
.got_pic_pal
	call FillBoxCGB
	; top-right corner still uses the border's palette
	hlcoord 18, 1, wAttrMap
	ld [hl], $1
	; leader faces get 3x3 boxes covering the whole mugshot,
	; like Polished Crystal (the top face row was showing the
	; border palette as a wrong-colored line over the hair)
	hlcoord 3, 10, wAttrMap
	lb bc, 3, 3
	ld a, $1 ; falkner
	call FillBoxCGB
	hlcoord 7, 10, wAttrMap
	lb bc, 3, 3
	ld a, $2 ; bugsy
	call FillBoxCGB
	hlcoord 11, 10, wAttrMap
	lb bc, 3, 3
	ld a, $3 ; whitney
	call FillBoxCGB
	hlcoord 15, 10, wAttrMap
	lb bc, 3, 3
	ld a, $4 ; morty
	call FillBoxCGB
	hlcoord 3, 13, wAttrMap
	lb bc, 3, 3
	ld a, $5 ; chuck
	call FillBoxCGB
	hlcoord 7, 13, wAttrMap
	lb bc, 3, 3
	ld a, $6 ; jasmine
	call FillBoxCGB
	hlcoord 11, 13, wAttrMap
	lb bc, 3, 3
	ld a, $7 ; pryce
	call FillBoxCGB
	; clair uses lyra's palette
	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	push af
	jr z, .got_gender3
	hlcoord 15, 13, wAttrMap
	lb bc, 3, 3
	ld a, $1
	call FillBoxCGB
.got_gender3
	pop af
	ld c, $0
	jr nz, .got_gender4
	inc c
.got_gender4
	ld a, c
	hlcoord 18, 1, wAttrMap
	ld [hl], a
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_TrainerCardKanto:
; Kanto badges page (Polished Crystal style)
	ld de, wBGPals1
	ld a, [wPlayerGender]
	cp PLAYERGENDER_INDIGO
	jr nz, .gold_palette
	ld hl, IndigoPlayerPalette
	jr .got_player_palette
.gold_palette
	xor a ; GOLD
	call GetTrainerPalettePointer
.got_player_palette
	call LoadPalette_White_Col1_Col2_Black
	ld a, FALKNER ; LYRA
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, BROCK
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, SABRINA ; also BLAINE
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, ERIKA ; also LT_SURGE
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, MISTY
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, JANINE
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	ld a, BLUE
	call GetTrainerPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	; each badge has its own OBJ palette (Polished Crystal style)
	ld hl, KantoBadgePalettes
	ld c, 8
.badge_pal_loop
	push bc
	call LoadHLPaletteIntoDE
	pop bc
	dec c
	jr nz, .badge_pal_loop

	; fill screen with opposite-gender palette for the card border
	hlcoord 0, 0, wAttrMap
	ld bc, SCREEN_WIDTH * SCREEN_HEIGHT
	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	ld a, $1 ; lyra
	jr z, .got_gender
	ld a, $0 ; gold
.got_gender
	call ByteFill
	; fill trainer sprite area with the player's own palette
	hlcoord 14, 1, wAttrMap
	lb bc, 7, 5
	ld a, [wPlayerGender]
	cp PLAYERGENDER_INDIGO
	jr z, .pic_pal_player
	bit PLAYERGENDER_FEMALE_F, a
	ld a, $1 ; lyra
	jr nz, .got_pic_pal
.pic_pal_player
	xor a ; gold/indigo
.got_pic_pal
	call FillBoxCGB
	; Lt.Surge (shares Erika's palette)
	hlcoord 3, 10, wAttrMap
	lb bc, 3, 3
	ld a, $4
	call FillBoxCGB
	; Sabrina
	hlcoord 7, 10, wAttrMap
	lb bc, 3, 3
	ld a, $3
	call FillBoxCGB
	; Misty
	hlcoord 11, 10, wAttrMap
	lb bc, 3, 3
	ld a, $5
	call FillBoxCGB
	; Erika
	hlcoord 15, 10, wAttrMap
	lb bc, 3, 3
	ld a, $4
	call FillBoxCGB
	; Janine
	hlcoord 3, 13, wAttrMap
	lb bc, 3, 3
	ld a, $6
	call FillBoxCGB
	; Brock
	hlcoord 7, 13, wAttrMap
	lb bc, 3, 3
	ld a, $2
	call FillBoxCGB
	; Blaine (shares Sabrina's palette)
	hlcoord 11, 13, wAttrMap
	lb bc, 3, 3
	ld a, $3
	call FillBoxCGB
	; Blue
	hlcoord 15, 13, wAttrMap
	lb bc, 3, 3
	ld a, $7
	call FillBoxCGB
	; top-right corner still uses the border's palette
	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	ld a, $0
	jr nz, .got_corner
	ld a, $1
.got_corner
	hlcoord 18, 1, wAttrMap
	ld [hl], a
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

JohtoBadgePalettes:
INCLUDE "gfx/trainer_card/johto_badges.pal"

KantoBadgePalettes:
INCLUDE "gfx/trainer_card/kanto_badges.pal"

_CGB_MoveList:
	ld de, wBGPals1
	ld a, PREDEFPAL_GOLDENROD
	call GetPredefPal
	call LoadHLPaletteIntoDE
	ld a, [wPlayerHPPal]
	ld l, a
	ld h, 0
	add hl, hl
	add hl, hl
	ld bc, HPBarPals
	add hl, bc
	call LoadPalette_White_Col1_Col2_Black
	call WipeAttrMap
	hlcoord 11, 1, wAttrMap
	lb bc, 2, 9
	ld a, $1
	call FillBoxCGB
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_BetaPikachuMinigame:
	ld hl, PalPacket_BetaPikachuMinigame + 1
	call CopyFourPalettes
	call WipeAttrMap
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_PokedexSearchOption:
	ld de, wBGPals1
	ld a, PREDEFPAL_POKEDEX
	call GetPredefPal
	call LoadHLPaletteIntoDE
	call WipeAttrMap
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_PackPals:
; pack pals
	ld a, [wBattleType]
	cp BATTLETYPE_TUTORIAL
	jr z, .tutorial_male

	ld a, [wPlayerGender]
	bit PLAYERGENDER_FEMALE_F, a
	jr z, .tutorial_male

	ld hl, .GoldPackPals
	jr .got_gender

.tutorial_male
	ld hl, .GoldPackPals

.got_gender
	ld de, wBGPals1
	ld bc, 8 palettes ; 6 palettes?
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	call WipeAttrMap
	hlcoord 0, 0, wAttrMap
	lb bc, 1, 10
	ld a, $1
	call FillBoxCGB
	hlcoord 10, 0, wAttrMap
	lb bc, 1, 10
	ld a, $2
	call FillBoxCGB
	hlcoord 7, 2, wAttrMap
	lb bc, 9, 1
	ld a, $3
	call FillBoxCGB
	hlcoord 0, 7, wAttrMap
	lb bc, 3, 5
	ld a, $4
	call FillBoxCGB
	hlcoord 0, 3, wAttrMap
	lb bc, 3, 5
	ld a, $5
	call FillBoxCGB
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

.GoldPackPals:
INCLUDE "gfx/pack/pack.pal"

.LyraPackPals:
INCLUDE "gfx/pack/pack_f.pal"

_CGB_Pokepic:
	call _CGB_MapPals
	ld de, SCREEN_WIDTH
	hlcoord 0, 0, wAttrMap
	ld a, [wMenuBorderTopCoord]
.loop
	and a
	jr z, .found_top
	dec a
	add hl, de
	jr .loop

.found_top
	ld a, [wMenuBorderLeftCoord]
	ld e, a
	ld d, $0
	add hl, de
	ld a, [wMenuBorderTopCoord]
	ld b, a
	ld a, [wMenuBorderBottomCoord]
	inc a
	sub b
	ld b, a
	ld a, [wMenuBorderLeftCoord]
	ld c, a
	ld a, [wMenuBorderRightCoord]
	sub c
	inc a
	ld c, a
	ld a, $0
	call FillBoxCGB
	call ApplyAttrMap
	ret

_CGB_MagnetTrain:
	ld hl, PalPacket_MagnetTrain + 1
	call CopyFourPalettes
	call WipeAttrMap
	hlcoord 0, 4, wAttrMap
	lb bc, 10, SCREEN_WIDTH
	ld a, $2
	call FillBoxCGB
	hlcoord 0, 6, wAttrMap
	lb bc, 6, SCREEN_WIDTH
	ld a, $1
	call FillBoxCGB
	call ApplyAttrMap
	call ApplyPals
	ld a, $1
	ldh [hCGBPalUpdate], a
	ret

_CGB_GamefreakLogo:
	ld de, wBGPals1
	ld a, PREDEFPAL_GAMEFREAK_LOGO_BG
	call GetPredefPal
	call LoadHLPaletteIntoDE
	ld hl, .Palette
	ld de, wOBPals1
	call LoadHLPaletteIntoDE
	ld hl, .Palette
	ld de, wOBPals1 palette 1
	call LoadHLPaletteIntoDE
	call WipeAttrMap
	call ApplyAttrMap
	call ApplyPals
	ret

.Palette:
INCLUDE "gfx/splash/logo.pal"

_CGB_PlayerOrMonFrontpicPals:
	ld de, wBGPals1
	ld a, [wCurPartySpecies]
	ld bc, wTempMonDVs
	call GetPlayerOrMonPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	call WipeAttrMap
	call ApplyAttrMap
	call ApplyPals
	ret

_CGB1e:
	ld de, wBGPals1
	ld a, [wCurPartySpecies]
	call GetMonPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	call WipeAttrMap
	call ApplyAttrMap
	ret

_CGB_TradeTube:
	ld hl, PalPacket_TradeTube + 1
	call CopyFourPalettes
	ld hl, PartyMenuOBPals
	ld de, wOBPals1
	ld bc, 1 palettes
	ld a, BANK(wOBPals1)
	call FarCopyWRAM
	ld de, wOBPals1 palette 7
	ld a, PREDEFPAL_TRADE_TUBE
	call GetPredefPal
	call LoadHLPaletteIntoDE
	call WipeAttrMap
	ret

_CGB_TrainerOrMonFrontpicPals:
	ld de, wBGPals1
	ld a, [wCurPartySpecies]
	ld bc, wTempMonDVs
	call GetFrontpicPalettePointer
	call LoadPalette_White_Col1_Col2_Black
	call WipeAttrMap
	call ApplyAttrMap
	call ApplyPals
	ret

_CGB_MysteryGift:
	ld hl, .Palettes
	ld de, wBGPals1
	ld bc, 2 palettes
	ld a, BANK(wBGPals1)
	call FarCopyWRAM
	call ApplyPals
	call WipeAttrMap
	hlcoord 3, 7, wAttrMap
	lb bc, 8, 14
	ld a, $1
	call FillBoxCGB
	hlcoord 1, 5, wAttrMap
	lb bc, 1, 18
	ld a, $1
	call FillBoxCGB
	hlcoord 1, 16, wAttrMap
	lb bc, 1, 18
	ld a, $1
	call FillBoxCGB
	hlcoord 0, 0, wAttrMap
	lb bc, 17, 2
	ld a, $1
	call FillBoxCGB
	hlcoord 18, 5, wAttrMap
	lb bc, 12, 1
	ld a, $1
	call FillBoxCGB
	call ApplyAttrMap
	ret

.Palettes:
INCLUDE "gfx/mystery_gift/mystery_gift.pal"
