; Used in wram.asm

flag_array: MACRO
	ds ((\1) + 7) / 8
ENDM

box_struct: MACRO
\1Species::        db
\1Item::           db
\1Moves::          ds NUM_MOVES
\1ID::             dw
\1Exp::            ds 3
\1StatExp::
\1HPExp::          dw
\1AtkExp::         dw
\1DefExp::         dw
\1SpdExp::         dw
\1SpcExp::         dw
\1DVs::            dw
\1PP::             ds NUM_MOVES
\1Happiness::      db
\1PokerusStatus::  db
\1CaughtData::
\1CaughtTime::
\1CaughtLevel::    db
\1CaughtGender::
\1CaughtLocation:: db
\1Level::          db
\1Personality::    db
\1End::
ENDM

party_struct: MACRO
	box_struct \1
\1Status::         db
\1Unused::         db
\1HP::             dw
\1MaxHP::          dw
\1Stats:: ; big endian
\1Attack::         dw
\1Defense::        dw
\1Speed::          dw
\1SpclAtk::        dw
\1SpclDef::        dw
\1StatsEnd::
ENDM

red_box_struct: MACRO
\1Species::    db
\1HP::         dw
\1BoxLevel::   db
\1Status::     db
\1Type::
\1Type1::      db
\1Type2::      db
\1CatchRate::  db
\1Moves::      ds NUM_MOVES
\1OTID::       dw
\1Exp::        ds 3
\1HPExp::      dw
\1AttackExp::  dw
\1DefenseExp:: dw
\1SpeedExp::   dw
\1SpecialExp:: dw
\1DVs::        dw
\1PP::         ds NUM_MOVES
ENDM

red_party_struct: MACRO
	red_box_struct \1
\1Level::      db
\1Stats::
\1MaxHP::      dw
\1Attack::     dw
\1Defense::    dw
\1Speed::      dw
\1Special::    dw
ENDM

battle_struct: MACRO
\1Species::   db
\1Item::      db
\1Moves::     ds NUM_MOVES
\1MovesEnd::
\1DVs::       dw
\1PP::        ds NUM_MOVES
\1Happiness:: db
\1Level::     db
\1Personality:: db
\1Status::    ds 2
\1HP::        dw
\1MaxHP::     dw
\1Stats:: ; big endian
\1Attack::    dw
\1Defense::   dw
\1Speed::     dw
\1SpclAtk::   dw
\1SpclDef::   dw
\1StatsEnd::
\1Type::
\1Type1::     db
\1Type2::     db
\1StructEnd::
ENDM

savemon_struct: MACRO
; Encoded PokeDB record. Offsets are mirrored by the SAVEMON_* constants
; (constants/pokemon_data_constants.asm) and documented in docs/pc_storage_design.md.
\1SpeciesIndex::   dw ; true 16-bit species index
\1Item::           db
\1Moves::          ds NUM_MOVES ; low 8 bits of true move indexes
\1ID::             dw
\1Exp::            ds 3
\1StatExp::
\1HPExp::          dw
\1AtkExp::         dw
\1DefExp::         dw
\1SpdExp::         dw
\1SpcExp::         dw
\1DVs::            dw
\1MovesHiPPUps::   ds NUM_MOVES ; bits 0-5: move index bits 8-13; bits 6-7: PP Ups
\1Happiness::      db
\1PokerusStatus::  db ; bits 0-5 pokerus, bit 6 male flag, bit 7 shiny flag
\1CaughtData::
\1CaughtTime::
\1CaughtLevel::    db
\1CaughtGender::
\1CaughtLocation:: db
\1Level::          db
\1Personality::    db
\1Flags::          db ; bit 0: is egg
\1Nickname::       ds SAVEMON_NAME_LENGTH
\1OT::             ds SAVEMON_NAME_LENGTH
\1Checksum::       dw
\1End::
ENDM

pokedb: MACRO
; \1 = label prefix, \2 = entry count
\1Mons::
	ds SAVEMON_STRUCT_LENGTH * (\2)
\1End::
ENDM

newbox: MACRO
; Box metadata: one PokeDB pointer per slot plus name and theme.
\1Entries:: ds MONS_PER_BOX ; 0 = empty, else PokeDB entry number
\1Banks::   flag_array MONS_PER_BOX ; bit clear = pool 1, set = pool 2
\1Name::    ds BOX_NAME_LENGTH ; no terminator
\1Theme::   db
\1End::
ENDM

map_connection_struct: MACRO
\1ConnectedMapGroup::       db
\1ConnectedMapNumber::      db
\1ConnectionStripPointer::  dw
\1ConnectionStripLocation:: dw
\1ConnectionStripLength::   db
\1ConnectedMapWidth::       db
\1ConnectionStripYOffset::  db
\1ConnectionStripXOffset::  db
\1ConnectionWindow::        dw
ENDM

channel_struct: MACRO
; Addreses are wChannel1 (c101).
\1MusicID::           dw
\1MusicBank::         db
\1Flags1::            db ; 0:on/off 1:subroutine 3:sfx 4:noise 5:rest
\1Flags2::            db ; 0:vibrato on/off 2:duty 4:cry pitch
\1Flags3::            db ; 0:vibrato up/down
\1MusicAddress::      dw
\1LastMusicAddress::  dw
                      dw
\1NoteFlags::         db ; 5:rest
\1Condition::         db ; conditional jumps
\1DutyCycle::         db ; bits 6-7 (0:12.5% 1:25% 2:50% 3:75%)
\1Intensity::         db ; hi:pressure lo:velocity
\1Frequency::         dw ; 11 bits
\1Pitch::             db ; 0:rest 1-c:note
\1Octave::            db ; 7-0 (0 is highest)
\1PitchOffset::       db ; raises existing octaves (to repeat phrases)
\1NoteDuration::      db ; frames remaining for the current note
\1Field16::           ds 1
                      ds 1
\1LoopCount::         db
\1Tempo::             dw
\1Tracks::            db ; hi:left lo:right
\1SFXDutyLoop::       db
\1VibratoDelayCount:: db ; initialized by \1VibratoDelay
\1VibratoDelay::      db ; number of frames a note plays until vibrato starts
\1VibratoExtent::     db
\1VibratoRate::       db ; hi:frames for each alt lo:frames to the next alt
\1PitchWheelTarget::  dw ; frequency endpoint for pitch wheel
\1PitchWheelAmount::  db
\1PitchWheelAmountFraction::   db
\1Field25::           db
                      ds 1
\1CryPitch::          dw
\1Field29::           ds 1
\1Field2a::           ds 2
\1Field2c::           ds 1
\1NoteLength::        db ; frames per 16th note
\1Field2e::           ds 1
\1Field2f::           ds 1
\1Field30::           ds 1
                      ds 1
ENDM

battle_tower_struct: MACRO
\1Name:: ds NAME_LENGTH + -1
\1TrainerClass:: ds 1
\1Mon1:: party_struct \1Mon1
\1Mon1Name:: ds MON_NAME_LENGTH
\1Mon1NameEnd::
\1Mon2:: party_struct \1Mon2
\1Mon2Name:: ds MON_NAME_LENGTH
\1Mon2NameEnd::
\1Mon3:: party_struct \1Mon3
\1Mon3Name:: ds MON_NAME_LENGTH
\1Mon3NameEnd::
\1TrainerData:: ds BATTLETOWER_TRAINERDATALENGTH
\1TrainerEnd::
ENDM

mailmsg: MACRO
\1Message::    ds MAIL_MSG_LENGTH
\1MessageEnd:: ds 1
\1Author::     ds PLAYER_NAME_LENGTH
\1AuthorNationality:: ds 2
\1AuthorID::   dw
\1Species::    db
\1Type::       db
\1End::
ENDM

roam_struct: MACRO
\1Species::   db
\1Level::     db
\1MapGroup::  db
\1MapNumber:: db
\1HP::        db
\1DVs::       dw
ENDM

bugcontestwinner: MACRO
\1WinnerID:: db
\1Mon::      db
\1Score::    dw
ENDM

hof_mon: MACRO
\1Species::  dw
\1ID::       dw
\1DVs::      dw
\1Level::    db
\1Nickname:: ds MON_NAME_LENGTH + -1
\1End::
ENDM

hall_of_fame: MACRO
\1WinCount:: db
\1Mon1:: hof_mon \1Mon1
\1Mon2:: hof_mon \1Mon2
\1Mon3:: hof_mon \1Mon3
\1Mon4:: hof_mon \1Mon4
\1Mon5:: hof_mon \1Mon5
\1Mon6:: hof_mon \1Mon6
\1End:: dw
ENDM

link_battle_record: MACRO
\1Name::   ds NAME_LENGTH + -1
\1ID::     dw
\1Wins::   dw
\1Losses:: dw
\1Draws::  dw
ENDM

trademon: MACRO
\1Species::     db ; wc6d0 | wc702
\1SpeciesName:: ds MON_NAME_LENGTH ; wc6d1 | wc703
\1Nickname::    ds MON_NAME_LENGTH ; wc6dc | wc70e
\1SenderName::  ds NAME_LENGTH ; wc6e7 | wc719
\1OTName::      ds NAME_LENGTH ; wc6f2 | wc724
\1DVs::         dw ; wc6fd | wc72f
\1ID::          dw ; wc6ff | wc731
\1CaughtData::  db ; wc701 | wc733
\1End::
ENDM

move_struct: MACRO
\1Animation::    db
\1Effect::       db
\1Power::        db
\1Type::         db
\1Category::      db
\1Accuracy::     db
\1PP::           db
\1EffectChance:: db
ENDM

slot_reel: MACRO
\1ReelAction::   db
\1TilemapAddr::  dw
\1Position::     db
\1SpinDistance:: db
\1SpinRate::     db
\1OAMAddr::      dw
\1XCoord::       db
\1ManipCounter:: db
\1ManipDelay::   db
\1Field0b::      ds 1
\1Field0c::      ds 1
\1Field0d::      ds 1
\1Field0e::      ds 1
\1StopDelay::    db
ENDM

object_struct: MACRO
\1Sprite::            db
\1MapObjectIndex::    db
\1SpriteTile::        db
\1MovementType::      db
\1Flags::             dw
\1Palette::           db
\1Walking::           db
\1Direction::         db
\1StepType::          db
\1StepDuration::      db
\1Action::            db
\1ObjectStepFrame::   db
\1Facing::            db
\1StandingTile::      db ; collision
\1LastTile::          db ; collision
\1StandingMapX::      db
\1StandingMapY::      db
\1LastMapX::          db
\1LastMapY::          db
\1ObjectInitX::       db
\1ObjectInitY::       db
\1Radius::            db
\1SpriteX::           db
\1SpriteY::           db
\1SpriteXOffset::     db
\1SpriteYOffset::     db
\1MovementByteIndex:: db
\1Field1c::           ds 1
\1Field1d::           ds 1
\1Field1e::           ds 1
\1Field1f::           ds 1
\1Range::             db
	ds 7
\1StructEnd::
ENDM

map_object: MACRO
\1ObjectStructID::  db
\1ObjectSprite::    db
\1ObjectYCoord::    db
\1ObjectXCoord::    db
\1ObjectMovement::  db
\1ObjectRadius::    db
\1ObjectHour::      db
\1ObjectTimeOfDay:: db
\1ObjectColor::     db
\1ObjectRange::     db
\1ObjectScript::    dw
\1ObjectEventFlag:: dw
	ds 2
ENDM

sprite_oam_struct: MACRO
\1YCoord::     db
\1XCoord::     db
\1TileID::     db
\1Attributes:: db
; bit 7: priority
; bit 6: y flip
; bit 5: x flip
; bit 4: pal # (non-cgb)
; bit 3: vram bank (cgb only)
; bit 2-0: pal # (cgb only)
ENDM

sprite_anim_struct: MACRO
\1Index::          db
\1FramesetID::     db
\1AnimSeqID::      db
\1TileID::         db
\1XCoord::         db
\1YCoord::         db
\1XOffset::        db
\1YOffset::        db
\1Duration::       db
\1DurationOffset:: db
\1FrameIndex::     db
\1JumptableIndex:: db
\1Field0c::        ds 1
\1Field0d::        ds 1
\1Field0e::        ds 1
\1Field0f::        ds 1
ENDM

battle_anim_struct: MACRO
; Placeholder until we can figure out what it all means
\1Index::              db
\1Field01::            ds 1
\1Field02::            ds 1
\1FramesetID::         db
\1Function::           db
\1Palette::            db
\1TileID::             db
\1XCoord::             db
\1YCoord::             db
\1XOffset::            db
\1YOffset::            db
\1Field0b::            ds 1
\1Duration::           db
\1Frame::              db
\1AnonJumptableIndex:: db
\1Field0f::            ds 1
\1Field10::            ds 1
\1Field11::            ds 1
\1Field12::            ds 1
\1Field13::            ds 1
\1Field14::            ds 1
\1Field15::            ds 1
\1Field16::            ds 1
\1Field17::            ds 1
ENDM

battle_bg_effect: MACRO
\1Function:: db
\1Field01::  ds 1
\1Field02::  ds 1
\1Field03::  ds 1
ENDM
