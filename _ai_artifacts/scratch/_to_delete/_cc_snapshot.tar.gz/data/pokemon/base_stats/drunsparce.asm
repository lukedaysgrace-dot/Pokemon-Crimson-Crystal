	db 0 ; species ID placeholder

	db 125, 100,  80,  55,  85,  75
	;  hp  atk  def  spd  sat  sdf

	db NORMAL, DRAGON ; type
	db 45 ; catch rate
	db 250 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/drunsparce/front.dimensions"
	abilities_for DRUNSPARCE, SERENE_GRACE, NO_ABILITY, RATTLED
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SNORE, PROTECT, ENDURE, FRUSTRATION, RETURN, DOUBLE_TEAM, SWAGGER, SLEEP_TALK, REST, ATTRACT
	; end
