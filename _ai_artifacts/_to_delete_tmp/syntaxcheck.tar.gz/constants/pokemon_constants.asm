; pokemon ids
; indexes for:
; - PokemonNames (see data/pokemon/names.asm)
; - BaseData (see data/pokemon/base_stats.asm)
; - EvosAttacksPointers (see data/pokemon/evos_attacks_pointers.asm)
; - EggMovePointers (see data/pokemon/egg_move_pointers.asm)
; - PokemonCries (see data/pokemon/cries.asm)
; - IconPointers (see data/icon_pointers.asm)
; - PokemonPicPointers (see data/pokemon/pic_pointers.asm)
; - PokemonPalettes (see data/pokemon/palettes.asm)
; - PokedexDataPointerTable (see data/pokemon/dex_entry_pointers.asm)
; - AlphabeticalPokedexOrder (see data/pokemon/dex_order_alpha.asm)
; - EZChat_SortedPokemon (see data/pokemon/ezchat_order.asm)
; - NewPokedexOrder (see data/pokemon/dex_order_new.asm)
; - Pokered_MonIndices (see data/pokemon/gen1_order.asm)
; - AnimationPointers (see gfx/pokemon/anim_pointers.asm)
; - AnimationIdlePointers (see gfx/pokemon/idle_pointers.asm)
; - BitmasksPointers (see gfx/pokemon/bitmask_pointers.asm)
; - FramesPointers (see gfx/pokemon/frame_pointers.asm)
; - Footprints (see gfx/footprints.asm)
	const_def 1
	const BULBASAUR  ; 01
	const IVYSAUR    ; 02
	const VENUSAUR   ; 03
	const CHARMANDER ; 04
	const CHARMELEON ; 05
	const CHARIZARD  ; 06
	const SQUIRTLE   ; 07
	const WARTORTLE  ; 08
	const BLASTOISE  ; 09
	const CATERPIE   ; 0a
	const METAPOD    ; 0b
	const BUTTERFREE ; 0c
	const WEEDLE     ; 0d
	const KAKUNA     ; 0e
	const BEEDRILL   ; 0f
	const PIDGEY     ; 10
	const PIDGEOTTO  ; 11
	const PIDGEOT    ; 12
	const RATTATA    ; 13
	const RATICATE   ; 14
	const SPEAROW    ; 15
	const FEAROW     ; 16
	const EKANS      ; 17
	const ARBOK      ; 18
	const PIKACHU    ; 19
	const RAICHU     ; 1a
	const SANDSHREW  ; 1b
	const SANDSLASH  ; 1c
	const NIDORAN_F  ; 1d
	const NIDORINA   ; 1e
	const NIDOQUEEN  ; 1f
	const NIDORAN_M  ; 20
	const NIDORINO   ; 21
	const NIDOKING   ; 22
	const CLEFAIRY   ; 23
	const CLEFABLE   ; 24
	const VULPIX     ; 25
	const NINETALES  ; 26
	const JIGGLYPUFF ; 27
	const WIGGLYTUFF ; 28
	const ZUBAT      ; 29
	const GOLBAT     ; 2a
	const ODDISH     ; 2b
	const GLOOM      ; 2c
	const VILEPLUME  ; 2d
	const PARAS      ; 2e
	const PARASECT   ; 2f
	const VENONAT    ; 30
	const VENOMOTH   ; 31
	const DIGLETT    ; 32
	const DUGTRIO    ; 33
	const MEOWTH     ; 34
	const PERSIAN    ; 35
	const PSYDUCK    ; 36
	const GOLDUCK    ; 37
	const MANKEY     ; 38
	const PRIMEAPE   ; 39
	const GROWLITHE  ; 3a
	const ARCANINE   ; 3b
	const POLIWAG    ; 3c
	const POLIWHIRL  ; 3d
	const POLIWRATH  ; 3e
	const ABRA       ; 3f
	const KADABRA    ; 40
	const ALAKAZAM   ; 41
	const MACHOP     ; 42
	const MACHOKE    ; 43
	const MACHAMP    ; 44
	const BELLSPROUT ; 45
	const WEEPINBELL ; 46
	const VICTREEBEL ; 47
	const TENTACOOL  ; 48
	const TENTACRUEL ; 49
	const GEODUDE    ; 4a
	const GRAVELER   ; 4b
	const GOLEM      ; 4c
	const PONYTA     ; 4d
	const RAPIDASH   ; 4e
	const SLOWPOKE   ; 4f
	const SLOWBRO    ; 50
	const MAGNEMITE  ; 51
	const MAGNETON   ; 52
	const FARFETCH_D ; 53
	const DODUO      ; 54
	const DODRIO     ; 55
	const SEEL       ; 56
	const DEWGONG    ; 57
	const GRIMER     ; 58
	const MUK        ; 59
	const SHELLDER   ; 5a
	const CLOYSTER   ; 5b
	const GASTLY     ; 5c
	const HAUNTER    ; 5d
	const GENGAR     ; 5e
	const ONIX       ; 5f
	const DROWZEE    ; 60
	const HYPNO      ; 61
	const KRABBY     ; 62
	const KINGLER    ; 63
	const VOLTORB    ; 64
	const ELECTRODE  ; 65
	const EXEGGCUTE  ; 66
	const EXEGGUTOR  ; 67
	const CUBONE     ; 68
	const MAROWAK    ; 69
	const HITMONLEE  ; 6a
	const HITMONCHAN ; 6b
	const LICKITUNG  ; 6c
	const KOFFING    ; 6d
	const WEEZING    ; 6e
	const RHYHORN    ; 6f
	const RHYDON     ; 70
	const CHANSEY    ; 71
	const TANGELA    ; 72
	const KANGASKHAN ; 73
	const HORSEA     ; 74
	const SEADRA     ; 75
	const GOLDEEN    ; 76
	const SEAKING    ; 77
	const STARYU     ; 78
	const STARMIE    ; 79
	const MR__MIME   ; 7a
	const SCYTHER    ; 7b
	const JYNX       ; 7c
	const ELECTABUZZ ; 7d
	const MAGMAR     ; 7e
	const PINSIR     ; 7f
	const TAUROS     ; 80
	const MAGIKARP   ; 81
	const GYARADOS   ; 82
	const LAPRAS     ; 83
	const DITTO      ; 84
	const EEVEE      ; 85
	const VAPOREON   ; 86
	const JOLTEON    ; 87
	const FLAREON    ; 88
	const PORYGON    ; 89
	const OMANYTE    ; 8a
	const OMASTAR    ; 8b
	const KABUTO     ; 8c
	const KABUTOPS   ; 8d
	const AERODACTYL ; 8e
	const SNORLAX    ; 8f
	const ARTICUNO   ; 90
	const ZAPDOS     ; 91
	const MOLTRES    ; 92
	const DRATINI    ; 93
	const DRAGONAIR  ; 94
	const DRAGONITE  ; 95
	const MEWTWO     ; 96
	const MEW        ; 97
JOHTO_POKEMON EQU const_value
	const CHIKORITA  ; 98
	const BAYLEEF    ; 99
	const MEGANIUM   ; 9a
	const CYNDAQUIL  ; 9b
	const QUILAVA    ; 9c
	const TYPHLOSION ; 9d
	const TOTODILE   ; 9e
	const CROCONAW   ; 9f
	const FERALIGATR ; a0
	const SENTRET    ; a1
	const FURRET     ; a2
	const HOOTHOOT   ; a3
	const NOCTOWL    ; a4
	const LEDYBA     ; a5
	const LEDIAN     ; a6
	const SPINARAK   ; a7
	const ARIADOS    ; a8
	const CROBAT     ; a9
	const CHINCHOU   ; aa
	const LANTURN    ; ab
	const PICHU      ; ac
	const CLEFFA     ; ad
	const IGGLYBUFF  ; ae
	const TOGEPI     ; af
	const TOGETIC    ; b0
	const NATU       ; b1
	const XATU       ; b2
	const MAREEP     ; b3
	const FLAAFFY    ; b4
	const AMPHAROS   ; b5
	const BELLOSSOM  ; b6
	const MARILL     ; b7
	const AZUMARILL  ; b8
	const SUDOWOODO  ; b9
	const POLITOED   ; ba
	const HOPPIP     ; bb
	const SKIPLOOM   ; bc
	const JUMPLUFF   ; bd
	const AIPOM      ; be
	const SUNKERN    ; bf
	const SUNFLORA   ; c0
	const YANMA      ; c1
	const WOOPER     ; c2
	const QUAGSIRE   ; c3
	const ESPEON     ; c4
	const UMBREON    ; c5
	const MURKROW    ; c6
	const SLOWKING   ; c7
	const MISDREAVUS ; c8
	const UNOWN      ; c9
	const WOBBUFFET  ; ca
	const GIRAFARIG  ; cb
	const PINECO     ; cc
	const FORRETRESS ; cd
	const DUNSPARCE  ; ce
	const GLIGAR     ; cf
	const STEELIX    ; d0
	const SNUBBULL   ; d1
	const GRANBULL   ; d2
	const QWILFISH   ; d3
	const SCIZOR     ; d4
	const SHUCKLE    ; d5
	const HERACROSS  ; d6
	const SNEASEL    ; d7
	const TEDDIURSA  ; d8
	const URSARING   ; d9
	const SLUGMA     ; da
	const MAGCARGO   ; db
	const SWINUB     ; dc
	const PILOSWINE  ; dd
	const CORSOLA    ; de
	const REMORAID   ; df
	const OCTILLERY  ; e0
	const DELIBIRD   ; e1
	const MANTINE    ; e2
	const SKARMORY   ; e3
	const HOUNDOUR   ; e4
	const HOUNDOOM   ; e5
	const KINGDRA    ; e6
	const PHANPY     ; e7
	const DONPHAN    ; e8
	const PORYGON2   ; e9
	const STANTLER   ; ea
	const SMEARGLE   ; eb
	const TYROGUE    ; ec
	const HITMONTOP  ; ed
	const SMOOCHUM   ; ee
	const ELEKID     ; ef
	const MAGBY      ; f0
	const MILTANK    ; f1
	const BLISSEY    ; f2
	const RAIKOU     ; f3
	const ENTEI      ; f4
	const SUICUNE    ; f5
	const LARVITAR   ; f6
	const PUPITAR    ; f7
	const TYRANITAR  ; f8
	const LUGIA      ; f9
	const HO_OH      ; fa
	const CELEBI     ; fb
	const CHARMANDER_CLONE  ; fc
	const CHARMELEON_CLONE  ; fd
	const CHARIZARD_CLONE   ; fe
	const SQUIRTLE_CLONE    ; ff
	const WARTORTLE_CLONE   ; 100
	const BLASTOISE_CLONE   ; 101
	const BULBASAUR_CLONE   ; 102
	const IVYSAUR_CLONE     ; 103
	const VENUSAUR_CLONE    ; 104
	const HONCHKROW  ; 105
	const AMBIPOM    ;
	const ANNIHILAPE ;
	const BAGON      ;
	const SHELGON    ;
	const SALAMENCE  ;
	const DRUNSPARCE ;
	const ELECTIVIRE ;
	const FARIGIRAF  ;
	const RALTS      ;
	const KIRLIA     ;
	const GARDEVOIR  ;
	const GALLADE    ;
	const GLACEON    ;
	const LEAFEON    ;
	const SYLVEON    ;
	const GLISCOR    ;
	const LICKILICKY ;
	const MAGMORTAR  ;
	const MAGNEZONE  ;
	const MAMOSWINE  ;
	const MESMERIA   ;
	const MISMAGIUS  ;
	const PORYGON_Z  ;
	const RHYPERIOR  ;
	const VENIPEDE   ;
	const WHIRLIPEDE ;
	const SCOLIPEDE  ;
	const TANGROWTH  ;
	const TOGEKISS   ;
	const URSALUNA   ;
	const WEAVILE    ;
	const WYRDEER    ;
	const YANMEGA    ;
	const LILEEP     ;
	const CRADILY    ;
	const ANORITH    ;
	const ARMALDO    ;
	const GOLETT     ;
	const GOLURK     ;
	const DUSKULL    ;
	const DUSCLOPS   ;
	const DUSKNOIR   ;
	const TIMBURR    ;
	const GURDURR    ;
	const CONKELDURR ;
	const LARVESTA   ;
	const VOLCARONA  ;
	const DEINO      ;
	const ZWEILOUS   ;
	const HYDREIGON  ;
	const DREEPY     ;
	const DRAKLOAK   ;
	const DRAGAPULT  ;
	const IMPIDIMP   ;
	const MORGREM    ;
	const GRIMMSNARL ;
	const TINKATINK  ;
	const TINKATUFF  ;
	const TINKATON   ;
	const FRIGIBAX   ;
	const ARCTIBAX   ;
	const BAXCALIBUR ;
	const CHARCADET  ;
	const ARMAROUGE  ;
	const CERULEDGE  ;
	const ROOKIDEE   ;
	const CORVISQUIRE ;
	const CORVIKNIGHT ;
	const SNOVER     ;
	const ABOMASNOW  ;
	const SWABLU     ;
	const ALTARIA    ;
	const APPLIN     ;
	const DIPPLIN    ;
	const APPLETUN   ;
	const FLAPPLE    ;
	const HYDRAPPLE  ;
	const DURALUDON  ;
	const ARCHALUDON ;
	const SHROOMISH  ;
	const BRELOOM    ;
	const BUNEARY    ;
	const LOPUNNY    ;
	const NUMEL      ;
	const CAMERUPT   ;
	const SIZZLIPEDE ;
	const CENTISKORCH ;
	const GRUBBIN    ;
	const CHARJABUG  ;
	const VIKAVOLT   ;
	const CROAGUNK   ;
	const TOXICROAK  ;
	const DRIFLOON   ;
	const DRIFBLIM   ;
	const DRILBUR    ;
	const EXCADRILL  ;
	const KOTORA     ;
	const RAITORA    ;
	const GOROTORA   ;
	const FLETCHLING ;
	const FLETCHINDER ;
	const TALONFLAME ;
	const TRAPINCH   ;
	const VIBRAVA    ;
	const FLYGON     ;
	const SNORUNT    ;
	const FROSLASS   ;
	const WIMPOD     ;
	const GOLISOPOD  ;
	const SPOINK     ;
	const GRUMPIG    ;
	const PAWNIARD   ;
	const BISHARP    ;
	const KINGAMBIT  ;
	const LOTAD      ;
	const LOMBRE     ;
	const LUDICOLO   ;
	const OVERQWIL   ;
	const SCRAGGY    ;
	const SCRAFTY    ;
	const SPHEAL     ;
	const SEALEO     ;
	const WALREIN    ;
	const TEDDIURSABM ;
	const URSARINGBM ;
	const URSALUNABM ;
	const AXEW       ;
	const FRAXURE    ;
	const HAXORUS    ;
	const CRANIDOS   ;
	const RAMPARDOS  ;
	const SHIELDON   ;
	const BASTIODON  ;
	const CETODDLE   ;
	const CETITAN    ;
	const FEEBAS     ;
	const MILOTIC    ;
	const MIMIKYU    ;
	const CORSOLA_GALARIAN  ;
	const CURSOLA    ;
	const MR__RIME   ;
	const SIRFETCH_D ;
	const RIOLU      ;
	const LUCARIO    ;
	const TYRUNT     ;
	const TYRANTRUM  ;
	const AMAURA     ;
	const AURORUS    ;
	const MUNCHLAX   ;
	const TORKOAL    ;
	const RATTATA_ALOLAN    ;
	const RATICATE_ALOLAN   ;
	const RAICHU_ALOLAN     ;
	const SANDSHREW_ALOLAN  ;
	const SANDSLASH_ALOLAN  ;
	const VULPIX_ALOLAN     ;
	const NINETALES_ALOLAN  ;
	const DIGLETT_ALOLAN    ;
	const DUGTRIO_ALOLAN    ;
	const MEOWTH_ALOLAN     ;
	const PERSIAN_ALOLAN    ;
	const GEODUDE_ALOLAN    ;
	const GRAVELER_ALOLAN   ;
	const GOLEM_ALOLAN      ;
	const GRIMER_ALOLAN     ;
	const MUK_ALOLAN        ;
	const EXEGGUTOR_ALOLAN  ;
	const MAROWAK_ALOLAN    ;
	const MEOWTH_GALARIAN   ;
	const PERRSERKER        ;
	const PONYTA_GALARIAN   ;
	const RAPIDASH_GALARIAN ;
	const SLOWPOKE_GALARIAN ;
	const SLOWBRO_GALARIAN  ;
	const SLOWKING_GALARIAN ;
	const WEEZING_GALARIAN  ;
	const GROWLITHE_HISUIAN ;
	const ARCANINE_HISUIAN  ;
	const VOLTORB_HISUIAN   ;
	const ELECTRODE_HISUIAN ;
	const TYPHLOSION_HISUIAN;
	const SNEASEL_HISUIAN   ;
	const SNEASLER          ;
	const WOOPER_PALDEAN    ;
	const CLODSIRE          ;
	const TAUROS_PALDEAN_FIRE;
	const TAUROS_PALDEAN_WATER;
	const WATU              ;
	const BOUNSWEET         ;
	const STEENEE           ;
	const TSAREENA          ;
	const ARON              ;
	const LAIRON            ;
	const AGGRON            ;
	const KLEAVOR           ;
	const GLIMMET           ;
	const GLIMMORA          ;
	const MAREANIE          ;
	const TOXAPEX           ;
	const ZANGOOSE          ;
	const SEVIPER           ;
	const SHUPPET           ;
	const BANETTE           ;
	const ARCHEN            ;
	const ARCHEOPS          ;
	const TIRTOUGA          ;
	const CARRACOSTA        ;
	const LITWICK           ;
	const LAMPENT           ;
	const CHANDELURE        ;
	const JOLTIK            ;
	const GALVANTULA        ;
	const MAWILE            ;
	const NOIBAT            ;
	const NOIVERN           ;
	const SALANDIT          ;
	const SALAZZLE          ;
	const FLITTLE           ;
	const ESPATHRA          ;
	const FINIZEN           ;
	const PALAFIN           ;
NUM_POKEMON EQU const_value + -1

EGG EQU -3

; limits:
; 999: everything that prints dex counts
; 1407: size of wPokedexOrder
; 4095: hard limit; would require serious redesign to increase
if NUM_POKEMON > 999
	fail "Too many Pokémon defined!"
endc

; Unown forms
; indexes for:
; - UnownWords (see data/pokemon/unown_words.asm)
; - UnownPicPointers (see data/pokemon/unown_pic_pointers.asm)
; - UnownAnimationPointers (see gfx/pokemon/unown_anim_pointers.asm)
; - UnownAnimationIdlePointers (see gfx/pokemon/unown_idle_pointers.asm)
; - UnownBitmasksPointers (see gfx/pokemon/unown_bitmask_pointers.asm)
; - UnownFramesPointers (see gfx/pokemon/unown_frame_pointers.asm)
	const_def 1
	const UNOWN_A ;  1
	const UNOWN_B ;  2
	const UNOWN_C ;  3
	const UNOWN_D ;  4
	const UNOWN_E ;  5
	const UNOWN_F ;  6
	const UNOWN_G ;  7
	const UNOWN_H ;  8
	const UNOWN_I ;  9
	const UNOWN_J ; 10
	const UNOWN_K ; 11
	const UNOWN_L ; 12
	const UNOWN_M ; 13
	const UNOWN_N ; 14
	const UNOWN_O ; 15
	const UNOWN_P ; 16
	const UNOWN_Q ; 17
	const UNOWN_R ; 18
	const UNOWN_S ; 19
	const UNOWN_T ; 20
	const UNOWN_U ; 21
	const UNOWN_V ; 22
	const UNOWN_W ; 23
	const UNOWN_X ; 24
	const UNOWN_Y ; 25
	const UNOWN_Z ; 26
NUM_UNOWN EQU const_value + -1 ; 26
