GOLDENRODPOKECENTER1F_FEEBAS_PRICE EQU 2000
GOLDENRODPOKECENTER1F_FEEBAS_LEVEL EQU 10

	object_const_def ; object_event constants
	const GOLDENRODPOKECENTER1F_NURSE
	const GOLDENRODPOKECENTER1F_BILL
	const GOLDENRODPOKECENTER1F_GAMEBOY_KID
	const GOLDENRODPOKECENTER1F_LASS
	const GOLDENRODPOKECENTER1F_POKEFAN_F
	const GOLDENRODPOKECENTER1F_FEEBAS_SALESMAN

GoldenrodPokecenter1F_MapScripts:
	db 0 ; scene scripts

	db 0 ; callbacks

GoldenrodPokecenter1FNurseScript:
	jumpstd pokecenternurse

GoldenrodPokecenter1F_GSBallSceneLeft:
	; Unlock immediately after the battle, before the Dragon's Den ceremony.
	checkevent EVENT_BEAT_CLAIR
	iffalse .cancel
	checkevent EVENT_GOT_GS_BALL_FROM_POKECOM_CENTER
	iftrue .cancel
	playsound SFX_EXIT_BUILDING
	moveobject GOLDENRODPOKECENTER1F_BILL, 0, 6
	disappear GOLDENRODPOKECENTER1F_BILL
	appear GOLDENRODPOKECENTER1F_BILL
	playmusic MUSIC_SHOW_ME_AROUND
	applymovement GOLDENRODPOKECENTER1F_BILL, GoldenrodPokeCenter1FBillApproachPlayerAtLeftDoorwayTileMovement
	turnobject PLAYER, UP
	opentext
	writetext GoldenrodPokeCenter1FBillPleaseAcceptGSBallText
	waitbutton
	verbosegiveitem GS_BALL
	iffalse .leave
	setevent EVENT_GOT_GS_BALL_FROM_POKECOM_CENTER
	setevent EVENT_CAN_GIVE_GS_BALL_TO_KURT
	writetext GoldenrodPokeCenter1FBillAfterGSBallText
	waitbutton
.leave
	closetext
	applymovement GOLDENRODPOKECENTER1F_BILL, GoldenrodPokeCenter1FBillWalkToStairsFromLeftDoorwayTileMovement
	special RestartMapMusic
	disappear GOLDENRODPOKECENTER1F_BILL
	playsound SFX_EXIT_BUILDING
.cancel
	end

GoldenrodPokecenter1F_GSBallSceneRight:
	checkevent EVENT_BEAT_CLAIR
	iffalse .cancel
	checkevent EVENT_GOT_GS_BALL_FROM_POKECOM_CENTER
	iftrue .cancel
	playsound SFX_EXIT_BUILDING
	moveobject GOLDENRODPOKECENTER1F_BILL, 0, 6
	disappear GOLDENRODPOKECENTER1F_BILL
	appear GOLDENRODPOKECENTER1F_BILL
	playmusic MUSIC_SHOW_ME_AROUND
	applymovement GOLDENRODPOKECENTER1F_BILL, GoldenrodPokeCenter1FBillApproachPlayerAtRightDoorwayTileMovement
	turnobject PLAYER, UP
	opentext
	writetext GoldenrodPokeCenter1FBillPleaseAcceptGSBallText
	waitbutton
	verbosegiveitem GS_BALL
	iffalse .leave
	setevent EVENT_GOT_GS_BALL_FROM_POKECOM_CENTER
	setevent EVENT_CAN_GIVE_GS_BALL_TO_KURT
	writetext GoldenrodPokeCenter1FBillAfterGSBallText
	waitbutton
.leave
	closetext
	applymovement GOLDENRODPOKECENTER1F_BILL, GoldenrodPokeCenter1FBillWalkToStairsFromRightDoorwayTileMovement
	special RestartMapMusic
	disappear GOLDENRODPOKECENTER1F_BILL
	playsound SFX_EXIT_BUILDING
.cancel
	end

GoldenrodPokecenter1FGameboyKidScript:
	jumptextfaceplayer GoldenrodPokecenter1FGameboyKidText

GoldenrodPokecenter1FLassScript:
	jumptextfaceplayer GoldenrodPokecenter1FLassText

GoldenrodPokecenter1FPokefanF:
	faceplayer
	opentext
	writetext GoldenrodPokecenter1FPokefanFDoYouHaveEonMailText
	waitbutton
	writetext GoldenrodPokecenter1FAskGiveAwayAnEonMailText
	yesorno
	iffalse .NoEonMail
	takeitem EON_MAIL
	iffalse .NoEonMail
	writetext GoldenrodPokecenter1FPlayerGaveAwayTheEonMailText
	waitbutton
	writetext GoldenrodPokecenter1FPokefanFThisIsForYouText
	waitbutton
	verbosegiveitem REVIVE
	iffalse .NoRoom
	writetext GoldenrodPokecenter1FPokefanFDaughterWillBeDelightedText
	waitbutton
	closetext
	end

.NoEonMail:
	writetext GoldenrodPokecenter1FPokefanFTooBadText
	waitbutton
	closetext
	end

.NoRoom:
	giveitem EON_MAIL
	writetext GoldenrodPokecenter1FPokefanFAnotherTimeThenText
	waitbutton
	closetext
	end

GoldenrodPokecenter1FFeebasSalesmanScript:
	faceplayer
	opentext
	writetext GoldenrodPokecenter1FFeebasSalesmanOfferText
	yesorno
	iffalse .Refused
	checkmoney YOUR_MONEY, GOLDENRODPOKECENTER1F_FEEBAS_PRICE
	ifequal HAVE_LESS, .NotEnoughMoney
	; don't take the money if the FEEBAS has nowhere to go
	readvar VAR_PARTYCOUNT
	ifless PARTY_LENGTH, .HaveRoom
	readvar VAR_BOXSPACE
	ifequal 0, .NoRoom
.HaveRoom:
	writetext GoldenrodPokecenter1FFeebasSalesmanSoldText
	buttonsound
	takemoney YOUR_MONEY, GOLDENRODPOKECENTER1F_FEEBAS_PRICE
	playsound SFX_TRANSACTION
	waitsfx
; same presentation as verbosegiveitem: the "received" line, then the
; item jingle, then the nickname prompt that givepoke raises
	writetext GoldenrodPokecenter1FFeebasSalesmanReceivedFeebasText
	playsound SFX_ITEM
	waitsfx
	waitbutton
	givepoke FEEBAS, GOLDENRODPOKECENTER1F_FEEBAS_LEVEL
	writetext GoldenrodPokecenter1FFeebasSalesmanSuckerText
	waitbutton
	closetext
; He stands at (5, 3), so he can only have been spoken to from (4, 3),
; (6, 3) or (5, 4). Leave by whichever route does not walk through the
; player: down his own column first if they are on his left, otherwise
; straight into column 4.
	readvar VAR_XCOORD
	ifequal 4, .LeaveDownFirst
	applymovement GOLDENRODPOKECENTER1F_FEEBAS_SALESMAN, GoldenrodPokecenter1FFeebasSalesmanLeavesLeftFirstMovement
	sjump .LeaveDone

.LeaveDownFirst:
	applymovement GOLDENRODPOKECENTER1F_FEEBAS_SALESMAN, GoldenrodPokecenter1FFeebasSalesmanLeavesDownFirstMovement

.LeaveDone:
	playsound SFX_EXIT_BUILDING
	disappear GOLDENRODPOKECENTER1F_FEEBAS_SALESMAN
	setevent EVENT_GOLDENROD_POKECENTER_FEEBAS_SALESMAN_LEFT
	waitsfx
	end

.Refused:
	writetext GoldenrodPokecenter1FFeebasSalesmanRefusedText
	waitbutton
	closetext
	end

.NoRoom:
	writetext GoldenrodPokecenter1FFeebasSalesmanNoRoomText
	waitbutton
	closetext
	end

.NotEnoughMoney:
	writetext GoldenrodPokecenter1FFeebasSalesmanNoMoneyText
	waitbutton
	closetext
	end

GoldenrodPokecenter1FFeebasSalesmanLeavesLeftFirstMovement:
; player is at (6, 3) or (5, 4): cut into column 4 and walk down to the door
	step LEFT
	step DOWN
	step DOWN
	step DOWN
	step DOWN
	step_end

GoldenrodPokecenter1FFeebasSalesmanLeavesDownFirstMovement:
; player is at (4, 3): stay in column 5 until past them, then cut across
	step DOWN
	step DOWN
	step DOWN
	step LEFT
	step DOWN
	step_end

GoldenrodPokeCenter1FBillApproachPlayerAtLeftDoorwayTileMovement:
	step UP
	step RIGHT
	step RIGHT
	step RIGHT
	turn_head DOWN
	step_end

GoldenrodPokeCenter1FBillWalkToStairsFromLeftDoorwayTileMovement:
	step LEFT
	step LEFT
	step LEFT
	step DOWN
	step_end

GoldenrodPokeCenter1FBillApproachPlayerAtRightDoorwayTileMovement:
	step UP
	step RIGHT
	step RIGHT
	step RIGHT
	step RIGHT
	turn_head DOWN
	step_end

GoldenrodPokeCenter1FBillWalkToStairsFromRightDoorwayTileMovement:
	step LEFT
	step LEFT
	step LEFT
	step LEFT
	step DOWN
	step_end

; unused
UnknownText_0x61072:
	text "Hello! Welcome to"
	line "#COM CENTER"
	cont "TRADE CORNER."

	para "You can trade"
	line "#MON with other"
	cont "people far away."
	done

UnknownText_0x610ce:
	text "To make a trade,"
	line "we must hold your"
	cont "#MON."

	para "Would you like to"
	line "trade?"
	done

UnknownText_0x61111:
	text "What kind of"
	line "#MON do you"
	cont "want in return?"
	done

UnknownText_0x6113b:
	text "Fine. We will try"
	line "to trade your"

	para "@"
	text_ram wStringBuffer3
	text " for"
	line "@"
	text_ram wStringBuffer4
	text "."

	para "We'll have to hold"
	line "your #MON"
	cont "during the trade."

	para "Please wait while"
	line "we prepare the"
	cont "room for it."
	done

UnknownText_0x611c9:
	text "Fine. We will try"
	line "to trade your"

	para "@"
	text_ram wStringBuffer3
	text " for a"
	line "#MON that you"
	cont "have never seen."

	para "We'll have to hold"
	line "your #MON"
	cont "during the trade."

	para "Please wait while"
	line "we prepare the"
	cont "room for it."
	done

UnknownText_0x61271:
	text "Your trade #MON"
	line "has been received."

	para "It will take time"
	line "to find a trade"

	para "partner. Please"
	line "come back later."
	done

UnknownText_0x612d8:
	text "Oh? You have only"
	line "one #MON in"
	cont "your party. "

	para "Please come back"
	line "once you've in-"
	cont "creased the size"
	cont "of your party."
	done

UnknownText_0x61344:
	text "We hope to see you"
	line "again."
	done

UnknownText_0x6135f:
	text "Communication"
	line "error…"
	done

UnknownText_0x61375:
	text "If we accept that"
	line "#MON, what will"
	cont "you battle with?"
	done

UnknownText_0x613a9:
	text "Sorry. We can't"
	line "accept an EGG."
	done

UnknownText_0x613c8:
	text "Sorry, but your"
	line "#MON appears to"

	para "be abnormal. We"
	line "can't accept it."
	done

UnknownText_0x61409:
	text "Oh? Aren't we"
	line "already holding a"
	cont "#MON of yours?"
	done

UnknownText_0x61438:
	text "We'll check the"
	line "rooms."

	para "Please wait."
	done

UnknownText_0x6145c:
	text "Thank you for your"
	line "patience."

	para "A trade partner"
	line "has been found."
	done

UnknownText_0x6149a:
	text "It's your new"
	line "partner."

	para "Please take care"
	line "of it with love."

	para "We hope to see you"
	line "again."
	done

UnknownText_0x614ed:
	text "Uh-oh. Your party"
	line "is already full."

	para "Please come back"
	line "when you have room"
	cont "in your party."
	done

UnknownText_0x61544:
	text "It's unfortunate,"
	line "but no one has"

	para "come forward as a"
	line "trade partner."

	para "Would you like"
	line "your #MON back?"
	done

UnknownText_0x615a5:
	text "We have returned"
	line "your #MON."
	done

UnknownText_0x615c2:
	text "It's unfortunate,"
	line "but no one has"

	para "come forward as a"
	line "trade partner."

	para "We've held your"
	line "#MON for a long"

	para "time. As a result,"
	line "it is very lonely."

	para "Sorry, but we must"
	line "return it to you."
	done

UnknownText_0x6166e:
	text "We hope to see you"
	line "again."
	done

UnknownText_0x61689:
	text "Fine. We will"
	line "continue to hold"
	cont "your #MON."
	done

UnknownText_0x616b4:
	text "Oh? You left your"
	line "#MON with us"
	cont "only recently."

	para "Please come back"
	line "later."
	done

UnknownText_0x616fb:
	text "We'll SAVE before"
	line "connecting to the"
	cont "CENTER."
	done

UnknownText_0x61727:
	text "Which #MON do"
	line "you want to trade?"
	done

UnknownText_0x61749:
	text "Sorry, but we must"
	line "cancel the trade."
	done

UnknownText_0x6191f:
	text "Please wait a"
	line "moment."
	done

UnknownText_0x619db:
	text "It's a #MON"
	line "NEWS MACHINE."
	done

UnknownText_0x619f5:
	text "What would you"
	line "like to do?"
	done

UnknownText_0x61a11:
	text "#MON NEWS is"
	line "news compiled from"

	para "the SAVE files of"
	line "#MON trainers."

	para "When reading the"
	line "NEWS, your SAVE"

	para "file may be sent"
	line "out."

	para "The SAVE file data"
	line "will contain your"

	para "adventure log and"
	line "mobile profile."

	para "Your phone number"
	line "will not be sent."

	para "The contents of"
	line "the NEWS will vary"

	para "depending on the"
	line "SAVE files sent by"

	para "you and the other"
	line "#MON trainers."

	para "You might even be"
	line "in the NEWS!"
	done

UnknownText_0x61b7c:
	text "Would you like to"
	line "get the NEWS?"
	done

UnknownText_0x61b9d:
	text "Reading the latest"
	line "NEWS… Please wait."
	done

UnknownText_0x61bc4:
	text "There is no old"
	line "NEWS…"
	done

UnknownText_0x61bdb:
	text "The NEWS data is"
	line "corrupted."

	para "Please download"
	line "the NEWS again."
	done

UnknownText_0x61c18:
	text "We're making"
	line "preparations."

	para "Please come back"
	line "later."
	done

UnknownText_0x61c4b:
	text "We will SAVE your"
	line "progress before"

	para "starting the NEWS"
	line "MACHINE."
	done

UnknownText_0x61c89:
	text "Whoa, this #MON"
	line "CENTER is huge."

	para "They just built"
	line "this place. They"

	para "installed lots of"
	line "new machines too."
	done

UnknownText_0x61cef:
	text "I thought up a fun"
	line "new thing for the"
	cont "TRADE CORNER!"

	para "I make a PIDGEY"
	line "hold MAIL, then"

	para "put it up for"
	line "trade for another"
	cont "one!"

	para "If everyone did"
	line "that, MAIL could"

	para "be traded with all"
	line "sorts of people!"

	para "I call it PIDGEY"
	line "MAIL!"

	para "If it becomes"
	line "popular, I might"

	para "make lots of new"
	line "friends!"
	done

UnknownText_0x61dfd:
	text "They said you can"
	line "trade #MON with"

	para "total strangers up"
	line "here."

	para "But they're still"
	line "adjusting things."
	done

UnknownText_0x61e5c:
	text "Some girl I don't"
	line "know sent me her"

	para "HOPPIP."
	line "You should trade"

	para "for a #MON that"
	line "you want."
	done

UnknownText_0x61eb2:
	text "I received a"
	line "female HOPPIP, but"
	cont "its named STANLEY!"

	para "That's my dad's"
	line "name!"
	done

UnknownText_0x61efa:
	text "What is the NEWS"
	line "MACHINE?"

	para "Does it get news"
	line "from a wider area"
	cont "than the radio?"
	done

UnknownText_0x61f48:
	text "The #COM CENTER"
	line "will link with all"

	para "#MON CENTERS in"
	line "a wireless net."

	para "That must mean"
	line "I'll be able to"

	para "link with all"
	line "sorts of people."
	done

UnknownText_0x61fc9:
	text "The machines here"
	line "can't be used yet."

	para "Still, it's nice"
	line "coming to a trendy"

	para "place before other"
	line "people."
	done

UnknownText_0x6202c:
	text "My friend was in"
	line "the NEWS a while"

	para "back. I was really"
	line "surprised!"
	done

UnknownText_0x6206d:
	text "I get anxious if I"
	line "don't check out"
	cont "the latest NEWS!"
	done

UnknownText_0x620a1:
	text "If I get in the"
	line "NEWS and become"

	para "famous, I bet I'll"
	line "be adored."

	para "I wonder how I"
	line "could get in the"
	cont "NEWS?"
	done

GoldenrodPokecenter1FGameboyKidText:
	text "The COLOSSEUM"
	line "upstairs is for"
	cont "link battles."

	para "Battle records are"
	line "posted on the"

	para "wall, so I can't"
	line "afford to lose."
	done

UnknownText_0x62173:
	text "I came over here"
	line "when I got word"

	para "that GOLDENROD's"
	line "#MON CENTER has"

	para "new machines that"
	line "no one's ever seen"
	cont "before."

	para "But it looks like"
	line "they're still busy"

	para "with all their"
	line "preparations…"
	done

UnknownText_0x62222:
	text "Just seeing all"
	line "these new things"

	para "here makes me feel"
	line "younger!"
	done

GoldenrodPokecenter1FLassText:
	text "A higher level"
	line "#MON doesn't"
	cont "always win."

	para "After all, it may"
	line "have a type dis-"
	cont "advantage."

	para "I don't think"
	line "there is a single"

	para "#MON that is"
	line "the toughest."
	done

GoldenrodPokeCenter1FBillPleaseAcceptGSBallText:
	text "I recently got my"
	line "hands on a very"
	cont "unusual # BALL"
	cont "from an old"
	cont "collection."

	para "I've never seen"
	line "anything quite"
	cont "like it. I can't"
	cont "even figure out"
	cont "how to open it!"

	para "I was hoping KURT"
	line "in AZALEA TOWN"
	cont "might know"
	cont "something about"
	cont "it. Would you mind"
	cont "taking it to him?"
	done

GoldenrodPokeCenter1FBillAfterGSBallText:
	text "I knew I could"
	line "count on you,"
	cont "<PLAYER>!"

	para "KURT is the"
	line "absolute authority"
	cont "on # BALLS."
	cont "Surely he'll be"
	cont "able to figure it"
	cont "out."

	para "I have to get back"
	line "to work. See you"
	cont "later!"
	done

UnknownText_0x62370:
	text "#COM CENTER"
	line "1F INFORMATION"

	para "Left:"
	line "ADMINISTRATION"

	para "Center:"
	line "TRADE CORNER"

	para "Right:"
	line "#MON NEWS"
	done

UnknownText_0x623c7:
	text "It's a #MON"
	line "NEWS MACHINE!"

	para "It's not in"
	line "operation yet…"
	done

GoldenrodPokecenter1FPokefanFDoYouHaveEonMailText:
	text "Oh my, your pack"
	line "looks so heavy!"

	para "Oh! Do you happen"
	line "to have something"
	cont "named EON MAIL?"

	para "My daughter is"
	line "after one."

	para "You can part with"
	line "one, can't you?"
	done

GoldenrodPokecenter1FAskGiveAwayAnEonMailText:
	text "Give away an EON"
	line "MAIL?"
	done

GoldenrodPokecenter1FPokefanFThisIsForYouText:
	text "Oh, that's great!"
	line "Thank you, honey!"

	para "Here, this is for"
	line "you in return!"
	done

GoldenrodPokecenter1FPokefanFDaughterWillBeDelightedText:
	text "My daughter will"
	line "be delighted!"
	done

GoldenrodPokecenter1FPokefanFTooBadText:
	text "Oh? You don't have"
	line "one? Too bad."
	done

GoldenrodPokecenter1FPokefanFAnotherTimeThenText:
	text "Oh… Well, another"
	line "time, then."
	done

GoldenrodPokecenter1FPlayerGaveAwayTheEonMailText:
	text "<PLAYER> gave away"
	line "the EON MAIL."
	done

GoldenrodPokecenter1FFeebasSalesmanOfferText:
	text "Well hello there!"

	para "How would you like"
	line "to purchase this"
	cont "swell FEEBAS for"
	cont "¥2000?"

	para "This is a once in"
	line "a lifetime kind of"
	cont "deal!"

	para "What do you say?"
	done

GoldenrodPokecenter1FFeebasSalesmanRefusedText:
	text "……fine."
	done

GoldenrodPokecenter1FFeebasSalesmanNoRoomText:
	text "Hey now! You've"
	line "got no room for"
	cont "another #MON."

	para "Make some space"
	line "and come back!"
	done

GoldenrodPokecenter1FFeebasSalesmanNoMoneyText:
	text "Hey now! You don't"
	line "even have ¥2000."

	para "Come back when"
	line "you're loaded."
	done

GoldenrodPokecenter1FFeebasSalesmanSoldText:
	text "Wonderful!"
	line "You won't regret"
	cont "this!"
	done

GoldenrodPokecenter1FFeebasSalesmanReceivedFeebasText:
	text "<PLAYER> received"
	line "FEEBAS!"
	done

GoldenrodPokecenter1FFeebasSalesmanSuckerText:
	text "Heheh… Sucker!"

	para "That thing's"
	line "worthless. I'm off"
	cont "to the SLOTS!"
	done

GoldenrodPokecenter1F_MapEvents:
	db 0, 0 ; filler

	db 4 ; warp events
	warp_event  3,  7, GOLDENROD_CITY, 15
	warp_event  4,  7, GOLDENROD_CITY, 15
	warp_event  0,  6, POKECOM_CENTER_ADMIN_OFFICE_MOBILE, 1
	warp_event  0,  7, POKECENTER_2F, 1

	db 2 ; coord events
	; Keep these inside the doorway so the exit warp cannot take priority.
	coord_event  3,  6, SCENE_DEFAULT, GoldenrodPokecenter1F_GSBallSceneLeft
	coord_event  4,  6, SCENE_DEFAULT, GoldenrodPokecenter1F_GSBallSceneRight

	db 0 ; bg events

	db 6 ; object events
	object_event  3,  1, SPRITE_NURSE, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, 0, OBJECTTYPE_SCRIPT, 0, GoldenrodPokecenter1FNurseScript, -1
	object_event 16,  8, SPRITE_BILL, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, 0, OBJECTTYPE_SCRIPT, 0, ObjectEvent, -1
	object_event  6,  1, SPRITE_GAMEBOY_KID, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_SCRIPT, 0, GoldenrodPokecenter1FGameboyKidScript, -1
	object_event  1,  4, SPRITE_LASS, SPRITEMOVEDATA_WALK_LEFT_RIGHT, 1, 0, -1, -1, 0, OBJECTTYPE_SCRIPT, 0, GoldenrodPokecenter1FLassScript, -1
	object_event  7,  5, SPRITE_POKEFAN_F, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_BROWN, OBJECTTYPE_SCRIPT, 0, GoldenrodPokecenter1FPokefanF, -1
	object_event  5,  3, SPRITE_FAT_GUY, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_PURPLE, OBJECTTYPE_SCRIPT, 0, GoldenrodPokecenter1FFeebasSalesmanScript, EVENT_GOLDENROD_POKECENTER_FEEBAS_SALESMAN_LEFT
