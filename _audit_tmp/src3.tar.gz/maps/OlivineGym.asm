	object_const_def ; object_event constants
	const OLIVINEGYM_JASMINE
	const OLIVINEGYM_GYM_GUY
	const OLIVINEGYM_DANIELLE
	const OLIVINEGYM_KATHRYN
	const OLIVINEGYM_ELISE

OlivineGym_MapScripts:
	db 0 ; scene scripts

	db 1 ; callbacks
	callback MAPCALLBACK_OBJECTS, .LassesCallback

.LassesCallback:
; The gym trainers only appear once Jasmine has returned to the gym
; from the lighthouse (after the sick Ampharos event).
	checkevent EVENT_JASMINE_RETURNED_TO_GYM
	iftrue .ShowLasses
	disappear OLIVINEGYM_DANIELLE
	disappear OLIVINEGYM_KATHRYN
	disappear OLIVINEGYM_ELISE
	return

.ShowLasses:
	appear OLIVINEGYM_DANIELLE
	appear OLIVINEGYM_KATHRYN
	appear OLIVINEGYM_ELISE
	return

OlivineGymJasmineScript:
	faceplayer
	opentext
	checkevent EVENT_BEAT_JASMINE
	iftrue .FightDone
	writetext Jasmine_SteelTypeIntro
	waitbutton
	closetext
	winlosstext Jasmine_BetterTrainer, 0
	loadtrainer JASMINE, JASMINE1
	startbattle
	reloadmapafterbattle
	setevent EVENT_BEAT_JASMINE
	opentext
	writetext Text_ReceivedMineralBadge
	playsound SFX_GET_BADGE
	waitsfx
	setflag ENGINE_MINERALBADGE
	readvar VAR_BADGES
	scall OlivineGymActivateRockets
.FightDone:
	checkevent EVENT_GOT_TM23_IRON_HEAD
	iftrue .GotIronHead
	writetext Jasmine_BadgeSpeech
	buttonsound
	verbosegiveitem TM_IRON_HEAD
	iffalse .NoRoomForIronHead
	setevent EVENT_GOT_TM23_IRON_HEAD
	writetext Jasmine_IronHeadSpeech
	buttonsound
.GiveMetalCoat:
	checkevent EVENT_GOT_METAL_COAT_FROM_JASMINE
	iftrue .GotMetalCoat
	writetext Jasmine_MetalCoatOffer
	buttonsound
	verbosegiveitem METAL_COAT
	iffalse .NoRoomForMetalCoat
	setevent EVENT_GOT_METAL_COAT_FROM_JASMINE
	writetext Jasmine_MetalCoatSpeech
	waitbutton
.GotMetalCoat:
	closetext
	end

.GotIronHead:
	checkevent EVENT_GOT_METAL_COAT_FROM_JASMINE
	iffalse .GiveMetalCoat
	checkevent EVENT_BEAT_JASMINE_REMATCH
	iftrue .RematchDone
	checkevent EVENT_BEAT_ELITE_FOUR
	iffalse .RematchDone
	writetext JasmineRematchChallengeText
	yesorno
	iffalse .RematchDone
	closetext
	winlosstext JasmineRematchWinText, 0
	loadtrainer JASMINE_REMATCH, JASMINE2
	startbattle
	reloadmapafterbattle
	setevent EVENT_BEAT_JASMINE_REMATCH
	end

.RematchDone:
	writetext Jasmine_GoodLuck
	waitbutton
.NoRoomForIronHead:
.NoRoomForMetalCoat:
	closetext
	end

OlivineGymActivateRockets:
	ifequal 7, .RadioTowerRockets
	ifequal 6, .GoldenrodRockets
	end

.GoldenrodRockets:
	jumpstd goldenrodrockets

.RadioTowerRockets:
	jumpstd radiotowerrockets

OlivineGymGuyScript:
	faceplayer
	checkevent EVENT_BEAT_JASMINE
	iftrue .OlivineGymGuyWinScript
	checkevent EVENT_JASMINE_RETURNED_TO_GYM
	iffalse .OlivineGymGuyPreScript
	opentext
	writetext OlivineGymGuyText
	waitbutton
	closetext
	end

.OlivineGymGuyWinScript:
	opentext
	writetext OlivineGymGuyWinText
	waitbutton
	closetext
	end

.OlivineGymGuyPreScript:
	opentext
	writetext OlivineGymGuyPreText
	waitbutton
	closetext
	end

TrainerLassDanielle:
	trainer LASS, DANIELLE, EVENT_BEAT_LASS_DANIELLE, LassDanielleSeenText, LassDanielleBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext LassDanielleAfterBattleText
	waitbutton
	closetext
	end

TrainerLassKathryn:
	trainer LASS, KATHRYN, EVENT_BEAT_LASS_KATHRYN, LassKathrynSeenText, LassKathrynBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext LassKathrynAfterBattleText
	waitbutton
	closetext
	end

TrainerLassElise:
	trainer LASS, ELISE, EVENT_BEAT_LASS_ELISE, LassEliseSeenText, LassEliseBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext LassEliseAfterBattleText
	waitbutton
	closetext
	end

OlivineGymStatue:
	checkflag ENGINE_MINERALBADGE
	iftrue .Beaten
	jumpstd gymstatue1
.Beaten:
	gettrainername STRING_BUFFER_4, JASMINE, JASMINE1
	jumpstd gymstatue2

Jasmine_SteelTypeIntro:
	text "…Thank you for"
	line "your help at the"
	cont "LIGHTHOUSE…"

	para "But this is dif-"
	line "ferent. Please"

	para "allow me to intro-"
	line "duce myself."

	para "I am JASMINE, a"
	line "GYM LEADER. I use"
	cont "the steel-type."

	para "…Do you know about"
	line "the steel-type?"

	para "It's a type that"
	line "was only recently"
	cont "discovered."

	para "…Um… May I begin?"
	done

Jasmine_BetterTrainer:
	text "…You are a better"
	line "trainer than me,"

	para "in both skill and"
	line "kindness."

	para "In accordance with"
	line "LEAGUE rules, I"

	para "confer upon you"
	line "this BADGE."
	done

Text_ReceivedMineralBadge:
	text "<PLAYER> received"
	line "MINERALBADGE."
	done

Jasmine_BadgeSpeech:
	text "…Um… Please take"
	line "this too…"
	done

Text_ReceivedTM09:
	text "<PLAYER> received"
	line "TM09."
	done

Jasmine_IronHeadSpeech:
	text "…You could use"
	line "that TM to teach"
	cont "IRON HEAD."
	done

Jasmine_MetalCoatOffer:
	text "Oh… And please,"
	line "take this as well."
	done

Jasmine_MetalCoatSpeech:
	text "It's a METAL COAT."
	line "STEELIX was just"
	cont "an ONIX that held"
	cont "one."
	done

Jasmine_GoodLuck:
	text "Um… I don't know"
	line "how to say this,"
	cont "but good luck…"
	done

OlivineGymGuyText:
	text "JASMINE uses the"
	line "newly discovered"
	cont "steel-type."

	para "I don't know very"
	line "much about it."
	done

OlivineGymGuyWinText:
	text "That was awesome."

	para "The steel-type,"
	line "huh?"

	para "That was a close"
	line "encounter of an"
	cont "unknown kind!"
	done

OlivineGymGuyPreText:
	text "JASMINE, the GYM"
	line "LEADER, is at the"
	cont "LIGHTHOUSE."

	para "She's been tending"
	line "to a sick #MON."

	para "A strong trainer"
	line "has to be compas-"
	cont "sionate."
	done

JasmineRematchChallengeText:
	text "…Welcome back."

	para "I've been working"
	line "with my team."
	cont "Would you like to"
	cont "see how we battle"
	cont "now?"
	done

JasmineRematchWinText:
	text "…We gave it our"
	line "best. Thank you"
	cont "for the battle."
	done

LassDanielleSeenText:
	text "Now that JASMINE"
	line "is back, we GYM"
	cont "TRAINERS are on"
	cont "duty again!"

	para "Let's see if you"
	line "can get past my"
	cont "steel-types!"
	done

LassDanielleBeatenText:
	text "Ohh, my #MON"
	line "got all scuffed"
	cont "up!"
	done

LassDanielleAfterBattleText:
	text "Steel-types have"
	line "so few weak-"
	cont "nesses."

	para "That's why we love"
	line "training them for"
	cont "JASMINE!"
	done

LassKathrynSeenText:
	text "I've been polish-"
	line "ing my steel-types"
	cont "just for today!"

	para "They won't rust"
	line "so easily!"
	done

LassKathrynBeatenText:
	text "My MAGNETON stuck"
	line "to the wall again!"
	done

LassKathrynAfterBattleText:
	text "JASMINE is waiting"
	line "at the back of"
	cont "the GYM."

	para "You've earned your"
	line "shot at her now."
	done

LassEliseSeenText:
	text "My MAWILE looks"
	line "sweet, but its"
	cont "jaws are pure"
	cont "steel!"
	done

LassEliseBeatenText:
	text "Clang!"
	done

LassEliseAfterBattleText:
	text "JASMINE taught me"
	line "to look for the"
	cont "weak joint in"
	cont "every suit of"
	cont "armor."

	para "You found mine"
	line "first."
	done

OlivineGym_MapEvents:
	db 0, 0 ; filler

	db 2 ; warp events
	warp_event  4, 15, OLIVINE_CITY, 2
	warp_event  5, 15, OLIVINE_CITY, 2

	db 0 ; coord events

	db 2 ; bg events
	bg_event  3, 13, BGEVENT_READ, OlivineGymStatue
	bg_event  6, 13, BGEVENT_READ, OlivineGymStatue

	db 5 ; object events
	object_event  5,  3, SPRITE_JASMINE, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_SCRIPT, 0, OlivineGymJasmineScript, EVENT_OLIVINE_GYM_JASMINE
	object_event  7, 13, SPRITE_GYM_GUY, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_SCRIPT, 0, OlivineGymGuyScript, -1
	object_event  6,  9, SPRITE_LASS, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 1, TrainerLassDanielle, EVENT_OLIVINE_GYM_LASS_DANIELLE
	object_event  3, 11, SPRITE_LASS, SPRITEMOVEDATA_STANDING_RIGHT, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 1, TrainerLassKathryn, EVENT_OLIVINE_GYM_LASS_KATHRYN
	object_event  3,  7, SPRITE_LASS, SPRITEMOVEDATA_STANDING_RIGHT, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 1, TrainerLassElise, EVENT_OLIVINE_GYM_LASS_ELISE
