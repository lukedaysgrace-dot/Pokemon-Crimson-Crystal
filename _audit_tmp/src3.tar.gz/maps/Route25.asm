	object_const_def ; object_event constants
	const ROUTE25_MISTY
	const ROUTE25_COOLTRAINER_M1
	const ROUTE25_PICNICKER
	const ROUTE25_POKEFAN_M
	const ROUTE25_COSPLAYER
	const ROUTE25_LASS
	const ROUTE25_JUGGLER
	const ROUTE25_SUPER_NERD
	const ROUTE25_COOLTRAINER_M2
	const ROUTE25_POKE_BALL
	const ROUTE25_CRYSTAL
	const ROUTE25_MEW

Route25_MapScripts:
	db 2 ; scene scripts
	scene_script .DummyScene0 ; SCENE_ROUTE25_NOTHING
	scene_script .DummyScene1 ; SCENE_ROUTE25_MISTYS_DATE

	db 1 ; callbacks
	callback MAPCALLBACK_OBJECTS, .Objects

.DummyScene0:
	end

.DummyScene1:
	end

.Objects:
; An object event flag reads as VISIBLE until something sets it, so both cape
; objects have to be hidden explicitly on a fresh save. Rather than trust the
; flags, derive both objects' visibility from the event state on every map
; load. Clear the old loss flag as a save migration so players who lost under
; the previous permanent-loss behavior can retry the battle too.
	clearevent EVENT_CRYSTAL_CAUGHT_MEW
	checkevent EVENT_ROUTE_25_CAUGHT_MEW
	iftrue .MewIsGone
	checkevent EVENT_ROUTE_25_MEW_ESCAPED
	iftrue .MewIsGone
	checkevent EVENT_ROUTE_25_MEW_APPEARED
	iffalse .MewIsGone
	appear ROUTE25_MEW
	sjump .CheckCrystal

.MewIsGone:
	disappear ROUTE25_MEW

.CheckCrystal:
	checkevent EVENT_ROUTE_25_CRYSTAL_LEFT
	iftrue .NoCrystal
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iffalse .NoCrystal
	appear ROUTE25_CRYSTAL
	return

.NoCrystal:
	disappear ROUTE25_CRYSTAL
	return

Route25MistyDate1Script:
	showemote EMOTE_HEART, ROUTE25_MISTY, 15
	pause 30
	showemote EMOTE_SHOCK, ROUTE25_COOLTRAINER_M1, 10
	turnobject ROUTE25_MISTY, DOWN
	applymovement ROUTE25_COOLTRAINER_M1, MovementData_0x19efe8
	disappear ROUTE25_COOLTRAINER_M1
	pause 15
	playmusic MUSIC_BEAUTY_ENCOUNTER
	turnobject ROUTE25_MISTY, UP
	pause 10
	applymovement ROUTE25_MISTY, MovementData_0x19efed
	opentext
	writetext Route25MistyDateText
	waitbutton
	closetext
	turnobject PLAYER, DOWN
	applymovement ROUTE25_MISTY, MovementData_0x19effa
	turnobject PLAYER, LEFT
	applymovement ROUTE25_MISTY, MovementData_0x19f000
	disappear ROUTE25_MISTY
	clearevent EVENT_TRAINERS_IN_CERULEAN_GYM
	setscene SCENE_ROUTE25_NOTHING
	special RestartMapMusic
	end

Route25MistyDate2Script:
	showemote EMOTE_HEART, ROUTE25_MISTY, 15
	pause 30
	showemote EMOTE_SHOCK, ROUTE25_COOLTRAINER_M1, 10
	turnobject ROUTE25_MISTY, DOWN
	applymovement ROUTE25_COOLTRAINER_M1, MovementData_0x19efea
	disappear ROUTE25_COOLTRAINER_M1
	pause 15
	playmusic MUSIC_BEAUTY_ENCOUNTER
	turnobject ROUTE25_MISTY, UP
	pause 10
	applymovement ROUTE25_MISTY, MovementData_0x19eff4
	opentext
	writetext Route25MistyDateText
	waitbutton
	closetext
	turnobject PLAYER, UP
	applymovement ROUTE25_MISTY, MovementData_0x19effd
	turnobject PLAYER, LEFT
	applymovement ROUTE25_MISTY, MovementData_0x19f000
	disappear ROUTE25_MISTY
	clearevent EVENT_TRAINERS_IN_CERULEAN_GYM
	setscene SCENE_ROUTE25_NOTHING
	special RestartMapMusic
	end

Route25MewAppearsScript:
; MEW drifts out over the cape the first time the player comes this way after
; defeating ERIKA and earning the RAINBOWBADGE.
	checkevent EVENT_ROUTE_25_MEW_APPEARED
	iftrue .Done
	checkflag ENGINE_RAINBOWBADGE
	iffalse .Done
.Appear:
	setevent EVENT_ROUTE_25_MEW_APPEARED
	special FadeOutMusic
	pause 20
	appear ROUTE25_MEW
	cry MEW
	pause 20
	showemote EMOTE_SHOCK, PLAYER, 20
	applymovement ROUTE25_MEW, Route25MewDriftMovement
	pause 15
	cry MEW
	pause 20
	special RestartMapMusic
.Done:
	end

; Stepping down onto the top of the jetty while MEW is still out there brings
; CRYSTAL walking in from the west along the clearing. One guard per trigger
; tile: each one parks her hidden object 5 tiles due west of the player before
; the shared scene runs, so a single RIGHT x5 walk always ends at (player x, 7),
; directly above them.
;
; The 5-tile spacing is a hard engine limit, not a style choice: an object
; whose current AND initial coords are both outside the player's visible
; window (x within player +/-5ish; see .CheckObjectStillVisible in
; engine/overworld/map_objects.asm) is DELETED the frame after `appear`, and
; the applymovement below then waits forever for a walk that no object is
; performing - the soft-lock this replaces. Spawning at exactly player x - 5
; is both safe and one tile past the left edge of the screen.

Route25CrystalApproachScript46:
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iftrue .Done
	checkevent EVENT_ROUTE_25_MEW_APPEARED
	iffalse .Done
	moveobject ROUTE25_CRYSTAL, 41, 7
	sjump Route25CrystalMewApproachScene
.Done:
	end

Route25CrystalApproachScript47:
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iftrue .Done
	checkevent EVENT_ROUTE_25_MEW_APPEARED
	iffalse .Done
	moveobject ROUTE25_CRYSTAL, 42, 7
	sjump Route25CrystalMewApproachScene
.Done:
	end

Route25CrystalApproachScript48:
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iftrue .Done
	checkevent EVENT_ROUTE_25_MEW_APPEARED
	iffalse .Done
	moveobject ROUTE25_CRYSTAL, 43, 7
	sjump Route25CrystalMewApproachScene
.Done:
	end

Route25CrystalApproachScript49:
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iftrue .Done
	checkevent EVENT_ROUTE_25_MEW_APPEARED
	iffalse .Done
	moveobject ROUTE25_CRYSTAL, 44, 7
	sjump Route25CrystalMewApproachScene
.Done:
	end

Route25CrystalMewApproachScene:
; The guard already parked her at (player x - 5, 7). She appears just off the
; west edge of the screen, walks right along the clearing, and stops at
; (player x, 7) - directly above the player on the jetty's top step - facing
; down at them.
	special FadeOutMusic
	pause 10
	cry MEW
	pause 20
	appear ROUTE25_CRYSTAL
	turnobject PLAYER, UP
	applymovement ROUTE25_CRYSTAL, Route25CrystalApproachMovement
	turnobject ROUTE25_CRYSTAL, DOWN
	sjump Route25CrystalMewSceneFinish

Route25CrystalMewScene:
; Fallback: the player reached MEW without crossing the approach row (climbed
; the jetty from the shore and talked to MEW straight away). They could be
; anywhere around MEW, so she walks to (46, 7) overlooking the steps and the
; two face each other from there. (44, 7) is within the visible window for
; every tile the player can talk to MEW from (x 46-49).
	special FadeOutMusic
	pause 10
	cry MEW
	pause 20
	moveobject ROUTE25_CRYSTAL, 44, 7
	appear ROUTE25_CRYSTAL
	applymovement ROUTE25_CRYSTAL, Route25CrystalFallbackMovement
	faceobject ROUTE25_CRYSTAL, PLAYER
	faceobject PLAYER, ROUTE25_CRYSTAL
	sjump Route25CrystalMewSceneFinish

Route25CrystalMewSceneFinish:
	showemote EMOTE_SHOCK, ROUTE25_CRYSTAL, 20
	pause 10
	playmusic MUSIC_CRYSTAL_ENCOUNTER
	sjump Route25CrystalBattle

Route25CrystalScript:
	faceplayer
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iftrue .GoCatchIt
	special FadeOutMusic
	playmusic MUSIC_CRYSTAL_ENCOUNTER
	sjump Route25CrystalBattle

.GoCatchIt:
	opentext
	farwritetext Route25CrystalGoCatchItText
	waitbutton
	closetext
	end

Route25CrystalBattle:
	opentext
	farwritetext Route25CrystalBeforeText
	waitbutton
	closetext
	checkevent EVENT_GOT_TOTODILE_FROM_ELM
	iftrue .Cyndaquil
	checkevent EVENT_GOT_SQUIRTLE_FROM_ELM
	iftrue .Cyndaquil
	checkevent EVENT_GOT_CHIKORITA_FROM_ELM
	iftrue .Totodile
	checkevent EVENT_GOT_BULBASAUR_FROM_ELM
	iftrue .Totodile
	loadtrainer CRYSTAL3, CRYSTAL3_CHIKORITA
	sjump .StartBattle

.Cyndaquil:
	loadtrainer CRYSTAL3, CRYSTAL3_CYNDAQUIL
	sjump .StartBattle

.Totodile:
	loadtrainer CRYSTAL3, CRYSTAL3_TOTODILE

.StartBattle:
	winlosstext Route25CrystalWinText, Route25CrystalLossText
	setlasttalked ROUTE25_CRYSTAL
	startbattle
	ifequal LOSE, .Lost
	setevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
.Lost:
	dontrestartmapmusic
	reloadmapafterbattle
	playmusic MUSIC_CRYSTAL_ENCOUNTER
	opentext
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iffalse .TryAgain
	farwritetext Route25CrystalAfterText
	sjump .FinishText
.TryAgain:
	farwritetext Route25CrystalTryAgainText
.FinishText:
	waitbutton
	closetext
	turnobject ROUTE25_CRYSTAL, DOWN
	playmapmusic
	end

Route25MewScript:
	faceplayer
	checkevent EVENT_BEAT_CRYSTAL_CERULEAN_CAPE
	iffalse Route25CrystalMewScene
	opentext
	writetext Route25MewText
	cry MEW
	pause 15
	closetext
	loadvar VAR_BATTLETYPE, BATTLETYPE_FORCEITEM
	loadwildmon MEW, 60
	startbattle
; MEW leaves the cape whatever happens: a catch ends the chase, and a KO or a
; run means it slipped away for good. Record which one before
; reloadmapafterbattle, because that reload re-runs .Objects.
	special CheckCaughtWildMon
	iffalse .GotAway
	setevent EVENT_ROUTE_25_CAUGHT_MEW
	sjump .MewIsGone

.GotAway:
	setevent EVENT_ROUTE_25_MEW_ESCAPED

.MewIsGone:
	disappear ROUTE25_MEW
	reloadmapafterbattle
	pause 20
	special FadeOutMusic
	playmusic MUSIC_CRYSTAL_ENCOUNTER

; The wandering MEW can be caught from any walkable tile in the 4-by-5 cape
; area. CRYSTAL starts at (48, 7), chooses the free tile immediately beside
; the player's current column, then walks down to their current row.
	readvar VAR_XCOORD
	ifequal 46, .ApproachLeft
	ifequal 48, .ApproachRight
	sjump .ApproachVertically

.ApproachLeft:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachLeftMovement
	sjump .ApproachVertically

.ApproachRight:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachRightMovement

.ApproachVertically:
	readvar VAR_YCOORD
	ifequal 8, .ApproachDown1
	ifequal 9, .ApproachDown2
	ifequal 10, .ApproachDown3
	ifequal 11, .ApproachDown4
	ifequal 12, .ApproachDown5
	sjump .CrystalApproached

.ApproachDown1:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachDown1Movement
	sjump .CrystalApproached

.ApproachDown2:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachDown2Movement
	sjump .CrystalApproached

.ApproachDown3:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachDown3Movement
	sjump .CrystalApproached

.ApproachDown4:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachDown4Movement
	sjump .CrystalApproached

.ApproachDown5:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtApproachDown5Movement

.CrystalApproached:
	faceobject ROUTE25_CRYSTAL, PLAYER
	faceobject PLAYER, ROUTE25_CRYSTAL
	checkevent EVENT_ROUTE_25_CAUGHT_MEW
	iftrue .CaughtItText
	opentext
	farwritetext Route25CrystalMewEscapedText
	waitbutton
	closetext
	sjump .CrystalLeaves

.CaughtItText:
	opentext
	farwritetext Route25CrystalMewCaughtText
	waitbutton
	closetext

.CrystalLeaves:

; Re-anchor her beside the player so the visibility culler cannot delete her
; during the exit. Return to the clearing row using the player's unchanged Y
; coordinate, then leave west along the known-safe row.
	writeobjectxy ROUTE25_CRYSTAL
	disappear ROUTE25_CRYSTAL
	appear ROUTE25_CRYSTAL
	readvar VAR_YCOORD
	ifequal 8, .ReturnUp1
	ifequal 9, .ReturnUp2
	ifequal 10, .ReturnUp3
	ifequal 11, .ReturnUp4
	ifequal 12, .ReturnUp5
	sjump .Leave

.ReturnUp1:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtReturnUp1Movement
	sjump .Leave

.ReturnUp2:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtReturnUp2Movement
	sjump .Leave

.ReturnUp3:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtReturnUp3Movement
	sjump .Leave

.ReturnUp4:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtReturnUp4Movement
	sjump .Leave

.ReturnUp5:
	applymovement ROUTE25_CRYSTAL, Route25CrystalCaughtReturnUp5Movement

.Leave:
	applymovement ROUTE25_CRYSTAL, Route25CrystalLeavesMovement
	setevent EVENT_ROUTE_25_CRYSTAL_LEFT
	disappear ROUTE25_CRYSTAL
	special RestartMapMusic
	end

TrainerCosplayerNoelle:
	trainer COSPLAYER, COSPLAYER6, EVENT_BEAT_COSPLAYER_NOELLE, CosplayerNoelleSeenText, CosplayerNoelleBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext CosplayerNoelleAfterBattleText
	waitbutton
	closetext
	end

TrainerJugglerSilas:
	trainer JUGGLER, SILAS, EVENT_BEAT_JUGGLER_SILAS, JugglerSilasSeenText, JugglerSilasBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext JugglerSilasAfterBattleText
	waitbutton
	closetext
	end

TrainerSchoolGirlNadia:
	trainer SCHOOL_GIRL, NADIA, EVENT_BEAT_SCHOOL_GIRL_NADIA, SchoolGirlNadiaSeenText, SchoolGirlNadiaBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SchoolGirlNadiaAfterBattleText
	waitbutton
	closetext
	end

TrainerLassPaige:
	trainer LASS, PAIGE, EVENT_BEAT_LASS_PAIGE, LassPaigeSeenText, LassPaigeBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext LassPaigeAfterBattleText
	waitbutton
	closetext
	end

TrainerPokefanmDustin:
	trainer POKEFANM, DUSTIN, EVENT_BEAT_POKEFANM_DUSTIN, PokefanmDustinSeenText, PokefanmDustinBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext PokefanmDustinAfterBattleText
	waitbutton
	closetext
	end

TrainerSupernerdPat:
	trainer SUPER_NERD, PAT, EVENT_BEAT_SUPER_NERD_PAT, SupernerdPatSeenText, SupernerdPatBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SupernerdPatAfterBattleText
	waitbutton
	closetext
	end

TrainerCooltrainermKevin:
	faceplayer
	opentext
	checkevent EVENT_BEAT_COOLTRAINERM_KEVIN
	iftrue .AfterBattle
	checkevent EVENT_CLEARED_NUGGET_BRIDGE
	iftrue .AfterNuggetBridge
	writetext CooltrainermKevinRewardText
	buttonsound
	; the two prizes are given separately so a full ITEM pocket can't
	; hand out the SCOPE LENS again every time the RARE CANDY doesn't fit
	checkevent EVENT_GOT_NUGGET_BRIDGE_SCOPE_LENS
	iftrue .GiveRareCandy
	verbosegiveitem SCOPE_LENS
	iffalse .NoRoomForPrize
	setevent EVENT_GOT_NUGGET_BRIDGE_SCOPE_LENS
.GiveRareCandy:
	verbosegiveitem RARE_CANDY
	iffalse .NoRoomForPrize
	setevent EVENT_CLEARED_NUGGET_BRIDGE
.AfterNuggetBridge:
	writetext CooltrainermKevinSeenText
	waitbutton
	closetext
	winlosstext CooltrainermKevinBeatenText, 0
	loadtrainer COOLTRAINERM, KEVIN
	startbattle
	reloadmapafterbattle
	setevent EVENT_BEAT_COOLTRAINERM_KEVIN
	opentext
.AfterBattle:
	writetext CooltrainermKevinAfterBattleText
	waitbutton
.NoRoomForPrize:
	closetext
	end

BillsHouseSign:
	jumptext BillsHouseSignText

Route25Protein:
	itemball PROTEIN

Route25HiddenPotion:
	hiddenitem POTION, EVENT_ROUTE_25_HIDDEN_POTION

Route25MewDriftMovement:
	slow_step RIGHT
	slow_step DOWN
	slow_step LEFT
	slow_step UP
	step_end

Route25CrystalLeavesMovement:
; She has returned to the clearing row at x=47-49, so she can head west
; through the gap in the cliff line regardless of where MEW was caught.
	step LEFT
	step LEFT
	step LEFT
	step LEFT
	step LEFT
	step LEFT
	step_end

Route25CrystalApproachMovement:
; Relative walk, shared by all four triggers: from (player x - 5, 7) five
; tiles east to (player x, 7), directly above the player.
	step RIGHT
	step RIGHT
	step RIGHT
	step RIGHT
	step RIGHT
	step_end

Route25CrystalFallbackMovement:
; (44, 7) -> (46, 7), overlooking the jetty steps
	step RIGHT
	step RIGHT
	step_end

Route25CrystalCaughtApproachLeftMovement:
; Player x=46: (48, 7) -> (47, 7), then approach down on their right.
	step LEFT
	step_end

Route25CrystalCaughtApproachRightMovement:
; Player x=48: (48, 7) -> (49, 7), then approach down on their right.
	step RIGHT
	step_end

Route25CrystalCaughtApproachDown1Movement:
	step DOWN
	step_end

Route25CrystalCaughtApproachDown2Movement:
	step DOWN
	step DOWN
	step_end

Route25CrystalCaughtApproachDown3Movement:
	step DOWN
	step DOWN
	step DOWN
	step_end

Route25CrystalCaughtApproachDown4Movement:
	step DOWN
	step DOWN
	step DOWN
	step DOWN
	step_end

Route25CrystalCaughtApproachDown5Movement:
	step DOWN
	step DOWN
	step DOWN
	step DOWN
	step DOWN
	step_end

Route25CrystalCaughtReturnUp1Movement:
	step UP
	step_end

Route25CrystalCaughtReturnUp2Movement:
	step UP
	step UP
	step_end

Route25CrystalCaughtReturnUp3Movement:
	step UP
	step UP
	step UP
	step_end

Route25CrystalCaughtReturnUp4Movement:
	step UP
	step UP
	step UP
	step UP
	step_end

Route25CrystalCaughtReturnUp5Movement:
	step UP
	step UP
	step UP
	step UP
	step UP
	step_end

MovementData_0x19efe8:
	big_step DOWN
	step_end

MovementData_0x19efea:
	big_step DOWN
	big_step DOWN
	step_end

MovementData_0x19efed:
	step UP
	step UP
	step UP
	step LEFT
	step LEFT
	step LEFT
	step_end

MovementData_0x19eff4:
	step UP
	step UP
	step LEFT
	step LEFT
	step LEFT
	step_end

MovementData_0x19effa:
	step DOWN
	step LEFT
	step_end

MovementData_0x19effd:
	step UP
	step LEFT
	step_end

MovementData_0x19f000:
	step LEFT
	step LEFT
	step LEFT
	step LEFT
	step LEFT
	step_end


Route25CrystalWinText:
	text "…All right. You"
	line "earned it."
	done

Route25CrystalLossText:
	text "We'll settle this"
	line "another time."
	done




; CRYSTAL's CERULEAN CAPE dialogue is too large to fit in this map's bank.
; It lives in data/text/route25_cape.asm and is read with farwritetext.
; Route25CrystalWinText/LossText have to stay here: winlosstext takes near
; pointers into the script's own bank.

Route25MewText:
	text "Myuu?"
	done

Route25MistyDateText:
	text "MISTY: Aww! Why"
	line "did you have to"

	para "show up and bug us"
	line "now?"

	para "Do you know what"
	line "they call people"
	cont "like you?"

	para "Pests! You heard"
	line "me right, pest!"

	para "…"

	para "…Oh? Those BADGES"
	line "you have… Are they"
	cont "JOHTO GYM BADGES?"

	para "If you have eight,"
	line "you must be good."

	para "OK, then. Come to"
	line "CERULEAN GYM."

	para "I'll be happy to"
	line "take you on."

	para "I'm MISTY, the"
	line "GYM LEADER in"
	cont "CERULEAN."
	done

SchoolGirlNadiaSeenText:
	text "Beat the five of"
	line "us to win a"
	cont "fabulous prize!"

	para "I built my team to"
	line "surprise you."
	done

SchoolGirlNadiaBeatenText:
	text "Back to the"
	line "drawing board!"
	done

SchoolGirlNadiaAfterBattleText:
	text "A team is a group"
	line "project. Everyone"
	cont "needs a job."

	para "We need to work on"
	line "ours!"
	done

PokefanmDustinSeenText:
	text "I'm second!"
	line "Now it's serious!"
	done

PokefanmDustinBeatenText:
	text "How could I lose?"
	done

PokefanmDustinAfterBattleText:
	text "I still think my"
	line "#MON are the"
	cont "best!"

	para "All right… Yours"
	line "are pretty great,"
	cont "too."
	done

CosplayerNoelleSeenText:
	text "I'm No. 3!"

	para "My mascot costume"
	line "is ready for its"
	cont "big battle debut!"
	done

CosplayerNoelleBeatenText:
	text "Whoo! Good stuff."
	done

CosplayerNoelleAfterBattleText:
	text "It's really hot"
	line "inside this mascot"
	cont "head."

	para "I can barely see"
	line "out of it!"
	done

LassPaigeSeenText:
	text "I'm No. 4!"
	line "Getting tired?"
	done

LassPaigeBeatenText:
	text "I lost too…"
	done

LassPaigeAfterBattleText:
	text "You still had all"
	line "that energy after"
	cont "three battles?"

	para "I need to train"
	line "longer!"
	done

JugglerSilasSeenText:
	text "I'm the last in"
	line "line, but I tell"
	cont "you, I'm tough!"
	done

JugglerSilasBeatenText:
	text "Whoa! Everything's"
	line "falling!"
	done

JugglerSilasAfterBattleText:
	text "Five battles and"
	line "you never lost"
	cont "your rhythm!"

	para "That's a tough act"
	line "to follow."
	done

SupernerdPatSeenText:
	text "Mufufufu…"

	para "I have nothing to"
	line "do with the five"
	cont "other trainers."

	para "I waited here to"
	line "beat you when you"

	para "were tired out by"
	line "all the battles."
	done

SupernerdPatBeatenText:
	text "Aren't you tired"
	line "at all?"
	done

SupernerdPatAfterBattleText:
	text "I'm sorry… I won't"
	line "cheat anymore…"
	done

CooltrainermKevinRewardText:
	text "You took on one"
	line "more battle than"

	para "you expected, but"
	line "you won anyway."

	para "As promised, you"
	line "win a prize!"
	done

CooltrainermKevinSeenText:
	text "But after seeing"
	line "how you battle, I"

	para "want to see how"
	line "I'll fare."

	para "How about it? Let"
	line "me take you on."
	done

CooltrainermKevinBeatenText:
	text "I've never had a"
	line "battle this good!"
	done

CooltrainermKevinAfterBattleText:
	text "That was a great"
	line "battle!"

	para "You and your #-"
	line "MON are truly out-"
	cont "standing!"
	done

BillsHouseSignText:
	text "SEA COTTAGE"
	line "BILL'S HOUSE"
	done

; unused
	text "BILL'S HOUSE"
	done

Route25_MapEvents:
	db 0, 0 ; filler

	db 1 ; warp events
	warp_event 47,  5, BILLS_HOUSE, 1

	db 8 ; coord events
	coord_event 42,  6, SCENE_ROUTE25_MISTYS_DATE, Route25MistyDate1Script
	coord_event 42,  7, SCENE_ROUTE25_MISTYS_DATE, Route25MistyDate2Script
; x=44 is the only gap in the cliff line, so the player has to cross one of
; these two tiles to reach the cape at all.
	coord_event 45,  6, -1, Route25MewAppearsScript
	coord_event 45,  7, -1, Route25MewAppearsScript
; Top row of the stone jetty only - one guard per tile so CRYSTAL can walk to
; whichever tile the player stopped on. A player who climbs the jetty from the
; shore also crosses this row before reaching the clearing; if they talk to
; MEW while still on the steps, the Route25MewScript fallback covers it.
	coord_event 46,  8, -1, Route25CrystalApproachScript46
	coord_event 47,  8, -1, Route25CrystalApproachScript47
	coord_event 48,  8, -1, Route25CrystalApproachScript48
	coord_event 49,  8, -1, Route25CrystalApproachScript49

	db 2 ; bg events
	bg_event 45,  5, BGEVENT_READ, BillsHouseSign
	bg_event  4,  5, BGEVENT_ITEM, Route25HiddenPotion

	db 12 ; object events
	object_event 46,  9, SPRITE_MISTY, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_SCRIPT, 0, ObjectEvent, EVENT_ROUTE_25_MISTY_BOYFRIEND
	object_event 46, 10, SPRITE_COOLTRAINER_M, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_SCRIPT, 0, ObjectEvent, EVENT_ROUTE_25_MISTY_BOYFRIEND
	object_event 12,  8, SPRITE_SCHOOL_GIRL, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_TRAINER, 3, TrainerSchoolGirlNadia, -1
	object_event 16, 11, SPRITE_POKEFAN_M, SPRITEMOVEDATA_STANDING_UP, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_TRAINER, 3, TrainerPokefanmDustin, -1
	object_event 21,  8, SPRITE_COSPLAYER, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 3, TrainerCosplayerNoelle, -1
	object_event 26,  8, SPRITE_LASS, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_TRAINER, 3, TrainerLassPaige, -1
	object_event 28,  4, SPRITE_JUGGLER_NEW, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_TRAINER, 2, TrainerJugglerSilas, -1
	object_event 31,  7, SPRITE_SUPER_NERD, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_BROWN, OBJECTTYPE_TRAINER, 1, TrainerSupernerdPat, -1
	object_event 37,  8, SPRITE_COOLTRAINER_M_NEW, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_SCRIPT, 0, TrainerCooltrainermKevin, -1
	object_event 32,  4, SPRITE_POKE_BALL, SPRITEMOVEDATA_STILL, 0, 0, -1, -1, 0, OBJECTTYPE_ITEMBALL, 0, Route25Protein, EVENT_ROUTE_25_PROTEIN
	object_event 48,  7, SPRITE_CRYSTAL, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_SCRIPT, 0, Route25CrystalScript, EVENT_ROUTE_25_CRYSTAL
	object_event 48, 10, SPRITE_MEW, SPRITEMOVEDATA_WANDER, 1, 1, -1, -1, PAL_NPC_PINK, OBJECTTYPE_SCRIPT, 0, Route25MewScript, EVENT_ROUTE_25_MEW
