AbilityDescriptions::
	dw NoAbilityDescription
	dw DrizzleDescription
	dw SpeedBoostDescription
	dw BattleArmorDescription
	dw SturdyDescription
	dw DampDescription
	dw LimberDescription
	dw SandVeilDescription
	dw StaticDescription
	dw VoltAbsorbDescription
	dw WaterAbsorbDescription
	dw ObliviousDescription
	dw CloudNineDescription
	dw CompoundEyesDescription
	dw InsomniaDescription
	dw ImmunityDescription
	dw FlashFireDescription
	dw OwnTempoDescription
	dw IntimidateDescription
	dw ShadowTagDescription
	dw LevitateDescription
	dw EffectSporeDescription
	dw SynchronizeDescription
	dw ClearBodyDescription
	dw NaturalCureDescription
	dw LightningRodDescription
	dw SereneGraceDescription
	dw SwiftSwimDescription
	dw ChlorophyllDescription
	dw TraceDescription
	dw HugePowerDescription
	dw PoisonPointDescription
	dw InnerFocusDescription
	dw MagmaArmorDescription
	dw WaterVeilDescription
	dw MagnetPullDescription
	dw SoundproofDescription
	dw RainDishDescription
	dw SandStreamDescription
	dw PressureDescription
	dw ThickFatDescription
	dw FlameBodyDescription
	dw KeenEyeDescription
	dw HyperCutterDescription
	dw PickupDescription
	dw HustleDescription
	dw CuteCharmDescription
	dw ShedSkinDescription
	dw GutsDescription
	dw MarvelScaleDescription
	dw OvergrowDescription
	dw BlazeDescription
	dw TorrentDescription
	dw SwarmDescription
	dw RockHeadDescription
	dw DroughtDescription
	dw ArenaTrapDescription
	dw VitalSpiritDescription
	dw WhiteSmokeDescription
	dw ShellArmorDescription
	dw TangledFeetDescription
	dw MotorDriveDescription
	dw RivalryDescription
	dw SteadfastDescription
	dw SnowCloakDescription
	dw AngerPointDescription
	dw DrySkinDescription
	dw IronFistDescription
	dw PoisonHealDescription
	dw AdaptabilityDescription
	dw SkillLinkDescription
	dw HydrationDescription
	dw SolarPowerDescription
	dw QuickFeetDescription
	dw SniperDescription
	dw MagicGuardDescription
	dw NoGuardDescription
	dw TechnicianDescription
	dw MoldBreakerDescription
	dw SuperLuckDescription
	dw AftermathDescription
	dw TintedLensDescription
	dw FilterDescription
	dw ScrappyDescription
	dw IceBodyDescription
	dw SolidRockDescription
	dw SnowWarningDescription
	dw HoneyGatherDescription
	dw FriskDescription
	dw RecklessDescription
	dw BadDreamsDescription
	dw SheerForceDescription
	dw ContraryDescription
	dw UnnerveDescription
	dw DefiantDescription
	dw CursedBodyDescription
	dw WeakArmorDescription
	dw MultiscaleDescription
	dw OvercoatDescription
	dw PoisonTouchDescription
	dw RegeneratorDescription
	dw BigPecksDescription
	dw SandRushDescription
	dw WonderSkinDescription
	dw AnalyticDescription
	dw ImposterDescription
	dw MoxieDescription
	dw JustifiedDescription
	dw RattledDescription
	dw MagicBounceDescription
	dw SapSipperDescription
	dw PranksterDescription
	dw SandForceDescription
	dw FurCoatDescription
	dw BulletproofDescription
	dw CompetitiveDescription
	dw MegaLauncherDescription
	dw ToughClawsDescription
	dw PixilateDescription
	dw ParentalBondDescription
	dw BerserkDescription
	dw SlushRushDescription
	dw GalvanizeDescription
	dw FluffyDescription
	dw TanglingHairDescription
	dw ScreenCleanerDescription
	dw SteelySpiritDescription
	dw PerishBodyDescription
	dw NeutralizingGasDescription
	dw PastelVeilDescription
	dw WindRiderDescription
	dw SharpnessDescription
	dw ArmorTailDescription
	dw MindsEyeDescription
	dw MegaSolDescription
	dw RefrigerateDescription
	dw AerilateDescription
	dw DisguiseDescription
	dw GaleWingsDescription
	dw MercilessDescription
	dw MirrorArmorDescription
	dw StormDrainDescription
	dw StaminaDescription
	dw StrongJawDescription
	dw SupremeOverlordDescription
	dw ThermalExchangeDescription
	dw TriageDescription
	dw IronBarbsDescription
	dw PoisonPuppeteerDescription
	dw ToxicDebrisDescription
	dw QueenlyMajestyDescription
	dw GluttonyDescription
	dw RunAwayDescription
	dw InfiltratorDescription
	dw LeafGuardDescription
	dw EarlyBirdDescription
	dw UnawareDescription
	dw StenchDescription
	dw AnticipationDescription
	dw PickpocketDescription
	dw ShieldDustDescription
	dw CorrosionDescription
	dw HarvestDescription
	dw DownloadDescription
	dw SuctionCupsDescription
	dw StickyHoldDescription
	dw UnburdenDescription
	dw KlutzDescription
	dw RipenDescription
	dw CudChewDescription
	dw ForewarnDescription
	dw SupersweetSyrupDescription

NoAbilityDescription:
	text "Abilities are"
	next "disabled."
	done

DrizzleDescription:
	text "Summons rain when"
	next "switched in."
	done

SpeedBoostDescription:
	text "Its Speed stat is"
	next "gradually boosted."
	done

BattleArmorDescription:
ShellArmorDescription:
	text "Protects from"
	next "critical hits."
	done

SturdyDescription:
	text "Cannot be knocked"
	next "out with one hit."
	done

DampDescription:
	text "Prevents self-"
	next "destructing moves."
	done

LimberDescription:
	text "Protects from"
	next "paralysis."
	done

SandVeilDescription:
	text "Boosts evasion in"
	next "a sandstorm."
	done

StaticDescription:
	text "Contact may cause"
	next "paralysis."
	done

VoltAbsorbDescription:
	text "Restores HP if hit"
	next "by Electric moves."
	done

WaterAbsorbDescription:
	text "Restores HP if hit"
	next "by Water moves."
	done

ObliviousDescription:
	text "Prevents it from"
	next "being infatuated."
	done

CloudNineDescription:
	text "Eliminates effects"
	next "of weather."
	done

CompoundEyesDescription:
	text "Boosts its"
	next "accuracy."
	done

InsomniaDescription:
VitalSpiritDescription:
	text "Prevents it from"
	next "falling asleep."
	done

ImmunityDescription:
PastelVeilDescription:
	text "Prevents it from"
	next "getting poisoned."
	done

FlashFireDescription:
	text "Absorbs Fire moves"
	next "to power up Fire."
	done

OwnTempoDescription:
	text "Prevents it from"
	next "becoming confused."
	done

IntimidateDescription:
	text "Lowers the foe's"
	next "Attack stat."
	done

ShadowTagDescription:
	text "Prevents the foe"
	next "from escaping."
	done

LevitateDescription:
	text "Gives immunity to"
	next "Ground-type moves."
	done

EffectSporeDescription:
	text "Contact may cause"
	next "Par, Psn, or Slp."
	done

SynchronizeDescription:
	text "Passes Psn, Par,"
	next "or Brn to foes."
	done

ClearBodyDescription:
WhiteSmokeDescription:
	text "Prevents foes from"
	next "lowering stats."
	done

NaturalCureDescription:
	text "Switch-outs heal"
	next "status problems."
	done

LightningRodDescription:
	text "Electric moves"
	next "boost Sp.Atk."
	done

SereneGraceDescription:
	text "Boosts the rate of"
	next "added effects."
	done

SwiftSwimDescription:
	text "Boosts its Speed"
	next "in rain."
	done

ChlorophyllDescription:
	text "Boosts its Speed"
	next "in sunshine."
	done

TraceDescription:
	text "Copies the foe's"
	next "Ability."
	done

HugePowerDescription:
	text "Boosts its Attack"
	next "stat."
	done

PoisonPointDescription:
	text "Contact may poison"
	next "the foe."
	done

InnerFocusDescription:
	text "Protects it from"
	next "flinching."
	done

MagmaArmorDescription:
	text "Prevents it from"
	next "becoming frozen."
	done

WaterVeilDescription:
	text "Prevents it from"
	next "getting a burn."
	done

MagnetPullDescription:
	text "Prevents escape by"
	next "Steel-type foes."
	done

SoundproofDescription:
	text "Gives immunity to"
	next "sound-based moves."
	done

RainDishDescription:
	text "Gradually regains"
	next "HP in rain."
	done

SandStreamDescription:
	text "Summons sandstorm"
	next "when switched in."
	done

PressureDescription:
	text "Raises the foe's"
	next "PP usage."
	done

ThickFatDescription:
	text "Ups resistance to"
	next "Fire and Ice."
	done

FlameBodyDescription:
	text "Contact may burn"
	next "the foe."
	done

KeenEyeDescription:
	text "Prevents foes from"
	next "lowering accuracy."
	done

HyperCutterDescription:
	text "Prevents foes from"
	next "lowering Attack."
	done

PickupDescription:
	text "The #MON may"
	next "pick up items."
	done

HustleDescription:
	text "Boosts Attack, but"
	next "lowers accuracy."
	done

CuteCharmDescription:
	text "Contact may cause"
	next "infatuation."
	done

ShedSkinDescription:
	text "May heal its own"
	next "status problems."
	done

GutsDescription:
	text "Boosts Attack on"
	next "status problems."
	done

MarvelScaleDescription:
	text "Boosts Defense on"
	next "status problems."
	done

OvergrowDescription:
	text "Boosts Grass moves"
	next "in a pinch."
	done

BlazeDescription:
	text "Boosts Fire moves"
	next "in a pinch."
	done

TorrentDescription:
	text "Boosts Water moves"
	next "in a pinch."
	done

SwarmDescription:
	text "Boosts Bug moves"
	next "in a pinch."
	done

RockHeadDescription:
	text "Protects it from"
	next "recoil damage."
	done

DroughtDescription:
	text "Summons sunlight"
	next "when switched in."
	done

ArenaTrapDescription:
	text "Prevents the foe"
	next "from fleeing."
	done

TangledFeetDescription:
	text "Boosts evasion if"
	next "it is confused."
	done

MotorDriveDescription:
	text "Electric moves"
	next "boost Speed."
	done

RivalryDescription:
	text "Boosts damage to"
	next "same-gender foes."
	done

SteadfastDescription:
	text "Boosts Speed when"
	next "it flinches."
	done

SnowCloakDescription:
	text "Boosts evasion in"
	next "hailstorms."
	done

AngerPointDescription:
	text "Maxes Attack after"
	next "a critical hit."
	done

DrySkinDescription:
	text "Reduces HP in sun."
	next "Water restores HP."
	done

IronFistDescription:
	text "Boosts power of"
	next "punching moves."
	done

PoisonHealDescription:
	text "Restores HP if"
	next "it is poisoned."
	done

AdaptabilityDescription:
	text "Powers up same-"
	next "type moves."
	done

SkillLinkDescription:
	text "Increases multi-"
	next "strike move hits."
	done

HydrationDescription:
	text "Heals status"
	next "problems in rain."
	done

SolarPowerDescription:
	text "Boosts Sp.Atk but"
	next "lowers HP in sun."
	done

QuickFeetDescription:
	text "Boosts Speed with"
	next "status problems."
	done

SniperDescription:
	text "Powers up critical"
	next "hits."
	done

MagicGuardDescription:
	text "Only takes damage"
	next "from attacks."
	done

NoGuardDescription:
	text "Ensures attacks by"
	next "or against it hit."
	done

TechnicianDescription:
	text "Powers up its"
	next "weaker moves."
	done

MoldBreakerDescription:
	text "Moves disregard"
	next "the foe's ability."
	done

SuperLuckDescription:
	text "Boosts the rate"
	next "of critical hits."
	done

AftermathDescription:
	text "Damages the foe on"
	next "fainting."
	done

TintedLensDescription:
	text "Powers up not very"
	next "effective moves."
	done

FilterDescription:
SolidRockDescription:
	text "Reduces super"
	next "effective damage."
	done

ScrappyDescription:
	text "Enables moves to"
	next "hit Ghost-types."
	done

IceBodyDescription:
	text "Gradually regains"
	next "HP in hail."
	done

SnowWarningDescription:
	text "Summons hailstorm"
	next "when switched in."
	done

HoneyGatherDescription:
	text "The #MON may"
if DEF(FAITHFUL)
	next "gather Honey."
else
	next "find Sweet Honey."
endc
	done

FriskDescription:
	text "Checks the foe's"
	next "held item."
	done

RecklessDescription:
	text "Powers up moves"
	next "that recoil."
	done

BadDreamsDescription:
	text "Reduces a sleeping"
	next "foe's HP."
	done

SheerForceDescription:
	text "Removes effects to"
	next "increase damage."
	done

ContraryDescription:
	text "Inverts the effect"
	next "of stat changes."
	done

UnnerveDescription:
	text "Prevents foes from"
	next "eating Berries."
	done

DefiantDescription:
	text "Boosts Attack when"
	next "stats are lowered."
	done

CursedBodyDescription:
	text "May disable a move"
	next "used on it."
	done

WeakArmorDescription:
	text "Physical hits"
	next "trade Def for Spd."
	done

MultiscaleDescription:
	text "Reduces damage"
	next "when HP is full."
	done

OvercoatDescription:
	text "Protects it from"
	next "weather damage."
	done

PoisonTouchDescription:
	text "May poison the foe"
	next "on contact."
	done

RegeneratorDescription:
	text "Restores HP when"
	next "withdrawn."
	done

BigPecksDescription:
	text "Prevents foes from"
	next "lowering Defense."
	done

SandRushDescription:
	text "Boosts Speed in"
	next "a sandstorm."
	done

WonderSkinDescription:
	text "Makes status moves"
	next "miss more often."
	done

AnalyticDescription:
	text "Boosts move power"
	next "when moving last."
	done

ImposterDescription:
	text "Transforms itself"
	next "into the foe."
	done

MoxieDescription:
	text "Boosts Attack when"
	next "knocking out foes."
	done

JustifiedDescription:
	text "Boosts Attack when"
	next "hit by Dark moves."
	done

RattledDescription:
	text "Dark, Ghost or Bug"
	next "moves boost Speed."
	done

MagicBounceDescription:
	text "Reflects status-"
	next "changing moves."
	done

SapSipperDescription:
	text "Boosts Attack when"
	next "hit by Grass."
	done

PranksterDescription:
	text "Gives priority to"
	next "a status move."
	done

SandForceDescription:
	text "Boosts some moves"
	next "in a sandstorm."
	done

FurCoatDescription:
	text "Halves damage from"
	next "physical moves."
	done

BulletproofDescription:
	text "Protects from ball"
	next "and bomb moves."
	done

CompetitiveDescription:
	text "Boosts Sp.Atk on"
	next "stat reduction."
	done

MegaLauncherDescription:
	text "Powers up aura"
	next "and pulse moves."
	done

ToughClawsDescription:
	text "Boosts moves that"
	next "make contact."
	done

PixilateDescription:
	text "Normal-type moves"
	next "become Fairy-type."
	done

ParentalBondDescription:
	text "Parent and child"
	next "attack together."
	done

BerserkDescription:
	text "Boosts Sp.Atk when"
	next "damaged over half."
	done

SlushRushDescription:
	text "Boosts Speed in"
	next "a hailstorm."
	done

GalvanizeDescription:
	text "Normal-type moves"
	next "become Electric."
	done

FluffyDescription:
	text "Resists contact,"
	next "but weak to Fire."
	done

TanglingHairDescription:
	text "Contact may lower"
	next "the foe's Speed."
	done

NeutralizingGasDescription:
	text "Suppresses all"
	next "other Abilities."
	done

WindRiderDescription:
	text "Gives immunity to"
	next "wind-based moves."
	done

SteelySpiritDescription:
	text "Boosts Steel-type"
	next "moves."
	done

PerishBodyDescription:
	text "Contact causes Pe-"
	next "rish Song status."
	done

ScreenCleanerDescription:
	text "Removes screens"
	next "when switched in."
	done

SharpnessDescription:
	text "Boosts power of"
	next "slicing moves."
	done

ArmorTailDescription:
	text "Stops foes using"
	next "priority moves."
	done

MindsEyeDescription:
	text "Bypass evasion and"
	next "Ghost immunity."
	done

MegaSolDescription:
	text "Uses moves as if"
	next "harsh sun is up."
	done

RefrigerateDescription:
	text "Normal moves"
	next "become Ice-type."
	done

AerilateDescription:
	text "Normal moves be-"
	next "come Flying-type."
	done

DisguiseDescription:
	text "Its disguise"
	next "blocks one hit."
	done

GaleWingsDescription:
	text "Flying moves"
	next "go first."
	done

MercilessDescription:
	text "Always crits"
	next "poisoned foes."
	done

MirrorArmorDescription:
	text "Bounces back"
	next "stat drops."
	done

StormDrainDescription:
	text "Draws in water,"
	next "raising Sp.Atk."
	done

StaminaDescription:
	text "Boosts Defense"
	next "when hit."
	done

StrongJawDescription:
	text "Boosts biting"
	next "moves' power."
	done

SupremeOverlordDescription:
	text "Grows stronger"
	next "for fallen pals."
	done

ThermalExchangeDescription:
	text "Fire raises Atk."
	next "Can't be burned."
	done

TriageDescription:
	text "Healing moves"
	next "go first."
	done

IronBarbsDescription:
	text "Hurts foes that"
	next "make contact."
	done

PoisonPuppeteerDescription:
	text "Foes it poisons"
	next "become confused."
	done

ToxicDebrisDescription:
	text "Lays Toxic Spikes"
	next "when hit."
	done

QueenlyMajestyDescription:
	text "Stops foes using"
	next "priority moves."
	done

GluttonyDescription:
	text "Eats a held Berry"
	next "earlier."
	done

RunAwayDescription:
	text "Always flees from"
	next "wild battles."
	done

InfiltratorDescription:
	text "Ignores barriers"
	next "like screens."
	done

LeafGuardDescription:
	text "Blocks status in"
	next "harsh sunlight."
	done

EarlyBirdDescription:
	text "Awakens from sleep"
	next "twice as fast."
	done

UnawareDescription:
	text "Ignores the foe's"
	next "stat changes."
	done

StenchDescription:
	text "Its stink may make"
	next "the foe flinch."
	done

AnticipationDescription:
	text "Senses a foe's"
	next "dangerous moves."
	done

PickpocketDescription:
	text "Steals the item of"
	next "a foe on contact."
	done

ShieldDustDescription:
	text "Blocks the added"
	next "effects of moves."
	done

CorrosionDescription:
	text "Can poison even"
	next "STEEL and POISON."
	done

HarvestDescription:
	text "May restore a"
	next "used Berry."
	done

DownloadDescription:
	text "Adjusts power to"
	next "the foe's defense."
	done

SuctionCupsDescription:
	text "Anchors down and"
	next "can't be moved."
	done

StickyHoldDescription:
	text "Its held item"
	next "can't be stolen."
	done

UnburdenDescription:
	text "Speeds up if its"
	next "item is lost."
	done

KlutzDescription:
	text "Can't use any"
	next "held items."
	done

RipenDescription:
	text "Doubles the effect"
	next "of its Berries."
	done

CudChewDescription:
	text "Eats a used Berry"
	next "a second time."
	done

ForewarnDescription:
	text "Reveals one of the"
	next "foe's moves."
	done

SupersweetSyrupDescription:
	text "Its scent lowers"
	next "the foe's evasion."
	done
