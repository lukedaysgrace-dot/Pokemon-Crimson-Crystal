ConsumeHeldItem:
	; Cud Chew only replays Eat; it does not consume the current held item,
	; overwrite the party item, or record another consumption.
	push hl
	push bc
	farcall CudChewReplaying_b
	ld a, b
	pop bc
	pop hl
	and a
	ret nz
	push hl
	push de
	push bc
	ldh a, [hBattleTurn]
	and a
	ld hl, wOTPartyMon1Item
	ld de, wEnemyMonItem
	ld a, [wCurOTMon]
	jr z, .theirturn
	ld hl, wPartyMon1Item
	ld de, wBattleMonItem
	ld a, [wCurBattleMon]

.theirturn
	push hl
	push af
	ld a, [de]
	ld b, a
	farcall GetItemHeldEffect
	ld hl, ConsumableEffects
.loop
	ld a, [hli]
	cp b
	jr z, .ok
	inc a
	jr nz, .loop
	pop af
	pop hl
	pop bc
	pop de
	pop hl
	ret

.ok
	; record the consumed item for Harvest/Cud Chew/Unburden
	farcall RecordConsumedItem
	xor a
	ld [de], a
	pop af
	pop hl
	call GetPartyLocation
	ldh a, [hBattleTurn]
	and a
	jr nz, .ourturn
	ld a, [wBattleMode]
	dec a
	jr z, .done

.ourturn
	ld [hl], NO_ITEM

.done
	pop bc
	pop de
	pop hl
	ret

INCLUDE "data/battle/held_consumables.asm"
