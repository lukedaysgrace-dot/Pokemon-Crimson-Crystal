	object_const_def ; object_event constants
	const GOLDENRODBIKESHOP_CLERK

GoldenrodBikeShop_MapScripts:
	db 0 ; scene scripts

	db 0 ; callbacks

.UnreferencedDummyScene:
	end

GoldenrodBikeShopClerkScript:
	faceplayer
	opentext
	checkevent EVENT_GOT_BICYCLE
	iftrue .GotRide
	writetext GoldenrodBikeShopClerkIntroText
	yesorno
	iffalse .Refused
	writetext GoldenrodBikeShopClerkAgreedText
	buttonsound
	writetext GoldenrodBikeShopAskBicycleText
	yesorno
	iftrue .GiveBicycle
	writetext GoldenrodBikeShopAskSkateboardText
	yesorno
	iftrue .GiveSkateboard
	sjump .Refused

.GiveBicycle:
	waitsfx
	giveitem BICYCLE
	writetext BorrowedABicycleText
	playsound SFX_KEY_ITEM
	waitsfx
	itemnotify
	setflag ENGINE_BIKE_SHOP_CALL_ENABLED
	setevent EVENT_GOT_BICYCLE
	sjump .GotRide

.GiveSkateboard:
	waitsfx
	giveitem SKATEBOARD
	writetext BorrowedASkateboardText
	playsound SFX_KEY_ITEM
	waitsfx
	itemnotify
	setflag ENGINE_BIKE_SHOP_CALL_ENABLED
	setevent EVENT_GOT_BICYCLE
.GotRide:
	checkitem SKATEBOARD
	iftrue .GotSkateboard
	writetext GoldenrodBikeShopClerkFirstRateBikesText
	sjump .Finish

.GotSkateboard:
	writetext GoldenrodBikeShopClerkFirstRateSkateboardsText

.Finish:
	waitbutton
	closetext
	end

.Refused:
	writetext GoldenrodBikeShopClerkRefusedText
	waitbutton
	closetext
	end

GoldenrodBikeShopJustReleasedCompactBike:
; unused
	jumptext GoldenrodBikeShopJustReleasedCompactBikeText

GoldenrodBikeShopBicycle:
	jumptext GoldenrodBikeShopBicycleText

GoldenrodBikeShopClerkIntroText:
	text "…Sigh… I moved"
	line "here, but nobody"
	cont "knows my shop."

	para "Could you ride a"
	line "BICYCLE or"
	cont "SKATEBOARD and"
	cont "advertise for me?"
	done

GoldenrodBikeShopClerkAgreedText:
	text "Really? Great!"

	para "Give me your name"
	line "and phone number."
	cont "I'll loan you a"
	cont "ride!"
	done

BorrowedABicycleText:
	text "<PLAYER> borrowed a"
	line "BICYCLE."
	done

GoldenrodBikeShopAskBicycleText:
	text "I've also got this"
	line "new SKATEBOARD in"
	cont "stock."

	para "But I can only"
	line "loan you one."

	para "Would you like the"
	line "BICYCLE?"
	done

GoldenrodBikeShopAskSkateboardText:
	text "Then how about the"
	line "SKATEBOARD?"
	done

BorrowedASkateboardText:
	text "<PLAYER> borrowed a"
	line "SKATEBOARD."
	done

GoldenrodBikeShopClerkFirstRateBikesText:
	text "My BICYCLES are"
	line "first-rate! Great"
	cont "for getting around"
	cont "town!"
	done

GoldenrodBikeShopClerkFirstRateSkateboardsText:
	text "My SKATEBOARDS are"
	line "first-rate! Great"
	cont "for getting around"
	cont "town!"
	done

GoldenrodBikeShopClerkRefusedText:
	text "…sigh… Oh, for"
	line "the kindness of"
	cont "people…"
	done

GoldenrodBikeShopJustReleasedCompactBikeText:
	text "Just released!"

	para "First-rate compact"
	line "BICYCLES!"
	done

GoldenrodBikeShopBicycleText:
	text "It's a shiny new"
	line "BICYCLE!"
	done

GoldenrodBikeShop_MapEvents:
	db 0, 0 ; filler

	db 2 ; warp events
	warp_event  2,  7, GOLDENROD_CITY, 2
	warp_event  3,  7, GOLDENROD_CITY, 2

	db 0 ; coord events

	db 9 ; bg events
	bg_event  1,  2, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  0,  3, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  1,  3, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  0,  5, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  1,  5, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  0,  6, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  1,  6, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  6,  6, BGEVENT_READ, GoldenrodBikeShopBicycle
	bg_event  7,  6, BGEVENT_READ, GoldenrodBikeShopBicycle

	db 1 ; object events
	object_event  7,  2, SPRITE_CLERK, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_SCRIPT, 0, GoldenrodBikeShopClerkScript, -1
