	object_const_def ; object_event constants
	const ROUTE42_FISHER
	const ROUTE42_POKEFAN_M
	const ROUTE42_SUPER_NERD
	const ROUTE42_SUICUNE
	const ROUTE42_FISHING_SPOT_FISHER
	const ROUTE42_APRICORN1
	const ROUTE42_APRICORN2
	const ROUTE42_APRICORN3

Route42_MapScripts:
	db 2 ; scene scripts
	scene_script .DummyScene0 ; SCENE_ROUTE42_NOTHING
	scene_script .DummyScene1 ; SCENE_ROUTE42_SUICUNE

	db 1 ; callbacks
	callback MAPCALLBACK_OBJECTS, .Apricorns

.DummyScene0:
	end

.DummyScene1:
	end

.Apricorns:
; Picked apricorns stay gone until the trees regrow the next day.
	setval FRUITTREE_ROUTE_42_1
	callasm CheckApricornTreePicked
	iffalse .Apricorn2
	disappear ROUTE42_APRICORN1
.Apricorn2:
	setval FRUITTREE_ROUTE_42_2
	callasm CheckApricornTreePicked
	iffalse .Apricorn3
	disappear ROUTE42_APRICORN2
.Apricorn3:
	setval FRUITTREE_ROUTE_42_3
	callasm CheckApricornTreePicked
	iffalse .ApricornsDone
	disappear ROUTE42_APRICORN3
.ApricornsDone:
	return

Route42SuicuneScript:
	showemote EMOTE_SHOCK, PLAYER, 15
	pause 15
	cry ENTEI
	playsound SFX_EMBER
	earthquake 50
	earthquake 40
	waitsfx
	playsound SFX_WARP_FROM
	applymovement ROUTE42_SUICUNE, Route42SuicuneMovement
	disappear ROUTE42_SUICUNE
	pause 10
	setscene SCENE_ROUTE42_NOTHING
	clearevent EVENT_SAW_SUICUNE_ON_ROUTE_36
	setmapscene ROUTE_36, SCENE_ROUTE36_SUICUNE
	end

Route42FishingSpotNearScript:
	checkevent EVENT_BEAT_JASMINE
	iftrue .Done
	showemote EMOTE_SHOCK, ROUTE42_FISHING_SPOT_FISHER, 15
	applymovement ROUTE42_FISHING_SPOT_FISHER, Route42FishingSpotFisherApproachNear
	turnobject PLAYER, RIGHT
	scall Route42FishingSpotFisherTalk
	follow PLAYER, ROUTE42_FISHING_SPOT_FISHER
	applymovement PLAYER, Route42FishingSpotPlayerPushedBack
	stopfollow
	applymovement ROUTE42_FISHING_SPOT_FISHER, Route42FishingSpotFisherResetNear
.Done
	end

Route42FishingSpotMiddleScript:
	checkevent EVENT_BEAT_JASMINE
	iftrue .Done
	showemote EMOTE_SHOCK, ROUTE42_FISHING_SPOT_FISHER, 15
	applymovement ROUTE42_FISHING_SPOT_FISHER, Route42FishingSpotFisherApproachMiddle
	turnobject PLAYER, RIGHT
	scall Route42FishingSpotFisherTalk
	follow PLAYER, ROUTE42_FISHING_SPOT_FISHER
	applymovement PLAYER, Route42FishingSpotPlayerPushedBack
	stopfollow
	applymovement ROUTE42_FISHING_SPOT_FISHER, Route42FishingSpotFisherResetMiddle
.Done
	end

Route42FishingSpotFarScript:
	checkevent EVENT_BEAT_JASMINE
	iftrue .Done
	showemote EMOTE_SHOCK, ROUTE42_FISHING_SPOT_FISHER, 15
	applymovement ROUTE42_FISHING_SPOT_FISHER, Route42FishingSpotFisherApproachFar
	turnobject PLAYER, RIGHT
	scall Route42FishingSpotFisherTalk
	follow PLAYER, ROUTE42_FISHING_SPOT_FISHER
	applymovement PLAYER, Route42FishingSpotPlayerPushedBack
	stopfollow
	applymovement ROUTE42_FISHING_SPOT_FISHER, Route42FishingSpotFisherResetFar
.Done
	end

Route42FishingSpotFisherTalk:
	opentext
	writetext Route42FishingSpotFisherText
	waitbutton
	closetext
	playsound SFX_TACKLE
	end

Route42FishingSpotFisherScript:
	jumptextfaceplayer Route42FishingSpotFisherText

TrainerFisherTully:
	trainer FISHER, TULLY1, EVENT_BEAT_FISHER_TULLY, FisherTullySeenText, FisherTullyBeatenText, 0, .Script

.Script:
	loadvar VAR_CALLERID, PHONE_FISHER_TULLY
	endifjustbattled
	opentext
	checkflag ENGINE_TULLY
	iftrue .WantsBattle
	checkflag ENGINE_TULLY_HAS_WATER_STONE
	iftrue .HasWaterStone
	checkcellnum PHONE_FISHER_TULLY
	iftrue .NumberAccepted
	checkevent EVENT_TULLY_ASKED_FOR_PHONE_NUMBER
	iftrue .AskedAlready
	writetext FisherTullyAfterBattleText
	buttonsound
	setevent EVENT_TULLY_ASKED_FOR_PHONE_NUMBER
	scall .AskNumber1
	sjump .AskForNumber

.AskedAlready:
	scall .AskNumber2
.AskForNumber:
	askforphonenumber PHONE_FISHER_TULLY
	ifequal PHONE_CONTACTS_FULL, .PhoneFull
	ifequal PHONE_CONTACT_REFUSED, .NumberDeclined
	gettrainername STRING_BUFFER_3, FISHER, TULLY1
	scall .RegisteredNumber
	sjump .NumberAccepted

.WantsBattle:
	scall .Rematch
	winlosstext FisherTullyBeatenText, 0
	readmem wTullyFightCount
	ifequal 3, .Fight3
	ifequal 2, .Fight2
	ifequal 1, .Fight1
	ifequal 0, .LoadFight0
.Fight3:
	checkevent EVENT_BEAT_FALKNER_REMATCH
	iffalse .Fight2LeagueFallback
	checkevent EVENT_BEAT_ELITE_FOUR
	iftrue .LoadFight3
.Fight2LeagueFallback:
.Fight2:
	checkevent EVENT_BEAT_ELITE_FOUR
	iftrue .LoadFight2
.Fight1:
	checkevent EVENT_CLEARED_ROCKET_HIDEOUT
	iftrue .LoadFight1
.LoadFight0:
	loadtrainer FISHER, TULLY1
	startbattle
	reloadmapafterbattle
	loadmem wTullyFightCount, 1
	clearflag ENGINE_TULLY
	end

.LoadFight1:
	loadtrainer FISHER, TULLY2
	startbattle
	reloadmapafterbattle
	loadmem wTullyFightCount, 2
	clearflag ENGINE_TULLY
	end

.LoadFight2:
	loadtrainer FISHER, TULLY3
	startbattle
	reloadmapafterbattle
	loadmem wTullyFightCount, 3
	clearflag ENGINE_TULLY
	end

.LoadFight3:
	loadtrainer FISHER, TULLY4
	startbattle
	reloadmapafterbattle
	clearflag ENGINE_TULLY
	end

.HasWaterStone:
	scall .Gift
	verbosegiveitem WATER_STONE
	iffalse .NoRoom
	clearflag ENGINE_TULLY_HAS_WATER_STONE
	setevent EVENT_TULLY_GAVE_WATER_STONE
	sjump .NumberAccepted

.NoRoom:
	sjump .PackFull

.AskNumber1:
	jumpstd asknumber1m
	end

.AskNumber2:
	jumpstd asknumber2m
	end

.RegisteredNumber:
	jumpstd registerednumberm
	end

.NumberAccepted:
	jumpstd numberacceptedm
	end

.NumberDeclined:
	jumpstd numberdeclinedm
	end

.PhoneFull:
	jumpstd phonefullm
	end

.Rematch:
	jumpstd rematchm
	end

.Gift:
	jumpstd giftm
	end

.PackFull:
	jumpstd packfullm
	end

TrainerPokemaniacShane:
	trainer POKEMANIAC, SHANE, EVENT_BEAT_POKEMANIAC_SHANE, PokemaniacShaneSeenText, PokemaniacShaneBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext PokemaniacShaneAfterBattleText
	waitbutton
	closetext
	end

TrainerHikerBenjamin:
	trainer HIKER, BENJAMIN, EVENT_BEAT_HIKER_BENJAMIN, HikerBenjaminSeenText, HikerBenjaminBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext HikerBenjaminAfterBattleText
	waitbutton
	closetext
	end

Route42Sign1:
	jumptext Route42Sign1Text

MtMortarSign1:
	jumptext MtMortarSign1Text

MtMortarSign2:
	jumptext MtMortarSign2Text

Route42Sign2:
	jumptext Route42Sign2Text

Route42HiddenCarbos:
	hiddenitem CARBOS, EVENT_ROUTE_42_HIDDEN_CARBOS

Route42HiddenPPUp:
	hiddenitem PP_UP, EVENT_ROUTE_42_HIDDEN_PP_UP

Route42FruitTree1:
	scall .Tree
	setval FRUITTREE_ROUTE_42_1
	callasm CheckApricornTreePicked
	iffalse .Done
	disappear ROUTE42_APRICORN1
.Done:
	end

.Tree:
	fruittree FRUITTREE_ROUTE_42_1

Route42FruitTree2:
	scall .Tree
	setval FRUITTREE_ROUTE_42_2
	callasm CheckApricornTreePicked
	iffalse .Done
	disappear ROUTE42_APRICORN2
.Done:
	end

.Tree:
	fruittree FRUITTREE_ROUTE_42_2

Route42FruitTree3:
	scall .Tree
	setval FRUITTREE_ROUTE_42_3
	callasm CheckApricornTreePicked
	iffalse .Done
	disappear ROUTE42_APRICORN3
.Done:
	end

.Tree:
	fruittree FRUITTREE_ROUTE_42_3

Route42HiddenMaxPotion:
	hiddenitem MAX_POTION, EVENT_ROUTE_42_HIDDEN_MAX_POTION

Route42SuicuneMovement:
	set_sliding
	fast_jump_step UP
	fast_jump_step UP
	fast_jump_step UP
	fast_jump_step RIGHT
	fast_jump_step RIGHT
	fast_jump_step RIGHT
	remove_sliding
	step_end


Route42FishingSpotFisherApproachNear:
	step RIGHT
	step DOWN
	turn_head LEFT
	step_end

Route42FishingSpotFisherApproachMiddle:
	step RIGHT
	step DOWN
	step DOWN
	turn_head LEFT
	step_end

Route42FishingSpotFisherApproachFar:
	step RIGHT
	step DOWN
	step DOWN
	step DOWN
	turn_head LEFT
	step_end

Route42FishingSpotPlayerPushedBack:
	step LEFT
	step_end

Route42FishingSpotFisherResetNear:
	step UP
	turn_head DOWN
	step_end

Route42FishingSpotFisherResetMiddle:
	step UP
	step UP
	turn_head DOWN
	step_end

Route42FishingSpotFisherResetFar:
	step UP
	step UP
	step UP
	turn_head DOWN
	step_end

FisherTullySeenText:
	text "Let me demonstrate"
	line "the power of the"
	cont "#MON I caught!"
	done

FisherTullyBeatenText:
	text "What? That's not"
	line "right."
	done

FisherTullyAfterBattleText:
	text "I want to become"
	line "the trainer CHAMP"

	para "using the #MON"
	line "I caught."

	para "That's the best"
	line "part of fishing!"
	done

HikerBenjaminSeenText:
	text "Ah, it's good to"
	line "be outside!"
	cont "I feel so free!"
	done

HikerBenjaminBeatenText:
	text "Gahahah!"
	done

HikerBenjaminAfterBattleText:
	text "Losing feels in-"
	line "significant if you"

	para "look up at the big"
	line "sky!"
	done

PokemaniacShaneSeenText:
	text "HEY!"

	para "This is my secret"
	line "place! Get lost,"
	cont "you outsider!"
	done

PokemaniacShaneBeatenText:
	text "I should have used"
	line "my MOON STONE…"
	done

PokemaniacShaneAfterBattleText:
	text "You're working on"
	line "a #DEX?"

	para "Wow, you must know"
	line "some pretty rare"
	cont "#MON!"

	para "May I please see"
	line "it? Please?"
	done

Route42Sign1Text:
	text "ROUTE 42"

	para "ECRUTEAK CITY -"
	line "MAHOGANY TOWN"
	done

MtMortarSign1Text:
	text "MT.MORTAR"

	para "WATERFALL CAVE"
	line "INSIDE"
	done

MtMortarSign2Text:
	text "MT.MORTAR"

	para "WATERFALL CAVE"
	line "INSIDE"
	done

Route42Sign2Text:
	text "ROUTE 42"

	para "ECRUTEAK CITY -"
	line "MAHOGANY TOWN"
	done

Route42FishingSpotFisherText:
	text "Sorry, bud. This"
	line "is my favorite"
	cont "fishing spot, and"
	cont "I'm just setting"
	cont "up."

	para "Come back later."

	para "Why not check out"
	line "the LIGHTHOUSE in"
	cont "OLIVINE?"

	para "I heard something"
	line "is wrong there."
	done

Route42_MapEvents:
	db 0, 0 ; filler

	db 5 ; warp events
	warp_event  0,  8, ROUTE_42_ECRUTEAK_GATE, 3
	warp_event  0,  9, ROUTE_42_ECRUTEAK_GATE, 4
	warp_event 10,  5, MOUNT_MORTAR_1F_OUTSIDE, 1
	warp_event 28,  9, MOUNT_MORTAR_1F_OUTSIDE, 2
	warp_event 46,  7, MOUNT_MORTAR_1F_OUTSIDE, 3

	db 4 ; coord events
	coord_event 24, 14, SCENE_ROUTE42_SUICUNE, Route42SuicuneScript
	coord_event 10,  7, -1, Route42FishingSpotNearScript
	coord_event 10,  8, -1, Route42FishingSpotMiddleScript
	coord_event 10,  9, -1, Route42FishingSpotFarScript

	db 10 ; bg events
	bg_event  4, 10, BGEVENT_READ, Route42Sign1
	bg_event  7,  5, BGEVENT_READ, MtMortarSign1
	bg_event 45,  9, BGEVENT_READ, MtMortarSign2
	bg_event 54,  8, BGEVENT_READ, Route42Sign2
	bg_event 16, 11, BGEVENT_ITEM, Route42HiddenMaxPotion
	bg_event  6,  4, BGEVENT_ITEM, Route42HiddenCarbos
	bg_event 33,  8, BGEVENT_ITEM, Route42HiddenPPUp
	; The trees are background tiles so Entei and all three apricorns fit OAM.
	bg_event 27, 16, BGEVENT_READ, Route42FruitTree1
	bg_event 28, 16, BGEVENT_READ, Route42FruitTree2
	bg_event 29, 16, BGEVENT_READ, Route42FruitTree3

	db 8 ; object events
	object_event 40, 10, SPRITE_FISHER, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_TRAINER, 1, TrainerFisherTully, -1
	object_event 51,  9, SPRITE_HIKER, SPRITEMOVEDATA_SPINRANDOM_FAST, 0, 0, -1, -1, PAL_NPC_BROWN, OBJECTTYPE_TRAINER, 3, TrainerHikerBenjamin, -1
	object_event 47,  8, SPRITE_POKEMANIAC_NEW, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_TRAINER, 3, TrainerPokemaniacShane, -1
	object_event 26, 16, SPRITE_ENTEI, SPRITEMOVEDATA_POKEMON, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_SCRIPT, 0, ObjectEvent, EVENT_SAW_SUICUNE_ON_ROUTE_42
	object_event 10,  6, SPRITE_FAT_GUY, SPRITEMOVEDATA_STANDING_DOWN, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_SCRIPT, 0, Route42FishingSpotFisherScript, EVENT_BEAT_JASMINE
	object_event 27, 16, SPRITE_APRICORN, SPRITEMOVEDATA_APRICORN, 0, 0, -1, -1, PAL_NPC_APRICORN, OBJECTTYPE_SCRIPT, 0, Route42FruitTree1, EVENT_TEMPORARY_UNTIL_MAP_RELOAD_2
	object_event 28, 16, SPRITE_APRICORN, SPRITEMOVEDATA_APRICORN, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_SCRIPT, 0, Route42FruitTree2, EVENT_TEMPORARY_UNTIL_MAP_RELOAD_3
	object_event 29, 16, SPRITE_APRICORN, SPRITEMOVEDATA_APRICORN_ONE_TONE, 0, 0, -1, -1, PAL_NPC_APRICORN, OBJECTTYPE_SCRIPT, 0, Route42FruitTree3, EVENT_TEMPORARY_UNTIL_MAP_RELOAD_4
