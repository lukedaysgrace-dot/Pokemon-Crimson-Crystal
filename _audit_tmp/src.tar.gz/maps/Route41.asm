	object_const_def ; object_event constants
	const ROUTE41_OLIVINE_RIVAL1
	const ROUTE41_OLIVINE_RIVAL2
	const ROUTE41_OLIVINE_RIVAL3
	const ROUTE41_OLIVINE_RIVAL4
	const ROUTE41_OLIVINE_RIVAL5
	const ROUTE41_SWIMMER_GIRL1
	const ROUTE41_SWIMMER_GIRL2
	const ROUTE41_SWIMMER_GIRL3
	const ROUTE41_SWIMMER_GIRL4
	const ROUTE41_SWIMMER_GIRL5
	const ROUTE41_FINIZEN

Route41_MapScripts:
	db 0 ; scene scripts

	db 2 ; callbacks
	callback MAPCALLBACK_NEWMAP, .ResetFinizen
	callback MAPCALLBACK_OBJECTS, .PlaceFinizen

.ResetFinizen:
; The chase has to be finished in one visit, so arriving on the route always
; puts FINIZEN back at its first spot. This runs on entry only - MAPCALLBACK_
; OBJECTS also fires after every wild battle, which would otherwise reset the
; count every time the player got jumped while surfing.
	loadmem wFinizenPosition, 1
	return

.PlaceFinizen:
; FINIZEN only shows up on Sundays, and only until it has been caught.
	checkevent EVENT_ROUTE_41_CAUGHT_FINIZEN
	iftrue .NoFinizen
	readvar VAR_WEEKDAY
	ifnotequal SUNDAY, .NoFinizen
	readmem wFinizenPosition
	ifequal 2, .SecondSpot
	ifequal 3, .ThirdSpot
	ifequal 4, .NoFinizen
	moveobject ROUTE41_FINIZEN, 26, 46
	appear ROUTE41_FINIZEN
	return

.SecondSpot:
	moveobject ROUTE41_FINIZEN, 19, 49
	appear ROUTE41_FINIZEN
	return

.ThirdSpot:
	moveobject ROUTE41_FINIZEN, 14, 52
	appear ROUTE41_FINIZEN
	return

.NoFinizen:
	disappear ROUTE41_FINIZEN
	return

TrainerSwimmerfKaylee:
	trainer SWIMMERF, KAYLEE, EVENT_BEAT_SWIMMERF_KAYLEE, SwimmerfKayleeSeenText, SwimmerfKayleeBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmerfKayleeAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmerfSusie:
	trainer SWIMMERF, SUSIE, EVENT_BEAT_SWIMMERF_SUSIE, SwimmerfSusieSeenText, SwimmerfSusieBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmerfSusieAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmerfDenise:
	trainer SWIMMERF, DENISE, EVENT_BEAT_SWIMMERF_DENISE, SwimmerfDeniseSeenText, SwimmerfDeniseBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmerfDeniseAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmerfKara:
	trainer SWIMMERF, KARA, EVENT_BEAT_SWIMMERF_KARA, SwimmerfKaraSeenText, SwimmerfKaraBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmerfKaraAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmerfWendy:
	trainer SWIMMERF, WENDY, EVENT_BEAT_SWIMMERF_WENDY, SwimmerfWendySeenText, SwimmerfWendyBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmerfWendyAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmermCharlie:
	trainer SWIMMERM, CHARLIE, EVENT_BEAT_SWIMMERM_CHARLIE, SwimmermCharlieSeenText, SwimmermCharlieBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmermCharlieAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmermGeorge:
	trainer SWIMMERM, GEORGE, EVENT_BEAT_SWIMMERM_GEORGE, SwimmermGeorgeSeenText, SwimmermGeorgeBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmermGeorgeAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmermBerke:
	trainer SWIMMERM, BERKE, EVENT_BEAT_SWIMMERM_BERKE, SwimmermBerkeSeenText, SwimmermBerkeBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmermBerkeAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmermKirk:
	trainer SWIMMERM, KIRK, EVENT_BEAT_SWIMMERM_KIRK, SwimmermKirkSeenText, SwimmermKirkBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmermKirkAfterBattleText
	waitbutton
	closetext
	end

TrainerSwimmermMathew:
	trainer SWIMMERM, MATHEW, EVENT_BEAT_SWIMMERM_MATHEW, SwimmermMathewSeenText, SwimmermMathewBeatenText, 0, .Script

.Script:
	endifjustbattled
	opentext
	writetext SwimmermMathewAfterBattleText
	waitbutton
	closetext
	end

Route41FinizenScript:
; Talk to it twice and it bolts to a new patch of open water. The third time it
; has run out of room and battles. Losing it there re-arms the encounter for the
; following Sunday, this time without the chase.
	faceplayer
	checkevent EVENT_ROUTE_41_FINIZEN_FOUGHT
	iftrue .Cornered
	readmem wFinizenPosition
	ifequal 2, .SecondFlee
	ifequal 3, .Cornered

	opentext
	writetext Route41FinizenFinText
	cry FINIZEN
	waitbutton
	closetext
; It breaks away from whichever side the player is crowding it from, so it never
; swims straight through them.
	readvar VAR_FACING
	ifequal RIGHT, .FirstFleeFromLeft
	ifequal UP, .FirstFleeFromBelow
	applymovement ROUTE41_FINIZEN, Route41FinizenFleeMovement1
	sjump .FirstFleeDone

.FirstFleeFromLeft:
	applymovement ROUTE41_FINIZEN, Route41FinizenFleeMovement1Left
	sjump .FirstFleeDone

.FirstFleeFromBelow:
	applymovement ROUTE41_FINIZEN, Route41FinizenFleeMovement1Below

.FirstFleeDone:
	moveobject ROUTE41_FINIZEN, 19, 49
	disappear ROUTE41_FINIZEN
	appear ROUTE41_FINIZEN
	loadmem wFinizenPosition, 2
	end

.SecondFlee:
	opentext
	writetext Route41FinizenFinText
	cry FINIZEN
	waitbutton
	closetext
	readvar VAR_FACING
	ifequal RIGHT, .SecondFleeFromLeft
	applymovement ROUTE41_FINIZEN, Route41FinizenFleeMovement2
	sjump .SecondFleeDone

.SecondFleeFromLeft:
	applymovement ROUTE41_FINIZEN, Route41FinizenFleeMovement2Left

.SecondFleeDone:
	moveobject ROUTE41_FINIZEN, 14, 52
	disappear ROUTE41_FINIZEN
	appear ROUTE41_FINIZEN
	loadmem wFinizenPosition, 3
	end

.Cornered:
	opentext
	writetext Route41FinizenCorneredText
	cry FINIZEN
	pause 15
	closetext
	loadwildmon FINIZEN, 30
	startbattle
	setevent EVENT_ROUTE_41_FINIZEN_FOUGHT
; A wild battle reports WIN for a knockout as well as a catch, so ask outright.
; This has to be settled before reloadmapafterbattle, which re-runs .PlaceFinizen.
	special CheckCaughtWildMon
	iffalse .GotAway
	setevent EVENT_ROUTE_41_CAUGHT_FINIZEN
.GotAway:
	loadmem wFinizenPosition, 4
	disappear ROUTE41_FINIZEN
	reloadmapafterbattle
	end

Route41FinizenFleeMovement1:
; 26,46 -> 19,49, keeping clear of the walls off the WHIRL ISLANDS
	big_step LEFT
	big_step LEFT
	big_step DOWN
	big_step DOWN
	big_step DOWN
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	step_end

Route41FinizenFleeMovement1Left:
; 26,46 -> 19,49 when the player talks to it from the west. Drops south first so
; it isn't swimming through the player's tile.
	big_step DOWN
	big_step LEFT
	big_step LEFT
	big_step DOWN
	big_step DOWN
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	step_end

Route41FinizenFleeMovement1Below:
; 26,46 -> 19,49 when the player talks to it from the south.
	big_step LEFT
	big_step LEFT
	big_step DOWN
	big_step DOWN
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step DOWN
	big_step LEFT
	step_end

Route41FinizenFleeMovement2:
; 19,49 -> 14,52. Used from above, from the east and from the south.
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step DOWN
	big_step DOWN
	big_step DOWN
	step_end

Route41FinizenFleeMovement2Left:
; 19,49 -> 14,52 when the player talks to it from the west. It ducks under them
; and pops back up before running for open water.
	big_step DOWN
	big_step LEFT
	big_step LEFT
	big_step LEFT
	big_step UP
	big_step LEFT
	big_step LEFT
	big_step DOWN
	big_step DOWN
	big_step DOWN
	step_end

Route41Rock:
; unused
	jumpstd smashrock

Route41HiddenMaxEther:
	hiddenitem MAX_ETHER, EVENT_ROUTE_41_HIDDEN_MAX_ETHER

Route41ShiverIsleSign:
	jumptext Route41ShiverIsleSignText

SwimmermCharlieSeenText:
	text "The water's warm"
	line "here. I'm loose"
	cont "and limber."

	para "Sure, I'll take"
	line "you on!"
	done

SwimmermCharlieBeatenText:
	text "Yikes! I've got"
	line "prune skin!"
	done

SwimmermCharlieAfterBattleText:
	text "Isn't it relaxing"
	line "just floating like"
	cont "this?"
	done

SwimmermGeorgeSeenText:
	text "I'm a bit tired."
	line "If I win, lend me"
	cont "your #MON."
	done

SwimmermGeorgeBeatenText:
	text "Pant, pant…"
	done

SwimmermGeorgeAfterBattleText:
	text "It's so far to"
	line "CIANWOOD."

	para "But it's no easy"
	line "return trip to"
	cont "OLIVINE either."

	para "What should I do?"
	done

SwimmermBerkeSeenText:
	text "See those islands"
	line "that are blocked"
	cont "by whirlpools?"

	para "There just has to"
	line "be a secret!"
	done

SwimmermBerkeBeatenText:
	text "What's the secret"
	line "to your strength?"
	done

SwimmermBerkeAfterBattleText:
	text "It was a dark and"
	line "stormy night…"

	para "I saw this giant"
	line "#MON flying"
	cont "from the islands."

	para "It was scattering"
	line "feathers from its"
	cont "silver wings."
	done

SwimmermKirkSeenText:
	text "The waves are wild"
	line "here."

	para "They tire you out"
	line "while you swim."
	done

SwimmermKirkBeatenText:
	text "I'm beat!"
	done

SwimmermKirkAfterBattleText:
	text "The currents keep"
	line "me from reaching"
	cont "that island."
	done

SwimmermMathewSeenText:
	text "Are you seeking"
	line "the secrets of"
	cont "WHIRL ISLANDS?"
	done

SwimmermMathewBeatenText:
	text "Ooh, you've got"
	line "great endurance!"
	done

SwimmermMathewAfterBattleText:
	text "A secret about"
	line "WHIRL ISLANDS…"

	para "It's pitch-black"
	line "inside!"
	done

SwimmerfKayleeSeenText:
	text "I'm on my way to"
	line "WHIRL ISLANDS."

	para "I'm going explor-"
	line "ing with friends."
	done

SwimmerfKayleeBeatenText:
	text "Is that how you do"
	line "it?"
	done

SwimmerfKayleeAfterBattleText:
	text "There's supposed"
	line "to be a big #-"
	cont "MON deep beneath"
	cont "WHIRL ISLANDS."

	para "I wonder what it"
	line "could be?"
	done

SwimmerfSusieSeenText:
	text "You look so ele-"
	line "gant, riding your"
	cont "#MON."
	done

SwimmerfSusieBeatenText:
	text "I'm crushed…"
	done

SwimmerfSusieAfterBattleText:
	text "Wasn't there a hit"
	line "song about a boy"
	cont "riding a LAPRAS?"
	done

SwimmerfDeniseSeenText:
	text "The weather is so"
	line "beautiful, I'm in"
	cont "a daze!"
	done

SwimmerfDeniseBeatenText:
	text "Ohhh!"
	done

SwimmerfDeniseAfterBattleText:
	text "A sunburn is the"
	line "worst for skin."

	para "But I don't use a"
	line "sunblock."

	para "I won't pollute"
	line "the water."
	done

SwimmerfKaraSeenText:
	text "If you need to"
	line "rest, just tread"
	cont "water."

	para "You'll get your"
	line "wind back, so you"

	para "can keep on going"
	line "strong."
	done

SwimmerfKaraBeatenText:
	text "Oh! You have more"
	line "energy than I do."
	done

SwimmerfKaraAfterBattleText:
	text "I heard roars from"
	line "deep inside the"
	cont "ISLANDS."
	done

SwimmerfWendySeenText:
	text "At night, STARYU"
	line "gather near the"
	cont "water's surface."
	done

SwimmerfWendyBeatenText:
	text "Oh, dear…"
	done

SwimmerfWendyAfterBattleText:
	text "The clusters of"
	line "STARYU light up"
	cont "at the same time."

	para "It's so beautiful,"
	line "it's scary."
	done

Route41ShiverIsleSignText:
	text "SHIVER ISLE"
	done

Route41FinizenFinText:
	text "Fin!"
	done

Route41FinizenCorneredText:
	text "Fin…"
	done

Route41_MapEvents:
	db 0, 0 ; filler

	db 5 ; warp events
	warp_event 12, 17, WHIRL_ISLAND_NW, 1
	warp_event 36, 19, WHIRL_ISLAND_NE, 1
	warp_event 12, 37, WHIRL_ISLAND_SW, 1
	warp_event 36, 45, WHIRL_ISLAND_SE, 1
	warp_event 44,  5, SHIVER_ISLE, 1

	db 0 ; coord events

	db 2 ; bg events
	bg_event  9, 35, BGEVENT_ITEM, Route41HiddenMaxEther
	bg_event 42,  6, BGEVENT_READ, Route41ShiverIsleSign

	db 11 ; object events
	object_event 32,  6, SPRITE_OLIVINE_RIVAL, SPRITEMOVEDATA_SPINRANDOM_FAST, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 3, TrainerSwimmermCharlie, -1
	object_event 48, 11, SPRITE_OLIVINE_RIVAL, SPRITEMOVEDATA_SPINRANDOM_FAST, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 3, TrainerSwimmermGeorge, -1
	object_event 20, 26, SPRITE_OLIVINE_RIVAL, SPRITEMOVEDATA_SPINCOUNTERCLOCKWISE, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 3, TrainerSwimmermBerke, -1
	object_event 32, 30, SPRITE_OLIVINE_RIVAL, SPRITEMOVEDATA_SPINCLOCKWISE, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 3, TrainerSwimmermKirk, -1
	object_event 19, 46, SPRITE_OLIVINE_RIVAL, SPRITEMOVEDATA_SPINCOUNTERCLOCKWISE, 0, 0, -1, -1, PAL_NPC_RED, OBJECTTYPE_TRAINER, 3, TrainerSwimmermMathew, -1
	object_event 17,  4, SPRITE_SWIMMER_GIRL, SPRITEMOVEDATA_SPINRANDOM_FAST, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_TRAINER, 3, TrainerSwimmerfKaylee, -1
	object_event 23, 19, SPRITE_SWIMMER_GIRL, SPRITEMOVEDATA_STANDING_UP, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_TRAINER, 3, TrainerSwimmerfSusie, -1
	object_event 27, 34, SPRITE_SWIMMER_GIRL, SPRITEMOVEDATA_STANDING_LEFT, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_TRAINER, 3, TrainerSwimmerfDenise, -1
	object_event 44, 28, SPRITE_SWIMMER_GIRL, SPRITEMOVEDATA_STANDING_RIGHT, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_TRAINER, 4, TrainerSwimmerfKara, -1
	object_event  9, 50, SPRITE_SWIMMER_GIRL, SPRITEMOVEDATA_SPINRANDOM_FAST, 0, 0, -1, -1, PAL_NPC_GREEN, OBJECTTYPE_TRAINER, 2, TrainerSwimmerfWendy, -1
	object_event 26, 46, SPRITE_FINIZEN, SPRITEMOVEDATA_SPINRANDOM_SLOW, 0, 0, -1, -1, PAL_NPC_BLUE, OBJECTTYPE_SCRIPT, 0, Route41FinizenScript, EVENT_ROUTE_41_FINIZEN
