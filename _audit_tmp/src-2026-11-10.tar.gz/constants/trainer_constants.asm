trainerclass: MACRO
	enum \1
const_value = 1
ENDM

; trainer class ids
; `trainerclass` indexes are for:
; - TrainerClassNames (see data/trainers/class_names.asm)
; - TrainerClassAttributes (see data/trainers/attributes.asm)
; - TrainerClassDVs (see data/trainers/dvs.asm)
; - TrainerGroups (see data/trainers/party_pointers.asm)
; - TrainerEncounterMusic (see data/trainers/encounter_music.asm)
; - TrainerPicPointers (see data/trainers/pic_pointers.asm)
; - TrainerPalettes (see data/trainers/palettes.asm)
; - BTTrainerClassSprites (see data/trainers/sprites.asm)
; - BTTrainerClassGenders (see data/trainers/genders.asm)
; trainer constants are Trainers indexes, for the sub-tables of TrainerGroups (see data/trainers/parties.asm)
	enum_start
GOLD EQU __enum__
	trainerclass TRAINER_NONE ; 0
	const PHONECONTACT_MOM
	const PHONECONTACT_BIKESHOP
	const PHONECONTACT_BILL
	const PHONECONTACT_ELM
	const PHONECONTACT_BUENA
	const PHONECONTACT_OAK
	const PHONECONTACT_CRYSTAL

LYRA EQU __enum__
	trainerclass FALKNER ; 1
	const FALKNER1
	const FALKNER2

	trainerclass WHITNEY ; 2
	const WHITNEY1
	const WHITNEY2

	trainerclass BUGSY ; 3
	const BUGSY1
	const BUGSY2

	trainerclass MORTY ; 4
	const MORTY1
	const MORTY2

	trainerclass PRYCE ; 5
	const PRYCE1
	const PRYCE2

	trainerclass JASMINE ; 6
	const JASMINE1
	const JASMINE2

	trainerclass CHUCK ; 7
	const CHUCK1
	const CHUCK2

	trainerclass CLAIR ; 8
	const CLAIR1
	const CLAIR2

	trainerclass RIVAL1 ; 9
	const RIVAL1_1_CHIKORITA
	const RIVAL1_1_CYNDAQUIL
	const RIVAL1_1_TOTODILE
	const RIVAL1_2_CHIKORITA
	const RIVAL1_2_CYNDAQUIL
	const RIVAL1_2_TOTODILE
	const RIVAL1_3_CHIKORITA
	const RIVAL1_3_CYNDAQUIL
	const RIVAL1_3_TOTODILE
	const RIVAL1_4_CHIKORITA
	const RIVAL1_4_CYNDAQUIL
	const RIVAL1_4_TOTODILE
	const RIVAL1_5_CHIKORITA
	const RIVAL1_5_CYNDAQUIL
	const RIVAL1_5_TOTODILE

	trainerclass POKEMON_PROF ; a

	trainerclass WILL ; b
	const WILL1
	const WILL2

	trainerclass CAL ; c
	const CAL1
	const CAL2
	const CAL3 ; Trainer House, player's highest level below 60
	const CAL4 ; Trainer House, highest level 60-69
	const CAL5 ; Trainer House, highest level 70-79
	const CAL6 ; Trainer House, highest level 80+

	trainerclass BRUNO ; d
	const BRUNO1
	const BRUNO2

	trainerclass KAREN ; e
	const KAREN1
	const KAREN2

	trainerclass KOGA ; f
	const KOGA1
	const KOGA2

	trainerclass CHAMPION ; 10
	const LANCE
	const LANCE2

	trainerclass BROCK ; 11
	const BROCK1

	trainerclass MISTY ; 12
	const MISTY1

	trainerclass LT_SURGE ; 13
	const LT_SURGE1

	trainerclass SCIENTIST ; 14
	const ROSS
	const MITCH
	const JED
	const MARC
	const RICH

	trainerclass ERIKA ; 15
	const ERIKA1

	trainerclass YOUNGSTER ; 16
	const JOEY1
	const MIKEY
	const ALBERT
	const GORDON
	const SAMUEL
	const IAN
	const JOEY2
	const JOEY3
	const WARREN
	const JIMMY
	const OWEN
	const JASON
	const JOEY4
	const JOEY5

	trainerclass SCHOOLBOY ; 17
	const JACK1
	const KIPP
	const ALAN1
	const JOHNNY
	const DANNY
	const TOMMY
	const DUDLEY
	const JOE
	const BILLY
	const CHAD1
	const NATE
	const RICKY
	const JACK2
	const JACK3
	const ALAN2
	const ALAN3
	const CHAD2
	const CHAD3
	const JACK4
	const JACK5
	const ALAN4
	const ALAN5
	const CHAD4
	const CHAD5

	trainerclass BIRD_KEEPER ; 18
	const ROD
	const ABE
	const BRYAN
	const THEO
	const TOBY
	const DENIS
	const VANCE1
	const HANK
	const ROY
	const BORIS
	const BOB
	const JOSE1
	const PETER
	const JOSE2
	const PERRY
	const BRET
	const JOSE3
	const VANCE2
	const VANCE3

	trainerclass LASS ; 19
	const CARRIE
	const BRIDGET
	const KRISE
	const CONNIE1
	const LAURA
	const SHANNON
	const MICHELLE
	const DANA1
	const ELLEN
	const CONNIE2
	const CONNIE3
	const DANA2
	const DANA3
	const DANA4
	const DANA5
	const DANIELLE
	const KATHRYN
	const PAIGE
	const ELISE

	trainerclass JANINE ; 1a
	const JANINE1

	trainerclass COOLTRAINERM ; 1b
	const NICK
	const AARON
	const PAUL
	const CODY
	const MIKE
	const GAVEN1
	const GAVEN2
	const RYAN
	const JAKE
	const GAVEN3
	const BLAKE
	const BRIAN
	const SEAN
	const KEVIN
	const ALLEN
	const DARIN
	const LARRY2
	const SNOW
	const CYANIDE
	const CHANTZ
	const ADRIAN

	trainerclass COOLTRAINERF ; 1c
	const GWEN
	const LOIS
	const FRAN
	const LOLA
	const KATE
	const IRENE
	const KELLY
	const JOYCE
	const BETH1
	const REENA1
	const MEGAN
	const BETH2
	const CAROL
	const QUINN
	const EMMA
	const CYBIL
	const JENN
	const BETH3
	const REENA2
	const REENA3
	const CARA
	const SELENE

	trainerclass BEAUTY ; 1d
	const VICTORIA
	const SAMANTHA
	const CASSIE
	const JULIA
	const VALERIE
	const OLIVIA

	trainerclass POKEMANIAC ; 1e
	const LARRY
	const ANDREW
	const CALVIN
	const SHANE
	const BEN
	const BRENT1
	const RON
	const ETHAN
	const BRENT2
	const BRENT3
	const ISSAC
	const DONALD
	const ZACH
	const BRENT4
	const MILLER

	trainerclass GRUNTM ; 1f
	const GRUNTM_2
	const GRUNTM_4
	const GRUNTM_6
	const GRUNTM_7
	const GRUNTM_10
	const GRUNTM_13
	const GRUNTM_14
	const GRUNTM_15
	const GRUNTM_18
	const GRUNTM_20
	const GRUNTM_21
	const GRUNTM_25
	const GRUNTM_28
	const GRUNTM_31
	const GRUNTM_GOLDENROD_RIOLU
	const GRUNTM_GOLDENROD_RIOLU_LEADER
	const GRUNTM_ROUTE43_TOLL1
	const GRUNTM_ROUTE43_TOLL2

	trainerclass GENTLEMAN ; 20
	const PRESTON
	const EDWARD
	const GREGORY
	const ALFRED

	trainerclass SKIER ; 21
	const ROXANNE
	const CLARISSA
	const SKIER_BIANCA
	const SKIER_HEIDI

	trainerclass TEACHER ; 22
	const COLETTE
	const HILLARY
	const SHIRLEY

	trainerclass SABRINA ; 23
	const SABRINA1

	trainerclass BUG_CATCHER ; 24
	const DON
	const ROB
	const ED
	const WADE1
	const BUG_CATCHER_BENNY
	const AL
	const JOSH
	const ARNIE1
	const KEN
	const WADE2
	const WADE3
	const DOUG
	const ARNIE2
	const ARNIE3
	const WADE4
	const WADE5
	const ARNIE4
	const ARNIE5
	const WAYNE

	trainerclass FISHER ; 25
	const JUSTIN
	const RALPH1
	const ARNOLD
	const KYLE
	const HENRY
	const MARVIN
	const TULLY1
	const ANDRE
	const RAYMOND
	const WILTON1
	const EDGAR
	const JONAH
	const MARTIN
	const STEPHEN
	const BARNEY
	const RALPH2
	const RALPH3
	const TULLY2
	const TULLY3
	const WILTON2
	const SCOTT
	const WILTON3
	const RALPH4
	const RALPH5
	const TULLY4

	trainerclass SWIMMERM ; 26
	const HAROLD
	const SIMON
	const RANDALL
	const CHARLIE
	const GEORGE
	const BERKE
	const KIRK
	const MATHEW
	const JEROME
	const TUCKER
	const CAMERON
	const SETH
	const PARKER

	trainerclass SWIMMERF ; 27
	const ELAINE
	const PAULA
	const KAYLEE
	const SUSIE
	const DENISE
	const KARA
	const WENDY
	const DAWN
	const NICOLE
	const LORI
	const NIKKI
	const DIANA
	const BRIANA

	trainerclass SAILOR ; 28
	const EUGENE
	const HUEY1
	const TERRELL
	const KENT
	const ERNEST
	const JEFF
	const GARRETT
	const KENNETH
	const STANLY
	const HARRY
	const HUEY2
	const HUEY3
	const HUEY4

	trainerclass SUPER_NERD ; 29
	const STAN
	const ERIC
	const SAM
	const TOM
	const PAT
	const SHAWN
	const TERU
	const HUGH
	const MARKUS

	trainerclass RIVAL2 ; 2a
	const RIVAL2_1_CHIKORITA
	const RIVAL2_1_CYNDAQUIL
	const RIVAL2_1_TOTODILE
	const RIVAL2_2_CHIKORITA
	const RIVAL2_2_CYNDAQUIL
	const RIVAL2_2_TOTODILE

	trainerclass GUITARIST ; 2b
	const CLYDE
	const VINCENT

	trainerclass HIKER ; 2c
	const ANTHONY1
	const RUSSELL
	const PHILLIP
	const LEONARD
	const ANTHONY2
	const BENJAMIN
	const ERIK
	const MICHAEL
	const PARRY1
	const TIMOTHY
	const BAILEY
	const ANTHONY3
	const TIM
	const NOLAND
	const SIDNEY
	const KENNY
	const JIM
	const DANIEL
	const PARRY2
	const PARRY3
	const ANTHONY4
	const ANTHONY5

	trainerclass BIKER ; 2d
	const DWAYNE
	const HARRIS
	const ZEKE
	const CHARLES
	const RILEY
	const JOEL
	const GLENN
	const ROUTE16_AXLE
	const ROUTE16_RUSTY

	trainerclass BLAINE ; 2e
	const BLAINE1

	trainerclass BURGLAR ; 2f
	const DUNCAN
	const EDDIE
	const COREY
	const MORTON
	const VANCE

	trainerclass FIREBREATHER ; 30
	const OTIS
	const BURT
	const BILL
	const WALT
	const RAY
	const LYLE
	const SCORCH
	const TORCH
	const DICK
	const NED

	trainerclass JUGGLER ; 31
	const IRWIN1
	const FRITZ
	const HORTON
	const IRWIN2
	const IRWIN3
	const IRWIN4
	const MARCO
	const LEON
	const SILAS

	trainerclass BLACKBELT_T ; 32
	const KENJI1
	const YOSHI
	const KENJI2
	const LAO
	const NOB
	const KIYO
	const LUNG
	const KENJI3
	const WAI
	const DOJO_RIKU
	const DOJO_MASARU

	trainerclass EXECUTIVEM ; 33
	const EXECUTIVEM_1
	const EXECUTIVEM_2
	const EXECUTIVEM_3
	const EXECUTIVEM_4

	trainerclass PSYCHIC_T ; 34
	const NATHAN
	const FRANKLIN
	const HERMAN
	const FIDEL
	const GREG
	const NORMAN
	const MARK
	const PHIL
	const RICHARD
	const GILBERT
	const JARED
	const RODNEY

	trainerclass PICNICKER ; 35
	const LIZ1
	const GINA1
	const BROOKE
	const CINDY
	const GINA2
	const ERIN1
	const LIZ2
	const LIZ3
	const GINA3
	const TIFFANY1
	const TIFFANY2
	const ERIN2
	const TIFFANY3
	const ERIN3
	const LIZ4
	const LIZ5
	const GINA4
	const GINA5
	const TIFFANY4

	trainerclass CAMPER ; 36
	const ROLAND
	const TODD1
	const IVAN
	const ELLIOT
	const BARRY
	const LLOYD
	const DEAN
	const SID
	const TED
	const TODD2
	const TODD3
	const JERRY
	const SPENCER
	const TODD4
	const TODD5
	const QUENTIN

	trainerclass EXECUTIVEF ; 37
	const EXECUTIVEF_1
	const EXECUTIVEF_2

	trainerclass SAGE ; 38
	const CHOW
	const NICO
	const JIN
	const TROY
	const JEFFREY
	const PING
	const EDMOND
	const NEAL
	const GAKU
	const MASA
	const KOJI

	trainerclass MEDIUM ; 39
	const MARTHA
	const GRACE
	const BETHANY
	const REBECCA
	const DORIS

	trainerclass BOARDER ; 3a
	const RONALD
	const BRAD
	const DOUGLAS
	const BOARDER_AIDAN
	const BOARDER_NOEL
	const BOARDER_SPENCER

	trainerclass POKEFANM ; 3b
	const WILLIAM
	const DEREK1
	const ROBERT
	const JOSHUA
	const CARTER
	const TREVOR
	const BRANDON
	const JEREMY
	const COLIN
	const DEREK2
	const DEREK3
	const ALEX
	const REX
	const ALLAN
	const DUSTIN

	trainerclass KIMONO_GIRL ; 3c
	const NAOKO1
	const NAOKO2
	const SAYO
	const ZUKI
	const KUNI
	const MIKI
	const FUYU
	const HANA
	const YUMI

	trainerclass TWINS ; 3d
	const AMYANDMAY1
	const ANNANDANNE1
	const ANNANDANNE2
	const AMYANDMAY2
	const JOANDZOE1
	const JOANDZOE2
	const MEGANDPEG1
	const MEGANDPEG2
	const LEAANDPIA1
	const LEAANDPIA2

	trainerclass POKEFANF ; 3e
	const BEVERLY1
	const RUTH
	const BEVERLY2
	const BEVERLY3
	const GEORGIA
	const JAIME

	trainerclass RED ; 3f
	const RED1

	trainerclass BLUE ; 40
	const BLUE1

	trainerclass OFFICER ; 41
	const KEITH
	const DIRK
	const CELADON_HAYES

	trainerclass GRUNTF ; 42
	const GRUNTF_1
	const GRUNTF_2
	const GRUNTF_3
	const GRUNTF_4
	const GRUNTF_5
	const GRUNTF_6
	const GRUNTF_7
	const GRUNTF_8
	const GRUNTF_9
	const GRUNTF_10
	const GRUNTF_11
	const GRUNTF_12
	const GRUNTF_13
	const GRUNTF_14
	const GRUNTF_15
	const GRUNTF_GOLDENROD_RIOLU

	trainerclass MYSTICALMAN ; 43
	const EUSINE
	const EUSINE2

	trainerclass CRYSTAL ; 44
	const CRYSTAL_1_CHIKORITA
	const CRYSTAL_1_CYNDAQUIL
	const CRYSTAL_1_TOTODILE
	const CRYSTAL_2_CHIKORITA
	const CRYSTAL_2_CYNDAQUIL
	const CRYSTAL_2_TOTODILE
	const CRYSTAL_3_CHIKORITA
	const CRYSTAL_3_CYNDAQUIL
	const CRYSTAL_3_TOTODILE
	const CRYSTAL_4_CHIKORITA
	const CRYSTAL_4_CYNDAQUIL
	const CRYSTAL_4_TOTODILE
	const CRYSTAL_5_CHIKORITA
	const CRYSTAL_5_CYNDAQUIL
	const CRYSTAL_5_TOTODILE

	trainerclass CRYSTAL2 ; 45
; CRYSTAL2 shares CrystalGroup (see data/trainers/party_pointers.asm), so these
; are aliases into the same party list - only the class (pic/palette) differs.
CRYSTAL2_4_CHIKORITA EQU CRYSTAL_4_CHIKORITA
CRYSTAL2_4_CYNDAQUIL EQU CRYSTAL_4_CYNDAQUIL
CRYSTAL2_4_TOTODILE EQU CRYSTAL_4_TOTODILE
; CRYSTAL2's Route 25 battle moved to CRYSTAL3 (declared at the end of this
; file) so the two fights can carry different stat exp.

	trainerclass PROTON ; 46
	const PROTON1
	const PROTON2

	trainerclass PETREL ; 47
	const PETREL1

	trainerclass ARIANA ; 48
	const ARIANA1
	const ARIANA2

	trainerclass ARCHER ; 49
	const ARCHER1
	const ARCHER2

	trainerclass PETREL_DIRECTOR ; 4a
	const PETREL_DIRECTOR1

	trainerclass HEX_MANIAC ; 4b
	const WINNIE
	const ODESSA
	const LILITH

	trainerclass COSPLAYER ; 4c
	const COSPLAYER1
	const COSPLAYER2
	const COSPLAYER3
	const COSPLAYER4
	const COSPLAYER5
	const COSPLAYER6

	trainerclass NINJA ; 4d
	const NINJA1
	const NINJA2
	const NINJA3
	const NINJA4

	trainerclass AGATHA ; 4e
	const AGATHA1

	trainerclass LORELEI ; 4f
	const LORELEI1

	trainerclass RED2 ; 50
	const RED2_1

	trainerclass BLUE_CLOAK ; 51
	const BLUE_CLOAK1

	trainerclass GREEN ; 52
	const GREEN1

	trainerclass BATTLE_GIRL ; 53
	const BATTLE_GIRL1
	const BATTLE_GIRL2
	const KIRA
	const MINA

	trainerclass TAMER ; 54
	const TAMER1
	const TAMER2
	const TAMER3
	const DEVIN
	const ROLF

	trainerclass SCHOOL_GIRL ; 55
	const KIM
	const HOPE
	const SHARON
	const DEBRA
	const HEIDI
	const EDNA
	const TANYA
	const NADIA

	trainerclass CRYSTAL3
; Crystal's final battle, on Route 25 (Cerulean Cape). CRYSTAL3 shares
; CrystalGroup (see data/trainers/party_pointers.asm), so these are aliases
; into the same party list - only the class differs. Splitting it out of
; CRYSTAL2 lets the Lv66-70 fight carry its own stat exp without inflating the
; Lv45-48 Ice Path fight (see data/trainers/stat_exp.asm).
CRYSTAL3_CHIKORITA EQU CRYSTAL_5_CHIKORITA
CRYSTAL3_CYNDAQUIL EQU CRYSTAL_5_CYNDAQUIL
CRYSTAL3_TOTODILE EQU CRYSTAL_5_TOTODILE

	trainerclass RIVAL3
; Silver's final battle, at the Indigo Plateau Pokecenter. Shares Rival2Group
; the same way, split off from RIVAL2 so it can outrank CRYSTAL3 without
; buffing the Mt. Moon fight.
RIVAL3_CHIKORITA EQU RIVAL2_2_CHIKORITA
RIVAL3_CYNDAQUIL EQU RIVAL2_2_CYNDAQUIL
RIVAL3_TOTODILE EQU RIVAL2_2_TOTODILE

; --- Rematch classes ---------------------------------------------------------
; These share their base class's party group, so map scripts keep using the
; existing party-index constants (FALKNER2, WILL2, LANCE2, ...) and only the
; class changes. Splitting them out lets a rematch carry its own stat exp
; instead of inheriting the value tuned for the first fight, which left the
; Lv65-70 rematches far weaker than the Kanto gyms fought alongside them.
; Named _REMATCH rather than *2 because FALKNER2, WILL2 etc. are already taken
; by the party-index constants above.

	trainerclass FALKNER_REMATCH
; Rematch team for FALKNER (party index FALKNER2 in FalknerGroup).

	trainerclass BUGSY_REMATCH
; Rematch team for BUGSY (party index BUGSY2 in BugsyGroup).

	trainerclass WHITNEY_REMATCH
; Rematch team for WHITNEY (party index WHITNEY2 in WhitneyGroup).

	trainerclass MORTY_REMATCH
; Rematch team for MORTY (party index MORTY2 in MortyGroup).

	trainerclass CHUCK_REMATCH
; Rematch team for CHUCK (party index CHUCK2 in ChuckGroup).

	trainerclass JASMINE_REMATCH
; Rematch team for JASMINE (party index JASMINE2 in JasmineGroup).

	trainerclass PRYCE_REMATCH
; Rematch team for PRYCE (party index PRYCE2 in PryceGroup).

	trainerclass CLAIR_REMATCH
; Rematch team for CLAIR (party index CLAIR2 in ClairGroup).

	trainerclass WILL_REMATCH
; Rematch team for WILL (party index WILL2 in WillGroup).

	trainerclass KOGA_REMATCH
; Rematch team for KOGA (party index KOGA2 in KogaGroup).

	trainerclass BRUNO_REMATCH
; Rematch team for BRUNO (party index BRUNO2 in BrunoGroup).

	trainerclass KAREN_REMATCH
; Rematch team for KAREN (party index KAREN2 in KarenGroup).

	trainerclass CHAMPION_REMATCH
; Lance's rematch team (party index LANCE2 in ChampionGroup).

	trainerclass ELDER
; The Elder of Sprout Tower (3F), who gives out HM05 Flash.
	const LI

	trainerclass AROMA_LADY
; Herbalists at the Olivine Lighthouse and on Route 38.
	const ROSIE
	const DAHLIA
	const JUNIPER

	trainerclass CUEBALL
	const CHOPPER

	trainerclass KARATE_KING
	const KARATE_KIYO

	trainerclass SLOT_MANIAC
	const SLOT_MANIAC_LUCKY

	trainerclass HOSTESS
; Reserved class only; individual trainers and teams will be added later.

NUM_TRAINER_CLASSES EQU __enum__
