; item ids
; indexes for:
; - ItemNames (see data/items/names.asm)
; - ItemDescriptions (see data/items/descriptions.asm)
; - ItemAttributes (see data/items/attributes.asm)
; - ItemEffects (see engine/items/item_effects.asm)
	const_def
	const NO_ITEM      ; 00
	const MASTER_BALL  ; 01
	const ULTRA_BALL   ; 02
	const RETIRED_BRIGHTPOWDER ; $0003: reserved; never reuse saved IDs
	const GREAT_BALL   ; 04
	const POKE_BALL    ; 05
	const DUSK_STONE   ; 06; repurposes the unused TERU-SAMA item slot
	const BICYCLE      ; 07
	const MOON_STONE   ; 08
	const ANTIDOTE     ; 09
	const BURN_HEAL    ; 0a
	const ICE_HEAL     ; 0b
	const AWAKENING    ; 0c
	const PARLYZ_HEAL  ; 0d
	const FULL_RESTORE ; 0e
	const MAX_POTION   ; 0f
	const HYPER_POTION ; 10
	const SUPER_POTION ; 11
	const POTION       ; 12
	const ESCAPE_ROPE  ; 13
	const REPEL        ; 14
	const MAX_ELIXER   ; 15
	const FIRE_STONE   ; 16
	const THUNDERSTONE ; 17
	const WATER_STONE  ; 18
	const SKATEBOARD   ; 19
	const HP_UP        ; 1a
	const PROTEIN      ; 1b
	const IRON         ; 1c
	const CARBOS       ; 1d
	const LUCKY_PUNCH  ; 1e
	const CALCIUM      ; 1f
	const RARE_CANDY   ; 20
	const X_ACCURACY   ; 21
	const LEAF_STONE   ; 22
	const METAL_POWDER ; 23
	const NUGGET       ; 24
	const POKE_DOLL    ; 25
	const FULL_HEAL    ; 26
	const REVIVE       ; 27
	const MAX_REVIVE   ; 28
	const GUARD_SPEC   ; 29
	const SUPER_REPEL  ; 2a
	const MAX_REPEL    ; 2b
	const DIRE_HIT     ; 2c
	const TART_APPLE   ; 2d
	const FRESH_WATER  ; 2e
	const SODA_POP     ; 2f
	const LEMONADE     ; 30
	const X_ATTACK     ; 31
	const SWEET_APPLE  ; 32
	const X_DEFEND     ; 33
	const X_SPEED      ; 34
	const X_SPECIAL    ; 35
	const COIN_CASE    ; 36
	const ITEMFINDER   ; 37
	const HELIX_FOSSIL   ; 38
	const EXP_SHARE    ; 39
	const OLD_ROD      ; 3a
	const GOOD_ROD     ; 3b
	const DOME_FOSSIL  ; 3c
	const SUPER_ROD    ; 3d
	const PP_UP        ; 3e
	const ETHER        ; 3f
	const MAX_ETHER    ; 40
	const ELIXER       ; 41
	const RED_SCALE    ; 42
	const SECRETPOTION ; 43
	const S_S_TICKET   ; 44
	const MYSTERY_EGG  ; 45
	const CLEAR_BELL   ; 46
	const SILVER_WING  ; 47
	const MOOMOO_MILK  ; 48
	const QUICK_CLAW   ; 49
	const PSNCUREBERRY ; 4a
	const OLD_AMBER    ; 4b
	const SOFT_SAND    ; 4c
	const SHARP_BEAK   ; 4d
	const PRZCUREBERRY ; 4e
	const BURNT_BERRY  ; 4f
	const ICE_BERRY    ; 50
	const POISON_BARB  ; 51
	const KINGS_ROCK   ; 52
	const BITTER_BERRY ; 53
	const MINT_BERRY   ; 54
	const RED_APRICORN ; 55
	const PP_MAX       ; 56; replaces the sell-only TINYMUSHROOM slot
	const WISHING_STAR ; 57; replaces the sell-only BIG_MUSHROOM slot
	const SILVERPOWDER ; 58
	const BLU_APRICORN ; 59
	const ICE_STONE    ; 5a
	const AMULET_COIN  ; 5b
	const YLW_APRICORN ; 5c
	const GRN_APRICORN ; 5d
	const CLEANSE_TAG  ; 5e
	const MYSTIC_WATER ; 5f
	const TWISTEDSPOON ; 60
	const WHT_APRICORN ; 61
	const BLACKBELT    ; 62
	const BLK_APRICORN ; 63
	const SYRUPY_APPLE ; 64
	const PNK_APRICORN ; 65
	const BLACKGLASSES ; 66
	const SLOWPOKETAIL ; 67
	const PINK_BOW     ; 68
	const STICK        ; 69
	const SMOKE_BALL   ; 6a
	const NEVERMELTICE ; 6b
	const MAGNET       ; 6c
	const MIRACLEBERRY ; 6d
	const PEARL        ; 6e
	const STAR_SHARD   ; 6f; replaces BIG_PEARL with Gramps's meteorite keepsake
	const EVERSTONE    ; 70
	const SPELL_TAG    ; 71
	const RAGECANDYBAR ; 72
	const GS_BALL      ; 73
	const BLUE_CARD    ; 74
	const MIRACLE_SEED ; 75
	const THICK_CLUB   ; 76
	const FOCUS_BAND   ; 77
	const RELIC_CLOCK ; 78
	const ENERGYPOWDER ; 79
	const ENERGY_ROOT  ; 7a
	const HEAL_POWDER  ; 7b
	const REVIVAL_HERB ; 7c
	const HARD_STONE   ; 7d
	const LUCKY_EGG    ; 7e
	const CARD_KEY     ; 7f
	const MACHINE_PART ; 80
	const ROOT_FOSSIL   ; 81
	const LOST_ITEM    ; 82
	const STARDUST     ; 83
	const STAR_PIECE   ; 84
	const BASEMENT_KEY ; 85
	const PASS         ; 86
	const ABILITY_CAP  ; 87
	const LOADED_DICE  ; 88
	const CHOICE_BAND  ; 89
	const CHARCOAL     ; 8a
	const BERRY_JUICE  ; 8b
	const SCOPE_LENS   ; 8c
	const CHOICE_SPECS ; 8d
	const CHOICE_SCARF ; 8e
	const METAL_COAT   ; 8f
	const DRAGON_FANG  ; 90
	const EVIOLITE     ; 91
	const LEFTOVERS    ; 92
	const ASSAULT_VEST ; 93
	const FOCUS_SASH   ; 94
	const EXPERT_BELT  ; 95
	const MYSTERYBERRY ; 96
	const DRAGON_SCALE ; 97
	const BERSERK_GENE ; 98
	const ROCKY_HELMET ; 99
	const LIFE_ORB     ; 9a
	const WEAK_POLICY  ; 9b
	const SACRED_ASH   ; 9c
	const HEAVY_BALL   ; 9d
	const FLOWER_MAIL  ; 9e
	const LEVEL_BALL   ; 9f
	const LURE_BALL    ; a0
	const FAST_BALL    ; a1
	const AIR_BALLOON  ; a2
	const LIGHT_BALL   ; a3
	const FRIEND_BALL  ; a4
	const MOON_BALL    ; a5
	const LOVE_BALL    ; a6
	const CLAW_FOSSIL   ; a7
	const SKULL_FOSSIL ; a8
	const SUN_STONE    ; a9
	const WIDE_LENS    ; aa; replaces the duplicate Normal-boosting bow
	const MUSCLE_BAND  ; ab
	const UP_GRADE     ; ac
	const BERRY        ; ad
	const GOLD_BERRY   ; ae
	const SQUIRTBOTTLE ; af
	const WISE_GLASSES ; b0
	const PARK_BALL    ; b1
	const RAINBOW_WING ; b2
	const FLAME_ORB    ; b3
	const BRICK_PIECE  ; b4
	const ARMOR_FOSSIL    ; b5
	const COVER_FOSSIL ; b6
	const PLUME_FOSSIL ; b7
	const JAW_FOSSIL   ; b8
	const EON_MAIL     ; b9
	const DAMP_ROCK    ; ba
	const HEAT_ROCK    ; bb
	const SMOOTH_ROCK  ; bc
	const ICY_ROCK     ; bd
	const TOXIC_ORB    ; be
	const ELEMENTAL_SPHERE ; bf
	const SAFARI_BALL  ; c0
	const SAIL_FOSSIL      ; c1

add_tm: MACRO
if !DEF(TM01)
TM01 EQU const_value
	enum_start 1
endc
	define _\@_1, "TM_\1"
	const _\@_1
	enum \1_TMNUM
ENDM

; see data/moves/tmhm_moves.asm for moves
	add_tm DRAIN_PUNCH
	add_tm HEADBUTT     ; c3
	add_tm CURSE        ; c4
	add_tm ROCK_TOMB
	add_tm ROAR         ; c6
	add_tm TOXIC        ; c7
	add_tm ZAP_CANNON   ; c8
	add_tm ROCK_SMASH   ; c9
	add_tm DRAGON_PULSE
	add_tm HIDDEN_POWER ; cb
	add_tm SUNNY_DAY    ; cc
	add_tm SWEET_SCENT  ; cd
	add_tm WORK_UP
	add_tm BLIZZARD     ; cf
	add_tm HYPER_BEAM   ; d0
	add_tm ICICLE_CRASH
	add_tm PROTECT      ; d2
	add_tm RAIN_DANCE   ; d3
	add_tm ENERGY_BALL
	add_tm WILL_O_WISP
	add_tm FACADE
	add_tm SOLARBEAM    ; d7
	add_tm IRON_HEAD
	add_tm DRAGON_CLAW
	add_tm THUNDER      ; da
	add_tm EARTHQUAKE   ; db
	add_tm RETURN       ; dc
	add_tm DIG          ; dd
	add_tm PSYCHIC_M    ; de
	add_tm SHADOW_BALL  ; df
	add_tm MUD_SLAP     ; e0
	add_tm SWAGGER
	add_tm ICE_PUNCH    ; e2
	add_tm FLASH_CANNON
	add_tm KNOCK_OFF
	add_tm SLUDGE_BOMB  ; e5
	add_tm SANDSTORM    ; e6
	add_tm FIRE_BLAST   ; e7
	add_tm SWIFT        ; e8
	add_tm BULK_UP
	add_tm THUNDERPUNCH ; ea
	add_tm NASTY_PLOT
	add_tm DRAGON_DANCE
	add_tm REST         ; ed
	add_tm ATTRACT      ; ee
	add_tm THIEF        ; ef
	add_tm STEEL_WING   ; f0
	add_tm FIRE_PUNCH   ; f1
	add_tm FURY_CUTTER
	add_tm HONE_CLAWS
	add_tm NIGHT_SLASH
	add_tm ZEN_HEADBUTT
	add_tm POWER_GEM
	add_tm WEATHER_BALL
NUM_TMS EQU const_value - TM01

add_hm: MACRO
if !DEF(HM01)
HM01 EQU const_value
endc
	define _\@_1, "HM_\1"
	const _\@_1
	enum \1_TMNUM
ENDM

	add_hm CUT          ; f8
	add_hm FLY          ; f9
	add_hm SURF         ; fa
	add_hm STRENGTH     ; fb
	add_hm FLASH        ; fc
	add_hm WHIRLPOOL    ; fd
	add_hm WATERFALL    ; fe
NUM_HMS EQU const_value - HM01

add_mt: MACRO
	enum \1_TMNUM
ENDM

	add_mt FLAMETHROWER
	add_mt THUNDERBOLT
	add_mt ICE_BEAM
NUM_TM_HM_TUTOR EQU __enum__ + -1

USE_SCRIPT_VAR EQU $00
ITEM_FROM_MEM  EQU $ffff

; leftovers from red
MOON_STONE_RED EQU $0a ; BURN_HEAL
FULL_HEAL_RED  EQU $34 ; X_SPEED

; Expanded catalogue. Existing item indices remain stable.
	const_def $101
	const TINYMUSHROOM
	const BIG_MUSHROOM
	const BIG_PEARL
	const POLKADOT_BOW
	const SURF_MAIL
	const LITEBLUEMAIL
	const PORTRAITMAIL
	const LOVELY_MAIL
	const MORPH_MAIL
	const BLUESKY_MAIL
	const MUSIC_MAIL
	const MIRAGE_MAIL
	const SILVER_LEAF
	const GOLD_LEAF
	const NORMAL_BOX
	const GORGEOUS_BOX
	; Retired duplicate berries ($0111..$0117). Never reuse saved item IDs.
	const_def $118
	const RARE_BONE
	const BALM_MUSHROOM
	const COMET_SHARD
	const BIG_NUGGET
	const PEARL_STRING
	const COVERT_CLOAK
	const CLEAR_AMULET
	const METRONOME_ITEM
	const RETIRED_HEAVY_DUTY_BOOTS
	const RETIRED_RED_CARD
	const RETIRED_EJECT_BUTTON
	const POWER_HERB
	const WHITE_HERB
	const RETIRED_BLACK_SLUDGE
	const LIGHT_CLAY
	const THROAT_SPRAY
	const PUNCHING_GLOVE
	const QUICK_POWDER
	const SAFETY_GOGGLES
	const BIG_ROOT
	const RETIRED_BLUNDER_POLICY
	; $012d: retired duplicate HP Berry; resolves to GOLD_BERRY.
	const_def $12e
	const RETIRED_CUSTAP_BERRY
	const RETIRED_SALAC_BERRY
	const EXP_RELAY
NUM_ITEM_INDEXES EQU const_value - 1
	assert NUM_ITEM_INDEXES < $ff00
