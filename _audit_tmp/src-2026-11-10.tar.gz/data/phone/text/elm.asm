ElmPhoneStartText:
	text "Hello, <PLAY_G>?"

	para "Try not to overdo"
	line "it."

	para "Be sure to heal"
	line "your #MON if"
	cont "they are hurt."
	done

ElmPhoneSawMrPokemonText:
	text "Hello, <PLAY_G>?"

	para "Did you meet MR."
	line "#MON? Great!"
	cont "Come back safely!"
	done

ElmPhonePokemonStolenText:
	text "<PLAY_G>? I'm very"
	line "upset now."

	para "We had a #MON"
	line "stolen from here."

	para "How could anyone"
	line "do that?"
	done

ElmPhoneCheckingEggText:
	text "Hello, <PLAY_G>?"

	para "We're checking the"
	line "EGG now. It does"

	para "appear to be a"
	line "#MON EGG."
	done

ElmPhoneAssistantText:
	text "Hello, <PLAY_G>?"

	para "Did you see my"
	line "assistant? He's at"

	para "the #MON CENTER"
	line "in VIOLET CITY."
	done

ElmPhoneEggUnhatchedText:
	text "Hello, <PLAY_G>?"

	para "How's the EGG? Has"
	line "anything changed?"

	para "If anything hap-"
	line "pens, please call."
	done

ElmPhoneEggHatchedText:
	text "Hello, <PLAY_G>?"
	line "How is the EGG?"

	para "What? It hatched?"
	line "Wow! What kind of"
	cont "#MON is it?"

	para "Please come show"
	line "me now!"
	done

ElmPhoneDiscovery1Text:
	text "Hello, <PLAY_G>?"

	para "I just made a new"
	line "discovery."

	para "The time it takes"
	line "for an EGG to"

	para "hatch depends on"
	line "the #MON."
	done

ElmPhoneDiscovery2Text:
	text "Hello, <PLAY_G>?"

	para "It's still a"
	line "mystery what kinds"

	para "of moves hatched"
	line "#MON have."

	para "We're investigat-"
	line "ing that now."
	done

ElmPhonePokerusText:
	text "Hello, <PLAY_G>?"

	para "I discovered an"
	line "odd thing."

	para "Apparently there's"
	line "something called"

	para "#RUS that in-"
	line "fects #MON."

	para "Yes, it's like a"
	line "virus, so it's"
	cont "called #RUS."

	para "It multiplies fast"
	line "and infects other"

	para "#MON too. But"
	line "that's all."

	para "It doesn't seem to"
	line "do anything, and"

	para "it goes away over"
	line "time."

	para "I guess it's"
	line "nothing to worry"
	cont "about. Bye!"
	done

ElmPhoneDisasterText:
	text "H-hello? <PLAY_G>?"
	line "It's a disaster!"

	para "Uh, um, it's just"
	line "terrible!"

	para "What should I do?"
	line "It… Oh, no…"

	para "Please get back"
	line "here now!"
	done

ElmPhoneEggAssistantText:
	text "Hello, <PLAY_G>? We"
	line "discovered some-"

	para "thing about the"
	line "EGG!"

	para "My assistant is at"
	line "the #MON CENTER"

	para "in VIOLET CITY. "
	line "Could you talk to"
	cont "him?"
	done

ElmPhoneRocketText:
	text "<PLAY_G>, how are"
	line "things going?"

	para "I called because"
	line "something weird is"

	para "happening with the"
	line "radio broadcasts."

	para "They were talking"
	line "about TEAM ROCKET."

	para "<PLAY_G>, do you"
	line "know anything"
	cont "about it?"

	para "Maybe TEAM ROCKET"
	line "has returned. No,"

	para "that just can't"
	line "be true."

	para "Sorry to bug you."
	line "Take care!"
	done

ElmPhoneGiftText:
	text "Hello, <PLAY_G>?"

	para "I have something"
	line "here for you."

	para "Could you swing by"
	line "my LAB?"

	para "See you later!"
	done

ElmPhoneSSTicketText:
	text "Hello, <PLAY_G>!"

	para "I heard you've"
	line "been making some"
	cont "serious progress"
	cont "in KANTO."

	para "I have something"
	line "here for you."

	para "Come to my LAB in"
	line "NEW BARK TOWN."

	para "I've contacted the"
	line "S.S.AQUA crew and"
	cont "paid for your"
	cont "return passage."

	para "You can sail from"
	line "VERMILION to"
	cont "OLIVINE today."

	para "No TICKET needed"
	line "for this trip!"

	para "See you soon!"
	done

ElmPhoneReturnReminderText:
	text "Hello, <PLAY_G>!"

	para "Your gift is still"
	line "here at my LAB in"
	cont "NEW BARK TOWN."

	para "Come see me soon!"
	done

ElmPhoneExpRelayText:
	text "Hello, <PLAY_G>!"
	line "It's PROF.ELM!"

	para "I heard you earned"
	line "your sixth BADGE!"
	cont "Congratulations!"

	para "You and your team"
	line "have come so far"
	cont "since you left!"

	para "I've finished a"
	line "new invention, and"
	cont "I thought of you."

	para "Could you swing by"
	line "my LAB in NEW BARK"
	cont "TOWN?"

	para "I'd like you to"
	line "have it. I'll show"
	cont "you how it works!"

	para "See you soon!"
	done

ElmPhoneExpRelayReminderText:
	text "Hi, <PLAY_G>!"
	line "It's PROF.ELM!"

	para "Your EXP RELAY is"
	line "waiting at my LAB"
	cont "in NEW BARK TOWN."

	para "It passes training"
	line "from one #MON"
	cont "to another."

	para "Drop by when you"
	line "can! I'd love to"
	cont "hear how you're"
	cont "doing."
	done

ElmPhoneUnusedText:
	text "Hello, <PLAY_G>?"
	line "How's it going?"

	para "I got ahold of"
	line "something neat."

	para "Swing by my LAB"
	line "and pick it up!"

	para "See you later!"
	done
