; Valid sprite IDs for each map group.
; Maps with environment ROUTE or TOWN can only use these sprites.

OutdoorSprites:
; entries correspond to map groups
	dw OlivineGroupSprites
	dw MahoganyGroupSprites
	dw DungeonsGroupSprites
	dw EcruteakGroupSprites
	dw BlackthornGroupSprites
	dw CinnabarGroupSprites
	dw CeruleanGroupSprites
	dw AzaleaGroupSprites
	dw LakeOfRageGroupSprites
	dw VioletGroupSprites
	dw GoldenrodGroupSprites
	dw VermilionGroupSprites
	dw PalletGroupSprites
	dw PewterGroupSprites
	dw FastShipGroupSprites
	dw IndigoGroupSprites
	dw FuchsiaGroupSprites
	dw LavenderGroupSprites
	dw SilverGroupSprites
	dw CableClubGroupSprites
	dw CeladonGroupSprites
	dw CianwoodGroupSprites
	dw ViridianGroupSprites
	dw NewBarkGroupSprites
	dw SaffronGroupSprites
	dw CherrygroveGroupSprites

PalletGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_RED
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_TEACHER
	db SPRITE_FAT_GUY ; Pallet Town non-trainer NPC
	db SPRITE_YOUNGSTER
	db SPRITE_BLUE
	db SPRITE_GRAMPS
	db SPRITE_BUG_CATCHER
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_SWIMMER_GIRL
	db SPRITE_SWIMMER_GUY
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

ViridianGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_DRAGOON ; Viridian City battle; keep animated facings in bank 1
	db SPRITE_BIRD ; Viridian City battle
	db SPRITE_COOLTRAINER_M_NEW ; Viridian City battle
	db SPRITE_COOLTRAINER_F_NEW ; Viridian City battle
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_POKEFAN_M ; Route 2 blocker
	db SPRITE_FAT_GUY ; Viridian City non-trainer NPC
	db SPRITE_YOUNGSTER
	db SPRITE_BLUE
	db SPRITE_GRAMPS
	db SPRITE_BUG_CATCHER
	db SPRITE_FIREBREATHER_NEW
	db SPRITE_ZANGOOSE ; forest rivalry; replaces unused swimmer
	db SPRITE_SEVIPER ; forest rivalry; replaces unused swimmer
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

PewterGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_COSPLAYER ; was SPRITE_SILVER_TROPHY (unused filler) - for Route 3 Cosplayers
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_TEACHER
	db SPRITE_FISHER
	db SPRITE_YOUNGSTER
	db SPRITE_BLUE
	db SPRITE_GRAMPS
	db SPRITE_BUG_CATCHER
	db SPRITE_FIREBREATHER_NEW
	db SPRITE_COOLTRAINER_F
	db SPRITE_SWIMMER_GUY
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

CinnabarGroupSprites:
; VRAM budget notes (see ArrangeUsedSprites in engine/overworld/overworld.asm).
; This group used to
; pack VRAM bank 0 to
; exactly 128/128 - byte for byte the state CeruleanGroupSprites was in before
; it started rendering NPCs as the player.
; - NURSE and OLD_LINK_RECEPTIONIST removed: both are only used by Pokecenter
;   1F maps, which are indoor and load their own sprites via AddIndoorSprites.
;   Their slots now hold Route 19's three legendary bird icons.
; - Walkers reordered. Only Routes 19/20/21 and Cinnabar Island are outdoor in
;   this group, and their only NPCs are swimmers/fishers - which were dead last
;   in the list, so their step frames landed in bank 0's font-shared table.
;   Every swimmer here is SPRITEMOVEDATA_SPINRANDOM_FAST, i.e. animating
;   nonstop, so they were the worst possible occupants of that bank.
	db SPRITE_MOLTRES ; Route 19 Elemental Sphere cutscene
	db SPRITE_SWIMMER_GIRL ; Routes 19/20/21 trainers (spin constantly)
	db SPRITE_SWIMMER_GUY ; Routes 19/20/21 trainers (spin constantly)
	db SPRITE_FISHER ; Route 21 trainer
	db SPRITE_BLUE_CLOAK ; Cinnabar Island
	db SPRITE_GREEN ; Route 20
	db SPRITE_BLUE ; Cinnabar Island (spinner)
	db SPRITE_TEACHER
	db SPRITE_YOUNGSTER
	; --- walkers below here land in VRAM bank 0 (font-shared step frames) ---
	db SPRITE_FAT_GUY ; Route 19 non-trainer NPCs (was unused GRAMPS)
	db SPRITE_BUG_CATCHER
	db SPRITE_COOLTRAINER_F
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_POKEDEX
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE
	db SPRITE_ARTICUNO ; Route 19 Elemental Sphere cutscene
	db SPRITE_ZAPDOS ; Route 19 Elemental Sphere cutscene

CeruleanGroupSprites:
; - SPRITE_MEW and SPRITE_CRYSTAL (Route 25 cape) must stay in bank 1. MEW
;   wanders nonstop, while CRYSTAL is hidden when the overworld font reloads
;   and only appears afterward for her scripted walk. If CRYSTAL is in bank 0,
;   her hidden object misses ReloadBank0SpriteFacings and walks with font tiles.
;   SPRITE_SUICUNE and SPRITE_POKEDEX were dropped to make room: no outdoor map
;   in this group uses either one.
; VRAM budget notes (see ArrangeUsedSprites in engine/overworld/overworld.asm):
; - Walking sprites are packed FIRST-COME after the player into VRAM bank 1
;   (the player + 8 more walkers fit). Walkers that overflow into bank 0 have
;   their step frames in the region shared with the overworld font, so they can
;   flicker letters while stepping during textboxes/map-name signs.
; - Order walkers by how much they actually WALK on screen: the two Route 25
;   event sprites, Cerulean City wanderers, and animated Route 9 trainers first;
;   standing NPCs later.
; - NURSE and OLD_LINK_RECEPTIONIST were removed: indoor maps load their own
;   sprites (AddIndoorSprites) and no outdoor map in this group uses them.
;   Keeping them overflowed bank 0 and made NPCs render with player tiles.
; - PICNICKER_NEW removed too: no outdoor map in this group has a Picnicker
;   (Route 9 uses CAMPER_NEW/HIKER/JUGGLER_NEW/SCHOOL_GIRL). With it the group
;   had 19 walkers for 18 walker slots (player + 8 in bank 1, 10 in bank 0),
;   so the last walker in packing order got no VRAM and rendered with player
;   tiles - that was CRYSTAL appearing as the player on the Route 25 cape.
	db SPRITE_MEW ; Route 25 cape (wanders nonstop; must stay out of bank 0)
	db SPRITE_CRYSTAL ; Route 25 cape (appears after font reload; must be bank 1)
	db SPRITE_COOLTRAINER_M ; Cerulean City wanderer (also Route 25)
	db SPRITE_SUPER_NERD ; Cerulean City wanderer (also Route 25)
	db SPRITE_FAT_GUY ; Cerulean City non-trainer NPC
	db SPRITE_YOUNGSTER ; Cerulean City spinner
	db SPRITE_CAMPER_NEW ; Route 9 trainers
	db SPRITE_JUGGLER_NEW ; Route 9/25 trainers
	; --- walkers below here land in VRAM bank 0 (font-shared step frames) ---
	db SPRITE_SCHOOL_GIRL ; Route 9 spinner; keep before the font tile range
	db SPRITE_ROCKET ; Route 24 spinner; keep before the font tile range
	db SPRITE_HIKER ; Route 9 (visible at font reload; only walks when engaging)
	db SPRITE_COOLTRAINER_F ; Cerulean City (standing; never steps)
	db SPRITE_COSPLAYER ; Route 4/25
	db SPRITE_BIRD_KEEPER_NEW ; Route 4
	db SPRITE_LASS ; Route 25
	db SPRITE_COOLTRAINER_M_NEW ; Route 25
	db SPRITE_MISTY ; Route 25
	db SPRITE_POKEFAN_M ; Route 25
	db SPRITE_POKE_BALL
	db SPRITE_SLOWBRO_NPC
	db SPRITE_GAMBLER_ASLEEP ; Route 9's sleeping Rock Tunnel blocker
	db SPRITE_NONE ; free slot (was SPRITE_POKEDEX; unused by this group)
	db SPRITE_NONE ; free slot (was SPRITE_PICNICKER_NEW; no outdoor map in this group has one)

SaffronGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_HIKER
	db SPRITE_BIRD_KEEPER_NEW
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_PICNICKER_NEW
	db SPRITE_CAMPER_NEW
	db SPRITE_COOLTRAINER_M_NEW
	db SPRITE_SLOWBRO_NPC
	db SPRITE_COOLTRAINER_M
	db SPRITE_SUPER_NERD
	db SPRITE_COOLTRAINER_F
	db SPRITE_FAT_GUY ; Saffron City non-trainer NPC
	db SPRITE_YOUNGSTER
	db SPRITE_LASS
	db SPRITE_POKEFAN_M
	db SPRITE_ROCKET
	db SPRITE_MISTY
	db SPRITE_POKE_BALL
	db SPRITE_SLOWPOKE

CeladonGroupSprites:
	db SPRITE_BURGLAR ; Celadon glasses chase; replaces unused outdoor filler
	db SPRITE_BATTLE_GIRL ; was SPRITE_SILVER_TROPHY (unused filler) - for Route 7 Battle Girls
	db SPRITE_CUEBALL ; Route 16 gang; replaces unused outdoor filler
	db SPRITE_OFFICER ; Celadon glasses confrontation; replaces unused outdoor filler
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_FAT_GUY ; Celadon City non-trainer NPC
	db SPRITE_POLIWRATH_NPC
	db SPRITE_TEACHER
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_LASS
	db SPRITE_BIKER
	db SPRITE_SILVER
	db SPRITE_BLUE
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

LavenderGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_HIKER
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_POKEFAN_M
	db SPRITE_MACHOP
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_FISHER
	db SPRITE_TEACHER
	db SPRITE_SUPER_NERD
	db SPRITE_BIG_SNORLAX
	db SPRITE_BIKER
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

VermilionGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_COOLTRAINER_M_NEW ; CHANTZ in Vermilion City (was SPRITE_BIG_LAPRAS, unused in this group)
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_POKEFAN_M
	db SPRITE_MACHOP
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_FISHER
	db SPRITE_TEACHER
	db SPRITE_SUPER_NERD
	db SPRITE_PSYCHIC
	db SPRITE_BIKER
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

FuchsiaGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_TAMER ; was SPRITE_SILVER_TROPHY (unused filler) - for Route 18 Tamers
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_HIKER
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_POKEFAN_M
	db SPRITE_MACHOP
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_FISHER
	db SPRITE_BIRD_KEEPER_NEW
	db SPRITE_SUPER_NERD
	db SPRITE_BIKER
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE
	db SPRITE_TEACHER

IndigoGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_POKEFAN_M
	db SPRITE_BUENA
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_FISHER
	db SPRITE_COOLTRAINER_M_NEW
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_BIRD_KEEPER_NEW
	db SPRITE_BIKER
	db SPRITE_POKE_BALL
	db SPRITE_BOULDER

NewBarkGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_PSYCHIC
	db SPRITE_FAT_GUY ; non-trainer NPCs (was indoor-only NURSE)
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_SILVER
	db SPRITE_TEACHER
	db SPRITE_FISHER
	db SPRITE_COOLTRAINER_M
	db SPRITE_YOUNGSTER
	db SPRITE_COOLTRAINER_M_NEW
	db SPRITE_GRAMPS
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_BIRD_KEEPER_NEW
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

CherrygroveGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_WIMPOD ; Route 31 (indoor nurses load their own graphics)
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_PIDGEY
	db SPRITE_SILVER
	db SPRITE_TEACHER
	db SPRITE_FAT_GUY ; Cherrygrove/Route 31 non-trainer NPCs
	db SPRITE_COOLTRAINER_M
	db SPRITE_YOUNGSTER
	db SPRITE_RATTATA_UP
	db SPRITE_GRAMPS
	db SPRITE_BUG_CATCHER
	db SPRITE_COOLTRAINER_F
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

SilverGroupSprites:
; VRAM budget notes (see ArrangeUsedSprites in engine/overworld/overworld.asm).
; Like
; CinnabarGroupSprites, this group used
; to pack VRAM bank 0 to exactly 128/128 - the pre-fix Cerulean state.
; - NURSE and OLD_LINK_RECEPTIONIST removed: both are only used by Pokecenter
;   1F maps, which are indoor and load their own sprites via AddIndoorSprites.
;   Frees 24 tiles, so bank 0 now sits at 104/128.
; - No reorder needed: Route 28 has no object events and Silver Cave Outside
;   only uses AGATHA and LORELEI, which are already first among the walkers and
;   so keep VRAM bank 1. (Both are SPRITEMOVEDATA_STANDING_DOWN anyway.)
	db SPRITE_SUICUNE
	db SPRITE_AGATHA ; Silver Cave Outside
	db SPRITE_LORELEI ; Silver Cave Outside
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NONE ; free slot (was SPRITE_NURSE; indoor maps self-load)
	db SPRITE_NONE ; free slot (was SPRITE_OLD_LINK_RECEPTIONIST)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_SILVER
	db SPRITE_TEACHER
	db SPRITE_FISHER
	db SPRITE_COOLTRAINER_M
	db SPRITE_YOUNGSTER
	db SPRITE_MONSTER
	db SPRITE_GRAMPS
	db SPRITE_BUG_CATCHER
	db SPRITE_COOLTRAINER_F
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

VioletGroupSprites:
	db SPRITE_ENTEI_NPC
	db SPRITE_YOUNGSTER
	db SPRITE_COOLTRAINER_M
	db SPRITE_BUG_CATCHER
	db SPRITE_NONE ; freed: Violet City's generic NPC reuses COOLTRAINER_M
	db SPRITE_GRAMPS
	db SPRITE_CRYSTAL
	db SPRITE_SCHOOL_GIRL ; Route 35
	db SPRITE_PSYCHIC
	db SPRITE_APRICORN ; Route 37 apricorns (stationary, fits bank 1's still-sprite tail)
	db SPRITE_FIREBREATHER_NEW ; Route 35 spinner; keep in VRAM bank 1
	db SPRITE_JUGGLER_NEW ; Route 35 spinner; keep below the font tile range
	db SPRITE_FAT_GUY ; non-trainer NPCs (was unused BIG_SNORLAX)
	db SPRITE_FISHER
	db SPRITE_LASS
	db SPRITE_CAMPER_NEW
	db SPRITE_PICNICKER_NEW
	db SPRITE_BIRD_KEEPER_NEW
	; Stationary sprites can safely occupy the font-shared tail of bank 0.
	db SPRITE_OFFICER
	db SPRITE_TWIN
	db SPRITE_WEIRD_TREE
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

EcruteakGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_JIRACHI ; wishing well; replaces unused outdoor console
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_MYSTICALMAN ; Ecruteak City Eusine event (was unused outdoor NURSE)
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_FAT_GUY ; Ecruteak City non-trainer NPC
	db SPRITE_LASS
	db SPRITE_OFFICER
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_GRANNY ; wishing well; replaces unused outdoor COOLTRAINER_M
	db SPRITE_BUG_CATCHER
	db SPRITE_SUPER_NERD
	db SPRITE_WEIRD_TREE
	db SPRITE_POKE_BALL
	db SPRITE_FRUIT_TREE

AzaleaGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_APRICORN ; Azalea Town apricorn (was unused SILVER_TROPHY filler)
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_HIKER
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_KURT
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_OFFICER
	db SPRITE_POKEFAN_M
	db SPRITE_BLACK_BELT
	db SPRITE_TEACHER
	db SPRITE_AZALEA_ROCKET
	db SPRITE_LASS
	db SPRITE_SILVER
	db SPRITE_FRUIT_TREE
	db SPRITE_SLOWPOKE

GoldenrodGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_DAY_CARE_MON_1
	db SPRITE_POKE_BALL
	db SPRITE_DAY_CARE_MON_2
	db SPRITE_COOLTRAINER_F
	db SPRITE_NONE
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_OFFICER
	db SPRITE_POKEFAN_M
	db SPRITE_CAMPER_NEW
	db SPRITE_PICNICKER_NEW
	db SPRITE_ROCKET
	db SPRITE_LASS
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_FRUIT_TREE
	db SPRITE_SLOWPOKE

CianwoodGroupSprites:
; VRAM budget notes (see ArrangeUsedSprites in engine/overworld/overworld.asm).
; Only four maps in this group are outdoor (ROUTE/TOWN) and so use this list:
; Route 40, Route 41, Cianwood City, Battle Tower Outside. Everything else in
; the group is INDOOR/CAVE/GATE and self-loads via AddIndoorSprites - including
; Shiver Isle, which pulls SKIER_NEW/SNOWBOARDER_NEW without being listed here.
; Nine entries are free slots for those four maps and remain SPRITE_NONE,
; taking bank 0 from 116/128 down to 24/128.
; SPRITE_FINIZEN (Route 41 Sunday event) was added in ENTEI's old slot so it
; lands in bank 1 - it spins nonstop while it is on screen. ENTEI moved below
; the bank-1 cutoff instead; its Cianwood City cameo is a short scripted beat.
; Bank 0 sits at 48/128; Gramps still fits in bank 1 with 8 tiles free.
	db SPRITE_NONE ; free slot (was SPRITE_SUICUNE; the Cianwood City beast cameo uses SPRITE_ENTEI)
	db SPRITE_NONE ; free slot (was SPRITE_SILVER_TROPHY; player's-room decor, indoor only)
	db SPRITE_NONE ; free slot (was SPRITE_FAMICOM; player's-room decor, indoor only)
	db SPRITE_NONE ; free slot (was SPRITE_POKEDEX; player's-room decor, indoor only)
	db SPRITE_NONE ; free slot (was SPRITE_WILL; unused by any map in this group)
	db SPRITE_NONE ; free slot (was SPRITE_KAREN; unused by any map in this group)
	db SPRITE_NONE ; free slot (was SPRITE_NURSE; Cianwood Pokecenter 1F is indoor, self-loads)
	db SPRITE_STANDING_YOUNGSTER ; Cianwood City, Route 40, Battle Tower Outside
	db SPRITE_NONE ; free slot (was SPRITE_BIG_ONIX; not on any outdoor map in this group)
	db SPRITE_ROCK ; Cianwood City, Route 40 smashable rocks (still sprite; sorts last regardless of slot)
	db SPRITE_NONE ; free slot (was SPRITE_BIG_SNORLAX; not on any outdoor map in this group)
	db SPRITE_OLIVINE_RIVAL ; Route 40/41 swimmer trainers
	db SPRITE_POKEFAN_M ; Cianwood City walker, Route 40
	db SPRITE_LASS ; Cianwood City walker, Route 40, Battle Tower Outside
	db SPRITE_BUENA ; Route 40 (Monica), Battle Tower Outside (wanders)
	db SPRITE_SWIMMER_GIRL ; Route 40/41 trainers
	db SPRITE_FINIZEN ; Route 41 Sunday event (spins nonstop; must stay out of bank 0)
	db SPRITE_SAILOR ; Battle Tower Outside walker
	db SPRITE_POKEFAN_F ; Cianwood City walker (Chuck's wife)
	db SPRITE_MYSTICALMAN ; Cianwood City (Eusine; standing)
	db SPRITE_CRYSTAL_SURF ; Cianwood City (standing)
	db SPRITE_GRAMPS ; Cianwood City Weather Ball giver (standing; after active walkers)
	; --- walkers below here land in VRAM bank 0 (font-shared step frames) ---
	db SPRITE_ENTEI ; Cianwood City beast cameo (brief scripted appearance)

OlivineGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_POKE_BALL ; Route 38 Soft Sand; replaces unused outdoor filler
	db SPRITE_POKEDEX
	db SPRITE_JASMINE ; lighthouse medicine encounter (replaces unused Will)
	db SPRITE_PSYCHIC
	db SPRITE_AROMA_LADY ; Route 38 trainer (replaces NURSE; Pokecenter 1F is indoor, self-loads)
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_STANDING_YOUNGSTER
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_FISHING_BOAT ; cove boats replace an unused outdoor sprite
	db SPRITE_OLIVINE_RIVAL
	db SPRITE_POKEFAN_M
	db SPRITE_LASS
	db SPRITE_BUENA
	db SPRITE_MILTANK
	db SPRITE_SWIMMER_GUY
	db SPRITE_SAILOR
	db SPRITE_POKEFAN_F
	db SPRITE_BIRD_KEEPER_NEW
	db SPRITE_FRUIT_TREE
	db SPRITE_ROCK

LakeOfRageGroupSprites:
	db SPRITE_RAIKOU ; was SPRITE_SUICUNE (roaming cameo, no longer used here)
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_SUPER_NERD
	db SPRITE_COOLTRAINER_F
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_LANCE
	db SPRITE_GRAMPS
	db SPRITE_POKEMANIAC_NEW
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_FISHER
	db SPRITE_COOLTRAINER_M_NEW
	db SPRITE_PICNICKER_NEW
	db SPRITE_CAMPER_NEW
	db SPRITE_GYARADOS
	db SPRITE_FRUIT_TREE
	db SPRITE_POKE_BALL

MahoganyGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_APRICORN ; Route 42 apricorns (was unused SILVER_TROPHY filler)
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_SKIER_NEW ; was SPRITE_WILL (unused filler) - for Route 44 Skier
	db SPRITE_HIKER
	db SPRITE_FAT_GUY ; non-trainer NPCs (was indoor-only NURSE)
	db SPRITE_SNOWBOARDER_NEW ; was SPRITE_OLD_LINK_RECEPTIONIST (unused filler) - for Route 44 Boarder
	db SPRITE_ENTEI
	db SPRITE_LANCE
	db SPRITE_SUDOWOODO
	db SPRITE_DRAGON
	db SPRITE_GRAMPS
	db SPRITE_PSYCHIC
	db SPRITE_LASS
	db SPRITE_POKEMANIAC_NEW
	db SPRITE_BIRD_KEEPER_NEW
	db SPRITE_POKEFAN_M
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_COOLTRAINER_M_NEW
	db SPRITE_FISHER
	db SPRITE_FRUIT_TREE
	db SPRITE_POKE_BALL

BlackthornGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_HIKER
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_COOLTRAINER_F
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_GRAMPS
	db SPRITE_YOUNGSTER
	db SPRITE_BLACK_BELT
	db SPRITE_CAMPER_NEW
	db SPRITE_COOLTRAINER_M_NEW
	db SPRITE_POKEFAN_M
	db SPRITE_PICNICKER_NEW
	db SPRITE_COOLTRAINER_F_NEW
	db SPRITE_SUPER_NERD
	db SPRITE_FRUIT_TREE
	db SPRITE_POKE_BALL

DungeonsGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_SILVER_TROPHY
	db SPRITE_FAMICOM
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_PSYCHIC
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_GAMEBOY_KID
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_LASS
	db SPRITE_POKEFAN_F
	db SPRITE_TEACHER
	db SPRITE_YOUNGSTER
	db SPRITE_PERSIAN
	db SPRITE_POKEFAN_M
	db SPRITE_ROCKER
	db SPRITE_FAT_GUY ; Ruins of Alph non-trainer NPC
	db SPRITE_SCIENTIST
	db SPRITE_POKE_BALL
	db SPRITE_BOULDER

FastShipGroupSprites:
	db SPRITE_SUICUNE
	db SPRITE_MACHAMP ; Olivine Port; replaces unused trophy graphics
	db SPRITE_FOSSIL ; Mt. Moon crater; replaces unused outdoor console
	db SPRITE_POKEDEX
	db SPRITE_WILL
	db SPRITE_KAREN
	db SPRITE_NURSE
	db SPRITE_NONE ; free slot (old link receptionist was unused filler)
	db SPRITE_BIG_LAPRAS
	db SPRITE_BIG_ONIX
	db SPRITE_SUDOWOODO
	db SPRITE_BIG_SNORLAX
	db SPRITE_SAILOR
	db SPRITE_FISHING_GURU
	db SPRITE_GENTLEMAN
	db SPRITE_SUPER_NERD
	db SPRITE_HO_OH
	db SPRITE_TEACHER
	db SPRITE_COOLTRAINER_F
	db SPRITE_YOUNGSTER
	db SPRITE_FAIRY
	db SPRITE_POKE_BALL
	db SPRITE_ROCK

CableClubGroupSprites:
	db SPRITE_OAK
	db SPRITE_FISHER
	db SPRITE_TEACHER
	db SPRITE_TWIN
	db SPRITE_POKEFAN_M
	db SPRITE_GRAMPS
	db SPRITE_FAIRY
	db SPRITE_SILVER
	db SPRITE_FISHING_GURU
	db SPRITE_POKE_BALL
	db SPRITE_POKEDEX
