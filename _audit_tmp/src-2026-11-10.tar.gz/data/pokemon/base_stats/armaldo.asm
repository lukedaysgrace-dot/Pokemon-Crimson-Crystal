	db 0 ; species ID placeholder

	db  75, 125, 100,  50,  70,  80
	;  hp  atk  def  spd  sat  sdf

	db ROCK, BUG ; type
	db 45 ; catch rate
	db 173 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F12_5 ; gender ratio
	db 100 ; unknown 1
	db 30 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/armaldo/front.dimensions"
	abilities_for ARMALDO, BATTLE_ARMOR, SWIFT_SWIM, TOUGH_CLAWS
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_WATER_3, EGG_WATER_3 ; egg groups

	; tm/hm learnset
	tmhm CURSE, ROCK_TOMB, TOXIC, ROCK_SMASH, HIDDEN_POWER, HYPER_BEAM, PROTECT, FACADE, EARTHQUAKE, RETURN, DIG, SWAGGER, FLASH_CANNON, KNOCK_OFF, SANDSTORM, REST, ATTRACT, FURY_CUTTER, HONE_CLAWS, POWER_GEM, STRENGTH, CUT, HEADBUTT, MUD_SLAP, SUNNY_DAY
	; end
