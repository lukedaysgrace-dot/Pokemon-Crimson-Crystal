	db 0 ; species ID placeholder

	db  40,  50,  40,  35,  50,  40
	;  hp  atk  def  spd  sat  sdf

	db FIRE, FIRE ; type
	db 90 ; catch rate
	db 51 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 35 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/charcadet/front.dimensions"
	abilities_for CHARCADET, FLASH_FIRE, NO_ABILITY, FLAME_BODY
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm SUNNY_DAY, PROTECT, WILL_O_WISP, FACADE, FIRE_BLAST, REST, FLAMETHROWER
	; end
