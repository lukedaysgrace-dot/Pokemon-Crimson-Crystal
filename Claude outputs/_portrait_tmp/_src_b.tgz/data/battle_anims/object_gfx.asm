anim_obj_gfx: MACRO
; # tiles, label
	db \1
	dba \2
ENDM

AnimObjGFX:
; entries correspond to ANIM_GFX_* constants
	anim_obj_gfx  0, AnimObj00GFX
	anim_obj_gfx 35, AnimObjHitGFX
	anim_obj_gfx  7, AnimObjCutGFX
	anim_obj_gfx  6, AnimObjFireGFX
	anim_obj_gfx 20, AnimObjWaterGFX
	anim_obj_gfx 26, AnimObjLightningGFX
	anim_obj_gfx 18, AnimObjPlantGFX
	anim_obj_gfx 12, AnimObjSmokeGFX
	anim_obj_gfx  9, AnimObjExplosionGFX
	anim_obj_gfx 19, AnimObjRocksGFX
	anim_obj_gfx  6, AnimObjIceGFX
	anim_obj_gfx 10, AnimObjPokeBallGFX
	anim_obj_gfx 19, AnimObjPoisonGFX
	anim_obj_gfx 14, AnimObjBubbleGFX
	anim_obj_gfx 16, AnimObjNoiseGFX
	anim_obj_gfx  2, AnimObjPowderGFX
	anim_obj_gfx 11, AnimObjBeamGFX
	anim_obj_gfx  9, AnimObjSpeedGFX
	anim_obj_gfx 10, AnimObjChargeGFX
	anim_obj_gfx 21, AnimObjWindGFX
	anim_obj_gfx 10, AnimObjWhipGFX
	anim_obj_gfx 12, AnimObjEggGFX
	anim_obj_gfx 18, AnimObjRopeGFX
	anim_obj_gfx 14, AnimObjPsychicGFX
	anim_obj_gfx 10, AnimObjReflectGFX
	anim_obj_gfx 31, AnimObjStatusGFX ; +4 Torment tiles (pokeorange)
	anim_obj_gfx 12, AnimObjSandGFX
	anim_obj_gfx 14, AnimObjWebGFX
	anim_obj_gfx 16, AnimObjHazeGFX
	anim_obj_gfx 11, AnimObjHornGFX
	anim_obj_gfx  8, AnimObjFlowerGFX
	anim_obj_gfx 40, AnimObjMiscGFX
	anim_obj_gfx 36, AnimObjSkyAttackGFX
	anim_obj_gfx 16, AnimObjGlobeGFX
	anim_obj_gfx 48, AnimObjShapesGFX
	anim_obj_gfx 21, AnimObjObjectsGFX
	anim_obj_gfx 38, AnimObjShineGFX
	anim_obj_gfx 35, AnimObjAngelsGFX
	anim_obj_gfx 18, AnimObjWaveGFX
	anim_obj_gfx 24, AnimObjAeroblastGFX
	anim_obj_gfx  1, NULL
	anim_obj_gfx  1, NULL
	anim_obj_gfx  2, AnimObjStatsGFX
	anim_obj_gfx 16, AnimObjAuraSphereGFX
	anim_obj_gfx 13, AnimObjBigGlowClearGFX
	anim_obj_gfx 13, AnimObjBigRingsGFX
	anim_obj_gfx 18, AnimObjBigWhipGFX
	anim_obj_gfx 18, AnimObjBulkUpGFX
	anim_obj_gfx 10, AnimObjEnergyBallGFX
	anim_obj_gfx 18, AnimObjFocusBlastGFX
	anim_obj_gfx 10, AnimObjGlowGFX
	anim_obj_gfx 55, AnimObjGyroBallGFX
	anim_obj_gfx  9, AnimObjHit2GFX
	anim_obj_gfx 18, AnimObjHurricaneGFX
	anim_obj_gfx  5, AnimObjMisc2GFX
	anim_obj_gfx 16, AnimObjPsystrikeGFX
	anim_obj_gfx  6, AnimObjRingsGFX
	anim_obj_gfx  9, AnimObjSmokePuffGFX
	anim_obj_gfx  7, AnimObjStarsGFX ; +2 Yawn drowziness tiles (pokeorange)
	anim_obj_gfx 24, AnimObjSwirlGFX
	anim_obj_gfx 14, AnimObjTrickRoomGFX
	anim_obj_gfx 28, AnimObjVoltSwitchGFX
	anim_obj_gfx 32, AnimObjVortexGFX
	anim_obj_gfx  4, AnimObjWindBGGFX
	anim_obj_gfx 48, AnimObjUTurnGFX
	anim_obj_gfx  5, AnimObjHeartsGFX
; polishedcrystal ports (batch 2)
	anim_obj_gfx 28, AnimObjAquaJetGFX
	anim_obj_gfx  9, AnimObjBugBuzzGFX
	anim_obj_gfx 10, AnimObjGlowShadowGFX
	anim_obj_gfx  6, AnimObjIcicleCrashGFX
	anim_obj_gfx  9, AnimObjMidGlowClearGFX
	anim_obj_gfx 16, AnimObjMoonGFX
	anim_obj_gfx 18, AnimObjMushroomGFX
	anim_obj_gfx 22, AnimObjObjects2GFX
	anim_obj_gfx  4, AnimObjPetalsGFX
	anim_obj_gfx  9, AnimObjTearGFX
	anim_obj_gfx 12, AnimObjTriangleGFX
	anim_obj_gfx 12, AnimObjWaterBallGFX
	anim_obj_gfx 10, AnimObjBeamAuroraGFX
	anim_obj_gfx 10, AnimObjBeamSolarGFX
	anim_obj_gfx 13, AnimObjMeteorGFX
	anim_obj_gfx  6, AnimObjRockPolishGFX
	anim_obj_gfx 10, AnimObjBigGlowSpikedGFX
; ported from polishedcoral
	anim_obj_gfx  8, AnimObjLuminaCrashGFX
	anim_obj_gfx  8, AnimObjTauntGFX ; ported from pokeorange
	anim_obj_gfx 16, AnimObjWeatherBallGFX ; ported from mae-pokeorange
