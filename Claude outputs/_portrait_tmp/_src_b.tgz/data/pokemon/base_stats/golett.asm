	db 0 ; species ID placeholder

	db  59,  74,  50,  40,  40,  40
	;  hp  atk  def  spd  sat  sdf

	db GROUND, GHOST ; type
	db 190 ; catch rate
	db 61 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_UNKNOWN ; gender ratio
	db 100 ; unknown 1
	db 25 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/golett/front.dimensions"
	abilities_for GOLETT, IRON_FIST, KLUTZ, NO_GUARD
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_MINERAL, EGG_MINERAL ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, CURSE, ROCK_TOMB, TOXIC, HIDDEN_POWER, PROTECT, WILL_O_WISP, FACADE, EARTHQUAKE, RETURN, DIG, SHADOW_BALL, MUD_SLAP, SWAGGER, ICE_PUNCH, KNOCK_OFF, SANDSTORM, THUNDERPUNCH, REST, FIRE_PUNCH
	; end
