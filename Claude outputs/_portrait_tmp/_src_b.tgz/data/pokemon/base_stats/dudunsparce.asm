	db 0 ; species ID placeholder

	db 125, 110,  85,  55,  85,  80
	;  hp  atk  def  spd  sat  sdf

	db NORMAL, DRAGON ; type
	db 45 ; catch rate
	db 182 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/dudunsparce/front.dimensions"
	abilities_for DUDUNSPARCE, SERENE_GRACE, RATTLED, RUN_AWAY
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, ROCK_TOMB, TOXIC, ZAP_CANNON, ROCK_SMASH, DRAGON_PULSE, HIDDEN_POWER, SUNNY_DAY, WORK_UP, HYPER_BEAM, PROTECT, RAIN_DANCE, FACADE, SOLARBEAM, IRON_HEAD, DRAGON_CLAW, THUNDER, RETURN, DIG, MUD_SLAP, SWAGGER, SWIFT, REST, ATTRACT, THIEF, ZEN_HEADBUTT, STRENGTH, FLAMETHROWER, THUNDERBOLT
	; end
