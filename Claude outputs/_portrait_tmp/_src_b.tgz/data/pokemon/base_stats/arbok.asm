	db 0 ; species ID placeholder

	db  60, 110,  70,  80,  55,  80
	;   hp  atk  def  spd  sat  sdf

	db POISON, DARK ; type
	db 90 ; catch rate
	db 157 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/arbok/front.dimensions"
	abilities_for ARBOK, INTIMIDATE, SHED_SKIN, MERCILESS
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_DRAGON ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, ENERGY_BALL, FACADE, EARTHQUAKE, RETURN, DIG, SWAGGER, KNOCK_OFF, SLUDGE_BOMB, REST, ATTRACT, THIEF, STRENGTH
	; end
