	db 0 ; species ID placeholder

	db 108,  68,  45,  43,  30,  40
	;  hp  atk  def  spd  sat  sdf

	db ICE, ICE ; type
	db 150 ; catch rate
	db 67 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 25 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/cetoddle/front.dimensions"
	abilities_for CETODDLE, THICK_FAT, SNOW_CLOAK, SHEER_FORCE
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, WORK_UP, BLIZZARD, ICICLE_CRASH, PROTECT, RAIN_DANCE, FACADE, EARTHQUAKE, RETURN, SWAGGER, KNOCK_OFF, REST, ATTRACT, SURF, STRENGTH, ICE_BEAM
	; end
