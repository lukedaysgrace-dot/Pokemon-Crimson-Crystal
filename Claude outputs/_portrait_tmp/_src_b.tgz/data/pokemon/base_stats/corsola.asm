	db 0 ; species ID placeholder

	db  65,  45, 115,  35,  90, 115
	;   hp  atk  def  spd  sat  sdf

	db WATER, ROCK ; type
	db 60 ; catch rate
	db 144 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F75 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/corsola/front.dimensions"
	abilities_for CORSOLA, HUSTLE, NATURAL_CURE, REGENERATOR
	db 0 ; padding
	db GROWTH_FAST ; growth rate
	dn EGG_WATER_1, EGG_WATER_3 ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, ROCK_TOMB, TOXIC, ROCK_SMASH, HIDDEN_POWER, SUNNY_DAY, PROTECT, RAIN_DANCE, FACADE, EARTHQUAKE, RETURN, PSYCHIC_M, MUD_SLAP, SWAGGER, SANDSTORM, REST, ATTRACT, POWER_GEM, SURF, STRENGTH, WHIRLPOOL, ICE_BEAM
	; end
