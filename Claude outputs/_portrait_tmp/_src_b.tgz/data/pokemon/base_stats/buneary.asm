	db 0 ; species ID placeholder

	db  55,  66,  44,  85,  44,  56
	;  hp  atk  def  spd  sat  sdf

	db NORMAL, NORMAL ; type
	db 190 ; catch rate
	db 70 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/buneary/front.dimensions"
	abilities_for BUNEARY, RUN_AWAY, KLUTZ, LIMBER
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, WORK_UP, PROTECT, FACADE, RETURN, SWAGGER, ICE_PUNCH, SWIFT, THUNDERPUNCH, REST, ATTRACT, FIRE_PUNCH
	; end
