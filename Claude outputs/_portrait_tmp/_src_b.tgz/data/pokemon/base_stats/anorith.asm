	db 0 ; species ID placeholder

	db  45,  95,  50,  75,  40,  50
	;  hp  atk  def  spd  sat  sdf

	db ROCK, BUG ; type
	db 45 ; catch rate
	db 71 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F12_5 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/anorith/front.dimensions"
	abilities_for ANORITH, BATTLE_ARMOR, SWIFT_SWIM, TOUGH_CLAWS
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_WATER_3, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm CURSE, ROCK_TOMB, TOXIC, ROCK_SMASH, HIDDEN_POWER, PROTECT, FACADE, EARTHQUAKE, RETURN, DIG, SWAGGER, KNOCK_OFF, SANDSTORM, REST, ATTRACT, FURY_CUTTER, HONE_CLAWS, POWER_GEM, STRENGTH
	; end
