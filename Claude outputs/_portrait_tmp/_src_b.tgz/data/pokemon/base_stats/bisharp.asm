	db 0 ; species ID placeholder

	db  65, 125, 100,  70,  60,  70
	;  hp  atk  def  spd  sat  sdf

	db DARK, STEEL ; type
	db 45 ; catch rate
	db 172 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/bisharp/front.dimensions"
	abilities_for BISHARP, DEFIANT, INNER_FOCUS, SHARPNESS
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, PROTECT, FACADE, IRON_HEAD, RETURN, DIG, SWAGGER, FLASH_CANNON, KNOCK_OFF, REST, ATTRACT, THIEF, HONE_CLAWS, NIGHT_SLASH, CUT, STRENGTH
	; end
