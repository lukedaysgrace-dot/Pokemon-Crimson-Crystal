	db 0 ; species ID placeholder

	db  65, 106,  84, 105,  44,  96
	;  hp  atk  def  spd  sat  sdf

	db NORMAL, FIGHTING ; type
	db 60 ; catch rate
	db 168 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/lopunny/front.dimensions"
	abilities_for LOPUNNY, SCRAPPY, CUTE_CHARM, ADAPTABILITY
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, HEADBUTT, CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, WORK_UP, HYPER_BEAM, PROTECT, FACADE, RETURN, SWAGGER, ICE_PUNCH, SWIFT, BULK_UP, THUNDERPUNCH, REST, ATTRACT, FIRE_PUNCH, STRENGTH
	; end
