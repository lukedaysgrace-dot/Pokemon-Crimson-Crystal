	db 0 ; species ID placeholder

	db  55,  85,  55,  60,  50,  55
	;  hp  atk  def  spd  sat  sdf

	db BUG, FIRE ; type
	db 45 ; catch rate
	db 72 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/larvesta/front.dimensions"
	abilities_for LARVESTA, FLAME_BODY, NO_ABILITY, SWARM
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_BUG, EGG_BUG ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, PROTECT, ENERGY_BALL, WILL_O_WISP, FACADE, SOLARBEAM, RETURN, PSYCHIC_M, SWAGGER, FIRE_BLAST, REST, ATTRACT, FURY_CUTTER, ZEN_HEADBUTT, FLAMETHROWER
	; end
