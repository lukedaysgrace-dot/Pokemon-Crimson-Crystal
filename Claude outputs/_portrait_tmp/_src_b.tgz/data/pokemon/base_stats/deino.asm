	db 0 ; species ID placeholder

	db  52,  65,  50,  38,  45,  50
	;  hp  atk  def  spd  sat  sdf

	db DARK, DRAGON ; type
	db 45 ; catch rate
	db 60 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/deino/front.dimensions"
	abilities_for DEINO, HUSTLE, NO_ABILITY, NO_ABILITY
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_DRAGON, EGG_DRAGON ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, ROAR, TOXIC, DRAGON_PULSE, HIDDEN_POWER, WORK_UP, PROTECT, FACADE, DRAGON_CLAW, RETURN, SWAGGER, KNOCK_OFF, FIRE_BLAST, NASTY_PLOT, REST, ATTRACT, THIEF, NIGHT_SLASH, ZEN_HEADBUTT, SURF, FLAMETHROWER
	; end
