	db 0 ; species ID placeholder

	db  65,  75,  45,  55,  35,  45
	;  hp  atk  def  spd  sat  sdf

	db DRAGON, ICE ; type
	db 45 ; catch rate
	db 64 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/frigibax/front.dimensions"
	abilities_for FRIGIBAX, THERMAL_EXCHANGE, NO_ABILITY, ICE_BODY
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_DRAGON, EGG_MINERAL ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, BLIZZARD, ICICLE_CRASH, PROTECT, FACADE, IRON_HEAD, DRAGON_CLAW, EARTHQUAKE, RETURN, SWAGGER, REST, ATTRACT, ICE_BEAM
	; end
