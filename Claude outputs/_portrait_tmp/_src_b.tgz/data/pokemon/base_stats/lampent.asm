	db 0 ; species ID placeholder

	db  60,  40,  60,  55,  95,  60
	;   hp  atk  def  spd  sat  sdf

	db GHOST, FIRE ; type
	db 90 ; catch rate
	db 130 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/lampent/front.dimensions"
	abilities_for LAMPENT, FLASH_FIRE, LEVITATE, CURSED_BODY
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_INDETERMINATE, EGG_INDETERMINATE ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, ENERGY_BALL, WILL_O_WISP, FACADE, RETURN, PSYCHIC_M, SHADOW_BALL, SWAGGER, FIRE_BLAST, SWIFT, REST, ATTRACT, THIEF, FLASH, FLAMETHROWER
	; end
