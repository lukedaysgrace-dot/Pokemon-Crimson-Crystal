	db 0 ; species ID placeholder

	db  95, 120,  75,  60,  75,  85
	;  hp  atk  def  spd  sat  sdf

	db DARK, FAIRY ; type
	db 45 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F0 ; gender ratio (male only)
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/grimmsnarl/front.dimensions"
	abilities_for GRIMMSNARL, PRANKSTER, FRISK, TOUGH_CLAWS
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_HUMANSHAPE, EGG_FAIRY ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, CURSE, TOXIC, HIDDEN_POWER, HYPER_BEAM, PROTECT, FACADE, RETURN, SWAGGER, ICE_PUNCH, KNOCK_OFF, BULK_UP, THUNDERPUNCH, NASTY_PLOT, REST, ATTRACT, THIEF, FIRE_PUNCH, NIGHT_SLASH, STRENGTH
	; end
