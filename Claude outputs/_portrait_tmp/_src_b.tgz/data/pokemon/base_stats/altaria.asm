	db 0 ; species ID placeholder

	db  75,  90,  90,  80,  90, 105
	;  hp  atk  def  spd  sat  sdf

	db DRAGON, FAIRY ; type
	db 45 ; catch rate
	db 172 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/altaria/front.dimensions"
	abilities_for ALTARIA, CLOUD_NINE, NATURAL_CURE, PIXILATE
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_FLYING, EGG_DRAGON ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, HYPER_BEAM, PROTECT, WILL_O_WISP, FACADE, DRAGON_CLAW, EARTHQUAKE, RETURN, SWAGGER, FIRE_BLAST, SWIFT, DRAGON_DANCE, REST, ATTRACT, STEEL_WING, HONE_CLAWS, WEATHER_BALL, FLY, STRENGTH, FLAMETHROWER
	; end
