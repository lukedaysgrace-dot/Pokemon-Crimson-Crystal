	db 0 ; species ID placeholder

	db  60,  62,  63,  60,  80,  80
	;   hp  atk  def  spd  sat  sdf

	db GRASS, POISON ; type
	db 45 ; catch rate
	db 142 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F12_5 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/ivysaur/front.dimensions"
	abilities_for IVYSAUR, CHLOROPHYLL, OVERGROW, EFFECT_SPORE
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_MONSTER, EGG_PLANT ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, SWEET_SCENT, WORK_UP, PROTECT, ENERGY_BALL, FACADE, SOLARBEAM, RETURN, MUD_SLAP, SWAGGER, KNOCK_OFF, SLUDGE_BOMB, REST, ATTRACT, FURY_CUTTER, WEATHER_BALL, CUT, FLASH
	; end
