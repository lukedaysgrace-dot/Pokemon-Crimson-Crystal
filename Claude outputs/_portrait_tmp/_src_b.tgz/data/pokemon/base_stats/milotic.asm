	db 0 ; species ID placeholder

	db  95,  60,  79,  81, 100, 125
	;  hp  atk  def  spd  sat  sdf

	db WATER, FAIRY ; type
	db 60 ; catch rate
	db 189 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/milotic/front.dimensions"
	abilities_for MILOTIC, MARVEL_SCALE, COMPETITIVE, WONDER_SKIN
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_WATER_1, EGG_WATER_2 ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, BLIZZARD, HYPER_BEAM, PROTECT, RAIN_DANCE, FACADE, RETURN, SWAGGER, DRAGON_DANCE, REST, ATTRACT, WEATHER_BALL, SURF, WHIRLPOOL, WATERFALL, ICE_BEAM
	; end
