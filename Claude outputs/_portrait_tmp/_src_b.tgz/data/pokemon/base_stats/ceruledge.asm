	db 0 ; species ID placeholder

	db  75, 125,  80,  85,  60, 100
	;  hp  atk  def  spd  sat  sdf

	db FIRE, GHOST ; type
	db 25 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/ceruledge/front.dimensions"
	abilities_for CERULEDGE, FLASH_FIRE, WEAK_ARMOR, SHARPNESS
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, WILL_O_WISP, FACADE, DRAGON_CLAW, RETURN, SHADOW_BALL, SWAGGER, FIRE_BLAST, BULK_UP, REST, ATTRACT, NIGHT_SLASH, STRENGTH, FLAMETHROWER
	; end
