	db 0 ; species ID placeholder

	db 105, 105,  75,  50,  65, 100
	;  hp  atk  def  spd  sat  sdf

	db POISON, DARK ; type
	db 75 ; catch rate
	db 175 ; base exp
	db NUGGET, NUGGET ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/muk_alolan/front.dimensions"
	abilities_for MUK_ALOLAN, POISON_TOUCH, GLUTTONY, POISON_PUPPETEER
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_INDETERMINATE, EGG_INDETERMINATE ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, SUNNY_DAY, HYPER_BEAM, PROTECT, RAIN_DANCE, ENERGY_BALL, FACADE, RETURN, DIG, SHADOW_BALL, SWAGGER, ICE_PUNCH, KNOCK_OFF, SLUDGE_BOMB, FIRE_BLAST, THUNDERPUNCH, REST, ATTRACT, THIEF, FIRE_PUNCH, NIGHT_SLASH, ZEN_HEADBUTT, STRENGTH, FLAMETHROWER
	; end
