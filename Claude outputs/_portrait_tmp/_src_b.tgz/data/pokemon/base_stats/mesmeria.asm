	db 0 ; species ID placeholder

	db  75,  50,  45, 105, 135, 105
	;  hp  atk  def  spd  sat  sdf

	db ICE, PSYCHIC ; type
	db 45 ; catch rate
	db 190 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F100 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/mesmeria/front.dimensions"
	; custom mon (Ice/Psychic, mesmerist flavor) - change freely
	abilities_for MESMERIA, SYNCHRONIZE, ICE_BODY, BAD_DREAMS
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, SWEET_SCENT, BLIZZARD, HYPER_BEAM, PROTECT, RAIN_DANCE, FACADE, RETURN, PSYCHIC_M, SHADOW_BALL, MUD_SLAP, SWAGGER, ICE_PUNCH, NASTY_PLOT, REST, ATTRACT, THIEF, ZEN_HEADBUTT, FLASH, ICE_BEAM
	; end
