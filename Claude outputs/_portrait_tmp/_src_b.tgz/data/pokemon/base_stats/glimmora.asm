	db 0 ; species ID placeholder

	db  83,  55,  90,  86, 130,  81
	;   hp  atk  def  spd  sat  sdf

	db ROCK, POISON ; type
	db 25 ; catch rate
	db 184 ; base exp
	db NO_ITEM, POISON_BARB ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/glimmora/front.dimensions"
	abilities_for GLIMMORA, TOXIC_DEBRIS, CORROSION, MERCILESS
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_MINERAL, EGG_MINERAL ; egg groups

	; tm/hm learnset
	tmhm CURSE, ROCK_TOMB, TOXIC, ROCK_SMASH, HIDDEN_POWER, HYPER_BEAM, PROTECT, ENERGY_BALL, FACADE, RETURN, SWAGGER, FLASH_CANNON, SLUDGE_BOMB, SANDSTORM, REST, ATTRACT, POWER_GEM
	; end
