	db 0 ; species ID placeholder

	db  80,  82, 100,  80,  93, 100
	;   hp  atk  def  spd  sat  sdf

	db GRASS, FAIRY ; type
	db 45 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F12_5 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/meganium/front.dimensions"
	abilities_for MEGANIUM, SERENE_GRACE, MEGA_SOL, TRIAGE
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_MONSTER, EGG_PLANT ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, ROCK_SMASH, HIDDEN_POWER, SUNNY_DAY, SWEET_SCENT, WORK_UP, HYPER_BEAM, PROTECT, ENERGY_BALL, FACADE, SOLARBEAM, IRON_HEAD, EARTHQUAKE, RETURN, MUD_SLAP, SWAGGER, KNOCK_OFF, REST, ATTRACT, FURY_CUTTER, ZEN_HEADBUTT, WEATHER_BALL, CUT, STRENGTH, FLASH
	; end
