	db 0 ; species ID placeholder

	db  65, 110, 130,  95,  60,  65
	;  hp  atk  def  spd  sat  sdf

	db GRASS, GRASS ; type
	db 45 ; catch rate
	db 184 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F12_5 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/leafeon/front.dimensions"
	abilities_for LEAFEON, LEAF_GUARD, SHARPNESS, CHLOROPHYLL
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, SUNNY_DAY, WORK_UP, HYPER_BEAM, PROTECT, RAIN_DANCE, ENERGY_BALL, FACADE, SOLARBEAM, IRON_HEAD, RETURN, SHADOW_BALL, MUD_SLAP, SWAGGER, KNOCK_OFF, SWIFT, REST, ATTRACT, WEATHER_BALL, STRENGTH
	; end
