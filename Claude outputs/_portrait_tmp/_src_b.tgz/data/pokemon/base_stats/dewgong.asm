	db 0 ; species ID placeholder

	db  90,  80,  80,  70,  80,  95
	;   hp  atk  def  spd  sat  sdf

	db WATER, ICE ; type
	db 75 ; catch rate
	db 166 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/dewgong/front.dimensions"
	abilities_for DEWGONG, THICK_FAT, SWIFT_SWIM, SNOW_WARNING
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_WATER_1, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, BLIZZARD, HYPER_BEAM, ICICLE_CRASH, PROTECT, RAIN_DANCE, FACADE, RETURN, SWAGGER, KNOCK_OFF, REST, ATTRACT, WEATHER_BALL, SURF, WHIRLPOOL, WATERFALL, ICE_BEAM
	; end
