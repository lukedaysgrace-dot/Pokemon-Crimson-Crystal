	db 0 ; species ID placeholder

	db  68,  80,  50, 102,  60,  50
	;  hp  atk  def  spd  sat  sdf

	db DRAGON, GHOST ; type
	db 45 ; catch rate
	db 144 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/drakloak/front.dimensions"
	abilities_for DRAKLOAK, CLEAR_BODY, INFILTRATOR, CURSED_BODY
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_INDETERMINATE, EGG_DRAGON ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, PROTECT, WILL_O_WISP, FACADE, DRAGON_CLAW, RETURN, SHADOW_BALL, SWAGGER, FIRE_BLAST, DRAGON_DANCE, REST, ATTRACT, FLAMETHROWER, THUNDERBOLT
	; end
