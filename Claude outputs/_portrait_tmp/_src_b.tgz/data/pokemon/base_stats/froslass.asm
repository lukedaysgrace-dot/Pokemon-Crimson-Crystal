	db 0 ; species ID placeholder

	db  70,  70,  70, 110, 110,  70
	;  hp  atk  def  spd  sat  sdf

	db ICE, GHOST ; type
	db 75 ; catch rate
	db 168 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F100 ; gender ratio (female only)
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/froslass/front.dimensions"
	abilities_for FROSLASS, LEVITATE, SNOW_CLOAK, CURSED_BODY
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_FAIRY, EGG_MINERAL ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, BLIZZARD, HYPER_BEAM, ICICLE_CRASH, PROTECT, WILL_O_WISP, FACADE, RETURN, SHADOW_BALL, SWAGGER, REST, ATTRACT, WEATHER_BALL, ICE_BEAM
	; end
