	db 0 ; species ID placeholder

	db  50,  65,  55,  40,  40,  40
	;  hp  atk  def  spd  sat  sdf

	db STEEL, STEEL ; type
	db 255 ; catch rate
	db 58 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/meowth_galarian/front.dimensions"
	abilities_for MEOWTH_GALARIAN, PICKUP, TOUGH_CLAWS, UNNERVE
	db 0 ; padding
	db GROWTH_MEDIUM_FAST ; growth rate
	dn EGG_GROUND, EGG_GROUND ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, ZAP_CANNON, HIDDEN_POWER, SUNNY_DAY, WORK_UP, PROTECT, RAIN_DANCE, FACADE, IRON_HEAD, THUNDER, RETURN, DIG, SHADOW_BALL, SWAGGER, FLASH_CANNON, KNOCK_OFF, NASTY_PLOT, REST, ATTRACT, THIEF, HONE_CLAWS, NIGHT_SLASH, CUT, FLASH, THUNDERBOLT
	; end
