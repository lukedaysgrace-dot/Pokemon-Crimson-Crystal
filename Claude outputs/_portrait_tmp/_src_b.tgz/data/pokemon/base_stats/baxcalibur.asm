	db 0 ; species ID placeholder

	db 115, 145,  92,  87,  75,  86
	;  hp  atk  def  spd  sat  sdf

	db DRAGON, ICE ; type
	db 10 ; catch rate
	db 255 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/baxcalibur/front.dimensions"
	abilities_for BAXCALIBUR, THERMAL_EXCHANGE, NO_ABILITY, ICE_BODY
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_DRAGON, EGG_MINERAL ; egg groups

	; tm/hm learnset
	tmhm CURSE, TOXIC, DRAGON_PULSE, HIDDEN_POWER, BLIZZARD, HYPER_BEAM, ICICLE_CRASH, PROTECT, FACADE, IRON_HEAD, DRAGON_CLAW, EARTHQUAKE, RETURN, SWAGGER, DRAGON_DANCE, REST, ATTRACT, ZEN_HEADBUTT, STRENGTH, ICE_BEAM
	; end
