	db 0 ; species ID placeholder

	db 105, 140,  95,  45,  55,  65
	;  hp  atk  def  spd  sat  sdf

	db FIGHTING, FIGHTING ; type
	db 45 ; catch rate
	db 227 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F25 ; gender ratio
	db 100 ; unknown 1
	db 20 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/conkeldurr/front.dimensions"
	abilities_for CONKELDURR, GUTS, SHEER_FORCE, IRON_FIST
	db 0 ; padding
	db GROWTH_MEDIUM_SLOW ; growth rate
	dn EGG_HUMANSHAPE, EGG_HUMANSHAPE ; egg groups

	; tm/hm learnset
	tmhm DRAIN_PUNCH, CURSE, ROCK_TOMB, TOXIC, ROCK_SMASH, HIDDEN_POWER, WORK_UP, HYPER_BEAM, PROTECT, FACADE, RETURN, SWAGGER, ICE_PUNCH, KNOCK_OFF, BULK_UP, THUNDERPUNCH, REST, ATTRACT, FIRE_PUNCH, STRENGTH
	; end
