	db 0 ; species ID placeholder

	db  85,  40,  70,  70,  90, 140
	;   hp  atk  def  spd  sat  sdf

	db WATER, FLYING ; type
	db 25 ; catch rate
	db 170 ; base exp
	db NO_ITEM, NO_ITEM ; items
	db GENDER_F50 ; gender ratio
	db 100 ; unknown 1
	db 25 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/mantine/front.dimensions"
	abilities_for MANTINE, SWIFT_SWIM, WATER_ABSORB, WATER_VEIL
	db 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_WATER_1, EGG_WATER_1 ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, CURSE, TOXIC, HIDDEN_POWER, BLIZZARD, PROTECT, RAIN_DANCE, FACADE, EARTHQUAKE, RETURN, MUD_SLAP, SWAGGER, SWIFT, REST, ATTRACT, FLY, SURF, WHIRLPOOL, WATERFALL, ICE_BEAM
	; end
