; Ability battle engine.
; Port of Polished Crystal's engine/battle/abilities.asm, adapted to the
; vanilla-style Supreme Silver battle engine.
;
; Ported categories: entry, status-heal, status prevention, end-of-turn,
; post-battle, contact/on-hit, nullification/absorb, damage/stat/accuracy/
; priority modifiers, faint abilities, Magic Bounce, Synchronize, trapping
; (Shadow Tag/Arena Trap/Magnet Pull), switch-out (Natural Cure/
; Regenerator), Serene Grace/Sheer Force/Skill Link/Prankster/Armor Tail/
; Analytic/Cursed Body/Berserk/Weak Armor/Justified/Aftermath/Cute Charm/
; Iron Barbs. See _ai_artifacts/reports/ABILITY_PORT_PLAN.md for status and
; known limitations.

; ==== Turn and jumptable helpers =========================================

SwitchTurn::
; Preserves all registers.
	push af
	ldh a, [hBattleTurn]
	xor 1
	ldh [hBattleTurn], a
	pop af
	ret

StackCallOpponentTurn::
; Inserts SwitchTurn into the call stack so the following function pointer
; is "wrapped" by SwitchTurns. See Polished Crystal home/battle.asm.
	add sp, -2
	push de
	push hl
	ld hl, sp + 7
	ld d, [hl]
	ld [hl], HIGH(SwitchTurn)
	dec hl
	ld e, [hl]
	ld [hl], LOW(SwitchTurn)
	dec hl
	ld [hl], d
	dec hl
	ld [hl], e
	pop hl
	pop de
	jr SwitchTurn

BattleJumptable::
; hl = jumptable of dbw entries, a = target.
; Returns z if no jump was made, nz otherwise.
	push bc
	ld b, a
.loop
	ld a, [hli]
	cp -1
	jr z, .end
	cp b
	jr z, .got_target
	inc hl
	inc hl
	jr .loop
.got_target
	ld a, [hli]
	ld h, [hl]
	ld l, a
	call _hl_
	or 1
.end
	pop bc
	ret

BattleRandomRange::
; in: a = n. out: a = 0 to n-1 (link-safe random).
	push bc
	ld c, a
	call BattleRandom
	call SimpleDivide
	pop bc
	ret

UserHasFainted::
	push hl
	ld hl, wBattleMonHP
	ldh a, [hBattleTurn]
	and a
	jr z, .got_hp
	ld hl, wEnemyMonHP
.got_hp
	ld a, [hli]
	or [hl]
	pop hl
	ret

OppHasFainted::
	call StackCallOpponentTurn
	jp UserHasFainted

; ==== Ability getters =====================================================

GetTrueUserAbility::
GetUserAbility::
; Current effective ability of the user, after Neutralizing Gas.
	call StackCallOpponentTurn
GetOpponentAbility::
; Current effective ability of the opponent, after Neutralizing Gas.
	push hl
	ld a, BATTLE_VARS_ABILITY_OPP
	call GetBattleVar
	ld l, a
	; check for the user's Neutralizing Gas
	ld a, BATTLE_VARS_ABILITY
	call GetBattleVar
	cp NEUTRALIZING_GAS
	ld a, l
	pop hl
	ret nz
	; A fainted Neutralizing Gas holder no longer suppresses the field.
	; Keep the opponent's ability in b while checking the current user.
	push bc
	ld b, a
	call UserHasFainted
	jr nz, .gas_active
	ld a, b
	pop bc
	ret
.gas_active
	; Neutralizing Gas suppresses unless the ability can't be suppressed.
	ld a, b
	call GetAbilityFlags
	and ABILFLAG_NO_SUPPRESS
	ld a, b
	pop bc
	ret nz
	xor a ; NO_ABILITY
	ret

GetPlayerAbilityEffective::
; Return the player's effective ability without changing hBattleTurn.
; Preserves bc so callers can use it in speed/priority calculations.
	push bc
	ldh a, [hBattleTurn]
	ld c, a
	call SetEnemyTurn ; the player is now the opponent
	call GetOpponentAbility
	ld b, a
	ld a, c
	ldh [hBattleTurn], a
	ld a, b
	pop bc
	ret

GetEnemyAbilityEffective::
; Return the enemy's effective ability without changing hBattleTurn.
; Preserves bc so callers can use it in speed/priority calculations.
	push bc
	ldh a, [hBattleTurn]
	ld c, a
	call SetPlayerTurn ; the enemy is now the opponent
	call GetOpponentAbility
	ld b, a
	ld a, c
	ldh [hBattleTurn], a
	ld a, b
	pop bc
	ret

GetTrueUserIgnorableAbility::
	call StackCallOpponentTurn
GetOpponentIgnorableAbility::
; Returns the opponent's ability, unless the user's Mold Breaker ignores it.
	call GetOpponentAbility
	push bc
	ld b, a
	call GetTrueUserAbility
	cp MOLD_BREAKER
	ld a, b
	jr nz, .done
	call GetAbilityFlags
	and ABILFLAG_IGNORABLE
	ld a, b
	jr z, .done
	xor a ; ignored
.done
	pop bc
	ret

GetAbilityFlags::
; return flags for ability in a. Preserves all but a.
	push hl
	push bc
	ld l, a
	ld h, 0
	ld bc, AbilityFlags
	add hl, bc
	ld a, [hl]
	pop bc
	pop hl
	ret

AbilityCanBeTraced::
; z if ability in a can be traced. Preserves a.
	push bc
	ld b, a
	call GetAbilityFlags
	and ABILFLAG_NO_TRACE
	ld a, b
	pop bc
	ret

; ==== Bank-safe name buffering =============================================
; wStringBuffer1 and wNamedObjectIndexBuffer both live in banked WRAM
; ($D000+), so every access goes through whatever rSVBK currently selects.
; Ability messages print at points in the battle flow - switch-in, banner
; dismissal, post-damage held item handling - where rSVBK is not guaranteed
; to be back on bank 1. Buffer names in bank 1, then copy them immediately
; to unbanked wBattleDynamicNameBuffer for the eventual text_ram command.
;
; This keeps the name safe across banners, animations, frame waits, and
; rSVBK changes. Never park an id in wNamedObjectIndexBuffer across them:
; it is a shared scratch byte.

AbilityCopyBufferedName:
; Copy wStringBuffer1 from WRAM bank 1 to unbanked battle text storage.
; Called with bank 1 selected. Preserves bc, de, and hl.
	push hl
	push de
	ld hl, wStringBuffer1
	ld de, wBattleDynamicNameBuffer
.loop
	ld a, [hli]
	ld [de], a
	inc de
	cp "@"
	jr nz, .loop
	pop de
	pop hl
	ret

AbilityBufferItemName::
; a = item id. Its name -> wBattleDynamicNameBuffer.
; Preserves bc and hl, as GetItemName does.
	push bc
	ld b, a
	ldh a, [rSVBK]
	push af
	ld a, BANK(wStringBuffer1)
	ldh [rSVBK], a
	ld a, b
	ld [wNamedObjectIndexBuffer], a
	call GetItemName
	call AbilityCopyBufferedName
	pop af
	ldh [rSVBK], a
	pop bc
	ret

AbilityBufferItemName_b::
; b = item id. Far-callable form: the farcall macro uses a for the ROM bank.
	ld a, b
	jp AbilityBufferItemName

AbilityBufferMoveName::
; a = move id. Its name -> wBattleDynamicNameBuffer.
; Preserves bc and hl, as GetMoveName does.
	push bc
	ld b, a
	ldh a, [rSVBK]
	push af
	ld a, BANK(wStringBuffer1)
	ldh [rSVBK], a
	ld a, b
	ld [wNamedObjectIndexBuffer], a
	call GetMoveName
	call AbilityCopyBufferedName
	pop af
	ldh [rSVBK], a
	pop bc
	ret

AbilityBufferAbilityName::
; b = ability constant. Its name -> wBattleDynamicNameBuffer.
	ldh a, [rSVBK]
	push af
	ld a, BANK(wStringBuffer1)
	ldh [rSVBK], a
	farcall GetAbilityName
	call AbilityCopyBufferedName
	pop af
	ldh [rSVBK], a
	ret

; ==== Activation framework ================================================

ShowAbilityBannerBrief::
; Full banner presentation, held briefly, then dismissed. Use this before
; effects that redraw the HUD or play animations (they corrupt a live
; banner on the player's side).
	call BeginAbility
	call ShowAbilityActivation
BannerHoldAndDismiss::
	ld c, 24
	call DelayFrames
	jp EndAbility

ShowEnemyAbilityBannerBrief::
; Like ShowAbilityBannerBrief, but presents the opponent's (defender's)
; banner. Held briefly, then dismissed before any text/effect runs.
	call BeginAbility
	call ShowEnemyAbilityActivation
	jr BannerHoldAndDismiss

BeginAbility::
	ld a, [wInAbility]
	and a
	ret nz
	push hl
	push de
	push bc
	call LoadTileMapToTempTileMap
	pop bc
	pop de
	pop hl
	ld a, 1
	ld [wInAbility], a
	ret

EndAbility::
	ld a, [wInAbility]
	and a
	ret z
	farcall DismissAbilityOverlays
	xor a
	ld [wInAbility], a
	ret

AbilityRestoreUserHP::
; bc = amount. The battle core's RestoreHP heals the side OPPOSITE to
; hBattleTurn (see its use by Leech Seed and Leftovers), so wrap it in
; SwitchTurns to heal the turn holder (the ability's owner).
	call SwitchTurn
	farcall RestoreHP
	jp SwitchTurn

ShowEnemyAbilityActivation::
	call StackCallOpponentTurn
ShowAbilityActivation::
; Unconditionally does the banner slideout for the user's current ability.
	push hl
	push de
	push bc
	ld a, BATTLE_VARS_ABILITY
	call GetBattleVar
	ld b, a
IF DEF(DEBUG_BATTLE)
	farcall DebugLogAbilityActivation
ENDC
	farcall PerformAbilityGFX
	pop bc
	pop de
	pop hl
	ret

ShowAbilityReplacement::
; Redraw the user's banner with ability a (for Trace).
	push hl
	push de
	push bc
	ld b, a
	farcall PerformAbilityReplacementGFX
	pop bc
	pop de
	pop hl
	ret

ShowPotentialAbilityActivation::
; Only shows the banner if we're within an ability execution (BeginAbility)
; and this side hasn't shown its banner yet. Avoids duplicate slideouts.
	ld a, [wInAbility]
	and a
	ret z
	push hl
	ld h, a
	ldh a, [hBattleTurn]
	inc a
	rrca
	rrca
	and h
	pop hl
	ret nz
	call ShowAbilityActivation
	ldh a, [hBattleTurn]
	inc a
	rrca
	rrca
	push hl
	ld h, a
	ld a, [wInAbility]
	or h
	ld [wInAbility], a
	pop hl
	ret

; ==== Entry abilities =====================================================

RunEntryAbilities::
; Runs the current turn holder's switch-in abilities.
	call EndAbility
	call RefreshWeatherSuppression
	call UserHasFainted
	ret z
	; a busted Mimikyu keeps its broken sprite when it re-enters
	call ReapplyBrokenDisguise
	call OppHasFainted
	ld hl, BattleEntryAbilities
	jr z, .got_table
	ld hl, BattleEntryAbilitiesNonfainted
.got_table
	call GetTrueUserAbility
	call BattleJumptable
	; fallthrough

CheckNeutralizingGasEnded:
; Turn = the battler that just entered. Once no Neutralizing Gas holder is
; left on the field, the other battler's on-entry abilities (blocked while
; it was out, e.g. Intimidate or Drizzle) activate, as in Gen 8+.
	ld a, [wNeutralizingGasActive]
	and a
	ret z
	ld a, BATTLE_VARS_ABILITY
	call GetBattleVar
	cp NEUTRALIZING_GAS
	jr nz, .check_opponent
	call UserHasFainted
	ret nz ; the entering mon has it
.check_opponent
	ld a, BATTLE_VARS_ABILITY_OPP
	call GetBattleVar
	cp NEUTRALIZING_GAS
	jr nz, .ended
	call OppHasFainted
	ret nz ; the mon already out still has it
.ended
	xor a
	ld [wNeutralizingGasActive], a
	call OppHasFainted
	ret z
	ld hl, NeutralizingGasWoreOffText
	call StdBattleTextbox
	call SwitchTurn
	call EndAbility
	call RefreshWeatherSuppression
	call OppHasFainted
	ld hl, GasEndedAbilitiesNoTarget
	jr z, .got_gas_table
	ld hl, GasEndedAbilities
.got_gas_table
	call GetTrueUserAbility
	call BattleJumptable
	; Status immunities also return immediately when suppression ends.
	ld hl, StatusHealAbilities
	call GetTrueUserAbility
	call BattleJumptable
	jp SwitchTurn

GasEndedAbilities:
	dbw TRACE, TraceAbility
	dbw INTIMIDATE, IntimidateAbility
	dbw FRISK, FriskAbility
	dbw UNNERVE, UnnerveAbility
	dbw DOWNLOAD, DownloadAbility
	dbw ANTICIPATION, AnticipationAbility
	dbw FOREWARN, ForewarnAbility
	dbw SUPERSWEET_SYRUP, SupersweetSyrupAbility
GasEndedAbilitiesNoTarget:
	dbw DRIZZLE, DrizzleAbility
	dbw DROUGHT, DroughtAbility
	dbw SAND_STREAM, SandStreamAbility
	dbw SNOW_WARNING, SnowWarningAbility
	dbw SCREEN_CLEANER, ScreenCleanerAbility
	dbw -1, -1

RunDelayedEntryAbilities::
; After a double KO the first replacement is sent out while the other side's
; slot is still empty, so its foe-targeting entry abilities (Intimidate,
; Trace, Download, ...) were skipped. Run them once the foe is out.
	call UserHasFainted
	ret z
	call OppHasFainted
	ret z
	ld hl, TargetedEntryAbilities
	call GetTrueUserAbility
	jp BattleJumptable

TargetedEntryAbilities:
	dbw TRACE, TraceAbility
	dbw IMPOSTER, ImposterAbility
	dbw INTIMIDATE, IntimidateAbility
	dbw FRISK, FriskAbility
	dbw UNNERVE, UnnerveAbility
	dbw DOWNLOAD, DownloadAbility
	dbw ANTICIPATION, AnticipationAbility
	dbw FOREWARN, ForewarnAbility
	dbw SUPERSWEET_SYRUP, SupersweetSyrupAbility
	dbw -1, -1

BattleEntryAbilitiesNonfainted:
	dbw TRACE, TraceAbility
	dbw IMPOSTER, ImposterAbility
	dbw INTIMIDATE, IntimidateAbility
	dbw FRISK, FriskAbility
	dbw UNNERVE, UnnerveAbility
	dbw DOWNLOAD, DownloadAbility
	dbw ANTICIPATION, AnticipationAbility
	dbw FOREWARN, ForewarnAbility
	dbw SUPERSWEET_SYRUP, SupersweetSyrupAbility
BattleEntryAbilities:
	dbw DRIZZLE, DrizzleAbility
	dbw DROUGHT, DroughtAbility
	dbw SAND_STREAM, SandStreamAbility
	dbw SNOW_WARNING, SnowWarningAbility
	dbw CLOUD_NINE, CloudNineAbility
	dbw PRESSURE, PressureAbility
	dbw MOLD_BREAKER, MoldBreakerAbility
	dbw NEUTRALIZING_GAS, NeutralizingGasAbility
	dbw SCREEN_CLEANER, ScreenCleanerAbility
	; fallthrough
StatusHealAbilities:
; Status immunity abilities that autoproc if the user has the status
	dbw LIMBER, LimberAbility
	dbw IMMUNITY, ImmunityAbility
	dbw PASTEL_VEIL, PastelVeilAbility
	dbw MAGMA_ARMOR, MagmaArmorAbility
	dbw WATER_VEIL, WaterVeilAbility
	dbw INSOMNIA, InsomniaAbility
	dbw VITAL_SPIRIT, VitalSpiritAbility
	dbw OWN_TEMPO, OwnTempoAbility
	dbw OBLIVIOUS, ObliviousAbility
	dbw THERMAL_EXCHANGE, WaterVeilAbility
	dbw -1, -1

CloudNineAbility:
	ld hl, NotifyCloudNineText
	jr NotificationAbilities
PressureAbility:
	ld hl, NotifyPressureText
	jr NotificationAbilities

OpponentHasPressure::
; Return z if the move target has Pressure. Pressure is not an ignorable
; defensive ability, so Mold Breaker does not bypass its extra PP cost.
; Moves that only affect the user or its side (stat boosts, recovery,
; Protect, weather...) do not target the Pressure holder and cost 1 PP.
	call GetOpponentAbility
	cp PRESSURE
	ret nz
	push bc
	push de
	push hl
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	ld hl, PressureExemptEffects
	ld de, 1
	call IsInArray
	pop hl
	pop de
	pop bc
	jr c, .exempt
	xor a ; z
	ret
.exempt
	or 1 ; nz
	ret

PressureExemptEffects:
	db EFFECT_ATTACK_UP
	db EFFECT_DEFENSE_UP
	db EFFECT_SPEED_UP
	db EFFECT_SP_ATK_UP
	db EFFECT_SP_DEF_UP
	db EFFECT_ACCURACY_UP
	db EFFECT_EVASION_UP
	db EFFECT_ATTACK_UP_2
	db EFFECT_DEFENSE_UP_2
	db EFFECT_SPEED_UP_2
	db EFFECT_SP_ATK_UP_2
	db EFFECT_SP_DEF_UP_2
	db EFFECT_ACCURACY_UP_2
	db EFFECT_EVASION_UP_2
	db EFFECT_CONVERSION
	db EFFECT_HEAL
	db EFFECT_LIGHT_SCREEN
	db EFFECT_MIST
	db EFFECT_FOCUS_ENERGY
	db EFFECT_REFLECT
	db EFFECT_SUBSTITUTE
	db EFFECT_SPLASH
	db EFFECT_HEAL_BELL
	db EFFECT_PROTECT
	db EFFECT_SANDSTORM
	db EFFECT_ENDURE
	db EFFECT_SAFEGUARD
	db EFFECT_BATON_PASS
	db EFFECT_MORNING_SUN
	db EFFECT_SYNTHESIS
	db EFFECT_MOONLIGHT
	db EFFECT_RAIN_DANCE
	db EFFECT_SUNNY_DAY
	db EFFECT_BELLY_DRUM
	db EFFECT_TELEPORT
	db EFFECT_DEFENSE_CURL
	db EFFECT_HAIL
	db EFFECT_BULK_UP
	db EFFECT_CALM_MIND
	db EFFECT_DRAGON_DANCE
	db EFFECT_HONE_CLAWS
	db EFFECT_SHELL_SMASH
	db EFFECT_ROOST
	db EFFECT_TRICK_ROOM
	db EFFECT_BANEFUL_BUNKER
	db EFFECT_QUIVER_DANCE
	db EFFECT_WORK_UP
	db EFFECT_WISH
	db EFFECT_CONVERSION2
	db EFFECT_DESTINY_BOND
	db EFFECT_SLEEP_TALK
	db EFFECT_METRONOME
	db -1
MoldBreakerAbility:
	ld hl, NotifyMoldBreakerText
	jr NotificationAbilities
UnnerveAbility:
	ld hl, NotifyUnnerveText
	jr NotificationAbilities
NeutralizingGasAbility:
	ld a, 1
	ld [wNeutralizingGasActive], a
	ld hl, NotifyNeutralizingGasText
	; fallthrough
NotificationAbilities:
	push hl
	call ShowAbilityBannerBrief
	pop hl
	jp StdBattleTextbox

TraceAbility:
	call GetOpponentAbility
	and a
	ret z
	call AbilityCanBeTraced
	ret nz
	push af
	call BeginAbility
	call ShowAbilityActivation
	call ShowEnemyAbilityActivation
	pop af
	push af
	call ShowAbilityReplacement
	call BannerHoldAndDismiss
	; announce the traced ability AFTER the banners (the banner GFX
	; clobbers wStringBuffer1, so buffer the name here, not earlier)
	pop af
	push af
	ld b, a
	call AbilityBufferAbilityName
	ld hl, TraceActivationText
	call StdBattleTextbox
	ld a, BATTLE_VARS_ABILITY
	call GetBattleVarAddr
	pop af
	ld [hl], a
	jp RunEntryAbilities

ImposterAbility:
; Banner briefly, then Transform (wave deform + sprite swap).
; BattleCommand_Transform plays the anim itself; skip TransformedText.
	call ShowAbilityBannerBrief
	; $ff: never a move animation ID (MOVE_TABLE_MINIMUM_RESERVED_INDEX), so
	; it can't be mistaken for the one usedmovetext leaves here
	ld a, $ff
	ld [wTempByteValue], a
	farcall BattleCommand_Transform
	xor a
	ld [wTempByteValue], a
	jp EndAbility

; Lasts 5 turns, consistent with Generation VI.
DrizzleAbility:
	ld a, WEATHER_RAIN
	ld hl, DownpourText
	jr WeatherAbility
DroughtAbility:
	ld a, WEATHER_SUN
	ld hl, SunGotBrightText
	jr WeatherAbility
SandStreamAbility:
	ld a, WEATHER_SANDSTORM
	ld hl, SandstormBrewedText
	jr WeatherAbility
SnowWarningAbility:
	ld a, WEATHER_HAIL
	ld hl, ItStartedToHailText
	; fallthrough
WeatherAbility:
	ld b, a
	ld a, [wBattleWeather]
	and WEATHER_TYPE_MASK
	cp b
	ret z ; don't re-activate it
	push hl
	push bc
	call ShowAbilityBannerBrief
	pop bc
	ld a, b
	call SetBattleWeatherPreservingSuppression
	call SetWeatherDurationFromUserItem
	pop hl
	call StdBattleTextbox
	; show the weather itself, right after the "it started" text
	ld a, [wBattleWeather]
	and WEATHER_TYPE_MASK
	ld b, a
	; fallthrough

PlayWeatherAbilityAnim:
; b = WEATHER_*. Play that weather's full-screen effect animation once.
	ld a, b
	cp WEATHER_RAIN
	ld de, RAIN_DANCE
	jr z, PlayWeatherAnimDE
	cp WEATHER_SUN
	ld de, SUNNY_DAY
	jr z, PlayWeatherAnimDE
	cp WEATHER_SANDSTORM
	ld de, ANIM_IN_SANDSTORM
	jr z, PlayWeatherAnimDE
	ld de, ANIM_IN_HAIL ; WEATHER_HAIL
	; fallthrough

PlayWeatherAnimDE:
; de = animation id. Play it full-screen.
	ld a, e
	ld [wFXAnimID], a
	ld a, d
	ld [wFXAnimID + 1], a
	xor a
	ld [wNumHits], a
	farcall PlayBattleAnim
	ret

PlayPerTurnWeatherAnim::
; Called from HandleWeather each turn (via farcall). Rain and sun replay
; their animation; sandstorm and hail already animate via their own
; between-turn damage path, so they are skipped here.
	ld a, [wBattleWeather]
	; Raw compare (no mask): while Cloud Nine suppresses weather, the
	; suppression bit makes these fail, matching every gameplay check.
	cp WEATHER_RAIN
	ld de, RAIN_DANCE
	jr z, PlayWeatherAnimDE
	cp WEATHER_SUN
	ret nz
	ld de, SUNNY_DAY
	jr PlayWeatherAnimDE

IntimidateAbility:
	; does not work against Inner Focus, Own Tempo, Oblivious, Scrappy
	call GetOpponentIgnorableAbility
	ld b, a
	and a
	jr z, .intimidate_ok
	call GetAbilityFlags
	and ABILFLAG_NO_INTIMIDATE
	jr z, .intimidate_ok
	; blocked: show both abilities and print the resist text.
	; NOTE: buffer the resisting ability's name AFTER the banners -
	; the banner GFX clobbers wStringBuffer1
	ld a, b
	push af
	call BeginAbility
	call ShowAbilityActivation
	call ShowEnemyAbilityActivation
	call BannerHoldAndDismiss
	pop af
	ld b, a
	call AbilityBufferAbilityName
	ld hl, IntimidateResistedText
	jp StdBattleTextbox

.intimidate_ok
	call ShowAbilityBannerBrief
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld b, ATTACK
	call AbilityLowerOppStat
	; if the stat fell, proc the opponent's Rattled
	ld a, [wFailedMessage]
	and a
	jp nz, EndAbility
	call SwitchTurn
	call GetTrueUserIgnorableAbility
	cp RATTLED
	ld b, SPEED
	call z, StatUpAbility
	call SwitchTurn
	jp EndAbility

FriskAbility:
	; wEnemyMonItem is in switchable WRAM, unlike wBattleMonItem. Select
	; its bank explicitly so Frisk is safe in every entry/switch context.
	ldh a, [rSVBK]
	push af
	ld a, BANK(wEnemyMonItem)
	ldh [rSVBK], a
	ldh a, [hBattleTurn]
	and a
	ld a, [wEnemyMonItem]
	jr z, .got_item
	ld a, [wBattleMonItem]
.got_item
	ld b, a
	pop af
	ldh [rSVBK], a
	ld a, b
	and a
	ret z ; no item
	; Carry the item on the stack, not in wNamedObjectIndexBuffer: that is a
	; shared scratch byte and the banner runs ~30 frames of animation before
	; we get back here. Buffer the name after the banner, like Polished does.
	push af
	call ShowAbilityBannerBrief
	pop af
	call AbilityBufferItemName
	ld hl, FriskedItemText
	jp StdBattleTextbox

ScreenCleanerAbility:
	; only Reflect/Light Screen count - the screens bytes also hold
	; Safeguard, Spikes and Toxic Spikes bits, which are none of Screen
	; Cleaner's business
	ld a, [wPlayerScreens]
	and (1 << SCREENS_REFLECT) | (1 << SCREENS_LIGHT_SCREEN)
	jr nz, .screens_up
	ld a, [wEnemyScreens]
	and (1 << SCREENS_REFLECT) | (1 << SCREENS_LIGHT_SCREEN)
	ret z
.screens_up
	call ShowAbilityBannerBrief
	ldh a, [hBattleTurn]
	push af
	call .do_it
	call SwitchTurn
	call .do_it
	pop af
	ldh [hBattleTurn], a
	ret

.do_it
	; the "<side> #MON's REFLECT faded!" texts start with wStringBuffer1,
	; which still holds the banner's ability name: put the side there
	ldh a, [hBattleTurn]
	and a
	ld de, .Your
	jr z, .got_side
	ld de, .Enemy
.got_side
	ld hl, wStringBuffer1
	call CopyName2
	ldh a, [hBattleTurn]
	and a
	ld hl, wPlayerScreens
	jr z, .got_screens
	ld hl, wEnemyScreens
.got_screens
	ld a, [hl]
	push af
	res SCREENS_REFLECT, [hl]
	res SCREENS_LIGHT_SCREEN, [hl]
	and 1 << SCREENS_REFLECT
	jr z, .no_reflect
	ld hl, BattleText_MonsReflectFaded
	call StdBattleTextbox
.no_reflect
	pop af
	and 1 << SCREENS_LIGHT_SCREEN
	ret z
	ld hl, BattleText_MonsLightScreenFell
	jp StdBattleTextbox

.Your:
	db "Your@"
.Enemy:
	db "Enemy@"

SetBattleWeatherFromB::
; farcall-safe entry: the farcall macro clobbers a (bank) and hl (address),
; so cross-bank callers must pass the weather type in b instead.
	ld a, b
	; fallthrough
SetBattleWeatherPreservingSuppression::
; in: a = WEATHER_*. Keep Cloud Nine's field-suppression bit intact.
; Only same-bank callers may use this entry point with a as the input.
	push bc
	ld b, a
	ld a, [wBattleWeather]
	and WEATHER_SUPPRESSED
	or b
	ld [wBattleWeather], a
	pop bc
	ret

SetWeatherDurationFromUserItem::
; b = WEATHER_*. Weather lasts 8 turns when its summoner holds the
; matching weather rock, and 5 turns otherwise.
	ld a, 5
	ld [wWeatherCount], a
	push bc
	call GetUserItem_Core
	ld a, b
	cp HELD_WEATHER_ROCK
	jr nz, .normal_duration
	ld a, c
	pop bc
	cp b
	ret nz
	ld a, 8
	ld [wWeatherCount], a
	ret

.normal_duration
	pop bc
	ret

RefreshWeatherSuppression::
; Recompute Cloud Nine's field state after entry or an ability change.
; Fainted holders do not suppress weather; Neutralizing Gas is respected
; by the effective-ability helpers.
	ld hl, wBattleWeather
	res WEATHER_SUPPRESSED_F, [hl]
	ld a, [wBattleMonHP]
	ld b, a
	ld a, [wBattleMonHP + 1]
	or b
	jr z, .enemy
	call GetPlayerAbilityEffective
	cp CLOUD_NINE
	jr z, .suppress
.enemy
	ld a, [wEnemyMonHP]
	ld b, a
	ld a, [wEnemyMonHP + 1]
	or b
	ret z
	call GetEnemyAbilityEffective
	cp CLOUD_NINE
	ret nz
.suppress
	set WEATHER_SUPPRESSED_F, [hl]
	ret

; ==== Stat change helpers =================================================

StatUpAbility::
; Force-raise stat b of the user. Shows the banner briefly, dismisses it,
; then applies the stat change (anims corrupt a live player-side banner).
	push bc
	call BeginAbility
	call ShowPotentialAbilityActivation
	ld c, 24
	call DelayFrames
	call EndAbility
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	pop bc
	; fallthrough
AbilityRaiseStat::
; b = stat. Prints the text on success; the generic stat-up
; animation plays from BattleCommand_StatUpMessage itself.
	farcall RaiseStat
	ld a, [wFailedMessage]
	and a
	ret nz
	farcall BattleCommand_StatUpMessage
	ret

AbilityLowerOppStat::
; b = stat. Lowers the user's opponent's stat; respects Mist.
; Prints the text on success; the generic stat-down animation
; plays from BattleCommand_StatDownMessage itself.
; Flags the drop as ability-driven so StatDown skips the vanilla
; 25% computer-miss roll (it randomly ate Mirror Armor reflections
; and enemy Intimidate).
	push hl
	ld hl, wDisguiseBusted
	set 6, [hl]
	; wAbilityStatDropFlag marks the whole drop+message+reaction sequence
	; as ability-driven: the move-effect byte is stale here, so StatDown
	; must not use it for the self-drop/Mist shortcuts and
	; RunStatDropReaction must not let it veto Defiant/Competitive.
	; (Bit 6 above can't serve: .ComputerMiss consumes it mid-sequence;
	; both wDisguiseBusted bytes' other bits are per-slot disguise data.)
	ld hl, wAbilityStatDropFlag
	ld [hl], 1
	pop hl
	farcall AbilityStatDown
	ld a, [wFailedMessage]
	and a
	jr nz, .done
	farcall BattleCommand_StatDownMessage
.done
	push hl
	ld hl, wAbilityStatDropFlag
	ld [hl], 0
	pop hl
	ret

; ==== Status heal / prevention ============================================

RunEnemyStatusHealAbilities::
	call StackCallOpponentTurn
RunStatusHealAbilities::
	ld hl, StatusHealAbilities
	call GetTrueUserAbility
	jp BattleJumptable

RunStatusHealAbilitiesBoth::
; Move-end update: an immunity bypassed by Mold Breaker cures the status
; before the holder's next action. Never cure a fainted mon or a suppressed
; ability. Preserve the caller's turn through both banners and stat recalcs.
	ldh a, [hBattleTurn]
	push af
	call SetPlayerTurn
	call .side
	call SetEnemyTurn
	call .side
	pop af
	ldh [hBattleTurn], a
	ret
.side
	call UserHasFainted
	ret z
	jp RunStatusHealAbilities

ImmunityAbility:
PastelVeilAbility:
	ld a, 1 << PSN
	jr HealStatusAbility
WaterVeilAbility:
	ld a, 1 << BRN
	jr HealStatusAbility
MagmaArmorAbility:
	ld a, 1 << FRZ
	jr HealStatusAbility
LimberAbility:
	ld a, 1 << PAR
	jr HealStatusAbility
InsomniaAbility:
VitalSpiritAbility:
	ld a, SLP
	; fallthrough
HealStatusAbility:
	ld b, a
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and b
	ret z ; not afflicted / wrong status
	push bc
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_STATUS
	call GetBattleVarAddr
	xor a
	ld [hl], a
	pop bc
	; Curing poison must also clear Toxic's field-only marker and counter;
	; otherwise a later ordinary poison can inherit toxic escalation.
	; Bit test, not equality: Shed Skin/Hydration cure with ALL_STATUS,
	; which never equals 1 << PSN exactly.
	ld a, b
	and 1 << PSN
	call nz, .clear_toxic
	; Sleep cures end Nightmare immediately, just like the ordinary wake-up
	; paths. Leaving the marker armed makes a later sleep inherit damage.
	ld a, b
	and SLP
	call nz, .clear_nightmare
	ld hl, BecameHealthyText
	; StdBattleTextbox runs the text engine, which clobbers bc; preserve the
	; cured-status mask in b for the stat-recalc checks below.
	push bc
	call StdBattleTextbox
	ldh a, [hBattleTurn]
	and a
	jr nz, .update_enemy
	call UpdateBattleMonInParty
	pop bc
	; Recalculate to undo the stored PAR/BRN/frostbite stat penalty that
	; was applied before this switch-in ability cured the status.
	ld a, b
	and (1 << PAR) | (1 << BRN) | (1 << FRZ)
	ret z
	farcall CalcPlayerStats
	ret
.update_enemy
	call UpdateEnemyMonInParty
	pop bc
	ld a, b
	and (1 << PAR) | (1 << BRN) | (1 << FRZ)
	ret z
	farcall CalcEnemyStats
	ret

.clear_toxic
	ld a, BATTLE_VARS_SUBSTATUS5
	call GetBattleVarAddr
	res SUBSTATUS_TOXIC, [hl]
	farcall ToxicClearUser_Core
	ld hl, wPlayerToxicCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_toxic_count
	ld hl, wEnemyToxicCount
.got_toxic_count
	xor a
	ld [hl], a
	ret

.clear_nightmare
	ld a, BATTLE_VARS_SUBSTATUS1
	call GetBattleVarAddr
	res SUBSTATUS_NIGHTMARE, [hl]
	ret

OwnTempoAbility:
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVar
	bit SUBSTATUS_CONFUSED, a
	ret z ; not confused
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVarAddr
	res SUBSTATUS_CONFUSED, [hl]
	ld hl, ConfusedNoMoreText
	jp StdBattleTextbox

ObliviousAbility:
	ld a, BATTLE_VARS_SUBSTATUS1
	call GetBattleVar
	bit SUBSTATUS_IN_LOVE, a
	ret z ; not infatuated
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_SUBSTATUS1
	call GetBattleVarAddr
	res SUBSTATUS_IN_LOVE, [hl]
	ld hl, NoLongerInfatuatedText
	jp StdBattleTextbox

; Status prevention: called from effect commands with hBattleTurn = attacker.
; Each returns carry if the DEFENDER's ability prevents the status
; (and shows the ability banner).
; Each list is prefixed with a "bounce kind" byte so Magic Bounce knows how
; to reflect a STATUS move of that kind back at its user.
; NOTE: de must be preserved on the no-carry path (SleepTarget keeps its
; status pointer in de across the farcall). The carry paths all jump
; straight to failure handling, so de is free to clobber there.

BOUNCE_NONE EQU 0
BOUNCE_SLP  EQU 1
BOUNCE_PAR  EQU 2
BOUNCE_PSN  EQU 3
BOUNCE_BRN  EQU 4
BOUNCE_CNF  EQU 5
BOUNCE_ATR  EQU 6

AbilityPreventsSleep::
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_SLP
	db INSOMNIA, VITAL_SPIRIT, LEAF_GUARD, -1

AbilityPreventsParalysis::
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_PAR
	db LIMBER, LEAF_GUARD, -1

AbilityPreventsPoison::
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_PSN
	db IMMUNITY, PASTEL_VEIL, LEAF_GUARD, -1

AbilityPreventsBurn::
	; Flash Fire also blocks Fire-type status moves (notably Will-O-Wisp).
	; Damaging Fire moves are handled earlier by RunNullificationAbilities.
	call GetOpponentIgnorableAbility
	cp FLASH_FIRE
	jr nz, .ordinary
	; Ability-inflicted burns (Flame Body, Synchronize) have no move behind
	; them: the turn-keyed move type read below would be the holder's own
	; stale last move (audit 2026-08-28 #15). The guard bit marks those.
	ld a, [wDisguiseBusted + 1]
	bit 6, a
	jr nz, .ordinary
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	jr nz, .ordinary
	call SwitchTurn
	call ShowAbilityBannerBrief
	call FlashFireRaiseHigherAttackStatus
	call SwitchTurn
	scf
	ret
.ordinary
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_BRN
	db WATER_VEIL, THERMAL_EXCHANGE, LEAF_GUARD, -1

AbilityPreventsFreeze::
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_NONE
	db MAGMA_ARMOR, LEAF_GUARD, -1

AbilityPreventsConfusion::
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_CNF
	db OWN_TEMPO, -1

AbilityPreventsAttraction::
	ld hl, .abilities
	jr CheckStatusPrevention
.abilities
	db BOUNCE_ATR
	db OBLIVIOUS, -1

CheckStatusPrevention:
; hl = bounce kind byte, then -1-terminated ability list.
; Carry if the defender's ability matches (or Magic Bounce reflected).
	call GetOpponentIgnorableAbility
	and a
	ret z ; nc
	ld b, a
	ld a, [hli] ; bounce kind
	ld c, a
	ld a, b
	cp MAGIC_BOUNCE
	jr z, .magic_bounce
.loop
	ld a, [hli]
	cp -1
	jr z, .no_match
	cp b
	jr nz, .loop
	; Leaf Guard only protects in harsh sunlight
	cp LEAF_GUARD
	jr nz, .not_leaf_guard
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jr nz, .no_match
	ld a, b
.not_leaf_guard
	; prevented. Thermal Exchange's Fire hit already shows its own Atk-up
	; banner via the on-hit path, so suppress this (redundant) second
	; banner for it - the burn is still blocked, just silently.
	cp THERMAL_EXCHANGE
	jr z, .prevented_no_banner
	; show the defender's banner
	call ShowEnemyAbilityBannerBrief
.prevented_no_banner
	scf
	ret
.no_match
	and a ; nc
	ret

.magic_bounce
	; Magic Bounce reflects STATUS moves back at their user.
	; Secondary effects of damaging moves are not bounced (canon), and a
	; bounced move can't be bounced again (guard bit 6 of wDisguiseBusted+1).
	ld a, c
	and a ; BOUNCE_NONE?
	jr z, .no_match
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	jr nz, .no_match
	ld a, [wDisguiseBusted + 1]
	bit 6, a
	jr nz, .no_match
	ld hl, wDisguiseBusted + 1
	set 6, [hl]
	; run the reflected status attempt from the bouncer's perspective
	; (the Try* handlers status the bouncer's OPPONENT = original attacker,
	; showing the bouncer's MAGIC BOUNCE banner)
	; Toxic must remain badly poisoned when reflected; the generic poison
	; handler is correct for every other poison-inducing status move.
	ld a, c
	cp BOUNCE_PSN
	jr nz, .ordinary_bounce
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_TOXIC
	ld hl, TryToxicOpponent
	jr z, .run_bounce
.ordinary_bounce
	ld hl, .bounce_handlers
	ld b, 0
	dec c
	sla c
	add hl, bc
	ld a, [hli]
	ld h, [hl]
	ld l, a
.run_bounce
	call SwitchTurn
	call _hl_
	call SwitchTurn
	ld hl, wDisguiseBusted + 1
	res 6, [hl]
	scf ; the original move fails
	ret

.bounce_handlers
	dw TrySleepOpponent      ; BOUNCE_SLP
	dw TryParalyzeOpponent   ; BOUNCE_PAR
	dw TryPoisonOpponentContact ; BOUNCE_PSN
	dw TryBurnOpponent       ; BOUNCE_BRN
	dw TryConfuseOpponent    ; BOUNCE_CNF
	dw TryAttractOpponent    ; BOUNCE_ATR

; ==== End-of-turn abilities ==============================================

RunEndTurnStatusAbility::
; Residual order 5 (with Leftovers): the current battler's Shed Skin or
; Hydration cures its status before Leech Seed and status damage.
	call UserHasFainted
	ret z
	call GetTrueUserAbility
	ld hl, EndTurnStatusAbilities
	jp BattleJumptable

RunEndTurnAbilitiesBoth::
; Late residual abilities (Speed Boost, Bad Dreams, Harvest, Cud Chew) share
; one pass in effective Speed order, after Perish Song and Trick Room's end.
	ld hl, EndTurnAbilities
	ldh a, [hBattleTurn]
	push af
	push hl
	call GetResidualFirstSide
	ldh [hBattleTurn], a
	pop hl
	push hl
	call .run
	pop hl
	call SwitchTurn
	call .run
	pop af
	ldh [hBattleTurn], a
	ret
.run
	ld a, [wBattleEnded]
	and a
	ret nz
	push hl
	call UserHasFainted
	pop hl
	ret z
	push hl
	call GetTrueUserAbility
	pop hl
	jp BattleJumptable

EndTurnStatusAbilities:
	dbw SHED_SKIN, ShedSkinAbility
	dbw HYDRATION, HydrationAbility
	dbw -1, -1

EndTurnAbilities:
	dbw SPEED_BOOST, SpeedBoostAbility
	dbw BAD_DREAMS, BadDreamsEndTurnAbility
	dbw HARVEST, HarvestAbility
	dbw CUD_CHEW, CudChewAbility
	dbw -1, -1

RunWeatherResidualAbilitiesBoth::
; Each holder's weather chip/healing precedes Wish, Leftovers and status chip.
; Resolve living holders by effective Speed (reversed under Trick Room).
	call PlayPerTurnWeatherAnim
	ldh a, [hBattleTurn]
	push af
	call GetResidualFirstSide
	and a
	jr nz, .enemy_first
	call SetPlayerTurn
	call .side
	call SetEnemyTurn
	jr .second
.enemy_first
	call SetEnemyTurn
	call .side
	call SetPlayerTurn
.second
	call .side
	pop af
	ldh [hBattleTurn], a
	ret
.side
	ld a, [wBattleEnded]
	and a
	ret nz
	call UserHasFainted
	ret z
	farcall HandleWeatherChip
	ld a, [wBattleEnded]
	and a
	ret nz
	call UserHasFainted
	ret z
	ld hl, WeatherResidualAbilities
	call GetTrueUserAbility
	call BattleJumptable
	farcall CheckResidualFaint
	ret

WeatherResidualAbilities:
	dbw RAIN_DISH, RainDishAbility
	dbw ICE_BODY, IceBodyAbility
	dbw DRY_SKIN, DrySkinAbility
	dbw SOLAR_POWER, SolarPowerAbility
	dbw -1, -1

BadDreamsEndTurnAbility:
; Resolve the sleeping victim's knockout before the next holder acts.
	ldh a, [hBattleTurn]
	push af
	call BadDreamsAbility
	call SwitchTurn
	farcall CheckResidualFaint
	pop af
	ldh [hBattleTurn], a
	ret

GetResidualFirstSide::
; a = first side for residual effects (0 player, 1 enemy). End-of-turn
; order uses effective Speed and random ties; Trick Room reverses it, as
; it does move order (Showdown's residual handlers use action speed).
	push bc
	call CompareSpeedsWithAbilities
	ld b, 0
	jr z, .tie
	jr nc, .done
	inc b
	jr .done
.tie
	call BattleRandom
	and 1
	ld b, a
.done
	ld a, b
	pop bc
	ret

SpeedBoostAbility:
	; A holder that entered after its side's action has not been active for a
	; full turn and must not receive Speed Boost yet. The First Impression
	; freshness flag is consumed at the mon's first action opportunity even if
	; sleep, flinching, paralysis, or an item prevents an actual move.
	ld hl, wPlayerFirstImpressionFresh
	ldh a, [hBattleTurn]
	and a
	jr z, .got_freshness
	inc hl ; wEnemyFirstImpressionFresh
.got_freshness
	ld a, [hl]
	and a
	ret nz
	call BeginAbility
	ld b, SPEED
	call StatUpAbility
	jp EndAbility

ShedSkinAbility:
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and a
	ret z
	; One-in-three chance to proc (Gen V onward).
	ld a, 3
	call BattleRandomRange
	and a
	ret nz
	jr HealAllStatusAbility

HydrationAbility:
	ld a, [wBattleWeather]
	cp WEATHER_RAIN
	ret nz
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and a
	ret z
	; fallthrough
HealAllStatusAbility:
	ld a, ALL_STATUS
	jp HealStatusAbility

RainDishAbility:
	ld a, [wBattleWeather]
	cp WEATHER_RAIN
	ret nz
	jr Heal16thAbility

IceBodyAbility:
	ld a, [wBattleWeather]
	cp WEATHER_HAIL
	ret nz
	; fallthrough
Heal16thAbility:
; Heal 1/16 max HP, if not already at full HP.
	call CheckUserFullHP
	ret z
	call ShowAbilityBannerBrief
	farcall GetEighthMaxHP
	; halve for 1/16, minimum 1
	srl b
	rr c
	ld a, c
	or b
	jr nz, .got_amount
	inc c
.got_amount
	call AbilityRestoreUserHP
	ld hl, RegainedHealthText
	call StdBattleTextbox
	jp EndAbility

DrySkinAbility:
	ld a, [wBattleWeather]
	cp WEATHER_RAIN
	jr z, .heal
	cp WEATHER_SUN
	ret nz
	; hurt 1/8 in sun
	call ShowAbilityBannerBrief
	farcall GetEighthMaxHP
	farcall SubtractHPFromUser
	ld hl, IsHurtText
	call StdBattleTextbox
	jp EndAbility
.heal
	call CheckUserFullHP
	ret z
	call ShowAbilityBannerBrief
	farcall GetEighthMaxHP
	call AbilityRestoreUserHP
	ld hl, RegainedHealthText
	call StdBattleTextbox
	jp EndAbility

SolarPowerAbility:
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	ret nz
	call ShowAbilityBannerBrief
	farcall GetEighthMaxHP
	farcall SubtractHPFromUser
	ld hl, IsHurtText
	call StdBattleTextbox
	jp EndAbility

BadDreamsAbility:
	; only if the opponent is asleep
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and SLP
	ret z
	call OppHasFainted
	ret z
	; Magic Guard prevents indirect damage from opposing abilities.
	call GetOpponentAbility
	cp MAGIC_GUARD
	ret z
	call ShowAbilityBannerBrief
	call SwitchTurn
	farcall GetEighthMaxHP
	farcall SubtractHPFromUser
	ld hl, TormentedText
	call StdBattleTextbox
	call SwitchTurn
	jp EndAbility

; ==== Post-battle abilities ==============================================

RunPostBattleAbilities::
; Party-wide Pickup / Honey Gather / Natural Cure.
	ld a, [wPartyCount]
	and a
	ret z
	xor a
.loop
	push af
	ld [wCurPartyMon], a
	; skip eggs: the party struct holds an Egg's real species, only
	; wPartySpecies says EGG
	ld e, a
	ld d, 0
	ld hl, wPartySpecies
	add hl, de
	ld a, [hl]
	cp EGG
	jr z, .next
	ld a, MON_SPECIES
	call GetPartyParamLocation
	ld a, [hl]
	ld c, a
	ld a, MON_PERSONALITY
	call GetPartyParamLocation
	ld b, [hl]
	call GetAbility
	ld a, b
	cp NATURAL_CURE
	jr z, .natural_cure
	cp PICKUP
	jr z, .pickup
	cp HONEY_GATHER
	jr z, .honey_gather
.next
	pop af
	inc a
	ld hl, wPartyCount
	cp [hl]
	jr c, .loop
	ret

.natural_cure
	ld a, MON_STATUS
	call GetPartyParamLocation
	xor a
	ld [hl], a
	jr .next

.pickup
	; 10% chance to pick up an item, if not holding one
	ld a, MON_ITEM
	call GetPartyParamLocation
	ld a, [hl]
	and a
	jr nz, .next
	ld a, 10
	call BattleRandomRange
	and a
	jr nz, .next
	push hl
	call GetRandomPickupItem
	pop hl
	ld [hl], a
	jr .next

.honey_gather
	; (level + 9) / 2 percent chance, floored to nearest 5%, to find honey
	ld a, MON_ITEM
	call GetPartyParamLocation
	ld a, [hl]
	and a
	jr nz, .next
	push hl
	ld a, 20
	call BattleRandomRange
	inc a
	ld c, a
	ld a, MON_LEVEL
	call GetPartyParamLocation
	ld a, [hl]
	add 9
	call SimpleDivide
	pop hl
	; success iff (level + 9) >= 10 * roll, i.e. quotient >= 10 - this makes
	; the chance floor((level + 9) / 10) * 5%, matching the formula above
	; (cp 11 was an off-by-one: it gave 0% below level 2 and ~5% less
	; everywhere else)
	ld a, b
	cp 10
	jr c, .next
	ld a, GOLD_BERRY ; no honey item; closest sweet treat
	ld [hl], a
	jr .next

GetRandomPickupItem:
; out: a = item
	ld a, 10
	call BattleRandomRange
	push hl
	ld hl, .items
	push bc
	ld c, a
	ld b, 0
	add hl, bc
	pop bc
	ld a, [hl]
	pop hl
	ret

.items
	db BERRY
	db GOLD_BERRY
	db SUPER_POTION
	db FULL_HEAL
	db ETHER
	db REVIVE
	db RARE_CANDY
	db NUGGET
	db MAX_POTION
	db ELIXER

RunNullificationAbilities::
; Called at the end of BattleCommand_Stab, on the attacker's turn, after
; wCurDamage and wTypeModifier are final. First checks type nullification;
; if the move goes through, applies ability damage modifiers to wCurDamage.
	; The AI reuses BattleCommand_Stab to PREDICT damage for each move it
	; is scoring (see AIDamageCalc). During that prediction we STILL run the
	; pure damage calc below - type/ability nullification and ability damage
	; modifiers - so the AI won't pick a move the target absorbs and it
	; accounts for boosts like Huge Power. Every LIVE side effect (banners,
	; heals, stat boosts, ability activations, wAttackMissed and flag writes)
	; is individually guarded by wAIDamagePrediction so it only fires on a
	; real hit; e.g. Motor Drive won't proc once per scored Electric move.
	ld a, [wAIDamagePrediction]
	and a
	jr nz, .prediction
	; clear a stale Disguise presentation flag (set by a move that missed
	; after damage calc and never reached its kingsrock command)
	ld hl, wDisguiseBusted + 1
	res 7, [hl]
.prediction
	call CheckAirBalloonImmunity
	ret c
	call .CheckNullification
	ret c ; nullified
	jp RunDamageModifiers

.CheckNullification:
	ld a, [wTypeModifier]
	and $7f
	jr nz, .not_immune
	and a ; clear carry
	ret
.not_immune
	call GetOpponentIgnorableAbility
	and a
	ret z
	cp DISGUISE
	jr nz, .not_disguise
	; Disguise only blocks damage. Status scripts run `stab` but never
	; `checkfaint`, so arming the deferred bust from Toxic/Thunder Wave
	; leaked the flag onto the next checkfaint-only move and busted the
	; wrong Pokemon (audit 2026-08-28 #5).
	push bc
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	pop bc
	jp nz, DisguiseBlock
.not_immune_done
	and a ; nc: not nullified
	ret
.not_disguise
	ld b, a
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	ld c, a
	ld hl, NullificationAbilities
.loop
	ld a, [hli]
	cp -1
	jr nz, .check
	jr .list_abilities ; type table exhausted; try move-list blockers
.check
	cp b
	jr nz, .next
	ld a, [hli]
	cp c
	jr z, .found
	inc hl
	inc hl
	jr .loop
.next
	inc hl
	inc hl
	inc hl
	jr .loop
.found
	; nullified: cancel the hit outright, like a natural immunity
	; (wTypeModifier alone does not stop applydamage - wCurDamage has
	; already been through the type-chart multiplication by now)
	xor a
	ld [wTypeModifier], a
	ld [wCurDamage], a
	ld [wCurDamage + 1], a
	; AI prediction: damage is zeroed above; skip the live absorb proc,
	; banner and miss flag so scoring stays a pure calculation.
	ld a, [wAIDamagePrediction]
	and a
	scf ; nullified
	ret nz
	; run the absorb effect on the defender's side
	ld a, [hli]
	ld h, [hl]
	ld l, a
	call SwitchTurn
	push hl
	call ShowAbilityBannerBrief
	pop hl
	call _hl_
	call SwitchTurn
	; flag the miss AFTER the effect (the stat-up helpers clear it)
	ld a, 1
	ld [wAttackMissed], a
	scf ; nullified
	ret

.list_abilities
	; Soundproof / Bulletproof / Wind Rider block whole move classes
	ld a, b
	push af
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	pop af
	ld de, 2
	cp SOUNDPROOF
	ld hl, SoundMoves
	jr z, .try_block
	cp BULLETPROOF
	ld hl, BallBombMoves
	jr z, .try_block
	cp WIND_RIDER
	jr nz, .no_block
	; Wind Rider also raises Attack when it blocks
	ld hl, WindMoves
	call IsInHalfwordArray
	jr nc, .no_block
	ld hl, AbsorbRaiseAttack
	jr .do_block
.try_block
	call IsInHalfwordArray
	jr nc, .no_block
	ld hl, AbsorbNothing
.do_block
	xor a
	ld [wTypeModifier], a
	ld [wCurDamage], a
	ld [wCurDamage + 1], a
	; AI prediction: damage zeroed above; skip banner, effect and miss flag.
	ld a, [wAIDamagePrediction]
	and a
	scf ; blocked
	ret nz
	call SwitchTurn
	push hl
	call ShowAbilityBannerBrief
	pop hl
	call _hl_
	call SwitchTurn
	ld a, 1
	ld [wAttackMissed], a
	scf ; blocked
	ret
.no_block
	and a ; nc
	ret

; ==== Ability-aware switch AI cores (farcalled from engine/battle/ai/switch.asm)

AISwitchAbilityAwareness:
; carry if the current trainer class has SWITCH_ABILITIES.
; Preserves bc, de. Clobbers a, hl.
	push bc
	ld hl, TrainerClassAttributes + TRNATTR_AI_ITEM_SWITCH
	; Battle Tower uses the first trainer class, like AI_SwitchOrTryItem
	ld a, [wInBattleTowerBattle]
	and a
	jr nz, .got_attr
	ld a, [wTrainerClass]
	dec a
	ld bc, NUM_TRAINER_ATTRIBUTES
	call AddNTimes
.got_attr
	ld a, BANK(TrainerClassAttributes)
	call GetFarByte
	pop bc
	bit SWITCH_ABILITIES_F, a
	scf
	ret nz
	and a ; nc
	ret

AIActiveEnemyAbilityNullifiesTypeFar::
; in: c = type of a player's move
; out: carry if the ACTIVE enemy mon's effective ability nullifies that
;      type (respecting the player's Mold Breaker and Neutralizing Gas).
	call AISwitchAbilityAwareness
	jr nc, .no
	ld a, [wPlayerAbility]
	cp MOLD_BREAKER
	jr z, .no
	push bc
	call GetEnemyAbilityEffective
	pop bc
	ld b, a
	jp AbilityNullifiesType
.no
	and a ; nc
	ret

AIPlayerAbilityNullifiesTypeFar::
; in: c = type of an enemy's move
; out: carry if the player's effective ability nullifies that type
;      (respecting the enemy's Mold Breaker and Neutralizing Gas).
	call AISwitchAbilityAwareness
	jr nc, .no
	ld a, [wEnemyAbility]
	cp MOLD_BREAKER
	jr z, .no
	push bc
	call GetPlayerAbilityEffective
	pop bc
	ld b, a
	jp AbilityNullifiesType
.no
	and a ; nc
	ret

AIPartyIndexAbilityNullifiesTypeFar::
; in: d = OT party index (0-5), c = move type
; out: carry if that party mon's ability nullifies the type
;      (respecting the player's Mold Breaker).
	call AISwitchAbilityAwareness
	jr nc, .no
	ld a, [wPlayerAbility]
	cp MOLD_BREAKER
	jr z, .no
	ld a, d
	ld hl, wOTPartyMon1
	push bc
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	pop bc
	push bc ; save c = move type
	ld c, [hl] ; species id
	ld de, MON_PERSONALITY
	add hl, de
	ld b, [hl] ; personality
	call GetAbility ; out: b = ability (clobbers c)
	pop de ; e = saved move type
	ld c, e
	jp AbilityNullifiesType
.no
	and a ; nc
	ret

AbilityNullifiesType::
; in: b = ability, c = move type
; out: carry if the ability grants a full immunity to that move type.
; Pure table lookup over NullificationAbilities (no live-battle state);
; farcalled by the switch AI. Preserves bc, de.
	push hl
	ld hl, NullificationAbilities
.loop
	ld a, [hli]
	cp -1
	jr z, .no
	cp b
	jr z, .match_ability
	inc hl ; skip type
	inc hl ; skip handler
	inc hl
	jr .loop
.match_ability
	ld a, [hli] ; type
	inc hl ; skip handler
	inc hl
	cp c
	jr nz, .loop
	scf
	jr .done
.no
	and a
.done
	pop hl
	ret

NullificationAbilities:
; ability, move type, handler
	db VOLT_ABSORB, ELECTRIC
	dw AbsorbHealQuarter
	db LIGHTNING_ROD, ELECTRIC
	dw AbsorbRaiseSpAtk
	db MOTOR_DRIVE, ELECTRIC
	dw AbsorbRaiseSpeed
	db WATER_ABSORB, WATER
	dw AbsorbHealQuarter
	db STORM_DRAIN, WATER
	dw AbsorbRaiseSpAtk
	db DRY_SKIN, WATER
	dw AbsorbHealQuarter
	db FLASH_FIRE, FIRE
	dw FlashFireRaiseHigherAttack
	db SAP_SIPPER, GRASS
	dw AbsorbRaiseAttack
	db LEVITATE, GROUND
	dw AbsorbNothing
	db -1

AbsorbHealQuarter:
	call CheckUserFullHP
	ret z ; immune, but nothing to heal
	farcall GetQuarterMaxHP
	call AbilityRestoreUserHP
	ld hl, RegainedHealthText
	jp StdBattleTextbox

AbsorbRaiseSpAtk:
	ld b, SP_ATTACK
	jr AbsorbRaiseStat
AbsorbRaiseSpeed:
	ld b, SPEED
	jr AbsorbRaiseStat
AbsorbRaiseAttack:
	ld b, ATTACK
AbsorbRaiseStat:
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	jp AbilityRaiseStat

AbsorbNothing:
	ret

FlashFireRaiseHigherAttack:
; Custom Flash Fire: absorb Fire and raise the holder's higher current
; offensive stat one stage. Compare the live, big-endian battle stats;
; Special Attack wins ties. These are normal, stacking stat stages.
	ld hl, wBattleMonAttack
	ld de, wBattleMonSpclAtk
	ldh a, [hBattleTurn]
	and a
	jr z, .compare
	ld hl, wEnemyMonAttack
	ld de, wEnemyMonSpclAtk
.compare
	ld c, 2
	call CompareBytes ; carry if Special Attack < Attack
	ld b, SP_ATTACK
	jr nc, .raise
	ld b, ATTACK
.raise
	jp AbsorbRaiseStat

FlashFireRaiseHigherAttackStatus:
; Will-O-Wisp is mid-status-effect; preserve its caller's failure state.
	ld a, [wAttackMissed]
	ld b, a
	ld a, [wEffectFailed]
	ld c, a
	push bc
	call FlashFireRaiseHigherAttack
	pop bc
	ld a, b
	ld [wAttackMissed], a
	ld a, c
	ld [wEffectFailed], a
	ret

CheckPlayerMoveRestrictions_Core:
; b = selected move. Carry + hl = reason text if the Assault Vest, Taunt
; or Torment forbids selecting it. (Replaces the old Assault Vest-only
; CheckPlayerAssaultVestMove_Core.)
	push bc
	callfar GetUserItem
	ld a, b
	cp HELD_ASSAULT_VEST
	jr nz, .no_vest
	ld a, [hl]
	call AbilityBufferItemName
	pop bc
	ld l, b
	ld a, MOVE_CATEGORY
	call GetMoveAttribute
	cp CATEGORIZE_STATUS
	jr z, .vest_blocked
	jr .taunt
.no_vest
	pop bc
.taunt
	ld a, [wPlayerTauntCount]
	and a
	jr z, .no_taunt
	ld l, b
	ld a, MOVE_CATEGORY
	call GetMoveAttribute
	cp CATEGORIZE_STATUS
	jr z, .taunt_blocked
.no_taunt
	ld a, [wPlayerSubStatus2]
	bit SUBSTATUS_TORMENTED, a
	jr z, .allowed
	ld a, [wLastPlayerMove]
	and a
	jr z, .allowed
	cp b
	jr z, .torment_blocked
.allowed
	and a
	ret
.vest_blocked
	ld hl, BattleText_AssaultVestPreventsMove
	scf
	ret
.taunt_blocked
	ld hl, BattleText_CantUseAfterTaunt
	scf
	ret
.torment_blocked
	ld hl, BattleText_MoveCantBeUsedTwice
	scf
	ret

PlayerMustStruggleExtra_Core:
; Carry if Taunt/Torment (on top of PP and Disable) leave the player
; without a single selectable move, forcing Struggle.
	ld a, [wPlayerTauntCount]
	and a
	jr nz, .restricted
	ld a, [wPlayerSubStatus2]
	bit SUBSTATUS_TORMENTED, a
	jr nz, .restricted
	and a
	ret
.restricted
	ld hl, wBattleMonMoves
	ld de, wBattleMonPP
	ld c, 0
.loop
	ld a, [hl]
	and a
	jr z, .next
	ld b, a
	ld a, [de]
	and PP_MASK
	jr z, .next
	ld a, [wDisabledMove]
	cp b
	jr z, .next
	ld a, [wPlayerTauntCount]
	and a
	jr z, .not_taunted
	push bc
	push de
	push hl
	ld l, b
	ld a, MOVE_CATEGORY
	call GetMoveAttribute
	pop hl
	pop de
	pop bc
	cp CATEGORIZE_STATUS
	jr z, .next
.not_taunted
	ld a, [wPlayerSubStatus2]
	bit SUBSTATUS_TORMENTED, a
	jr z, .legal
	ld a, [wLastPlayerMove]
	cp b
	jr z, .next
.legal
	and a
	ret
.next
	inc hl
	inc de
	inc c
	ld a, c
	cp NUM_MOVES
	jr c, .loop
	scf
	ret

CheckPlayerChoiceLock_Core:
; b = selected move. Carry if a Choice item locks another move.
	push bc
	callfar GetUserItem
	ld a, b
	sub HELD_CHOICE_BAND
	cp HELD_CHOICE_SCARF - HELD_CHOICE_BAND + 1
	jr nc, .not_choice
	ld a, [hl]
	call AbilityBufferItemName
	pop bc
	ld a, [wPlayerChoiceLockedMove]
	and a
	jr z, .set_lock
	cp b
	jr nz, .blocked
	and a
	ret
.set_lock
	ld a, b
	ld [wPlayerChoiceLockedMove], a
	and a
	ret
.not_choice
	pop bc
	xor a
	ld [wPlayerChoiceLockedMove], a
	and a
	ret
.blocked
; a = locked move id, b = selected move id.
; If the locked move can't be used anymore (no PP or disabled), the
; holder must Struggle - like the enemy handler - instead of leaving
; the player soft-locked in the move menu.
	ld c, a
	ld a, [wDisabledMove]
	cp c
	jr z, .must_struggle
	ld hl, wBattleMonMoves
	ld de, wBattleMonPP
	push bc
	ld b, NUM_MOVES
.find_locked
	ld a, [hli]
	cp c
	jr z, .found_locked
	inc de
	dec b
	jr nz, .find_locked
	; the locked move is gone (e.g. overwritten): drop the lock
	pop bc
	ld a, b
	ld [wPlayerChoiceLockedMove], a
	and a
	ret
.found_locked
	pop bc
	ld a, [de]
	and PP_MASK
	jr z, .must_struggle
	scf
	ret
.must_struggle
	ld hl, STRUGGLE
	call GetMoveIDFromIndex
	ld b, a
	and a
	ret


HandleEnemyHeldMoveLocks_Core:
	call .item_locks
	; Taunt: a taunted enemy must not pick a status move
	ld a, [wEnemyTauntCount]
	and a
	jr z, .no_taunt
	ld a, [wCurEnemyMove]
	call EnemyMoveIsStatus
	jr nc, .no_taunt
	call FindFirstEnemyDamagingMove
	jr c, .no_taunt
	jp ForceEnemyStruggle
.no_taunt
	; Torment: not the same move twice in a row
	ld a, [wEnemySubStatus2]
	bit SUBSTATUS_TORMENTED, a
	ret z
	push bc
	ld hl, STRUGGLE
	call GetMoveIDFromIndex
	ld b, a
	ld a, [wCurEnemyMove]
	cp b
	pop bc
	ret z ; Struggle is always legal
	ld b, a
	ld a, [wLastEnemyMove]
	and a
	ret z
	cp b
	ret nz
	call FindEnemyMoveNotB
	ret c
	jp ForceEnemyStruggle

.item_locks
	call SetEnemyTurn
	callfar GetUserItem
	ld a, b
	cp HELD_ASSAULT_VEST
	jr z, .assault_vest
	sub HELD_CHOICE_BAND
	cp HELD_CHOICE_SCARF - HELD_CHOICE_BAND + 1
	jr nc, .not_choice
	ld a, [wEnemyChoiceLockedMove]
	and a
	jr nz, .use_locked
	ld a, [wCurEnemyMove]
	and a
	ret z
	ld [wEnemyChoiceLockedMove], a
	ret
.use_locked
	ld b, a
	call FindEnemyMoveWithPP
	ret c
	jr ForceEnemyStruggle
.not_choice
	xor a
	ld [wEnemyChoiceLockedMove], a
	ret
.assault_vest
	xor a
	ld [wEnemyChoiceLockedMove], a
	ld a, [wCurEnemyMove]
	call EnemyMoveIsStatus
	ret nc
	call FindFirstEnemyDamagingMove
	ret c
	; fallthrough
ForceEnemyStruggle:
	ld hl, STRUGGLE
	call GetMoveIDFromIndex
	ld [wCurEnemyMove], a
	ret

FindEnemyMoveWithPP:
; b = move id. Carry if the enemy can use it.
	ld hl, wEnemyMonMoves
	ld de, wEnemyMonPP
	ld c, 0
.loop
	ld a, [hli]
	cp b
	jr nz, .next
	ld a, [wEnemyDisabledMove]
	cp b
	jr z, .no
	ld a, [de]
	and PP_MASK
	jr z, .no
	ld a, c
	ld [wCurEnemyMoveNum], a
	ld a, b
	ld [wCurEnemyMove], a
	scf
	ret
.next
	inc de
	inc c
	ld a, c
	cp NUM_MOVES
	jr c, .loop
.no
	and a
	ret

FindEnemyMoveNotB:
; b = forbidden move id. Carry if a usable other move was found and
; loaded into wCurEnemyMove(Num). Respects PP, Disable and Taunt.
	ld hl, wEnemyMonMoves
	ld de, wEnemyMonPP
	ld c, 0
.loop
	ld a, [hl]
	and a
	jr z, .next
	cp b
	jr z, .next
	push bc
	ld b, a
	ld a, [wEnemyDisabledMove]
	cp b
	jr z, .next_pop
	ld a, [de]
	and PP_MASK
	jr z, .next_pop
	ld a, [wEnemyTauntCount]
	and a
	jr z, .usable
	ld a, b
	push hl
	push de
	call EnemyMoveIsStatus ; clobbers hl
	pop de
	pop hl
	jr c, .next_pop
.usable
	ld a, c
	pop bc
	; a still holds c? no - reload slot below
	ld a, [hl]
	push af
	ld a, c
	ld [wCurEnemyMoveNum], a
	pop af
	ld [wCurEnemyMove], a
	scf
	ret
.next_pop
	pop bc
.next
	inc hl
	inc de
	inc c
	ld a, c
	cp NUM_MOVES
	jr c, .loop
	and a
	ret

FindFirstEnemyDamagingMove:
	ld hl, wEnemyMonMoves
	ld de, wEnemyMonPP
	ld c, 0
.loop
	ld a, [hli]
	and a
	jr z, .next
	ld b, a
	ld a, [wEnemyDisabledMove]
	cp b
	jr z, .next
	ld a, [de]
	and PP_MASK
	jr z, .next
	ld a, b
	push hl
	push de
	call EnemyMoveIsStatus ; clobbers hl (GetMoveAttribute)
	pop de
	pop hl
	jr c, .next
	ld a, c
	ld [wCurEnemyMoveNum], a
	ld a, b
	ld [wCurEnemyMove], a
	scf
	ret
.next
	inc de
	inc c
	ld a, c
	cp NUM_MOVES
	jr c, .loop
	and a
	ret

EnemyMoveIsStatus:
; Carry if move a is status.
	ld l, a
	ld a, MOVE_CATEGORY
	call GetMoveAttribute
	cp CATEGORIZE_STATUS
	jr z, .status
	and a
	ret
.status
	scf
	ret

RunDamageModifiers:
; Apply ability-based damage modifiers to wCurDamage.
; Attacker = current turn holder. Physical/special moves only.
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	ret z
	ld e, a ; e = category
	call ApplyHeldItemDamageModifiers

	; ---- attacker's ability ----
	call GetTrueUserAbility
	ld d, a
	cp ANALYTIC
	jp z, .analytic
	cp SHEER_FORCE
	jp z, .sheer_force
	cp SNIPER
	jp z, .sniper
	cp RIVALRY
	jp z, .rivalry
	cp TOUGH_CLAWS
	jp z, .tough_claws
	cp IRON_FIST
	jp z, .iron_fist
	cp SHARPNESS
	jp z, .sharpness
	cp RECKLESS
	jp z, .reckless
	cp ADAPTABILITY
	jp z, .adaptability
	cp STEELY_SPIRIT
	jp z, .steely_spirit
	cp MEGA_LAUNCHER
	jp z, .mega_launcher
	cp MEGA_SOL
	jp z, .mega_sol
	cp SAND_FORCE
	jp z, .sand_force
	cp HUGE_POWER
	jr z, .huge_power
	cp GUTS
	jr z, .guts
	cp HUSTLE
	jr z, .hustle
	cp TECHNICIAN
	jr z, .technician
	cp TINTED_LENS
	jr z, .tinted_lens
	cp STRONG_JAW
	jp z, .strong_jaw
	cp SUPREME_OVERLORD
	jp z, .supreme_overlord
	cp SOLAR_POWER
	jr z, .solar_power
	cp OVERGROW
	ld b, GRASS
	jr z, .pinch_boost
	cp BLAZE
	ld b, FIRE
	jr z, .pinch_boost
	cp TORRENT
	ld b, WATER
	jr z, .pinch_boost
	cp SWARM
	ld b, BUG
	jr z, .pinch_boost
	call CheckAteAbilityBoost
	jr nc, .defender
	call DamageX1_2
	jr .defender

.huge_power
	ld a, e
	and a ; CATEGORIZE_PHYSICAL == 0
	jr nz, .defender
	call DoubleDamage
	jr .defender

.guts
	ld a, e
	and a
	jr nz, .defender
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and a
	jr z, .defender
	; Guts ignores the burn attack cut: an extra x2 when burned makes
	; the net effect x1.5 of unburned damage
	bit BRN, a
	jr z, .guts_boost
	; Facade's damage-stat loader already restores its unburned Attack.
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_FACADE
	jr z, .guts_boost
	call DoubleDamage
.guts_boost
	call DamageX1_5
	jr .defender

.hustle
	ld a, e
	and a ; physical?
	jr nz, .defender
	call DamageX1_5
	jr .defender

.technician
	ld a, BATTLE_VARS_MOVE_POWER
	call GetBattleVar
	cp 60 + 1
	jr nc, .defender
	call DamageX1_5
	jr .defender

.tinted_lens
	ld a, [wTypeModifier]
	and $7f
	cp EFFECTIVE
	jr nc, .defender
	call DoubleDamage
	jr .defender

.solar_power
	ld a, e
	cp CATEGORIZE_SPECIAL
	jr nz, .defender
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jr nz, .defender
	call DamageX1_5
	jr .defender

.pinch_boost
	; 1.5x for the matching type when at 1/3 max HP or less
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp b
	jr nz, .defender
	call CheckUserThirdHP
	jr nc, .defender
	call DamageX1_5
	; fallthrough

.defender
	; ---- defender's ability ----
	call GetOpponentIgnorableAbility
	ld d, a
	cp THICK_FAT
	jr z, .thick_fat
	cp MULTISCALE
	jr z, .multiscale
	cp FUR_COAT
	jr z, .fur_coat
	cp MARVEL_SCALE
	jr z, .marvel_scale
	cp FILTER
	jr z, .filter
	cp SOLID_ROCK
	jr z, .filter
	cp DRY_SKIN
	jr z, .dry_skin
	cp FLUFFY
	jr z, .fluffy
	ret

.thick_fat
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	jp z, HalveDamage
	cp ICE
	jp z, HalveDamage
	ret

.multiscale
	call SwitchTurn
	call CheckUserFullHP
	call SwitchTurn
	ret nz
	jp HalveDamage

.fur_coat
	ld a, e
	and a ; physical?
	ret nz
	jp HalveDamage

.marvel_scale
	; A 1.5x Defense boost is equivalent to two-thirds physical damage.
	ld a, e
	and a
	ret nz
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret z
	jp DamageX2_3

.filter
	ld a, [wTypeModifier]
	and $7f
	cp EFFECTIVE + 1
	ret c ; not super effective
	cp SUPER_EFFECTIVE * 2
	jp nc, HalveDamage
	jp DamageX0_75

.dry_skin
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	ret nz
	jp DamageX1_25

.fluffy
	; halves contact damage, but doubles Fire damage taken (both can apply)
	call CheckContactMove
	jr nc, .fluffy_fire
	call HalveDamage
.fluffy_fire
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	ret nz
	jp DoubleDamage

.strong_jaw
	; x1.5 for biting moves
	push de
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	ld de, 2
	ld hl, BiteMoves
	call IsInHalfwordArray
	pop de
	jp nc, .defender
	call DamageX1_5
	jp .defender

.supreme_overlord
	; ~+10% damage for each fainted ally (x1.09375 each, additive)
	push de
	call CountFaintedAllies
	pop de
	and a
	jp z, .defender
	call SupremeOverlordBoost
	jp .defender

.analytic
	; x1.3 if the user moved last this turn
	ld a, [wEnemyGoesFirst] ; 0 if the player went first
	ld b, a
	ldh a, [hBattleTurn]
	and a
	jr z, .analytic_player
	; enemy attacker: boost only if the player went first
	ld a, b
	and a
	jp nz, .defender
	jr .analytic_boost
.analytic_player
	; player attacker: boost only if the enemy went first
	ld a, b
	and a
	jp z, .defender
.analytic_boost
	ld a, 130
	call DamagePercent
	jp .defender

.sheer_force
	; x1.3 only when the move has a removable secondary effect. MOVE_CHANCE
	; alone is not enough: guaranteed self-drops and Thief also use that byte.
	call CurrentMoveHasSheerForceEffect
	jp nc, .defender
	ld a, 130
	call DamagePercent
	jp .defender

.sniper
	; x1.5 damage on critical hits
	ld a, [wCriticalHit]
	and a
	jp z, .defender
	call DamageX1_5
	jp .defender

.rivalry
	; x1.25 vs the same gender, x0.75 vs the opposite gender
	push de
	call CheckGenderMatchup
	pop de
	and a
	jr z, .rivalry_boost
	dec a
	jp nz, .defender ; genderless involved: no change
	call DamageX0_75
	jp .defender
.rivalry_boost
	call DamageX1_25
	jp .defender

.tough_claws
	; x1.3 for contact moves
	call CheckContactMove
	jp nc, .defender
	ld a, 130
	call DamagePercent
	jp .defender

.iron_fist
	; x1.2 for punching moves
	ld hl, PunchMoves
	call CurrentMoveInList
	jp nc, .defender
	call DamageX1_2
	jp .defender

.sharpness
	; x1.5 for slicing moves
	ld hl, SliceMoves
	call CurrentMoveInList
	jp nc, .defender
	call DamageX1_5
	jp .defender

.mega_launcher
	; x1.5 for pulse moves
	ld hl, PulseMoves
	call CurrentMoveInList
	jp nc, .defender
	call DamageX1_5
	jp .defender

.reckless
	; x1.2 for recoil and crash-damage moves
	; Struggle uses fixed max-HP recoil, which does not qualify.
	push bc
	ld a, BATTLE_VARS_MOVE
	call GetBattleVar
	ld bc, STRUGGLE
	farcall_a CompareMove
	pop bc
	jp z, .defender
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_RECOIL_HIT
	jr z, .reckless_boost
	cp EFFECT_FLARE_BLITZ
	jr z, .reckless_boost
	cp EFFECT_VOLT_TACKLE
	jr z, .reckless_boost
	cp EFFECT_JUMP_KICK
	jp nz, .defender
.reckless_boost
	call DamageX1_2
	jp .defender

.adaptability
	; STAB becomes x2 (an extra x1.33 on top of the normal x1.5)
	push hl
	ld hl, wBattleMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .adapt_got_types
	ld hl, wEnemyMonType1
.adapt_got_types
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp [hl]
	inc hl
	jr z, .adapt_boost
	cp [hl]
	jr z, .adapt_boost
	pop hl
	jp .defender
.adapt_boost
	pop hl
	ld a, 133
	call DamagePercent
	jp .defender

.steely_spirit
	; x1.5 for Steel-type moves
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp STEEL
	jp nz, .defender
	call DamageX1_5
	jp .defender

.sand_force
	; x1.3 for Rock/Ground/Steel moves in a sandstorm
	ld a, [wBattleWeather]
	cp WEATHER_SANDSTORM
	jp nz, .defender
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp ROCK
	jr z, .sand_force_boost
	cp GROUND
	jr z, .sand_force_boost
	cp STEEL
	jp nz, .defender
.sand_force_boost
	ld a, 130
	call DamagePercent
	jp .defender

.mega_sol
	; the user's moves act as if Sunny Day were active:
	; Fire x1.5, Water x0.5 (compensating if rain is really up)
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jp z, .defender ; real sun already applied
	cp WEATHER_RAIN
	jr z, .mega_sol_rain
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	jr z, .mega_sol_fire
	cp WATER
	jp nz, .defender
	call HalveDamage
	jp .defender
.mega_sol_fire
	call DamageX1_5
	jp .defender
.mega_sol_rain
	; rain already halved Fire / boosted Water - convert to sun's numbers
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	jr z, .mega_sol_rain_fire
	cp WATER
	jp nz, .defender
	ld a, 33 ; x1.5 rain boost -> x0.5 net
	call DamagePercent
	jp .defender
.mega_sol_rain_fire
	call DoubleDamage
	call DamageX1_5 ; x0.5 rain cut -> x1.5 net
	jp .defender

ApplyHeldItemDamageModifiers:
	callfar GetUserItem
	ld a, b
	cp HELD_CHOICE_BAND
	jr z, .physical_50
	cp HELD_CHOICE_SPECS
	jr z, .special_50
	cp HELD_EXPERT_BELT
	jr z, .expert_belt
	cp HELD_LIFE_ORB
	jr z, .life_orb
	cp HELD_MUSCLE_BAND
	jr z, .physical_10
	cp HELD_WISE_GLASSES
	jr z, .special_10
	ret
.physical_50
	ld a, e
	and a
	ret nz
	ld a, 150
	jp DamagePercent
.special_50
	ld a, e
	cp CATEGORIZE_SPECIAL
	ret nz
	ld a, 150
	jp DamagePercent
.expert_belt
	ld a, [wTypeModifier]
	and $7f
	cp EFFECTIVE + 1
	ret c
	ld a, 120
	jp DamagePercent
.life_orb
	ld a, 130
	jp DamagePercent
.physical_10
	ld a, e
	and a
	ret nz
	ld a, 110
	jp DamagePercent
.special_10
	ld a, e
	cp CATEGORIZE_SPECIAL
	ret nz
	ld a, 110
	jp DamagePercent

GetMoveCategory::
; a = current move's damage category
	push hl
	ld hl, wPlayerMoveStructCategory
	ldh a, [hBattleTurn]
	and a
	jr z, .got
	ld hl, wEnemyMoveStructCategory
.got
	ld a, [hl]
	pop hl
	ret

CheckUserThirdHP:
; carry if the user's HP is at 1/3 max or below
	push hl
	push de
	push bc
	ld hl, wBattleMonHP
	ldh a, [hBattleTurn]
	and a
	jr z, .got_hp
	ld hl, wEnemyMonHP
.got_hp
	; bc = HP * 3 (with overflow guard in a)
	ld a, [hli]
	ld b, a
	ld a, [hli]
	ld c, a
	push hl
	ld h, b
	ld l, c
	add hl, bc
	jr c, .no ; HP*2 overflowed; certainly above 1/3
	add hl, bc
	jr c, .no
	ld b, h
	ld c, l
	pop hl
	; compare with max HP: carry if HP*3 <= MaxHP i.e. MaxHP >= HP*3
	ld a, [hli]
	cp b
	jr c, .no_pop
	jr nz, .yes
	ld a, [hl]
	cp c
	jr c, .no_pop
.yes
	scf
	jr .done
.no
	pop hl
.no_pop
	and a
.done
	pop bc
	pop de
	pop hl
	ret

; ---- wCurDamage fraction helpers ----
DamagePercent:
; a = percent multiplier for wCurDamage. Preserves de.
	push hl
	push bc
	push de
	ldh [hMultiplier], a
	xor a
	ldh [hMultiplicand + 0], a
	ld hl, wCurDamage
	ld a, [hli]
	ldh [hMultiplicand + 1], a
	ld a, [hl]
	ldh [hMultiplicand + 2], a
	call Multiply
	ld a, 100
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ld hl, wCurDamage
	ldh a, [hQuotient + 2]
	ld [hli], a
	ldh a, [hQuotient + 3]
	ld [hl], a
	pop de
	pop bc
	pop hl
	ret

DamageX2_3:
; Exact floor(2 * wCurDamage / 3), minimum 1. Preserves bc and de.
	push hl
	push bc
	push de
	xor a
	ldh [hMultiplicand + 0], a
	ld hl, wCurDamage
	ld a, [hli]
	ldh [hMultiplicand + 1], a
	ld a, [hl]
	ldh [hMultiplicand + 2], a
	ld a, 2
	ldh [hMultiplier], a
	call Multiply
	ld a, 3
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 2]
	ld b, a
	ldh a, [hQuotient + 3]
	ld c, a
	ld a, b
	or c
	jr nz, .store
	inc c
.store
	ld a, b
	ld [wCurDamage], a
	ld a, c
	ld [wCurDamage + 1], a
	pop de
	pop bc
	pop hl
	ret

DoubleDamage:
	push hl
	ld hl, wCurDamage
	ld a, [hli]
	ld l, [hl]
	ld h, a
	add hl, hl
	jr nc, .store
	ld hl, $ffff
.store
	ld a, h
	ld [wCurDamage], a
	ld a, l
	ld [wCurDamage + 1], a
	pop hl
	ret

DamageX1_5:
	push hl
	push de
	ld hl, wCurDamage
	ld a, [hli]
	ld l, [hl]
	ld h, a
	ld d, h
	ld e, l
	srl d
	rr e
	add hl, de
	jr nc, .store
	ld hl, $ffff
.store
	ld a, h
	ld [wCurDamage], a
	ld a, l
	ld [wCurDamage + 1], a
	pop de
	pop hl
	ret

DamageX1_2:
; Exact 120% multiplier used by -ate abilities, Iron Fist and Reckless.
	ld a, 120
	jp DamagePercent

DamageX1_25:
	push hl
	push de
	ld hl, wCurDamage
	ld a, [hli]
	ld l, [hl]
	ld h, a
	ld d, h
	ld e, l
	srl d
	rr e
	srl d
	rr e
	add hl, de
	jr nc, .store
	ld hl, $ffff
.store
	ld a, h
	ld [wCurDamage], a
	ld a, l
	ld [wCurDamage + 1], a
	pop de
	pop hl
	ret

DamageX0_75:
	push hl
	push de
	ld hl, wCurDamage
	ld a, [hli]
	ld l, [hl]
	ld h, a
	ld d, h
	ld e, l
	srl d
	rr e
	srl d
	rr e
	ld a, l
	sub e
	ld l, a
	ld a, h
	sbc d
	ld h, a
	jr HalveDamage.store_min1

DamageX0_69:
; x11/16: half + eighth + sixteenth
	push hl
	push de
	ld hl, wCurDamage
	ld a, [hli]
	ld l, [hl]
	ld h, a
	ld d, h
	ld e, l
	srl d
	rr e ; 1/2
	push de
	srl d
	rr e
	srl d
	rr e ; 1/8
	ld h, d
	ld l, e
	srl d
	rr e ; 1/16
	add hl, de
	pop de
	add hl, de
	jr HalveDamage.store_min1

HalveDamage:
	push hl
	push de
	ld hl, wCurDamage
	ld a, [hli]
	ld l, [hl]
	ld h, a
	srl h
	rr l
.store_min1
	ld a, h
	or l
	jr nz, .store
	ld l, 1
.store
	ld a, h
	ld [wCurDamage], a
	ld a, l
	ld [wCurDamage + 1], a
	pop de
	pop hl
	ret

StatDropSubCheckExempt::
; Carry if the opponent's Magic Bounce will reflect this stat-drop move:
; the bounce works even from behind the holder's own Substitute, so the
; caller must skip its Substitute bail and let AbilityProtectsStatDrop's
; magic_bounce_drop path handle it. Secondary drops of damaging moves
; (non-STATUS category) are still blocked by the sub, per canon.
	call GetOpponentIgnorableAbility
	cp MAGIC_BOUNCE
	jr nz, .no
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	jr nz, .no
	scf
	ret
.no
	and a ; nc
	ret

ContraryInvertsSelfDrop::
; Self-inflicted drops (Superpower & co.) arrive through switchturn, so
; the drop's target is the turn holder's opponent = the move's own user.
; Canon: Contrary inverts those drops into raises. Carry if inverted
; (the raise is fully resolved; the caller silences the down-message).
	ld a, [wAttackMissed]
	and a
	jr z, .try
	; move missed / was absorbed: no drop happens, nothing to invert
	and a ; nc
	ret
.try
	ld a, [wEffectFailed]
	and a
	jr nz, .no
	call GetOpponentAbility
	cp CONTRARY
	jp z, AbilityProtectsStatDrop.contrary
.no
	and a ; nc
	ret

AbilityProtectsStatDrop::
; Carry if the opponent's (stat-drop target's) ability protects the stat
; in wLoweredStat. Shows the ability banner when it does.
	call GetOpponentIgnorableAbility
	and a
	ret z ; nc
	ld b, a
	cp MIRROR_ARMOR
	jr z, .mirror_armor
	cp MAGIC_BOUNCE
	jr z, .magic_bounce_drop
	cp CONTRARY
	jr z, .contrary
	cp CLEAR_BODY
	jr z, .protected
	cp WHITE_SMOKE
	jr z, .protected
	ld a, [wLoweredStat]
	and $f
	ld c, a
	ld a, b
	cp HYPER_CUTTER
	jr nz, .not_atk
	ld a, c
	cp ATTACK
	jr z, .protected
	jr .no
.not_atk
	cp KEEN_EYE
	jr z, .check_acc
	cp MINDS_EYE
	jr nz, .not_acc
.check_acc
	ld a, c
	cp ACCURACY
	jr z, .protected
	jr .no
.not_acc
	cp BIG_PECKS
	jr nz, .no
	ld a, c
	cp DEFENSE
	jr z, .protected
.no
	and a ; nc
	ret
.protected
	call ShowEnemyAbilityBannerBrief
	scf
	ret

.contrary
	; Contrary: drops on the holder become raises (any source, incl.
	; Intimidate). The bit-7 marker stops ContraryCheckRaise from
	; re-inverting the synthetic raise.
	call ShowEnemyAbilityBannerBrief
	ld a, [wLoweredStat]
	and $1f
	ld b, a
	ld a, [wLoweredStat]
	or $80
	ld [wLoweredStat], a
	call SwitchTurn
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	call AbilityRaiseStat
	call SwitchTurn
	scf ; the original drop "fails"
	ret

.magic_bounce_drop
	; Magic Bounce reflects stat drops from STATUS moves only - not from
	; abilities (Intimidate/Tangling Hair, flagged via bit 6) and not from
	; secondary effects of damaging moves.
	ld a, [wDisguiseBusted]
	bit 6, a
	jr nz, .no
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	jr nz, .no
	; fallthrough: bounce it exactly like Mirror Armor
.mirror_armor
	; bounce the drop back at its source (no ping-pong between two
	; Mirror Armors: while the guard bit is set, take the drop instead)
	ld a, [wDisguiseBusted]
	bit 7, a
	jr nz, .no
	call ShowEnemyAbilityBannerBrief
	ld hl, wDisguiseBusted
	set 7, [hl]
	ld a, [wLoweredStat]
	ld b, a ; stat | possible $10 sharp-drop flag
	call StackCallOpponentTurn
	; (defender's perspective from here; ret unswitches)
	call AbilityLowerOppStat
	ld hl, wDisguiseBusted
	res 7, [hl]
	scf
	ret

AbilityImmuneToSandstorm::
; Carry if the current turn holder's ability grants sandstorm immunity.
	call GetTrueUserAbility
	cp SAND_VEIL
	jr z, WeatherImmune
	cp SAND_RUSH
	jr z, WeatherImmune
	cp SAND_FORCE
	jr z, WeatherImmune
	jr WeatherImmuneCommon

AbilityImmuneToHail::
; Carry if the current turn holder's ability grants hail immunity.
	call GetTrueUserAbility
	cp ICE_BODY
	jr z, WeatherImmune
	cp SNOW_CLOAK
	jr z, WeatherImmune
	cp SLUSH_RUSH
	jr z, WeatherImmune
	; fallthrough
WeatherImmuneCommon:
	cp OVERCOAT
	jr z, WeatherImmune
	cp MAGIC_GUARD
	jr z, WeatherImmune
	and a ; nc
	ret
WeatherImmune:
	scf
	ret

AbilityPreHitTargetBlock::
; Carry if an opponent-targeted move is blocked before accuracy handling.
; This must run at the very start of checkhit so Lock-On, X Accuracy,
; always-hit effects and weather accuracy shortcuts cannot bypass it.
	; Since Gen VII, Dark-type opponents are immune to status moves whose
	; priority was raised by Prankster. This hook only receives moves that
	; actually target the opposing Pokemon, so self/side moves remain valid.
	call GetTrueUserAbility
	cp PRANKSTER
	jr nz, .not_prankster
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	jr nz, .not_prankster
	ld a, DARK
	call OpponentIsType
	jr nz, .not_prankster
	scf
	ret
.not_prankster
	; Armor Tail / Queenly Majesty fail increased-priority moves outright.
	; "Priority" is EFFECTIVE priority, counting Prankster/Gale Wings/Triage.
	call GetOpponentIgnorableAbility
	cp ARMOR_TAIL
	jr z, .priority_block
	cp QUEENLY_MAJESTY
	jp nz, AbilityAccuracyMods.status_class_block
.priority_block
	call AbilityAccuracyMods.armor_tail_blocks
	jr nc, AbilityAccuracyMods.status_class_block
	call ShowEnemyAbilityBannerBrief
	scf
	ret

AbilityPreExecutionTargetBlock::
; Some selected-foe status moves do not use checkhit. Carry if one of those
; is blocked by Armor Tail / Queenly Majesty. Side-targeting hazards and
; user-targeting moves (including Psych Up) deliberately are not listed.
; Preserves bc, de and hl so BattleCommand_DoTurn can keep its PP/status
; pointers live across this farcall.
	push hl
	push de
	push bc
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_CURSE
	jr z, .curse
	ld hl, .effects
	ld de, 1
	call IsInArray
	jr nc, .not_blocked
	jr .check_ability
.curse
	; Curse targets the foe only when its user is a Ghost type.
	ld hl, wBattleMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wEnemyMonType1
.got_types
	ld a, [hli]
	cp GHOST
	jr z, .check_ability
	ld a, [hl]
	cp GHOST
	jr nz, .not_blocked
.check_ability
	call AbilityPreHitTargetBlock
	jr .done
.not_blocked
	and a ; nc
.done
	pop bc
	pop de
	pop hl
	ret

.effects
	db EFFECT_MEAN_LOOK
	db EFFECT_NIGHTMARE
	db EFFECT_SKETCH
	db EFFECT_TRANSFORM
	db -1

AbilityAccuracyMods::
; b = hit chance (0-255, -1 = never miss). Modify per abilities.
	; Priority immunities and status Soundproof/Wind Rider are handled by
	; AbilityPreHitTargetBlock before checkhit's unconditional-hit exits.
	; True always-hit effects, Lock-On, X Accuracy, and weather guarantees
	; have already returned in the caller. Here $ff can be an ordinary 100%
	; move, which evasion and accuracy abilities must still modify.
	; No Guard on either side: always hits
	call GetTrueUserAbility
	cp NO_GUARD
	jp z, .always_hit
	call GetOpponentAbility
	cp NO_GUARD
	jp z, .always_hit
	; attacker mods (jp: the status-class block is between here and there)
	call GetTrueUserAbility
	cp COMPOUND_EYES
	jp z, .compound_eyes
	cp HUSTLE
	jp z, .hustle
.defender
	call GetOpponentIgnorableAbility
	cp SAND_VEIL
	jp z, .sand_veil
	cp SNOW_CLOAK
	jp z, .snow_cloak
	cp TANGLED_FEET
	jp z, .tangled_feet
	cp WONDER_SKIN
	jp z, .wonder_skin
	ret

.status_class_block
	; Damaging sound/wind/Grass moves are nullified after damage
	; calculation, but status moves never reach that hook. Block them
	; during accuracy setup.
	; If an earlier command already failed the move, don't block (and
	; banner/boost) a second time: DoParalyze runs stab before checkhit,
	; so Sap Sipper absorbs Stun Spore from the Stab nullification hook.
	ld a, [wAttackMissed]
	and a
	jr nz, .class_not_blocked
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	jr nz, .class_not_blocked
	call GetOpponentIgnorableAbility
	cp SOUNDPROOF
	jr z, .soundproof_status
	cp WIND_RIDER
	jr z, .wind_rider_status
	cp SAP_SIPPER
	jr z, .sap_sipper_status
	cp OVERCOAT
	jr z, .overcoat_status
	jr .class_not_blocked
.soundproof_status
	ld hl, SoundMoves
	jr .block_if_in_list
.overcoat_status
	; powder and spore moves don't affect an Overcoat holder
	ld hl, PowderMoves
.block_if_in_list
	push bc
	call CurrentMoveInList
	pop bc
	jr nc, .class_not_blocked
	call ShowEnemyAbilityBannerBrief
	ld b, 0
	scf
	ret
.sap_sipper_status
	; Sap Sipper absorbs any Grass move targeting the holder; the status
	; ones (Sleep Powder, Spore, Cotton Spore, Leech Seed...) land here
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp GRASS
	jr nz, .class_not_blocked
	jr .absorb_status
.wind_rider_status
	push bc
	ld hl, WindMoves
	call CurrentMoveInList
	pop bc
	jr nc, .class_not_blocked
.absorb_status
	; same convention as RunNullificationAbilities.found: the banner and
	; the +1 Atk absorb handler run from the defender's perspective
	call SwitchTurn
	call ShowAbilityBannerBrief
	call AbsorbRaiseAttack
	call SwitchTurn
	ld b, 0
	scf
	ret
.class_not_blocked
	and a
	ret

.always_hit
	ld b, -1
	ret

.compound_eyes
	ld a, 130
	call AccuracyPercent
	jp .defender ; jp: the status-class block pushed .defender out of jr range

.hustle
	; physical moves only: x0.8
	call GetMoveCategory
	and a ; CATEGORIZE_PHYSICAL
	jp nz, .defender
	jr ReduceAccuracyQuarter_Defender

.sand_veil
	ld a, [wBattleWeather]
	cp WEATHER_SANDSTORM
	ret nz
	jr ReduceAccuracyQuarter
.snow_cloak
	ld a, [wBattleWeather]
	cp WEATHER_HAIL
	ret nz
	jr ReduceAccuracyQuarter

.tangled_feet
	; only while the defender is confused
	ld a, BATTLE_VARS_SUBSTATUS3_OPP
	call GetBattleVar
	bit SUBSTATUS_CONFUSED, a
	ret z
	srl b
	ret

.wonder_skin
	; status moves get 50% accuracy at most
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	ret nz
	ld a, b
	cp 50 percent + 1
	ret c
	ld b, 50 percent + 1
	ret

.armor_tail_blocks
; carry if the attacker's move has increased EFFECTIVE priority
; (base priority plus the attacker's Prankster/Gale Wings/Triage boosts)
	push bc
	call .armor_tail_move
	and a
	jr z, .armor_tail_ok ; no move (item/switch edge case)
	ld e, a
	farcall GetMovePriority_e
	ld d, e ; d = base priority
	call .armor_tail_move
	ld b, a ; b = move id
	call GetTrueUserAbility
	ld c, a ; c = the attacker's effective ability
	call AbilityCompareMovePriority.Adjust
	ld a, d
	cp BASE_PRIORITY + 1
	jr c, .armor_tail_ok ; normal or negative priority
	pop bc
	scf
	ret
.armor_tail_ok
	pop bc
	and a
	ret

.armor_tail_move
; a = the attacker's chosen move id
	ldh a, [hBattleTurn]
	and a
	ld a, [wCurPlayerMove]
	ret z
	ld a, [wCurEnemyMove]
	ret

ReduceAccuracyQuarter_Defender:
	call ReduceAccuracyQuarter
	jp AbilityAccuracyMods.defender
ReduceAccuracyQuarter:
; Exact 80% accuracy multiplier.
	ld a, 80
	jr AccuracyPercent

AccuracyPercent:
; a = percent, b = hit chance. Returns floor(b * a / 100) in b,
; capped below the engine's special never-miss value. Preserves c, de, hl.
	push hl
	push de
	push bc
	ldh [hMultiplier], a
	xor a
	ldh [hMultiplicand + 0], a
	ldh [hMultiplicand + 1], a
	ld a, b
	ldh [hMultiplicand + 2], a
	call Multiply
	ld a, 100
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 2]
	and a
	jr nz, .cap
	ldh a, [hQuotient + 3]
	cp $ff
	jr c, .done
.cap
	ld a, $fe
.done
	pop bc
	ld b, a
	pop de
	pop hl
	ret

AbilityIgnoresOpponentEvasion::
; Carry if the user's ability ignores the opponent's evasion stage.
; Keen Eye and Mind's Eye only ignore evasion INCREASES: a stage at or
; below neutral still applies, so the user keeps the benefit of drops.
; cp leaves carry set whenever a < the compared constant, so every
; "no" path must clear carry explicitly before returning.
	call GetTrueUserAbility
	cp KEEN_EYE
	jr z, .relevant_ability
	cp MINDS_EYE
	jr z, .relevant_ability
	cp UNAWARE
	jr z, .always_ignore
	and a ; clear carry: this ability does not touch evasion
	ret
.relevant_ability
	ld hl, wEnemyEvaLevel
	ldh a, [hBattleTurn]
	and a
	jr z, .got_eva
	ld hl, wPlayerEvaLevel
.got_eva
	ld a, [hl]
	cp BASE_STAT_LEVEL + 1
	ccf ; carry iff the stage is above neutral (raised)
	ret
.always_ignore
	scf
	ret

CompareSpeedsWithAbilities::
; Compare ability-adjusted speeds. Returns like CompareBytes on
; (player speed, enemy speed): z = tie, carry = enemy is faster.
	push hl
	push de
	push bc
	; player effective speed -> hl
	call GetPlayerAbilityEffective
	ld c, a
	ld a, [wBattleMonStatus]
	ld b, a
	ld hl, wBattleMonSpeed
	call .GetEffectiveSpeed
	ld a, [wBattleMonItem]
	ld b, a
	call GetPlayerAbilityEffective
	cp KLUTZ
	ld a, b
	jr z, .player_no_scarf
	call .ChoiceScarfBoost
.player_no_scarf
	ld d, 0
	call .UnburdenBoost
	push hl
	; enemy effective speed -> hl
	call GetEnemyAbilityEffective
	ld c, a
	ld a, [wEnemyMonStatus]
	ld b, a
	ld hl, wEnemyMonSpeed
	call .GetEffectiveSpeed
	ld a, [wEnemyMonItem]
	ld b, a
	call GetEnemyAbilityEffective
	cp KLUTZ
	ld a, b
	jr z, .enemy_no_scarf
	call .ChoiceScarfBoost
.enemy_no_scarf
	ld d, 1
	call .UnburdenBoost
	ld d, h
	ld e, l
	pop hl
	; compare hl (player) vs de (enemy)
	ld a, h
	cp d
	jr nz, .done
	ld a, l
	cp e
.done
	jr z, .finish
	sbc a ; $ff if the enemy is faster, else $00
	ld b, a
	ld a, [wTrickRoomTimer]
	and a
	ld a, b
	jr z, .tr_done
	cpl ; Trick Room inverts speed order
.tr_done
	and a
	jr z, .player_faster
	scf ; enemy faster: carry set, z clear (a is $ff)
	jr .finish
.player_faster
	or 1 ; player faster: carry and z clear
.finish
	pop bc
	pop de
	pop hl
	ret

.GetEffectiveSpeed:
; hl = speed stat ptr, c = ability, b = status. Returns speed in hl.
	ld a, [hli]
	ld d, a
	ld e, [hl]
	; hl := de
	ld h, d
	ld l, e
	ld a, c
	cp QUICK_FEET
	jr z, .quick_feet
	ld d, WEATHER_RAIN
	cp SWIFT_SWIM
	jr z, .weather_double
	ld d, WEATHER_SUN
	cp CHLOROPHYLL
	jr z, .weather_double
	ld d, WEATHER_SANDSTORM
	cp SAND_RUSH
	jr z, .weather_double
	ld d, WEATHER_HAIL
	cp SLUSH_RUSH
	ret nz
	; fallthrough
.weather_double
	ld a, [wBattleWeather]
	cp d
	ret nz
	add hl, hl
	ret nc
	ld hl, $ffff
	ret

.UnburdenBoost:
; d = side (0 player, 1 enemy). Doubles the effective speed in hl if the
; side's mon has Unburden, currently holds nothing, and has used or lost
; an item since entering.
	ld a, d
	and a
	jr nz, .unburden_enemy
	call GetPlayerAbilityEffective
	ld b, a
	ld a, [wBattleMonItem]
	jr .unburden_join
.unburden_enemy
	call GetEnemyAbilityEffective
	ld b, a
	ld a, [wEnemyMonItem]
.unburden_join
	and a
	ret nz
	ld a, b
	cp UNBURDEN
	ret nz
	push bc
	ld c, d
	call ReadItemStateFlags
	ld a, b
	pop bc
	and %00000011 ; ate or lost an item
	ret z
	add hl, hl
	ret nc
	ld hl, $ffff
	ret

.ChoiceScarfBoost:
	cp CHOICE_SCARF
	ret nz
	ld d, h
	ld e, l
	srl d
	rr e
	add hl, de
	ret nc
	ld hl, $ffff
	ret

.quick_feet
	; x1.5 while statused. Paralysis permanently halves the stored Speed
	; (ApplyPrzEffectOnSpeed), so undo that reduction first: Quick Feet
	; ignores paralysis's Speed penalty.
	ld a, b
	and a
	ret z
	bit PAR, b
	jr z, .quick_feet_boost
	add hl, hl
	jr c, .speed_cap
.quick_feet_boost
	ld d, h
	ld e, l
	srl d
	rr e
	add hl, de
	ret nc
.speed_cap
	ld hl, $ffff
	ret

CheckAirBalloonImmunity:
	call GetMoveCategory
	cp CATEGORIZE_STATUS
	jr z, .no
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp GROUND
	jr nz, .no
	callfar GetOpponentItem
	ld a, b
	cp HELD_AIR_BALLOON
	jr nz, .no
	xor a
	ld [wTypeModifier], a
	ld [wCurDamage], a
	ld [wCurDamage + 1], a
	; AI prediction: immune, damage zeroed; skip item name, miss flag, banner.
	ld a, [wAIDamagePrediction]
	and a
	scf
	ret nz
	ld a, [hl]
	call AbilityBufferItemName
	ld a, 1
	ld [wAttackMissed], a
	ld hl, AirBalloonImmuneText
	call StdBattleTextbox
	scf
	ret
.no
	and a
	ret

RunPostDamageDefenderHeldItems:
	; a hit taken by a Substitute doesn't touch the holder:
	; no balloon pop, policy proc or helmet chip through a sub. Infiltrator
	; routes damage to the holder, so those reactions apply normally.
	ld a, [wHitSubstitute]
	and a
	ret nz
	call UserMoveBypassesSubstitute_Core
	jr c, .hit_holder
	ld a, BATTLE_VARS_SUBSTATUS4_OPP
	call GetBattleVar
	bit SUBSTATUS_SUBSTITUTE, a
	ret nz
.hit_holder
	call AirBalloonPop
	call WeaknessPolicyBoost
	jp RockyHelmetDamage

LifeOrbRecoil::
	callfar GetUserItem
	ld a, b
	cp HELD_LIFE_ORB
	ret nz
	farcall ParentalBondHitPending_Core
	ret c ; once per completed Parental Bond move, including an early KO
	; multi-hit moves recoil once, after the final hit,
	; not once per hit (this hook runs from every checkfaint)
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_MULTI_HIT
	jr z, .multi_hit
	cp EFFECT_DOUBLE_HIT
	jr z, .multi_hit
	cp EFFECT_POISON_MULTI_HIT
	jr z, .multi_hit
	cp EFFECT_TRIPLE_KICK
	jr z, .multi_hit
	cp EFFECT_BEAT_UP
	jr z, .multi_hit
	cp EFFECT_SCALE_SHOT
	jr z, .multi_hit
.recoil
	call GetTrueUserAbility
	cp MAGIC_GUARD
	ret z
	cp SHEER_FORCE
	jr nz, .do_recoil
	; A Sheer Force-boosted move also suppresses Life Orb recoil. Use the
	; exact same eligibility test as the damage and effect-suppression paths.
	call CurrentMoveHasSheerForceEffect
	ret c
.do_recoil
	call UserHasFainted
	ret z
	ld d, 10
	call GetUserMaxHPFraction
	farcall SubtractHPFromUser
	ld hl, LifeOrbRecoilText
	jp StdBattleTextbox

.multi_hit
	; a KO cuts the loop short: that hit was the final one
	call OppHasFainted
	jr z, .recoil
	; endloop hasn't run yet on the first hit, so IN_LOOP clear
	; means more hits are coming
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVar
	bit SUBSTATUS_IN_LOOP, a
	ret z
	; the loop counter (see BattleCommand_EndLoop) reads 1 during
	; the last hit's checkfaint
	ld hl, wPlayerRolloutCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_count
	ld hl, wEnemyRolloutCount
.got_count
	ld a, [hl]
	dec a
	ret nz
	jr .recoil

AirBalloonPop:
	call OppHasFainted
	ret z ; the balloon goes down with its holder, no pop message
	callfar GetOpponentItem
	ld a, b
	cp HELD_AIR_BALLOON
	ret nz
	ld a, [hl]
	call AbilityBufferItemName
	callfar ConsumeHeldItem
	ld hl, AirBalloonPoppedText
	jp StdBattleTextbox

WeaknessPolicyBoost:
	call OppHasFainted
	ret z ; no boost if the holder didn't survive the hit (canon)
	ld a, [wTypeModifier]
	and $7f
	cp EFFECTIVE + 1
	ret c
	callfar GetOpponentItem
	ld a, b
	cp HELD_WEAKNESS_POLICY
	ret nz
	ld a, [hl]
	call AbilityBufferItemName
	callfar ConsumeHeldItem
	call SwitchTurn
	ld hl, AbilityItemActivatedText
	call StdBattleTextbox
	; One stat up anim + "ATTACK and SPCL.ATK sharply rose!"
	farcall DeferStatMessages_Core
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	farcall BattleCommand_AttackUp2
	farcall BattleCommand_StatUpMessage
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	farcall BattleCommand_SpecialAttackUp2
	farcall BattleCommand_StatUpMessage
	farcall FlushStatMessages_Core
	jp SwitchTurn

RockyHelmetDamage:
	call CheckContactMove
	ret nc
	call UserHasFainted
	ret z
	call GetTrueUserAbility
	cp MAGIC_GUARD
	ret z
	callfar GetOpponentItem
	ld a, b
	cp HELD_ROCKY_HELMET
	ret nz
	ld a, [hl]
	call AbilityBufferItemName
	ld d, 6
	call GetUserMaxHPFraction
	farcall SubtractHPFromUser
	ld hl, RockyHelmetText
	jp StdBattleTextbox

GetUserMaxHPFraction:
; d = divisor. Returns bc = max(1, max HP / d).
; Also refreshes wBuffer1-2 (= wCurHPAnimMaxHP) with the USER's max HP, the
; way GetMaxHP does, so a following SubtractHPFromUser animates the bar
; against the right maximum. Without this the bar scales the user's HP
; against whatever max was last left in the buffer (the just-KO'd defender's
; on the Aftermath/Rocky Helmet/Life Orb paths), garbling the HP bar.
	ld hl, wBattleMonMaxHP
	ldh a, [hBattleTurn]
	and a
	jr z, .got_hp
	ld hl, wEnemyMonMaxHP
.got_hp
	xor a
	ldh [hDividend + 0], a
	ldh [hDividend + 1], a
	ld a, [hli]
	ldh [hDividend + 2], a
	ld [wBuffer2], a ; HP-bar max HP, high byte
	ld a, [hl]
	ldh [hDividend + 3], a
	ld [wBuffer1], a ; HP-bar max HP, low byte
	ld a, d
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 2]
	ld b, a
	ldh a, [hQuotient + 3]
	ld c, a
	or b
	ret nz
	inc c
	ret

RunContactAbilitiesHook::
; Runs after damage is applied. Turn = attacker.
	; deferred Disguise reveal: now that the move animation has played,
	; bust the disguise, swap the sprite and print the texts
	ld hl, wDisguiseBusted + 1
	bit 7, [hl]
	call nz, DisguisePresentation
	ld a, [wAttackMissed]
	and a
	ret nz
	ld a, [wTypeModifier]
	and $7f
	ret z
	ld a, [wCurDamage]
	ld b, a
	ld a, [wCurDamage + 1]
	or b
	ret z
	call RunPostDamageDefenderHeldItems
	; no procs through a Substitute unless Infiltrator hit the holder
	ld a, [wHitSubstitute]
	and a
	jp nz, .life_orb
	call UserMoveBypassesSubstitute_Core
	jr c, .through_substitute
	ld a, BATTLE_VARS_SUBSTATUS4_OPP
	call GetBattleVar
	bit SUBSTATUS_SUBSTITUTE, a
	jp nz, .life_orb
.through_substitute
	; Stench: the attacker's damaging hits have a 10% flinch chance
	call GetTrueUserAbility
	cp STENCH
	call z, StenchAbility
	; defender on-hit abilities (any damaging move, contact or not)
	call GetOpponentAbility
	; Cursed Body and Toxic Debris still have a useful effect when the hit
	; knocks their holder out. Stat-changing reactions do not.
	cp CURSED_BODY
	jp z, .cursed_body
	cp TOXIC_DEBRIS
	jp z, .toxic_debris
	ld b, a
	call OppHasFainted
	jr z, .contact
	ld a, b
	cp STAMINA
	jr z, .stamina
	cp THERMAL_EXCHANGE
	jr z, .thermal_exchange
	cp JUSTIFIED
	jr z, .justified
	cp RATTLED
	jr z, .rattled
	cp WEAK_ARMOR
	jp z, .weak_armor
	cp ANGER_POINT
	jp z, .anger_point
.contact
	call CheckContactMove
	jr nc, .check_aftermath
	; hold the Magic Bounce anti-rebounce guard set across the contact
	; status procs (Poison Touch, Static, Flame Body, Poison Point, Effect
	; Spore, Cute Charm) - see RunGuardedStatusProc. Both branches below
	; converge on the matching clear.
	ld hl, wDisguiseBusted + 1
	set 6, [hl]
	; attacker on-contact abilities
	call OppHasFainted
	jr z, .defender_contact ; don't try to status a fainted defender
	call GetTrueUserAbility
	cp POISON_TOUCH
	call z, PoisonTouchAbility
	; defender on-contact abilities (perspective switches to the defender)
.defender_contact
	; Explicit SwitchTurn pair: StackCallOpponentTurn would leave the turn
	; flipped until the enclosing ret, running .check_aftermath/.aftermath/
	; .life_orb from the defender's perspective on every contact path.
	call SwitchTurn
	call _RunDefenderContactAbilities
	call SwitchTurn
	ld hl, wDisguiseBusted + 1
	res 6, [hl]
.check_aftermath
	call OppHasFainted
	jp z, .aftermath
	jp .life_orb

.stamina
	ld b, DEFENSE
	jr .on_hit_stat_up
.thermal_exchange
	; only Fire-type hits (checked from the attacker's perspective)
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp FIRE
	jr nz, .contact
	ld b, ATTACK
	jr .on_hit_stat_up
.justified
	; Atk+1 when hit by a Dark-type move
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp DARK
	jr nz, .contact
	ld b, ATTACK
	jr .on_hit_stat_up
.rattled
	; Dark-, Ghost-, and Bug-type hits raise Speed. Intimidate's separate
	; Rattled trigger remains in IntimidateAbility above.
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp DARK
	jr z, .rattled_raise
	cp GHOST
	jr z, .rattled_raise
	cp BUG
	jr nz, .contact
.rattled_raise
	ld b, SPEED
.on_hit_stat_up
	call SwitchTurn
	call BeginAbility
	call StatUpAbility
	call EndAbility
	call SwitchTurn
	; don't leak a maxed-stat failure into the rest of the move script
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	jr .contact

.weak_armor
	; physical hits lower the holder's Defense but sharply raise its Speed
	call GetMoveCategory
	and a ; CATEGORIZE_PHYSICAL
	jr nz, .contact
	call ShowEnemyAbilityBannerBrief
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld b, DEFENSE
	call AbilityLowerOppStat
	call SwitchTurn
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld b, $10 | SPEED ; sharply (+2)
	call AbilityRaiseStat
	call SwitchTurn
	; don't leak a failed stat change into the rest of the move script
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	jp .contact

.cursed_body
	; 30% chance to disable the move that hit the holder
	call ContactChance
	jp nc, .contact
	call CursedBodyEffect
	jp .contact

.anger_point
	; a critical hit maxes the holder's Attack
	ld a, [wCriticalHit]
	and a
	jp z, .contact
	call AngerPointEffect
	jp .contact

.toxic_debris
	; a physical hit makes the holder scatter Toxic Spikes on the attacker's
	; side (max 2 layers). Turn = attacker, so the attacker's own screens are
	; wPlayerScreens when hBattleTurn == 0, else wEnemyScreens.
	call GetMoveCategory
	and a ; CATEGORIZE_PHYSICAL
	jp nz, .contact
	call .toxic_debris_screens
	bit SCREENS_TOXIC_SPIKES_2, [hl]
	jp nz, .contact ; already two layers down
	call ShowEnemyAbilityBannerBrief
	; play the Toxic Spikes move animation. AbilityStatusAnim flips to the
	; holder's (defender's) perspective before PlayBattleAnim, so the spikes
	; render on the attacker's field - exactly the side we just spiked.
	ld de, TOXIC_SPIKES
	call AbilityStatusAnim
	call .toxic_debris_screens ; the banner + anim clobbered hl
	bit SCREENS_TOXIC_SPIKES_1, [hl]
	jr z, .toxic_debris_first
	set SCREENS_TOXIC_SPIKES_2, [hl]
	jr .toxic_debris_text
.toxic_debris_first
	set SCREENS_TOXIC_SPIKES_1, [hl]
.toxic_debris_text
	ld hl, ToxicDebrisText
	call StdBattleTextbox
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	jp .contact
.toxic_debris_screens
	ldh a, [hBattleTurn]
	and a
	ld hl, wPlayerScreens
	ret z
	ld hl, wEnemyScreens
	ret

.aftermath
	; the fainted defender's Aftermath hurts a contact attacker (1/4 max HP)
	call GetOpponentAbility
	cp AFTERMATH
	jr nz, .life_orb
	; a Damp attacker suffers no Aftermath damage (canon)
	call GetTrueUserAbility
	cp DAMP
	jr z, .life_orb
	cp MAGIC_GUARD
	jr z, .life_orb
	call CheckContactMove
	jr nc, .life_orb
	call UserHasFainted
	jr z, .life_orb
	call ShowEnemyAbilityBannerBrief
	ld d, 4
	call GetUserMaxHPFraction
	farcall SubtractHPFromUser
	ld hl, IsHurtText
	call StdBattleTextbox
.life_orb
	; Attacker recoil resolves after defender items and reactive abilities.
	call LifeOrbRecoil
	jp RunMoveKOAbilities

RunBerserkMoveEnd_Core::
	call ApplyBerserkMoveEnd
	farcall ClearMoveDamageToHolder_Core
	; Single-hit Berserk resolves before an HP Berry can erase its crossing.
	; Multi-hit moves eat between hits and use their final HP instead.
	ldh a, [rSVBK]
	push af
	ld a, BANK(wBerserkBerryPending)
	ldh [rSVBK], a
	ld a, [wBerserkBerryPending]
	ld b, a
	xor a
	ld [wBerserkBerryPending], a
	pop af
	ldh [rSVBK], a
	ld a, b
	and a
	ret z
	call OppHasFainted
	ret z
	farcall HandleHPHealingItem
	ret

CheckBerserkBerryDelay_Core::
; Carry when a single-hit move must delay its target's HP Berry until the
; after-move Berserk event. Sheer Force and multi-hit moves don't delay it.
	call GetOpponentAbility
	cp BERSERK
	jr nz, .no
	call GetTrueUserAbility
	cp SHEER_FORCE
	jr nz, .ordinary_move
	call CurrentMoveHasSheerForceEffect
	jr c, .no
.ordinary_move
	farcall CheckParentalBondMove_Core
	jr c, .no
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_MULTI_HIT
	jr z, .no
	cp EFFECT_DOUBLE_HIT
	jr z, .no
	cp EFFECT_POISON_MULTI_HIT
	jr z, .no
	cp EFFECT_TRIPLE_KICK
	jr z, .no
	cp EFFECT_BEAT_UP
	jr z, .no
	cp EFFECT_SCALE_SHOT
	jr z, .no
	ldh a, [rSVBK]
	push af
	ld a, BANK(wBerserkBerryPending)
	ldh [rSVBK], a
	ld a, 1
	ld [wBerserkBerryPending], a
	pop af
	ldh [rSVBK], a
	scf
	ret
.no
	and a
	ret

ApplyBerserkMoveEnd:
; Berserk is an after-move ability. A multi-hit move can cross half HP,
; consume a Berry, and then KO the holder; only its final surviving state
; matters. The total excludes damage absorbed by a Substitute.
	call GetOpponentAbility
	cp BERSERK
	ret nz
	call OppHasFainted
	ret z
	call GetTrueUserAbility
	cp SHEER_FORCE
	jr nz, .eligible
	call CurrentMoveHasSheerForceEffect
	ret c
.eligible
	farcall ReadMoveDamageToHolder_Core
	ld a, b
	or c
	ret z
	push bc ; damage dealt to the holder
	ld hl, wEnemyMonHP
	ldh a, [hBattleTurn]
	and a
	jr z, .hp
	ld hl, wBattleMonHP
.hp
	ld a, [hli]
	ld d, a
	ld a, [hli]
	ld e, a
	ld a, [hli]
	ld b, a
	ld c, [hl]
	srl b
	rr c
	; Current HP must be <= half max HP.
	ld a, d
	cp b
	jr c, .below_half
	jr nz, .no
	ld a, e
	cp c
	jr z, .below_half
	jr nc, .no
.below_half
	ld h, d
	ld l, e
	pop de ; total damage
	add hl, de
	jr c, .activate
	ld a, h
	cp b
	ret c
	jr nz, .activate
	ld a, l
	cp c
	ret c
	ret z
.activate
	call SwitchTurn
	call BeginAbility
	ld b, SP_ATTACK
	call StatUpAbility
	call EndAbility
	call SwitchTurn
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ret
.no
	pop bc
	ret

AngerPointEffect:
; Turn = attacker. Maximizes the crit victim's Attack.
	call SwitchTurn ; holder's perspective
	; already maxed?
	ld hl, wPlayerStatLevels + ATTACK
	ldh a, [hBattleTurn]
	and a
	jr z, .got_levels
	ld hl, wEnemyStatLevels + ATTACK
.got_levels
	ld a, [hl]
	cp MAX_STAT_LEVEL
	jr nc, .done
	call ShowAbilityBannerBrief
.raise_loop
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld b, $10 | ATTACK
	farcall RaiseStat
	ld a, [wFailedMessage]
	and a
	jr z, .raise_loop
	; clear the cap-failure state RaiseStat left behind
	xor a
	ld [wFailedMessage], a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld hl, MaxedAttackText
	call StdBattleTextbox
.done
	jp SwitchTurn

CursedBodyEffect:
; Turn = attacker. Disables the attacker's current move for 4 turns.
	; not if the attacker already has a disabled move
	ldh a, [hBattleTurn]
	and a
	jr z, .player_attacker
	ld a, [wEnemyDisableCount]
	and a
	ret nz
	ld a, [wCurEnemyMoveNum]
	ld c, a
	ld de, wEnemyDisableCount
	ld hl, wDisabledMove + 1
	jr .apply
.player_attacker
	ld a, [wPlayerDisableCount]
	and a
	ret nz
	ld a, [wCurMoveNum]
	ld c, a
	ld de, wPlayerDisableCount
	ld hl, wDisabledMove
.apply
	; get the move id; don't disable Struggle (or no-move hits)
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	and a
	ret z
	ld b, a
	push hl
	push de
	push bc
	ld hl, STRUGGLE
	call GetMoveIDFromIndex
	pop bc
	pop de
	pop hl
	cp b
	ret z
	; Disable the move in the slot that was used, not the executed move: after
	; Mirror Move / Metronome / Sleep Talk the executed move isn't in the
	; moveset, and the AI scans the moveset for the disabled move id.
	push hl
	ldh a, [hBattleTurn]
	and a
	ld hl, wBattleMonMoves
	jr z, .got_moves
	ld hl, wEnemyMonMoves
.got_moves
	ld b, 0
	add hl, bc
	ld b, [hl]
	pop hl
	ld a, b
	and a
	ret z
	; store the disabled move id
	ld [hl], b
	; count = (slot+1)<<4 | 4 turns
	ld a, c
	inc a
	swap a
	or 4
	ld [de], a
	; banner on the defender's side, then the disable text (naming the
	; attacker, so print it from the defender's perspective)
	call ShowEnemyAbilityBannerBrief
	ld a, b
	call AbilityBufferMoveName
	call SwitchTurn
	ld hl, CursedBodyDisabledText
	call StdBattleTextbox
	jp SwitchTurn

_RunDefenderContactAbilities:
	; Turn = defender. Its contact ability can still activate if the holder
	; fainted, but there is nothing to affect if the attacker also fainted.
	call OppHasFainted
	ret z
	call GetTrueUserAbility
	ld hl, TargetContactAbilities
	jp BattleJumptable

TargetContactAbilities:
	dbw STATIC, StaticAbility
	dbw FLAME_BODY, FlameBodyAbility
	dbw POISON_POINT, PoisonPointAbility
	dbw EFFECT_SPORE, EffectSporeAbility
	dbw TANGLING_HAIR, TanglingHairAbility
	dbw CUTE_CHARM, CuteCharmAbility
	dbw IRON_BARBS, IronBarbsAbility
	dbw PERISH_BODY, PerishBodyAbility
	dbw PICKPOCKET, PickpocketAbility
	dbw -1, -1

CheckContactMove::
; carry if the current move makes contact
	push hl
	push bc
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	ld c, a
	call CheckContactMoveID
	pop bc
	pop hl
	ret

CheckContactMoveID::
; carry if the move whose 8-bit ID is in c makes contact.
; Used by the AI (farcalled from AI_Abilities), which scores moves that
; are not the currently executing one. Preserves hl, de, bc.
	push hl
	push de
	push bc
	ld a, c
	and a
	jr z, .no ; no move (e.g. confusion self-hit)
	call GetMoveIndexFromID
	; bit l&7 of ContactMoves[index >> 3]
	ld a, l
	and %111
	ld c, a
	srl h
	rr l
	srl h
	rr l
	srl h
	rr l
	ld de, ContactMoves
	add hl, de
	ld b, [hl]
	inc c
.shift
	srl b
	dec c
	jr nz, .shift
	; bit now in carry
	jr c, .yes
.no
	and a
.yes
	pop bc
	pop de
	pop hl
	ret

PoisonTouchAbility:
; attacker ability: 30% to poison the defender
	; Like other added effects, Poison Touch cannot penetrate Shield Dust.
	call GetOpponentAbility
	cp SHIELD_DUST
	ret z
	ld a, 10
	call BattleRandomRange
	cp 3
	ret nc
	jp TryPoisonOpponentContact

StaticAbility:
	call ContactChance
	ret nc
	; fallthrough
TryParalyzeOpponent:
; Paralyzes the turn holder's opponent, with banner/anim/text.
; Shared by Static, Effect Spore, Synchronize and Magic Bounce.
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret nz
	call SafeCheckSafeguard_Core
	ret nz ; Safeguard blocks ability-inflicted status too (audit 2026-08-28 #10)
	call OpponentIsElectricType
	ret z ; Electric-types cannot be paralyzed
	call AbilityPreventsParalysis
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	set PAR, [hl]
	call UpdateOpponentInParty
	; CallBattleCore lives in the Effect Commands bank - a plain call from
	; this bank jumps into garbage and crashes. farcall does the same job
	; with the target's own bank.
	farcall ApplyPrzEffectOnSpeed
	ld de, ANIM_PAR
	call AbilityStatusAnim
	call UpdateBattleHuds
	farcall PrintParalyze
	jp FinishAbilityMajorStatus

FlameBodyAbility:
	call ContactChance
	ret nc
	; fallthrough
TryBurnOpponent:
; Burns the turn holder's opponent, with banner/anim/text.
; Shared by Flame Body, Synchronize and Magic Bounce.
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret nz
	call SafeCheckSafeguard_Core
	ret nz ; Safeguard blocks ability-inflicted status too (audit 2026-08-28 #10)
	call OpponentIsFireType
	ret z ; Fire-types can't be burned (move burns already ensure this
	      ; via CheckMoveTypeMatchesTarget; this covers the ability paths)
	call AbilityPreventsBurn
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	set BRN, [hl]
	call UpdateOpponentInParty
	; see StaticAbility: CallBattleCore is not callable from this bank
	farcall ApplyBrnEffectOnAttack
	ld de, ANIM_BRN
	call AbilityStatusAnim
	call UpdateBattleHuds
	ld hl, WasBurnedText
	call StdBattleTextbox
	jp FinishAbilityMajorStatus

PoisonPointAbility:
	call ContactChance
	ret nc
TryPoisonOpponentContact:
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret nz
	call SafeCheckSafeguard_Core
	ret nz ; Safeguard blocks ability-inflicted status too (audit 2026-08-28 #10)
	call OpponentIsPoisonImmuneType
	ret z
	call AbilityPreventsPoison
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	set PSN, [hl]
	call UpdateOpponentInParty
	ld de, ANIM_PSN
	call AbilityStatusAnim
	call UpdateBattleHuds
	ld hl, WasPoisonedText
	call StdBattleTextbox
	jp FinishAbilityMajorStatus

TryToxicOpponent:
; Badly poison the turn holder's opponent. Used by Synchronize and Magic
; Bounce so Toxic does not get degraded into regular poison.
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret nz
	call SafeCheckSafeguard_Core
	ret nz ; Safeguard blocks ability-inflicted status too (audit 2026-08-28 #10)
	call OpponentIsPoisonImmuneType
	ret z
	call AbilityPreventsPoison
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	set PSN, [hl]
	ld a, BATTLE_VARS_SUBSTATUS5_OPP
	call GetBattleVarAddr
	set SUBSTATUS_TOXIC, [hl]
	ld bc, wEnemyToxicCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_toxic_count
	ld bc, wPlayerToxicCount
.got_toxic_count
	xor a
	ld [bc], a
	farcall ToxicMarkOpp_Core
	call UpdateOpponentInParty
	ld de, ANIM_PSN
	call AbilityStatusAnim
	call UpdateBattleHuds
	ld hl, BadlyPoisonedText
	call StdBattleTextbox
	jp FinishAbilityMajorStatus

EffectSporeAbility:
	; Grass-types and Overcoat holders are immune to spores.
	call OpponentIsGrassType
	ret z
	call GetOpponentAbility
	cp OVERCOAT
	ret z
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret nz
	; One 0-99 roll gives the main-series 30% total distribution:
	; 0-8 poison (9%), 9-18 paralysis (10%), 19-29 sleep (11%).
	ld a, 100
	call BattleRandomRange
	cp 9
	jp c, TryPoisonOpponentContact
	cp 19
	jp c, TryParalyzeOpponent
	cp 30
	ret nc
	; fallthrough for sleep
TrySleepOpponent:
; Puts the turn holder's opponent to sleep, with banner/anim/text.
; Shared by Effect Spore and Magic Bounce.
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and a
	ret nz
	call SafeCheckSafeguard_Core
	ret nz ; Safeguard blocks ability-inflicted status too (audit 2026-08-28 #10)
	call AbilityPreventsSleep
	ret c
	call ShowAbilityBannerBrief
.sleep_roll
	; 2-4, i.e. 1-3 turns asleep (see BattleCommand_SleepTarget)
	call BattleRandom
	swap a
	and %11
	jr z, .sleep_roll
	inc a
	ld b, a
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	ld [hl], b
	call UpdateOpponentInParty
	ld de, ANIM_SLP
	call AbilityStatusAnim
	call UpdateBattleHuds
	ld hl, FellAsleepText
	call StdBattleTextbox
	jp FinishAbilityMajorStatus

FinishAbilityMajorStatus:
; Contact abilities, Synchronize and Magic Bounce all use the Try* helpers.
; Status-curing held items must therefore activate here just as they do for
; statuses inflicted by ordinary move commands.
	farcall UseHeldStatusHealingItem
	jp EndAbility

TryConfuseOpponent:
; Confuses the turn holder's opponent, with banner/anim/text (Magic Bounce).
	ld a, BATTLE_VARS_SUBSTATUS3_OPP
	call GetBattleVar
	bit SUBSTATUS_CONFUSED, a
	ret nz
	call SafeCheckSafeguard_Core
	ret nz ; Safeguard blocks confusion (audit 2026-08-28 #10)
	call AbilityPreventsConfusion
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_SUBSTATUS3_OPP
	call GetBattleVarAddr
	set SUBSTATUS_CONFUSED, [hl]
	; confused for 2-5 turns
	ld bc, wEnemyConfuseCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_confuse_count
	ld bc, wPlayerConfuseCount
.got_confuse_count
	call BattleRandom
	and %11
	inc a
	inc a
	ld [bc], a
	ld de, ANIM_CONFUSED
	call AbilityStatusAnim
	ld hl, BecameConfusedText
	call StdBattleTextbox
	farcall UseConfusionHealingItem
	jp EndAbility

TryAttractOpponent:
; Infatuates the turn holder's opponent (Magic Bounce reflection of Attract;
; the genders already passed the original move's compatibility check).
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVar
	bit SUBSTATUS_IN_LOVE, a
	ret nz
	call AbilityPreventsAttraction
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVarAddr
	set SUBSTATUS_IN_LOVE, [hl]
	ld hl, FellInLoveText
	call StdBattleTextbox
	jp EndAbility

CuteCharmAbility:
; Defender contact ability: 30% to infatuate the attacker. Turn = defender.
	call ContactChance
	ret nc
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVar
	bit SUBSTATUS_IN_LOVE, a
	ret nz
	; genders must be opposite (CheckOppositeGender is turn-agnostic:
	; it compares the two active battlers directly)
	farcall CheckOppositeGender
	ret c
	call AbilityPreventsAttraction
	ret c
	call ShowAbilityBannerBrief
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVarAddr
	set SUBSTATUS_IN_LOVE, [hl]
	ld hl, FellInLoveText
	call StdBattleTextbox
	jp EndAbility

IronBarbsAbility:
; Defender contact ability: the attacker loses 1/8 of its max HP.
	call GetOpponentAbility
	cp MAGIC_GUARD
	ret z
	call ShowAbilityBannerBrief
	call SwitchTurn
	ld d, 8
	call GetUserMaxHPFraction
	farcall SubtractHPFromUser
	ld hl, IsHurtText
	call StdBattleTextbox
	jp SwitchTurn

TanglingHairAbility:
	call ShowAbilityBannerBrief
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld b, SPEED
	call AbilityLowerOppStat
	; don't leak a failed drop into the rest of the move script
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	jp EndAbility

PerishBodyAbility:
; Defender contact ability: both mons will faint in three turns
; (unless the attacker is already perishing). Turn = defender.
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVar
	bit SUBSTATUS_PERISH, a
	ret nz
	call ShowAbilityBannerBrief
	; doom the attacker
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVarAddr
	set SUBSTATUS_PERISH, [hl]
	ld hl, wPlayerPerishCount
	ldh a, [hBattleTurn]
	and a
	jr nz, .got_attacker_count ; holder = enemy -> attacker = player
	ld hl, wEnemyPerishCount
.got_attacker_count
	ld [hl], 4
	; the holder is doomed too (unless already counting down)
	ld a, BATTLE_VARS_SUBSTATUS1
	call GetBattleVarAddr
	bit SUBSTATUS_PERISH, [hl]
	jr nz, .text
	set SUBSTATUS_PERISH, [hl]
	ld hl, wEnemyPerishCount
	ldh a, [hBattleTurn]
	and a
	jr nz, .got_holder_count
	ld hl, wPlayerPerishCount
.got_holder_count
	ld [hl], 4
.text
	ld hl, StartPerishText
	jp StdBattleTextbox

ContactChance:
; carry 30% of the time
	ld a, 10
	call BattleRandomRange
	cp 3
	ret

AbilityStatusAnim::
; de = status anim id (ANIM_PAR/BRN/PSN/SLP). Plays it on the turn
; holder's opponent (the mon that just got the status). Same mechanism as
; Effect Commands' PlayOpponentBattleAnim, which is in another bank.
; Safe here: every caller uses ShowAbilityBannerBrief, so the banner is
; already dismissed before the animation redraws the scene.
	ld a, e
	ld [wFXAnimID], a
	ld a, d
	ld [wFXAnimID + 1], a
	xor a
	ld [wNumHits], a
	call SwitchTurn
	farcall PlayBattleAnim
	jp SwitchTurn

OpponentIsElectricType::
	ld a, ELECTRIC
	jr OpponentIsType

OpponentIsGrassType:
	ld a, GRASS
	jr OpponentIsType

OpponentIsFireType:
; z if the turn holder's opponent is the type in a.
	ld a, FIRE
OpponentIsType:
	push hl
	push bc
	ld b, a
	ld hl, wEnemyMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wBattleMonType1
.got_types
	ld a, [hli]
	cp b
	jr z, .done
	ld a, [hl]
	cp b
.done
	pop bc
	pop hl
	ret

OpponentIsPoisonImmuneType:
; z if the opponent is Poison- or Steel-type
	push hl
	ld hl, wEnemyMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wBattleMonType1
.got_types
	ld a, [hli]
	cp POISON
	jr z, .immune
	cp STEEL
	jr z, .immune
	ld a, [hl]
	cp POISON
	jr z, .immune
	cp STEEL
.immune
	pop hl
	ret

INCLUDE "data/moves/contact_moves.asm"

AbilityConvertMoveType::
; "-ate" abilities: the user's Normal-type moves become their
; element (Galvanize/Pixilate/Refrigerate/Aerilate). Runs right after the
; move struct is loaded for this use. Struggle is exempt.
	call GetTrueUserAbility
	and a
	ret z
	ld b, a
	; Weather Ball and Hidden Power determine their own type and are never
	; converted, including Weather Ball's Normal form without weather.
	push bc
	ld hl, AteTypeExcludedMoves
	call CurrentMoveInList
	pop bc
	ret c
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp NORMAL
	ret nz
	ld a, b
	ld c, ELECTRIC
	cp GALVANIZE
	jr z, .convert
	ld c, FAIRY
	cp PIXILATE
	jr z, .convert
	ld c, ICE
	cp REFRIGERATE
	jr z, .convert
	ld c, FLYING
	cp AERILATE
	ret nz
.convert
	; not Struggle
	push hl
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	call GetMoveIndexFromID
	ld a, h
	cp HIGH(STRUGGLE)
	jr nz, .not_struggle
	ld a, l
	cp LOW(STRUGGLE)
	jr z, .abort
.not_struggle
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVarAddr
	ld [hl], c
.abort
	pop hl
	ret

AteTypeExcludedMoves:
	dw WEATHER_BALL
	dw HIDDEN_POWER
	dw STRUGGLE
	dw -1

CheckAteAbilityBoost:
; carry if the attacker has an "-ate" ability and this move was converted
; (its original type is Normal and its live type matches that ability).
; The live-type check matters for Weather Ball under active weather.
	push bc
	call GetTrueUserAbility
	ld c, ELECTRIC
	cp GALVANIZE
	jr z, .check_live
	ld c, FAIRY
	cp PIXILATE
	jr z, .check_live
	ld c, ICE
	cp REFRIGERATE
	jr z, .check_live
	ld c, FLYING
	cp AERILATE
	jr nz, .no_boost
.check_live
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp c
	jr nz, .no_boost
.check_original
	push hl
	push de
	; Hidden Power is stored as Normal but its live type is the user's own
	; chosen type - it is never "-ate"-converted, so it never gets the boost.
	ld hl, AteTypeExcludedMoves
	call CurrentMoveInList
	jr c, .no_boost_after_push
	; Original type straight from the move data via GetMoveAttribute (the
	; Moves table is indirect with 7-byte entries; the old flat *9 read
	; fetched garbage).
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	ld l, a
	ld a, MOVE_TYPE
	call GetMoveAttribute
	cp NORMAL
	pop de
	pop hl
	pop bc
	scf
	ret z
	and a ; nc
	ret
.no_boost_after_push
	pop de
	pop hl
	pop bc
	and a ; nc
	ret
.no_boost
	pop bc
	and a ; nc
	ret

AbilityCapCore::
; ABILITY CAP key item: cycle the chosen mon's ability through its
; available slots (1 -> 2 -> hidden -> 1), skipping empty ones.
	ld b, PARTYMENUACTION_HEALING_ITEM
	callfar UseItem_SelectMon
	ret c ; cancelled
	; no eggs (the party struct holds an Egg's real species)
	ld a, [wCurPartyMon]
	ld e, a
	ld d, 0
	ld hl, wPartySpecies
	add hl, de
	ld a, [hl]
	cp EGG
	jr z, .no_effect
	ld a, MON_SPECIES
	call GetPartyParamLocation
	ld a, [hl]
	ld [wCurSpecies], a
	push af
	call GetBaseData
	pop af
	ld c, a ; c = species id
	; current slot
	ld a, MON_PERSONALITY
	call GetPartyParamLocation
	ld a, [hl]
	and ABILITY_MASK
	ld d, a
	; availability
	ld a, [wBaseAbility2]
	and a
	ld e, 0
	jr z, .no_second
	set 1, e
.no_second
	ld a, [wBaseHiddenAbility]
	and a
	jr z, .no_hidden
	set 2, e
.no_hidden
	ld a, e
	and a
	jr z, .no_effect ; only one ability exists
	; cycle d to the next available slot
	ld a, d
	cp ABILITY_1
	jr z, .from_one
	cp ABILITY_2
	jr z, .from_two
	; from hidden (or unset): go to slot 1
	ld d, ABILITY_1
	jr .apply
.from_one
	bit 1, e
	ld d, ABILITY_2
	jr nz, .apply
	ld d, HIDDEN_ABILITY
	jr .apply
.from_two
	bit 2, e
	ld d, HIDDEN_ABILITY
	jr nz, .apply
	ld d, ABILITY_1
.apply
	ld a, [hl]
	and ~ABILITY_MASK & $ff
	or d
	ld [hl], a
	; announce the new ability
	ld b, a
	call GetAbility
	call AbilityBufferAbilityName
	push de
	ld de, SFX_FULL_HEAL
	call PlaySFX
	call WaitSFX
	pop de
	ld hl, .BecameText
	jp PrintText

.no_effect
	ld hl, .NoEffectText
	jp PrintText

.BecameText:
	text "Its ability is"
	line "now @"
	text_ram wBattleDynamicNameBuffer
	text "!"
	prompt

.NoEffectText:
	text "It won't have"
	line "any effect."
	prompt
RunFaintAbilities::
	; Generic faint cleanup runs for direct and indirect KOs alike.
	call RefreshWeatherSuppression
	; Suppressed entry abilities resume as soon as the gas holder faints,
	; including when no replacement exists. The faint hooks do not guarantee
	; hBattleTurn identifies the fainted side, so establish that perspective.
	ld a, [wNeutralizingGasActive]
	and a
	ret z
	ldh a, [hBattleTurn]
	push af
	call SetPlayerTurn
	ld a, [wPlayerAbility]
	cp NEUTRALIZING_GAS
	jr nz, .enemy_gas
	call UserHasFainted
	jr z, .ended
.enemy_gas
	call SetEnemyTurn
	ld a, [wEnemyAbility]
	cp NEUTRALIZING_GAS
	jr nz, .restore_turn
	call UserHasFainted
	jr nz, .restore_turn
.ended
	call CheckNeutralizingGasEnded
.restore_turn
	pop af
	ldh [hBattleTurn], a
	ret

RunMoveKOAbilities:
; Called only from the damaging-move post-hit hook, after recoil and reactive
; damage resolve. If the attacker survived and its target fainted, run Moxie.
	; A fainted Cloud Nine holder stops suppressing the underlying weather
	; via RunFaintAbilities later; this path is only for move-caused KO rewards.
	call UserHasFainted
	ret z
	call OppHasFainted
	ret nz ; opponent alive; the fainter was the user's side
	call GetTrueUserAbility
	cp MOXIE
	ret nz
	call BeginAbility
	ld b, ATTACK
	call StatUpAbility
	jp EndAbility

CheckUserFullHP:
; z if the user is at full HP
	push hl
	push de
	ld hl, wBattleMonHP
	ldh a, [hBattleTurn]
	and a
	jr z, .got_hp
	ld hl, wEnemyMonHP
.got_hp
	ld a, [hli]
	ld d, a
	ld a, [hli]
	ld e, a
	ld a, [hli]
	cp d
	jr nz, .done
	ld a, [hl]
	cp e
.done
	pop de
	pop hl
	ret

; ==== Session 4 additions ================================================

AbilityCriticalMods::
; Called from BattleCommand_Critical before the normal crit roll.
; Returns carry if the crit decision is final (wCriticalHit already set):
; Battle Armor/Shell Armor block crits; Merciless always crits poisoned foes.
	call GetOpponentIgnorableAbility
	cp BATTLE_ARMOR
	jr z, .blocked
	cp SHELL_ARMOR
	jr z, .blocked
	call GetTrueUserAbility
	cp MERCILESS
	jr nz, .normal
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and 1 << PSN
	jr z, .normal
	ld a, 1
	ld [wCriticalHit], a
	scf
	ret
.blocked
	xor a
	ld [wCriticalHit], a
	scf
	ret
.normal
	and a
	ret

AbilityCompareMovePriority::
; Replaces the body of CompareMovePriority (Battle Core).
; Returns carry if the player goes first, z if the priorities match.
; Applies Gale Wings (X/Y behavior: all Flying moves +1, no HP condition)
; and Triage (+3 to HP-restoring moves).
	ld a, [wCurPlayerMove]
	ld e, a
	farcall GetMovePriority_e
	ld d, e
	ld a, [wCurPlayerMove]
	ld b, a
	call GetPlayerAbilityEffective
	ld c, a
	call .Adjust
	push de
	ld a, [wCurEnemyMove]
	ld e, a
	farcall GetMovePriority_e
	ld d, e
	ld a, [wCurEnemyMove]
	ld b, a
	call GetEnemyAbilityEffective
	ld c, a
	call .Adjust
	pop bc ; b = player priority
	ld a, d ; enemy priority
	cp b
	ret

.Adjust:
; b = move id, c = ability, d = priority. Returns adjusted priority in d.
	ld a, b
	and a
	ret z ; no move chosen (switch/item)
	ld a, c
	cp GALE_WINGS
	jr z, .gale_wings
	cp TRIAGE
	jr z, .triage
	cp PRANKSTER
	jr z, .prankster
	ret

.prankster
	; +1 priority for status moves
	push hl
	ld l, b
	ld a, MOVE_CATEGORY
	call GetMoveAttribute
	pop hl
	cp CATEGORIZE_STATUS
	ret nz
	inc d
	ret

.gale_wings
	; +1 priority for Flying-type moves (type as stored in the move data)
	; Uses GetMoveAttribute: the Moves table is indirect with 7-byte entries,
	; so the old flat (index-1)*9 read fetched garbage.
	push hl
	ld l, b
	ld a, MOVE_TYPE
	call GetMoveAttribute
	pop hl
	cp FLYING
	ret nz
	inc d
	ret

.triage
	; +3 priority for HP-restoring moves
	ld a, b
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	push de
	ld de, 2
	ld hl, TriageMoves
	call IsInHalfwordArray
	pop de
	ret nc
	ld a, d
	add 3
	ld d, a
	ret

CountFaintedAllies:
; a = number of fainted mons in the user's party (0-5). Eggs don't count.
	push hl
	push de
	push bc
	ldh a, [hBattleTurn]
	and a
	jr z, .player
	; wild mons have no party
	ld a, [wBattleMode]
	dec a ; WILDMON?
	jr z, .none
	ld a, [wOTPartyCount]
	and a
	jr z, .none
	ld c, a
	ld hl, wOTPartySpecies
	ld de, wOTPartyMon1HP
	jr .count
.player
	ld a, [wPartyCount]
	and a
	jr z, .none
	ld c, a
	ld hl, wPartySpecies
	ld de, wPartyMon1HP
.count
	ld b, 0
.loop
	ld a, [hli]
	cp EGG
	jr z, .next
	push hl
	ld h, d
	ld l, e
	ld a, [hli]
	or [hl]
	pop hl
	jr nz, .next
	inc b
.next
	push hl
	ld hl, PARTYMON_STRUCT_LENGTH
	add hl, de
	ld d, h
	ld e, l
	pop hl
	dec c
	jr nz, .loop
	ld a, b
	jr .done
.none
	xor a
.done
	pop bc
	pop de
	pop hl
	ret

SupremeOverlordBoost:
; Multiply damage by (100 + 10 * fainted allies)% (a = 1-5).
	push bc
	ld b, a
	add a, a ; 2n
	add a, a ; 4n
	add a, b ; 5n
	add a, a ; 10n
	add 100
	call DamagePercent
	pop bc
	ret

; ==== Disguise (Sun/Moon behavior) ========================================

DisguiseBlock:
; Jumped to from .CheckNullification with the defender's ability = DISGUISE.
; Blocks the damage of the first hit outright (no HP loss - S/M behavior),
; but not the move's other effects. Returns carry if the hit was blocked.
	call SwitchTurn ; user = the Disguise holder from here
	ldh a, [hBattleTurn]
	and a
	ld a, [wBattleMonSpecies]
	jr z, .got_species
	ld a, [wEnemyMonSpecies]
.got_species
	call GetPokemonIndexFromID
	ld a, l
	cp LOW(MIMIKYU)
	jr nz, .no_block
	ld a, h
	cp HIGH(MIMIKYU)
	jr nz, .no_block
	; A normal hit is caught by the Substitute. Infiltrator reaches the
	; holder, so Disguise still blocks that first direct hit.
	call GetOpponentAbility
	cp INFILTRATOR
	jr z, .check_busted
	ld a, BATTLE_VARS_SUBSTATUS4
	call GetBattleVar
	bit SUBSTATUS_SUBSTITUTE, a
	jr nz, .no_block
.check_busted
	call GetDisguiseFlag
	and [hl]
	jr nz, .no_block ; already busted
	; cancel the damage, but keep the move's secondary effects:
	; zero wCurDamage and neutralize the effectiveness text
	xor a
	ld [wCurDamage], a
	ld [wCurDamage + 1], a
	ld [wCriticalHit], a
	ld a, [wTypeModifier]
	and $80
	or EFFECTIVE
	ld [wTypeModifier], a
	; AI prediction: block the damage but don't arm the real disguise bust.
	ld a, [wAIDamagePrediction]
	and a
	jr nz, .predicted
	; the bust + presentation are DEFERRED to DisguisePresentation (run
	; from the kingsrock hook), so the move's animation plays first and a
	; move that misses after damage calc doesn't break the disguise
	ld hl, wDisguiseBusted + 1
	set 7, [hl]
.predicted
	call SwitchTurn
	scf
	ret
.no_block
	call SwitchTurn
	and a
	ret

DisguisePresentation:
; Deferred from DisguiseBlock; runs from the kingsrock hook (turn =
; attacker), after the move animation and HP bar update.
	ld hl, wDisguiseBusted + 1
	res 7, [hl]
	; if the move ultimately missed, the disguise never broke
	ld a, [wAttackMissed]
	and a
	ret nz
	call SwitchTurn ; the Disguise holder's side
	; guard: only ever bust an actual Mimikyu with an intact disguise
	; (audit 2026-08-28 #5)
	ldh a, [hBattleTurn]
	and a
	ld a, [wBattleMonSpecies]
	jr z, .got_species
	ld a, [wEnemyMonSpecies]
.got_species
	call GetPokemonIndexFromID
	ld a, l
	cp LOW(MIMIKYU)
	jp nz, SwitchTurn
	ld a, h
	cp HIGH(MIMIKYU)
	jp nz, SwitchTurn
	call GetDisguiseFlag
	ld b, a
	ld a, [hl]
	and b
	jp nz, SwitchTurn ; already busted
	ld a, [hl]
	or b
	ld [hl], a ; mark this slot's disguise as busted
	call ShowAbilityBannerBrief
	ld hl, DisguiseDecoyText
	call StdBattleTextbox
	call LoadBrokenDisguisePic
	ld hl, DisguiseBustedText
	call StdBattleTextbox
	jp SwitchTurn

GetDisguiseFlag:
; For the current turn holder: hl = its wDisguiseBusted byte,
; a = the bit mask for its current party slot (wild mons use bit 0).
	ldh a, [hBattleTurn]
	and a
	jr z, .player
	ld hl, wDisguiseBusted + 1
	ld a, [wBattleMode]
	dec a ; WILDMON?
	ld a, 0
	jr z, .got_slot
	ld a, [wCurOTMon]
	jr .got_slot
.player
	ld hl, wDisguiseBusted
	ld a, [wCurBattleMon]
.got_slot
	and %111
	push bc
	ld b, a
	ld a, 1
	inc b
.shift
	dec b
	jr z, .shifted
	add a, a
	jr .shift
.shifted
	pop bc
	ret

ReapplyBrokenDisguise:
; If the entering turn holder is a Mimikyu whose disguise busted earlier
; this battle, restore the broken sprite (the switch-in loaded the normal
; pic).
	ldh a, [hBattleTurn]
	and a
	ld a, [wBattleMonSpecies]
	jr z, .got_species
	ld a, [wEnemyMonSpecies]
.got_species
	call GetPokemonIndexFromID
	ld a, l
	cp LOW(MIMIKYU)
	ret nz
	ld a, h
	cp HIGH(MIMIKYU)
	ret nz
	call GetDisguiseFlag
	and [hl]
	ret z
	; fallthrough

LoadBrokenDisguisePic:
; Load the broken-disguise pic for the current turn holder's side.
; Enemy: animated 5x5 frontpic padded to 7x7 at vTiles2 $00 (+ animation
; tiles in VRAM bank 1, mirroring GetAnimatedFrontpic's layout).
; Player: 6x6 backpic at vTiles2 $31.
	push hl
	push de
	push bc
	ldh a, [rSVBK]
	push af
	ld a, BANK(wDecompressScratch)
	ldh [rSVBK], a
	xor a
	ldh [hBGMapMode], a
	ldh a, [hBattleTurn]
	and a
	jr z, .backpic
	; enemy frontpic
	ld a, BANK(MimikyuBrokenFrontpic)
	ld hl, MimikyuBrokenFrontpic
	ld de, wDecompressScratch
	call FarDecompress
	ld de, wDecompressScratch
	ld hl, wDecompressScratch + 50 tiles
	call .Pad5x5To7x7
	ld hl, vTiles2
	ld de, wDecompressScratch + 50 tiles
	ld c, 7 * 7
	ldh a, [hROMBank]
	ld b, a
	call Get2bpp
	; animation frames -> VRAM bank 1, after the padded base pic
	ld a, BANK(vTiles3)
	ldh [rVBK], a
	ld hl, vTiles2 tile $31
	ld de, wDecompressScratch + 25 tiles
	ld c, 25
	ldh a, [hROMBank]
	ld b, a
	call Get2bpp
	xor a
	ldh [rVBK], a
	jr .done
.backpic
	ld a, BANK(MimikyuBrokenBackpic)
	ld hl, MimikyuBrokenBackpic
	ld de, wDecompressScratch
	call FarDecompress
	ld hl, vTiles2 tile $31
	ld de, wDecompressScratch
	ld c, 6 * 6
	ldh a, [hROMBank]
	ld b, a
	call Get2bpp
.done
	pop af
	ldh [rSVBK], a
	ld a, $1
	ldh [hBGMapMode], a
	pop bc
	pop de
	pop hl
	ret

.Pad5x5To7x7:
; de = source (25 tiles, column-major), hl = dest (49 tiles).
; Mirrors PadFrontpic's 5x5 layout: 1 blank column, 5x (2 blank tiles +
; 5 pic tiles), 1 blank column.
	xor a
	ld c, 7 * 16
	call .fill
	ld b, 5
.column
	xor a
	ld c, 2 * 16
	call .fill
	ld c, 5 * 16
.copy
	ld a, [de]
	inc de
	ld [hli], a
	dec c
	jr nz, .copy
	dec b
	jr nz, .column
	xor a
	ld c, 7 * 16
	; fallthrough
.fill
	ld [hli], a
	dec c
	jr nz, .fill
	ret

; ==== Session 6 additions ================================================

RunSynchronizePar::
; Called (farcall) right after the attacker's move paralyzed the defender.
	ld hl, TryParalyzeOpponent
	jr RunSynchronize
RunSynchronizeBrn::
; Called right after the attacker's move burned the defender.
	ld hl, TryBurnOpponent
	jr RunSynchronize
RunSynchronizePsn::
; Called right after the attacker's move poisoned the defender.
; Doubles as the Poison Puppeteer hook - both react to "this move just
; poisoned the target" (primary Toxic/Poison Gas/Powder via the Poison
; body, secondaries via PoisonTarget/ToxicTarget).
	call RunPoisonPuppeteer
	ld hl, TryPoisonOpponentContact
	ld a, BATTLE_VARS_SUBSTATUS5_OPP
	call GetBattleVar
	bit SUBSTATUS_TOXIC, a
	jr z, RunSynchronize
	ld hl, TryToxicOpponent
	; fallthrough
RunSynchronize:
; If the defender has Synchronize, pass the status back to the attacker.
; Turn = attacker; the Try* helpers run from the defender's perspective.
	call GetOpponentAbility
	cp SYNCHRONIZE
	ret nz
	call SwitchTurn
	call RunGuardedStatusProc
	jp SwitchTurn

RunPoisonPuppeteer:
; Poison Puppeteer: a target poisoned by the holder's move also becomes
; confused (no species requirement here, unlike canon Pecharunt).
; Turn = attacker = the Puppeteer holder; TryConfuseOpponent handles the
; banner, the already-confused/Own Tempo guards, count, anim and text.
	call GetTrueUserAbility
	cp POISON_PUPPETEER
	ret nz
	ld hl, TryConfuseOpponent
	; fallthrough
RunGuardedStatusProc:
; Call the status helper at hl with bit 6 of wDisguiseBusted+1 (the Magic
; Bounce anti-rebounce guard) held set: an ability-inflicted status has no
; status move behind it, so CheckStatusPrevention's Magic Bounce path -
; which decides move-ness from a (stale) move-category read - must not
; "reflect" it back onto the ability holder. The clear below runs on every
; body exit, so the bit can't leak set. StatDown's ability-drop flag is
; bit 6 of the OTHER byte (wDisguiseBusted + 0), so the two can't collide.
; res/ld don't touch flags: the helper's F flag reaches the caller intact.
	push hl
	ld hl, wDisguiseBusted + 1
	set 6, [hl]
	pop hl
	call _hl_
	ld hl, wDisguiseBusted + 1
	res 6, [hl]
	ret

BerserkGeneConfusion_b::
; Berserk Gene confusion, gated on Own Tempo (HandleBerserkGene applies
; the Attack boost itself). Returns the holder's PRIOR SubStatus3 in b;
; when Own Tempo blocks the confusion, the confused bit is faked into b
; so the caller's tail skips the confusion anim/text either way.
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVarAddr
	ld b, [hl]
	call GetTrueUserAbility
	cp OWN_TEMPO
	jr z, .blocked
	set SUBSTATUS_CONFUSED, [hl]
	farcall SetBerserkGeneConfusionDuration ; Battle Core Overflow bank
	ret
.blocked
	set SUBSTATUS_CONFUSED, b
	ret

AbilityEffectChanceMods::
; b = secondary effect chance. Serene Grace doubles it; Sheer Force
; suppresses it (carry) - its damage boost lives in RunDamageModifiers.
; The defender's Shield Dust suppresses it outright.
	push bc
	call GetOpponentIgnorableAbility
	pop bc
	cp SHIELD_DUST
	jr nz, .check_user_ability
	; Shield Dust blocks additional effects on its holder, not secondary
	; effects that benefit the attacker itself.
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_DEFENSE_UP_HIT
	jr z, .check_user_ability
	cp EFFECT_ATTACK_UP_HIT
	jr z, .check_user_ability
	cp EFFECT_ALL_UP_HIT
	jr z, .check_user_ability
	cp EFFECT_SPEED_UP_HIT
	jr z, .check_user_ability
	cp EFFECT_SP_ATK_UP_HIT
	jr nz, .suppress
.check_user_ability
	call GetTrueUserAbility
	cp SHEER_FORCE
	jr z, .check_sheer_force
	cp SERENE_GRACE
	jr z, .double
	and a ; nc
	ret
.check_sheer_force
	call CurrentMoveHasSheerForceEffect
	jr c, .suppress
	and a ; this effect is not removable; nc
	ret
.double
	sla b
	ret nc
	ld b, $ff
	and a ; nc
	ret
.suppress
	ld a, b
	and a
	ret z ; no chance to suppress; nc
	scf
	ret

CurrentMoveHasSheerForceEffect::
; Carry if the current damaging move has a removable secondary effect.
; This is the single eligibility contract for Sheer Force's damage boost,
; secondary suppression, Life Orb exception and King's Rock interaction.
; Preserves bc, de and hl. All no-match paths return with carry clear.
	push hl
	push de
	push bc
	; A shared effect can back both an ordinary move and a secondary-effect
	; move (HEX / INFERNAL PARADE), so a nonzero chance is still required.
	ld hl, wPlayerMoveStruct + MOVE_CHANCE
	ldh a, [hBattleTurn]
	and a
	jr z, .got_chance
	ld hl, wEnemyMoveStruct + MOVE_CHANCE
.got_chance
	ld a, [hl]
	and a
	jr z, .no
	ld a, BATTLE_VARS_MOVE_POWER
	call GetBattleVar
	and a
	jr z, .no ; status moves never receive Sheer Force's damage boost
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	ld hl, SheerForceEffects
	ld de, 1
	call IsInArray
	jr c, .yes
.no
	pop bc
	pop de
	pop hl
	and a ; nc
	ret
.yes
	pop bc
	pop de
	pop hl
	scf
	ret

SheerForceEffects:
; Effect classes with a removable additional effect. Deliberately excludes
; primary effects (such as Thief), recoil/thawing and user drawbacks. Mortal
; Spin is included for poison; its primary hazard clearing remains active.
	db EFFECT_POISON_HIT
	db EFFECT_BURN_HIT
	db EFFECT_FREEZE_HIT
	db EFFECT_PARALYZE_HIT
	db EFFECT_FLINCH_HIT
	db EFFECT_TRI_ATTACK
	db EFFECT_ATTACK_DOWN_HIT
	db EFFECT_DEFENSE_DOWN_HIT
	db EFFECT_SPEED_DOWN_HIT
	db EFFECT_SP_ATK_DOWN_HIT
	db EFFECT_SP_DEF_DOWN_HIT
	db EFFECT_DEF_SPDEF_DOWN_HIT
	db EFFECT_ACCURACY_DOWN_HIT
	db EFFECT_EVASION_DOWN_HIT
	db EFFECT_DEFENSE_UP_HIT
	db EFFECT_ATTACK_UP_HIT
	db EFFECT_ALL_UP_HIT
	db EFFECT_SPEED_UP_HIT
	db EFFECT_SP_ATK_UP_HIT
	db EFFECT_SKY_ATTACK
	db EFFECT_CONFUSE_HIT
	db EFFECT_POISON_MULTI_HIT
	db EFFECT_SNORE
	db EFFECT_FLAME_WHEEL
	db EFFECT_SACRED_FIRE
	db EFFECT_TWISTER
	db EFFECT_STOMP
	db EFFECT_THUNDER
	db EFFECT_POISON_FANG
	db EFFECT_BLIZZARD
	db EFFECT_FAKE_OUT
	db EFFECT_FLARE_BLITZ
	db EFFECT_HURRICANE
	db EFFECT_SCALD
	db EFFECT_MORTAL_SPIN
	db EFFECT_VOLT_TACKLE
	db EFFECT_DIRE_CLAW
	db EFFECT_BARB_BARRAGE
	db EFFECT_HEX
	db EFFECT_SHELL_SIDE_ARM
	db EFFECT_FREEZE_DRY
	db EFFECT_BOUNCE
	db EFFECT_SP_DEF_DOWN_2_HIT
	db EFFECT_STEALTH_ROCK_HIT
	db EFFECT_EERIE_SPELL
	db -1

GetTrueUserAbility_b::
; farcall-safe wrapper: the user's effective ability, returned in b.
	call GetTrueUserAbility
	ld b, a
	ret

FoeUnnerveCheck_b::
; b = TRUE if the turn holder (a held-item holder) can't eat Berries because
; its opponent has Unnerve.
	call StackCallOpponentTurn
	; fallthrough
UnnerveCheck_b::
; b = TRUE if the turn holder's effective ability is Unnerve, which stops its
; opponent (the held-item holder) from eating Berries. A fainted Unnerve
; holder no longer makes anyone nervous.
	call GetTrueUserAbility
	cp UNNERVE
	ld b, FALSE
	ret nz
	call UserHasFainted
	ret z
	inc b
	ret

GetOpponentAbility_b::
; farcall-safe wrapper: the opponent's effective ability, returned in b.
	call GetOpponentAbility
	ld b, a
	ret

GetPlayerAbilityEffective_b::
; farcall-safe wrapper: the player's effective ability, returned in b.
	call GetPlayerAbilityEffective
	ld b, a
	ret

GetEnemyAbilityEffective_b::
; farcall-safe wrapper: the enemy's effective ability, returned in b.
	call GetEnemyAbilityEffective
	ld b, a
	ret

GetAbilityFlags_b::
; farcall-safe wrapper: the flags for ability b, returned in b.
; (The farcall macro clobbers a, so the input must arrive in b.)
	ld a, b
	call GetAbilityFlags
	ld b, a
	ret

TransformCopyAbility::
; Transform/Imposter also copies the target's ability (canon), unless
; that ability can't be acquired by transforming (ABILFLAG_NO_TRANSFORM,
; e.g. Neutralizing Gas) - then the user keeps its own ability.
; The copy lasts until the mon leaves the field: send-out recomputes
; the ability from species and personality.
	push hl
	push bc
	ld a, BATTLE_VARS_ABILITY_OPP
	call GetBattleVar
	and a
	jr z, .done ; target has no ability; keep ours
	ld b, a
	call GetAbilityFlags
	and ABILFLAG_NO_TRANSFORM
	jr nz, .done
	ld a, BATTLE_VARS_ABILITY
	call GetBattleVarAddr
	ld [hl], b
	call RefreshWeatherSuppression
.done
	pop bc
	pop hl
	ret

CheckPlayerIsTrapped::
; Carry if the player's mon can't be recalled: Wrap, Mean Look, or an
; enemy trapping ability. (Lives here to keep Battle Core bytes down.)
	ld a, [wBattleMonType1]
	cp GHOST
	jr z, .free
	ld a, [wBattleMonType2]
	cp GHOST
	jr z, .free
	ld a, [wPlayerWrapCount]
	and a
	jr nz, .trapped
	ld a, [wEnemySubStatus5]
	bit SUBSTATUS_CANT_RUN, a
	jr z, CheckOpponentTrapAbility
.trapped
	scf
	ret
.free
	and a
	ret

CheckOpponentTrapAbility::
; Carry if the ENEMY's ability prevents the player's mon from
; switching or fleeing. Preserves hl/de/bc.
	push hl
	push de
	push bc
	; Ghost-types can always leave (Gen 6 rules)
	ld a, [wBattleMonType1]
	cp GHOST
	jr z, .free
	ld a, [wBattleMonType2]
	cp GHOST
	jr z, .free
	call GetEnemyAbilityEffective
	cp SHADOW_TAG
	jr z, .shadow_tag
	cp MAGNET_PULL
	jr z, .magnet_pull
	cp ARENA_TRAP
	jr nz, .free
	; Arena Trap only traps grounded mons
	ld a, [wBattleMonType1]
	cp FLYING
	jr z, .free
	ld a, [wBattleMonType2]
	cp FLYING
	jr z, .free
	call GetPlayerAbilityEffective
	cp KLUTZ
	jr z, .player_grounded
	ld a, [wBattleMonItem]
	cp AIR_BALLOON
	jr z, .free
.player_grounded
	call GetPlayerAbilityEffective
	cp LEVITATE
	jr z, .free
	jr .trapped
.shadow_tag
	; Shadow Tag doesn't trap another Shadow Tag holder (Gen 4 rules)
	call GetPlayerAbilityEffective
	cp SHADOW_TAG
	jr z, .free
	jr .trapped
.magnet_pull
	; only Steel-types are trapped
	ld a, [wBattleMonType1]
	cp STEEL
	jr z, .trapped
	ld a, [wBattleMonType2]
	cp STEEL
	jr z, .trapped
.free
	pop bc
	pop de
	pop hl
	and a
	ret
.trapped
	pop bc
	pop de
	pop hl
	scf
	ret

CheckPlayerTrapsEnemy::
; Carry if the PLAYER's ability prevents the enemy mon from
; fleeing or switching. Preserves hl/de/bc.
	push hl
	push de
	push bc
	ld a, [wEnemyMonType1]
	cp GHOST
	jr z, .free
	ld a, [wEnemyMonType2]
	cp GHOST
	jr z, .free
	call GetPlayerAbilityEffective
	cp SHADOW_TAG
	jr z, .shadow_tag
	cp MAGNET_PULL
	jr z, .magnet_pull
	cp ARENA_TRAP
	jr nz, .free
	ld a, [wEnemyMonType1]
	cp FLYING
	jr z, .free
	ld a, [wEnemyMonType2]
	cp FLYING
	jr z, .free
	call GetEnemyAbilityEffective
	cp KLUTZ
	jr z, .enemy_grounded
	ld a, [wEnemyMonItem]
	cp AIR_BALLOON
	jr z, .free
.enemy_grounded
	call GetEnemyAbilityEffective
	cp LEVITATE
	jr z, .free
	jr .trapped
.shadow_tag
	call GetEnemyAbilityEffective
	cp SHADOW_TAG
	jr z, .free
	jr .trapped
.magnet_pull
	ld a, [wEnemyMonType1]
	cp STEEL
	jr z, .trapped
	ld a, [wEnemyMonType2]
	cp STEEL
	jr z, .trapped
.free
	pop bc
	pop de
	pop hl
	and a
	ret
.trapped
	pop bc
	pop de
	pop hl
	scf
	ret

RunPlayerSwitchOutAbilities::
; Natural Cure / Regenerator for the outgoing player mon (wLastPlayerMon).
; Called right before RecallPlayerMon; edits the party struct directly.
	call GetPlayerAbilityEffective
	cp NATURAL_CURE
	jr z, .natural_cure
	cp REGENERATOR
	ret nz
	ld a, [wLastPlayerMon]
	ld hl, wPartyMon1HP
	jr DoRegenerator
.natural_cure
	ld a, [wLastPlayerMon]
	ld hl, wPartyMon1Status
	call GetPartyLocation
	xor a
	ld [hl], a
	ret

RunEnemySwitchOutAbilities::
; Natural Cure / Regenerator for the outgoing enemy mon (wCurOTMon).
; Called before AI_Switch swaps it out.
	ld a, [wBattleMode]
	dec a ; WILDMON?
	ret z
	call GetEnemyAbilityEffective
	cp NATURAL_CURE
	jr z, .natural_cure
	cp REGENERATOR
	ret nz
	ld a, [wCurOTMon]
	ld hl, wOTPartyMon1HP
	jr DoRegenerator
.natural_cure
	ld a, [wCurOTMon]
	ld hl, wOTPartyMon1Status
	call GetPartyLocation
	xor a
	ld [hl], a
	ret

DoRegenerator:
; a = party index, hl = partymon 1 HP base. Heals 1/3 max HP, capped.
	call GetPartyLocation
	; skip if fainted
	ld a, [hli]
	ld b, a
	ld a, [hld]
	or b
	ret z
	; de = max HP / 3
	push hl
	inc hl
	inc hl ; -> max HP
	xor a
	ldh [hDividend + 0], a
	ldh [hDividend + 1], a
	ld a, [hli]
	ldh [hDividend + 2], a
	ld a, [hld]
	ldh [hDividend + 3], a
	ld a, 3
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 2]
	ld d, a
	ldh a, [hQuotient + 3]
	ld e, a
	; bc = max HP
	ld a, [hli]
	ld b, a
	ld c, [hl]
	pop hl
	; HP += de (big-endian in the struct)
	inc hl ; -> HP low
	ld a, [hl]
	add e
	ld [hld], a
	ld a, [hl]
	adc d
	ld [hli], a
	; cap at max HP: hl -> HP low, compare (high in a)
	ld d, a
	ld e, [hl]
	ld a, d
	cp b
	jr c, .done
	jr nz, .cap
	ld a, e
	cp c
	jr c, .done
	jr z, .done
.cap
	ld a, c
	ld [hld], a
	ld [hl], b
	ret
.done
	ret

; ==== Session 7 additions ================================================

ContraryCheckRaise::
; Hooked at the top of RaiseStat. b = stat id (with $10 sharp bit).
; Carry if Contrary converted the turn holder's raise into a drop
; (fully resolved, "fell" message printed; wLoweredStat bit 7 tells the
; pending statupmessage to stay quiet).
	ld a, [wLoweredStat]
	add a ; bit 7 -> carry
	jr c, .no ; this raise IS a Contrary inversion - don't recurse
	ld a, [wAttackMissed]
	and a
	jr nz, .no
	ld a, [wEffectFailed]
	and a
	jr nz, .no
	call GetTrueUserAbility
	cp CONTRARY
	jr z, .invert
.no
	and a
	ret
.invert
	call SwitchTurn
	; from here the holder is the "opponent"; drop its stat via the
	; StatDown core, skipping Mist/protection (self-inflicted, canon)
	ld hl, wDisguiseBusted
	set 6, [hl] ; skip the AI 25% miss roll
	ld a, b
	and $1f
	ld [wLoweredStat], a
	farcall StatDownSkipProtect
	farcall BattleCommand_StatDownMessage
	call SwitchTurn
	; mark the pending statupmessage as handled; report success
	ld a, [wLoweredStat]
	or $80
	ld [wLoweredStat], a
	xor a
	ld [wFailedMessage], a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	scf
	ret

AbilityPiercesGhosts::
; Carry if the user's ability lets Normal/Fighting hit Ghosts
; (Scrappy, Mind's Eye) - hooked at the type chart's Foresight marker.
	call GetTrueUserAbility
	cp SCRAPPY
	jr z, .yes
	cp MINDS_EYE
	jr z, .yes
	and a
	ret
.yes
	scf
	ret

CurrentMoveInList:
; hl = -1-terminated dw move-index list. Carry if the current move is in
; the list. Preserves de.
	push de
	push hl
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	pop hl
	ld de, 2
	call IsInHalfwordArray
	pop de
	ret

AbilityCritLevelMods::
; c = crit stage. Super Luck adds one stage (capped at the table limit).
	call GetTrueUserAbility
	cp SUPER_LUCK
	ret nz
	inc c
	ld a, c
	cp 5
	ret c
	ld c, 4
	ret

AbilityPreventsFlinch::
; Carry if the defender's ability blocks this additional flinch effect.
; Canon: no message is shown.
	call GetOpponentIgnorableAbility
	cp INNER_FOCUS
	jr z, .block
	cp SHIELD_DUST
	jr z, .block
	and a ; nc
	ret
.block
	scf
	ret

RunSteadfast::
; Called when the turn holder loses its action to a flinch.
	call GetTrueUserAbility
	cp STEADFAST
	ret nz
	call BeginAbility
	ld b, SPEED
	call StatUpAbility
	call EndAbility
	; a maxed Speed shouldn't leave failure flags set mid-turn
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld [wFailedMessage], a
	ret

RunStatDropReaction::
; Called after a successful stat-drop message. If the victim (the turn
; holder's opponent) has Defiant/Competitive, its Atk/SpA sharply rises.
	ld a, [wFailedMessage]
	and a
	ret nz
	; Ability-driven drops (Intimidate & co.) always come from the
	; opponent; the move-effect byte is stale then and must not be allowed
	; to veto Defiant/Competitive (e.g. enemy's last move was Superpower).
	ld a, [wAbilityStatDropFlag]
	and a
	jr nz, .from_opponent
	; Self-inflicted drops (Superpower & co. lower the user through
	; switchturn, so the "victim" here is the move's own user) never
	; trigger Defiant/Competitive - only opponent-caused drops do.
	; The message runs with the turn flipped, so a raw read of
	; BATTLE_VARS_MOVE_EFFECT would be the OPPONENT's move (audit
	; 2026-08-28 #4); CheckSelfInflictedStatDrop recovers the originating
	; effect from the savemiss snapshot instead.
	farcall CheckSelfInflictedStatDrop
	ret z
.from_opponent
	call GetOpponentAbility
	cp DEFIANT
	ld b, $10 | ATTACK
	jr z, .proc
	cp COMPETITIVE
	ld b, $10 | SP_ATTACK
	ret nz
.proc
	push bc
	call SwitchTurn
	call BeginAbility
	pop bc
	call StatUpAbility
	call EndAbility
	call SwitchTurn
	; restore the caller's success state (the drop DID land)
	xor a
	ld [wFailedMessage], a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ret

AbilityPreventsSelfdestruct::
; Carry if Damp (on either side) blocks the user's selfdestructing move.
; Sets the missed/failed flags so the rest of the script fizzles.
	call GetOpponentIgnorableAbility
	cp DAMP
	jr z, .blocked_opp
	call GetTrueUserAbility
	cp DAMP
	jr z, .blocked_self
	and a ; nc
	ret
.blocked_opp
	call ShowEnemyAbilityBannerBrief
	jr .fail
.blocked_self
	call ShowAbilityBannerBrief
.fail
	ld a, 1
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	scf
	ret

GetOpponentIgnorableAbility_b::
GetOppIgnorableAbility_b::
; farcall-safe wrapper: the opponent's effective (Mold Breaker-ignorable)
; ability, returned in b.
	call GetOpponentIgnorableAbility
	ld b, a
	ret

RunResidualStatusAbilities::
; Called from ResidualDamage before poison/burn chip is applied.
; Carry = skip the damage: Magic Guard ignores it, Poison Heal replaces
; it with healing.
	call GetTrueUserAbility
	cp MAGIC_GUARD
	jr z, .no_damage
	cp POISON_HEAL
	jr z, .poison_heal
	and a ; nc
	ret
.poison_heal
	; heals 1/8 max HP while poisoned; burn damages normally
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and 1 << PSN
	ret z ; nc
	call CheckUserFullHP
	jr z, .no_damage
	call ShowAbilityBannerBrief
	farcall GetEighthMaxHP
	call AbilityRestoreUserHP
	ld hl, RegainedHealthText
	call StdBattleTextbox
	call EndAbility
.no_damage
	scf
	ret

CheckGenderMatchup:
; For the two active battlers: a = 0 if same gender, 1 if opposite
; genders, 2 if either is genderless/unknown. (Same setup as
; CheckOppositeGender in attract.asm, which lives in another bank.)
	ld a, MON_SPECIES
	call BattlePartyAttr
	ld a, [hl]
	ld [wCurPartySpecies], a
	ld a, [wCurBattleMon]
	ld [wCurPartyMon], a
	xor a
	ld [wMonType], a
	farcall GetGender
	jr c, .genderless
	ld b, 1
	jr nz, .got_gender
	dec b
.got_gender
	push bc
	ld a, [wTempEnemyMonSpecies]
	ld [wCurPartySpecies], a
	; The enemy's gender lives in wEnemyMonShinyGenderFlags (wild and trainer
	; mons alike), which is what the WILDMON path of GetGender reads. The old
	; TEMPMON path read a stale wTempMonUnused byte instead.
	ld a, WILDMON
	ld [wMonType], a
	farcall GetGender
	pop bc
	jr c, .genderless
	ld a, 1
	jr nz, .got_enemy_gender
	dec a
.got_enemy_gender
	xor b ; 0 = same, 1 = opposite
	ret
.genderless
	ld a, 2
	ret

BattleCommand_EffectChance_Core::
; Relocated from effect_commands.asm; adds Serene Grace (double chance)
; and Sheer Force (suppress the secondary effect).
	xor a
	ld [wEffectFailed], a
	; Attacker-beneficial secondaries still activate on a Substitute hit.
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_DEFENSE_UP_HIT
	jr z, .check_chance
	cp EFFECT_ATTACK_UP_HIT
	jr z, .check_chance
	cp EFFECT_ALL_UP_HIT
	jr z, .check_chance
	cp EFFECT_SPEED_UP_HIT
	jr z, .check_chance
	cp EFFECT_SP_ATK_UP_HIT
	jr z, .check_chance
	callfar CheckSubstituteOpp
	jr nz, .failed
.check_chance
	ld hl, wPlayerMoveStruct + MOVE_CHANCE
	ldh a, [hBattleTurn]
	and a
	jr z, .got_move_chance
	ld hl, wEnemyMoveStruct + MOVE_CHANCE
.got_move_chance
	ld b, [hl]
	call AbilityEffectChanceMods
	jr c, .failed ; Sheer Force

	; $ff is the data encoding for a guaranteed secondary effect. Handle it
	; before the RNG comparison so a roll of $ff cannot make it fail.
	ld a, b
	cp $ff
	ret z
	call BattleRandom
	cp b
	ret c

.failed
	ld a, 1
	ld [wEffectFailed], a
	and a
	ret

BattleDefSpDefDownHit_Core::
; OCTAZOOKA: a single effect-chance roll lowers both the target's DEFENSE
; and SPCL.DEF by one stage, with one combined "fell!" message. resetmiss
; between the two keeps a DEFENSE already at -6 from blocking the SPCL.DEF
; drop (the move is known to have hit and the roll to have passed).
	callfar BattleCommand_EffectChance
	ld a, [wEffectFailed]
	and a
	ret nz
	ld a, [wAttackMissed]
	and a
	ret nz
	callfar BattleCommand_DeferStatMessages
	callfar BattleCommand_DefenseDown
	callfar BattleCommand_StatDownMessage
	callfar BattleCommand_ResetMiss
	callfar BattleCommand_SpecialDefenseDown
	callfar BattleCommand_StatDownMessage
	callfar BattleCommand_FlushStatMessages
	ret

BattleOHKO_Core::
; Relocated from effect_commands.asm; adds Sturdy's OHKO immunity.
	callfar ResetDamage
	ld a, [wTypeModifier]
	and $7f
	jr z, .no_effect
	; Sturdy is immune to OHKO moves (classic effect)
	call GetOpponentIgnorableAbility
	cp STURDY
	jr z, .sturdy
	ld hl, wEnemyMonLevel
	ld de, wBattleMonLevel
	ld bc, wPlayerMoveStruct + MOVE_ACC
	ldh a, [hBattleTurn]
	and a
	jr z, .got_move_accuracy
	push hl
	ld h, d
	ld l, e
	pop de
	ld bc, wEnemyMoveStruct + MOVE_ACC
.got_move_accuracy
	ld a, [de]
	sub [hl]
	jr c, .no_effect
	add a
	ld e, a
	ld a, [bc]
	add e
	jr nc, .finish_ohko
	ld a, $ff
.finish_ohko
	ld [bc], a
	callfar BattleCommand_CheckHit
	ld hl, wCurDamage
	ld a, $ff
	ld [hli], a
	ld [hl], a
	ld a, $2
	ld [wCriticalHit], a
	ret

.sturdy
	call ShowEnemyAbilityBannerBrief
.no_effect
	ld a, $ff
	ld [wCriticalHit], a
	ld a, $1
	ld [wAttackMissed], a
	ret

BattleRecoil_Core::
; Relocated from effect_commands.asm; adds Rock Head / Magic Guard.
	ld a, [wAttackMissed]
	and a
	ret nz
	call UserHasFainted
	ret z
	; Struggle recoil is direct damage: neither immunity ability stops it,
	; and it is based on the user's max HP rather than damage dealt.
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	ld a, h
	cp HIGH(STRUGGLE)
	jr nz, .ordinary
	ld a, l
	cp LOW(STRUGGLE)
	jr nz, .ordinary
	ld d, 1
	call GetUserMaxHPFraction
	ld a, 25
	jr .fraction
.ordinary
	call GetTrueUserAbility
	cp MAGIC_GUARD
	ret z
	cp ROCK_HEAD
	ret z
	; Most modern recoil attacks use 33%; Take Down and Submission use
	; 25%, while Head Smash uses 50%. Keep move IDs as 16-bit indexes.
	ld a, b
	cp HIGH(HEAD_SMASH)
	jr nz, .not_head_smash
	ld a, c
	cp LOW(HEAD_SMASH)
	ld a, 50
	jr z, .damage_fraction
.not_head_smash
	ld a, b
	and a
	jr nz, .third
	ld a, c
	cp TAKE_DOWN
	jr z, .quarter
	cp SUBMISSION
	jr z, .quarter
.third
	ld a, 33
	jr .damage_fraction
.quarter
	ld a, 25
.damage_fraction
	ld d, a
	farcall ParentalBondRecoilDamage_Core
	ld a, b
	or c
	ret z
	ld a, d
.fraction
; bc = source amount; a = percentage. Round to nearest, minimum 1.
	ldh [hMultiplier], a
	xor a
	ldh [hMultiplicand + 0], a
	ld a, b
	ldh [hMultiplicand + 1], a
	ld a, c
	ldh [hMultiplicand + 2], a
	call Multiply
	ldh a, [hProduct + 3]
	add 50
	ldh [hProduct + 3], a
	ldh a, [hProduct + 2]
	adc 0
	ldh [hProduct + 2], a
	ldh a, [hProduct + 1]
	adc 0
	ldh [hProduct + 1], a
	ld a, 100
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 2]
	ld b, a
	ldh a, [hQuotient + 3]
	ld c, a
	ld a, b
	or c
	jr nz, .recoil
	inc c
.recoil
	push bc
	ld d, 1
	call GetUserMaxHPFraction ; refresh HP-bar maximum for the user
	pop bc
	farcall SubtractHPFromUser
	ld hl, RecoilText
	jp StdBattleTextbox

PunchMoves:
; Iron Fist: punching moves in this game
	dw COMET_PUNCH
	dw MEGA_PUNCH
	dw FIRE_PUNCH
	dw ICE_PUNCH
	dw THUNDERPUNCH
	dw DIZZY_PUNCH
	dw MACH_PUNCH
	dw DYNAMICPUNCH
	dw SHADOW_PUNCH
	dw BULLET_PUNCH
	dw DRAIN_PUNCH
	dw PIXIE_PUNCH
	dw RAGE_FIST
	dw HAMMER_ARM
	dw -1

SliceMoves:
; Sharpness: slicing moves in this game
	dw CUT
	dw RAZOR_LEAF
	dw SLASH
	dw FURY_CUTTER
	dw BITTER_BLADE
	dw AIR_SLASH
	dw LEAF_BLADE
	dw X_SCISSOR
	dw SOLAR_BLADE
	dw AERIAL_ACE
	dw NIGHT_SLASH
	dw PSYCHO_CUT
	dw SACRED_SWORD
	dw AIR_CUTTER
	dw CROSS_POISON
	dw KOWTOW_CLEAVE
	dw STONE_AXE
	dw -1

PulseMoves:
; Mega Launcher: aura/pulse moves in this game
	dw DARK_PULSE
	dw DRAGON_PULSE
	dw WATER_PULSE
	dw AURA_SPHERE
	dw -1

SoundMoves:
; Soundproof: sound-based moves in this game
	dw GROWL
	dw ROAR
	dw SING
	dw SUPERSONIC
	dw SCREECH
	dw SNORE
	dw PERISH_SONG
	dw BUG_BUZZ
	dw HYPER_VOICE
	dw DISARMING_VOICE
	dw SNARL
	dw EERIE_SPELL
	dw -1

BallBombMoves:
; Bulletproof: ball and bomb moves in this game
	dw EGG_BOMB
	dw BARRAGE
	dw SLUDGE_BOMB
	dw OCTAZOOKA
	dw ZAP_CANNON
	dw SHADOW_BALL
	dw AURA_SPHERE
	dw ENERGY_BALL
	dw FOCUS_BLAST
	dw GYRO_BALL
	dw ROCK_BLAST
	dw SEED_BOMB
	dw BULLET_SEED
	dw WEATHER_BALL
	dw -1

WindMoves:
; Wind Rider: wind moves in this game
	dw GUST
	dw WHIRLWIND
	dw BLIZZARD
	dw AEROBLAST
	dw ICY_WIND
	dw TWISTER
	dw FAIRY_WIND
	dw HURRICANE
	dw HEAT_WAVE
	dw AIR_CUTTER
	dw -1

PowderMoves:
; Overcoat: powder and spore moves in this game (the same class Effect
; Spore's proc immunity covers; Grass-type powder immunity is deliberately
; deferred - see _ai_artifacts/reports/ABILITY_PORT_PLAN.md)
	dw POISONPOWDER
	dw STUN_SPORE
	dw SLEEP_POWDER
	dw SPORE
	dw COTTON_SPORE
	dw -1

BiteMoves:
; Strong Jaw: biting moves (canon list, restricted to moves in this game)
	dw BITE
	dw CRUNCH
	dw HYPER_FANG
	dw FIRE_FANG
	dw ICE_FANG
	dw THUNDER_FANG
	dw POISON_FANG
	dw -1

TryEnemyFlee_Core::
; Relocated from core.asm ("Battle Core" was full). Carry = the wild
; enemy flees. farcall preserves flags on return.
	ld a, [wBattleMode]
	dec a
	jr nz, .Stay
	; Ghosts ignore binding and escape prevention as well as trap abilities.
	ld a, [wEnemyMonType1]
	cp GHOST
	jr z, .CanFlee
	ld a, [wEnemyMonType2]
	cp GHOST
	jr z, .CanFlee

	ld a, [wPlayerSubStatus5]
	bit SUBSTATUS_CANT_RUN, a
	jr nz, .Stay

	ld a, [wEnemyWrapCount]
	and a
	jr nz, .Stay

	; trapping abilities (Shadow Tag/Arena Trap/Magnet Pull); same bank now
	call CheckPlayerTrapsEnemy
	jr c, .Stay
.CanFlee
	ld a, [wEnemyMonStatus]
	and SLP ; frostbite no longer immobilizes; only sleep pins a wild mon
	jr nz, .Stay

	ld a, [wTempEnemyMonSpecies]
	call GetPokemonIndexFromID
	ld b, h
	ld c, l
	ld de, 2
	ld hl, AlwaysFleeMons
	call IsInHalfwordArray
	jr c, .Flee

	call BattleRandom
	add a, a
	jr nc, .Stay

	push af
	; de preserved from last call
	ld hl, OftenFleeMons
	call IsInHalfwordArray
	pop de
	jr c, .Flee

	ld a, d
	cp 20 percent ; double the value because of the previous add a, a
	jr nc, .Stay

	ld de, 2
	ld hl, SometimesFleeMons
	call IsInHalfwordArray
	jr c, .Flee

.Stay:
	and a
	ret

.Flee:
	scf
	ret

INCLUDE "data/wild/flee_mons.asm"

TriageMoves:
; Triage: HP-restoring moves (canon list, restricted to moves in this game)
	dw ABSORB
	dw MEGA_DRAIN
	dw GIGA_DRAIN
	dw LEECH_LIFE
	dw DREAM_EATER
	dw DRAIN_PUNCH
	dw DRAINING_KISS
	dw BITTER_BLADE
	dw RECOVER
	dw SOFTBOILED
	dw ROOST
	dw REST
	dw MILK_DRINK
	dw MORNING_SUN
	dw SYNTHESIS
	dw MOONLIGHT
	dw -1

UserCantRest::
; carry if the user's own ability prevents Rest's self-sleep (canon:
; Insomnia / Vital Spirit users fail Rest). Returns nc otherwise.
	call GetTrueUserAbility
	cp INSOMNIA
	jr z, .prevented
	cp VITAL_SPIRIT
	jr z, .prevented
	cp LEAF_GUARD
	jr nz, .allowed
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jr z, .prevented
.allowed
	and a
	ret
.prevented
	scf
	ret

INCLUDE "data/abilities/flags.asm"

; Keep compressed art out of the nearly full executable ability bank. The
; loader already uses BANK(label) + FarDecompress, so these are bank-safe.
; ==== 2026-08-13 worklist batch ===========================================
; Gluttony, Run Away, Infiltrator, Leaf Guard, Early Bird, Unaware, Stench,
; Anticipation, Pickpocket, Shield Dust, Corrosion, Harvest, Download,
; Suction Cups, Sticky Hold, Unburden, Klutz, Ripen, Cud Chew, Forewarn,
; Supersweet Syrup.
; (Heavy Metal and Light Metal were removed from the game entirely: no
; weight mechanics exist in this engine.)

; --- Banked item-state access ---------------------------------------------
; wPlayer/wEnemyItemStateFlags + wPlayer/wEnemyConsumedItem live in WRAM
; bank 2 (WRAM0 is full). All access goes through these helpers, which
; save and restore rSVBK. c = side: 0 = player, 1 = enemy.

GetItemStateAddrs:
; c = side -> hl = flags addr, de = consumed-item addr
	ld hl, wPlayerItemStateFlags
	ld de, wPlayerConsumedItem
	ld a, c
	and a
	ret z
	ld hl, wEnemyItemStateFlags
	ld de, wEnemyConsumedItem
	ret

ReadItemStateFlags::
; c = side -> b = flags
	push hl
	push de
	call GetItemStateAddrs
	ldh a, [rSVBK]
	push af
	ld a, BANK(wPlayerItemStateFlags)
	ldh [rSVBK], a
	ld b, [hl]
	pop af
	ldh [rSVBK], a
	pop de
	pop hl
	ret

WriteItemStateFlags::
; c = side, b = flags
	push hl
	push de
	call GetItemStateAddrs
	ldh a, [rSVBK]
	push af
	ld a, BANK(wPlayerItemStateFlags)
	ldh [rSVBK], a
	ld [hl], b
	pop af
	ldh [rSVBK], a
	pop de
	pop hl
	ret

ReadConsumedItem::
; c = side -> b = recorded item id (0 = none)
	push hl
	push de
	call GetItemStateAddrs
	ldh a, [rSVBK]
	push af
	ld a, BANK(wPlayerConsumedItem)
	ldh [rSVBK], a
	ld a, [de]
	ld b, a
	pop af
	ldh [rSVBK], a
	pop de
	pop hl
	ret

WriteConsumedItem::
; c = side, b = item id
	push hl
	push de
	call GetItemStateAddrs
	ldh a, [rSVBK]
	push af
	ld a, BANK(wPlayerConsumedItem)
	ldh [rSVBK], a
	ld a, b
	ld [de], a
	pop af
	ldh [rSVBK], a
	pop de
	pop hl
	ret

GetUserSide:
; -> c = the turn holder's side (0 = player, 1 = enemy)
	ldh a, [hBattleTurn]
	and a
	ld c, 0
	ret z
	inc c
	ret

InitAbilityItemState::
; Farcalled from the battle-start send-out (replaces the plain wInAbility
; clear there). Zeroes held-item state and once-per-battle ability state.
	xor a
	ld [wInAbility], a
	ld b, a
	ld c, 0
	call WriteItemStateFlags
	call WriteConsumedItem
	ld b, 0
	ld c, 1
	call WriteItemStateFlags
	call WriteConsumedItem
	; Supersweet Syrup is once per battle for each party member.
	ldh a, [rSVBK]
	push af
	ld a, BANK(wPlayerSyrupUsedFlags)
	ldh [rSVBK], a
	xor a
	ld [wPlayerSyrupUsedFlags], a
	ld [wEnemySyrupUsedFlags], a
	pop af
	ldh [rSVBK], a
	ret

ClearUserItemState:
; Clears the item state for the side whose mon is entering (turn holder).
	push bc
	call GetUserSide
	ld b, 0
	call WriteItemStateFlags
	call WriteConsumedItem
	pop bc
	ret

ClearUserItemState_Core::
; Farcall entry used by the real switch-in path before entry hazards. Keeping
; the reset out of RunEntryAbilities prevents Skill Swap from erasing state.
	jp ClearUserItemState

RecordConsumedItem::
; Farcalled from ConsumeHeldItem right before it zeroes the item slot.
; There, de points at the holder's battle item byte (the holder is the
; turn holder's OPPONENT, per the Get*OpponentItem convention). Records
; the item id, sets the "consumed" flag, and arms Cud Chew.
	push hl
	push de
	push bc
	; which side holds the item? de is either wBattleMonItem (WRAM0) or
	; wEnemyMonItem (banked WRAM): the high bytes differ.
	ld a, d
	cp HIGH(wBattleMonItem)
	ld c, 0
	jr z, .got_side
	ld c, 1
.got_side
	ld a, [de]
	ld e, a ; e = item id
	ld b, a
	call WriteConsumedItem
	call ReadItemStateFlags
	set 0, b ; consumed a held item
	; arm Cud Chew (replays at the end of the NEXT turn) if the holder
	; has the ability and this was an HP-restoring Berry
	push bc
	ld a, c
	and a
	jr nz, .enemy_ability
	call GetPlayerAbilityEffective
	jr .got_ability
.enemy_ability
	call GetEnemyAbilityEffective
.got_ability
	cp CUD_CHEW
	pop bc
	jr nz, .store
	; This engine can replay its two HP-restoring Berries. Match the actual
	; item ids so Berry Juice is not mistaken for a Berry by held-effect code.
	ld a, e
	cp BERRY
	jr z, .arm_cud_chew
	cp GOLD_BERRY
	jr nz, .store
.arm_cud_chew
	set 2, b
.store
	call WriteItemStateFlags
	pop bc
	pop de
	pop hl
	ret

; --- Entry abilities ------------------------------------------------------

DownloadAbility:
; Raises Atk or SpA depending on which of the foe's unmodified defenses
; is lower (ties raise SpA, like the original games).
	ldh a, [rSVBK]
	push af
	ld a, BANK(wEnemyMonDefense)
	ldh [rSVBK], a
	ld hl, wEnemyMonDefense
	ld de, wEnemyMonSpclDef
	ldh a, [hBattleTurn]
	and a
	jr z, .got_stats
	ld hl, wBattleMonDefense
	ld de, wBattleMonSpclDef
.got_stats
	; bc = Defense
	ld a, [hli]
	ld b, a
	ld c, [hl]
	; hl = Sp.Def
	ld a, [de]
	ld h, a
	inc de
	ld a, [de]
	ld l, a
	pop af
	ldh [rSVBK], a
	; Def < SpDef -> raise Attack, else raise Sp.Atk
	ld a, b
	cp h
	jr c, .raise_attack
	jr nz, .raise_spatk
	ld a, c
	cp l
	jr c, .raise_attack
.raise_spatk
	ld b, SP_ATTACK
	jr .raise
.raise_attack
	ld b, ATTACK
.raise
	call BeginAbility
	call StatUpAbility
	jp EndAbility

SupersweetSyrupAbility:
; The scent lowers the foe's evasion on entry, once per party member per
; battle. The bitset survives switches but is reset by InitAbilityItemState.
	call CheckAndMarkSupersweetSyrup
	ret c
	call ShowAbilityBannerBrief
	xor a
	ld [wAttackMissed], a
	ld [wEffectFailed], a
	ld b, EVASION
	call AbilityLowerOppStat
	jp EndAbility

CheckAndMarkSupersweetSyrup:
; Carry if this party member already activated Supersweet Syrup.
	; wCurBattleMon is in WRAM bank 1, so read the slot before selecting the
	; bank-2 bitset. wCurOTMon is unbanked.
	ldh a, [hBattleTurn]
	and a
	jr nz, .enemy_index
	ldh a, [rSVBK]
	push af
	ld a, BANK(wCurBattleMon)
	ldh [rSVBK], a
	ld a, [wCurBattleMon]
	ld c, a
	jr .select_state_bank
.enemy_index
	ld a, [wCurOTMon]
	ld c, a
	ldh a, [rSVBK]
	push af
.select_state_bank
	ld a, BANK(wPlayerSyrupUsedFlags)
	ldh [rSVBK], a
	ld hl, wPlayerSyrupUsedFlags
	ldh a, [hBattleTurn]
	and a
	jr z, .got_side
	inc hl
.got_side
	ld a, c
	ld b, 1
	and a
	jr z, .got_mask
.mask_loop
	sla b
	dec a
	jr nz, .mask_loop
.got_mask
	ld a, [hl]
	and b
	jr nz, .already_used
	ld a, [hl]
	or b
	ld [hl], a
	pop af
	ldh [rSVBK], a
	and a
	ret
.already_used
	pop af
	ldh [rSVBK], a
	scf
	ret

CopyOppMovesToBuffer:
; Copies the opponent's four move ids to wBuffer1-4 (bank-safe).
	ldh a, [rSVBK]
	push af
	ld a, BANK(wEnemyMonMoves)
	ldh [rSVBK], a
	ld hl, wEnemyMonMoves
	ldh a, [hBattleTurn]
	and a
	jr z, .got_moves
	ld hl, wBattleMonMoves
.got_moves
	ld de, wBuffer1
	ld bc, NUM_MOVES
	call CopyBytes
	pop af
	ldh [rSVBK], a
	ret

ForewarnAbility:
; Reveals the foe's strongest move (highest base power; if the foe only
; has status moves, the first move is revealed).
	ldh a, [rSVBK]
	push af
	ld a, BANK(wBuffer1)
	ldh [rSVBK], a
	call CopyOppMovesToBuffer
	ld hl, wBuffer1
	ld b, 0 ; best power
	ld c, 0 ; best move id
	ld e, NUM_MOVES
.scan
	ld a, [hli]
	and a
	jr z, .scanned
	ld d, a
	push hl
	push de
	push bc
	ld l, a
	ld a, MOVE_POWER
	call GetMoveAttribute
	pop bc
	pop de
	pop hl
	cp b
	jr c, .next
	jr z, .next
	ld b, a
	ld c, d
.next
	dec e
	jr nz, .scan
.scanned
	ld a, c
	and a
	jr nz, .got_move
	ld a, [wBuffer1]
	and a
	jr nz, .use_first
	pop af
	ldh [rSVBK], a
	ret ; no moves at all
.use_first
	ld c, a
.got_move
	pop af
	ldh [rSVBK], a
	push bc
	call ShowAbilityBannerBrief
	pop bc
	ld a, c
	call AbilityBufferMoveName
	ld hl, ForewarnAlertText
	jp StdBattleTextbox

AnticipationAbility:
; Shudders if the foe has a super-effective or OHKO move.
	ldh a, [rSVBK]
	push af
	ld a, BANK(wBuffer1)
	ldh [rSVBK], a
	call CopyOppMovesToBuffer
	; the holder's own types -> wBuffer5/6
	ld hl, wBattleMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wEnemyMonType1
.got_types
	ld a, [hli]
	ld [wBuffer5], a
	ld a, [hl]
	ld [wBuffer6], a
	; scan the foe's moves (bounded to NUM_MOVES, like Forewarn: with a
	; full moveset the old zero-terminated scan ran into wBuffer5/6 and
	; live WRAM beyond - audit 2026-08-28 #13)
	ld hl, wBuffer1
	ld c, NUM_MOVES
.scan
	ld a, [hli]
	and a
	jr z, .no_shudder
	push hl
	push bc
	ld e, a ; e = move id
	; OHKO moves always trigger
	ld l, a
	ld a, MOVE_EFFECT
	call GetMoveAttribute
	cp EFFECT_OHKO
	jr z, .shudder
	; only damaging moves count
	ld l, e
	ld a, MOVE_POWER
	call GetMoveAttribute
	and a
	jr z, .next
	; super effective vs the holder's typing?
	ld l, e
	ld a, MOVE_TYPE
	call GetMoveAttribute
	ld b, a
	ld hl, wBuffer5
	ld a, BANK(CheckTypeMatchupFar)
	ld de, CheckTypeMatchupFar
	call FarCall_de
	ld a, [wTypeMatchup]
	cp 10 + 1
	jr nc, .shudder
.next
	pop bc
	pop hl
	dec c
	jr nz, .scan
	jr .no_shudder
.shudder
	pop bc
	pop hl
	pop af
	ldh [rSVBK], a
	call ShowAbilityBannerBrief
	ld hl, AnticipationShudderText
	jp StdBattleTextbox
.no_shudder
	pop af
	ldh [rSVBK], a
	ret

; --- On-hit abilities -----------------------------------------------------

StenchAbility:
; 10% chance for the attacker's damaging hits to flinch. Doesn't stack
; with moves that already have a flinch chance; Inner Focus blocks it.
; Canon: silent (no banner or message until the flinch itself).
	call OppHasFainted
	ret z
	; A foe that already acted cannot flinch this turn. Leaving the bit set
	; would instead steal its action on the following turn.
	callfar CheckOpponentWentFirst
	ret nz
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	ld hl, .native_flinch_effects
	ld de, 1
	call IsInArray
	ret c
	; Stench and King's Rock/Razor Fang share the added-flinch slot.
	call GetUserItem_Core
	ld a, b
	cp HELD_FLINCH
	ret z
	ld a, 10
	call BattleRandomRange
	and a
	ret nz
	; Reuse the regular handler for sleep, Substitute/Infiltrator, action
	; order, Shield Dust/Inner Focus and recharge handling.
	farcall BattleCommand_FlinchTarget
	ret

.native_flinch_effects
	db EFFECT_FLINCH_HIT
	db EFFECT_SNORE
	db EFFECT_TWISTER
	db EFFECT_STOMP
	db EFFECT_FAKE_OUT
	db EFFECT_SKY_ATTACK
	db -1

PickpocketAbility:
; Contact chain, turn = the defending Pickpocket holder. Steals the
; attacker's held item when the holder has none. Sticky Hold protects
; the attacker; mail can't be taken.
	call UserHasFainted
	ret z
	; the holder's item slot must be empty
	ld hl, wBattleMonItem
	ldh a, [hBattleTurn]
	and a
	jr z, .got_holder_item
	ld hl, wEnemyMonItem
.got_holder_item
	ld a, [hl]
	and a
	ret nz
	; Sticky Hold keeps the attacker's item where it is
	call GetOpponentAbility
	cp STICKY_HOLD
	ret z
	; the attacker must have an item
	ld hl, wEnemyMonItem
	ldh a, [hBattleTurn]
	and a
	jr z, .got_attacker_item
	ld hl, wBattleMonItem
.got_attacker_item
	ld a, [hl]
	and a
	ret z
	; no stealing mail
	ld d, a
	push de
	farcall ItemIsMail
	pop de
	ret c
	ldh a, [hBattleTurn]
	and a
	jr nz, .enemy_holder
	; the player's mon steals the enemy's item.
	; Mirror Thief's rule: no permanent theft in link non-trainer battles.
	ld a, [wLinkMode]
	and a
	jr z, .take_from_enemy
	ld a, [wBattleMode]
	dec a
	ret z
.take_from_enemy
	xor a
	ld [wEnemyMonItem], a
	push de
	ld a, MON_ITEM
	call OTPartyAttr
	xor a
	ld [hl], a
	pop de
	ld a, d
	ld [wBattleMonItem], a
	push de
	ld a, MON_ITEM
	call BattlePartyAttr
	pop de
	ld [hl], d
	ld c, 1 ; the enemy side lost its item
	jr .stole
.enemy_holder
	xor a
	ld [wBattleMonItem], a
	push de
	ld a, MON_ITEM
	call BattlePartyAttr
	xor a
	ld [hl], a
	pop de
	ld a, d
	ld [wEnemyMonItem], a
	push de
	ld a, MON_ITEM
	call OTPartyAttr
	pop de
	ld [hl], d
	ld c, 0 ; the player side lost its item
.stole
	; mark the victim's side for Unburden
	push de
	call ReadItemStateFlags
	set 1, b
	call WriteItemStateFlags
	pop de
	; banner, then buffer the name (the banner clobbers wStringBuffer1)
	push de
	call ShowAbilityBannerBrief
	pop de
	ld a, d
	ld [wNamedObjectIndexBuffer], a
	call GetItemName
	ld hl, StoleText
	jp StdBattleTextbox

; --- End-of-turn abilities ------------------------------------------------

HarvestAbility:
; 50% chance (100% in sun) to restore the holder's consumed Berry.
	call GetUserSide
	call ReadItemStateFlags
	bit 0, b
	ret z
	; the holder must currently hold nothing
	ld hl, wBattleMonItem
	ldh a, [hBattleTurn]
	and a
	jr z, .got_item
	ld hl, wEnemyMonItem
.got_item
	ld a, [hl]
	and a
	ret nz
	; the consumed item must have been a Berry
	call ReadConsumedItem
	ld a, b
	and a
	ret z
	push bc
	ld hl, BerryItems
	ld de, 1
	call IsInArray
	pop bc
	ret nc
	; roll: guaranteed in sun, 50% otherwise
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jr z, .restore
	ld a, 2
	call BattleRandomRange
	and a
	ret nz
.restore
	; put the Berry back: battle item...
	ld hl, wBattleMonItem
	ldh a, [hBattleTurn]
	and a
	jr z, .got_item2
	ld hl, wEnemyMonItem
.got_item2
	ld [hl], b
	; ...and the party struct (skip the OT struct in wild battles)
	push bc
	ldh a, [hBattleTurn]
	and a
	jr nz, .enemy_struct
	ld a, MON_ITEM
	call BattlePartyAttr
	jr .write_struct
.enemy_struct
	ld a, [wBattleMode]
	dec a
	jr z, .skip_struct
	ld a, MON_ITEM
	call OTPartyAttr
.write_struct
	pop bc
	ld [hl], b
	push bc
	jr .cleared
.skip_struct
	pop bc
	push bc
.cleared
	; forget the consumed record (the Berry is back)
	call GetUserSide
	ld b, 0
	call WriteItemStateFlags
	call WriteConsumedItem
	pop bc
	; banner + text with the item name
	push bc
	call ShowAbilityBannerBrief
	pop bc
	ld a, b
	call AbilityBufferItemName
	ld hl, HarvestedBerryText
	jp StdBattleTextbox

IsBerryItem_Core:
; Returns carry if item b is a Berry (used by Incinerate).
	ld a, b
	ld hl, BerryItems
	ld de, 1
	jp IsInArray

BerryItems:
	db PSNCUREBERRY
	db PRZCUREBERRY
	db BURNT_BERRY
	db ICE_BERRY
	db BITTER_BERRY
	db MINT_BERRY
	db MIRACLEBERRY
	db MYSTERYBERRY
	db BERRY
	db GOLD_BERRY
	db -1

CudChewAbility:
; The end of the turn after eating an HP Berry, eats it again.
	call GetUserSide
	call ReadItemStateFlags
	; Bit 2 (armed) becomes bit 3 (due) at the start of the next turn (see
	; PromoteCudChewFlags), so a Berry eaten mid-turn (right after a hit) is
	; not replayed until the end of the following turn.
	bit 3, b
	ret z
	res 2, b
	res 3, b
	call WriteItemStateFlags
	call ReadConsumedItem
	ld a, b
	and a
	ret z
	push bc
	farcall GetItemHeldEffect
	ld a, b
	pop de ; e = item id (unused; kept for clarity)
	cp HELD_BERRY
	ret nz
	; bc = 0:param = the Berry's heal amount
	ld b, 0
	call CheckUserFullHP
	ret z
	push bc
	call ShowAbilityBannerBrief
	pop bc
	call AbilityRestoreUserHP
	ld hl, RegainedHealthText
	call StdBattleTextbox
	jp EndAbility

PromoteCudChewFlags::
; Called at the start of every turn: a Berry eaten before this turn is due
; for Cud Chew at this turn's end.
	ld c, 0
	call .side
	ld c, 1
.side
	call ReadItemStateFlags
	bit 2, b
	ret z
	res 2, b
	set 3, b
	jp WriteItemStateFlags

; --- Escape / force-switch ------------------------------------------------

StickyHoldAnnounce_Core::
; Farcalled from Thief/Knock Off when the victim's Sticky Hold keeps its
; item: just present the victim's banner.
	jp ShowEnemyAbilityBannerBrief

MarkSideLostItem_Core::
; c = side that lost its held item (for Unburden).
	call ReadItemStateFlags
	set 1, b
	jp WriteItemStateFlags

CheckAmuletCoin_Core::
; Post-battle money hook. Klutz disables the active battler's Amulet Coin.
	call GetPlayerAbilityEffective
	cp KLUTZ
	ret z
	ld a, [wBattleMonItem]
	ld b, a
	farcall GetItemHeldEffect
	ld a, b
	cp HELD_AMULET_COIN
	ret nz
	ld a, 1
	ld [wAmuletCoin], a
	ret

CheckRunAwayEscape_Core::
; Farcalled from TryToRunAwayFromBattle after the trainer-battle check.
; Carry if the player's mon flees with Run Away (ignores trapping). When it
; does not, b reports whether effective Klutz suppresses its Smoke Ball.
	call GetPlayerAbilityEffective
	cp RUN_AWAY
	jr z, .escape
	cp KLUTZ
	jr z, .klutz
	ld b, FALSE
	and a
	ret
.klutz
	ld b, TRUE
	and a
	ret
.escape
	call SetPlayerTurn
	call ShowAbilityBannerBrief
	scf
	ret

SuctionCupsBlock_Core::
; Farcalled from BattleCommand_ForceSwitch. Carry if the force-switch
; target (the turn holder's opponent) anchors itself.
	call GetOpponentIgnorableAbility
	cp SUCTION_CUPS
	jr z, .block
	and a
	ret
.block
	call ShowEnemyAbilityBannerBrief
	ld hl, AnchorsItselfText
	call StdBattleTextbox
	scf
	ret

; --- Relocated Effect Commands bodies -------------------------------------

EarlyBirdPlayerSleep::
; Replaces "dec a / ld [wBattleMonStatus], a / and SLP" in the player's
; sleep path of BattleCommand_CheckTurn. Early Bird ticks twice.
; Returns the remaining sleep count's flags (and the count in c).
	ld a, [wBattleMonStatus]
	and SLP
	dec a
	jr z, .store
	ld b, a
	call GetPlayerAbilityEffective
	cp EARLY_BIRD
	ld a, b
	jr nz, .store
	dec a
.store
	ld [wBattleMonStatus], a
	and SLP
	ld c, a
	ret

EarlyBirdEnemySleep::
; Enemy-side twin of EarlyBirdPlayerSleep.
	ld a, [wEnemyMonStatus]
	and SLP
	dec a
	jr z, .store
	ld b, a
	call GetEnemyAbilityEffective
	cp EARLY_BIRD
	ld a, b
	jr nz, .store
	dec a
.store
	ld [wEnemyMonStatus], a
	and SLP
	ld c, a
	ret

CheckSubstituteOpp_Core::
; Relocated body of CheckSubstituteOpp. nz = a Substitute is in the way.
; The attacker's Infiltrator ignores it.
	ld a, [wHitSubstitute]
	and a
	ret nz ; the just-completed hit struck even a now-broken Substitute
	call UserMoveBypassesSubstitute_Core
	jr c, .pierce
	ld a, BATTLE_VARS_SUBSTATUS4_OPP
	call GetBattleVar
	bit SUBSTATUS_SUBSTITUTE, a
	ret
.pierce
	xor a
	ret

AbilitySubBypass_Core::
; Replaces "ld c, FALSE" before the damage application: c = TRUE when
; the attacker's Infiltrator makes the hit go through a Substitute.
	call UserMoveBypassesSubstitute_Core
	ld c, FALSE
	ret nc
	inc c ; TRUE
	ret

UserMoveBypassesSubstitute_Core::
; Carry if the current move reaches its target through a Substitute.
; Since Gen VI, sound moves bypass it independently of Infiltrator.
; Preserves bc/de/hl for accuracy, damage, and secondary-effect callers.
	push hl
	push de
	push bc
	call GetTrueUserAbility
	cp INFILTRATOR
	jr z, .yes
	ld hl, SoundMoves
	call CurrentMoveInList
	jr c, .yes
	pop bc
	pop de
	pop hl
	and a
	ret
.yes
	pop bc
	pop de
	pop hl
	scf
	ret

SafeCheckSafeguard_Core::
; Relocated body of SafeCheckSafeguard; nz = Safeguard protects the
; opponent. The attacker's Infiltrator ignores Safeguard.
	push hl
	call GetTrueUserAbility
	cp INFILTRATOR
	jr z, .pierced
	ld hl, wEnemyScreens
	ldh a, [hBattleTurn]
	and a
	jr z, .got_turn
	ld hl, wPlayerScreens
.got_turn
	bit SCREENS_SAFEGUARD, [hl]
	pop hl
	ret
.pierced
	xor a
	pop hl
	ret

CheckPoisonTypeImmunity_Core::
; Relocated body of CheckIfTargetIsPoisonType.
; z = the target's typing (Poison/Steel) blocks poison. The attacker's
; Corrosion ignores that typing.
	call GetTrueUserAbility
	cp CORROSION
	jr z, .corrosion
	ld de, wEnemyMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .ok
	ld de, wBattleMonType1
.ok
	ld b, 2
.type_loop
	ld a, [de]
	inc de
	cp POISON
	ret z
	cp STEEL
	ret z
	dec b
	jr nz, .type_loop
.corrosion
	or 1
	ret

CorrosionPiercesCurrentMove_Core::
; b = TRUE when Corrosion should neutralize Poison-vs-Steel immunity for the
; current poison-inflicting move; damaging Poison attacks remain ineffective.
	call GetTrueUserAbility
	cp CORROSION
	jr nz, .no
	ld a, BATTLE_VARS_MOVE_TYPE
	call GetBattleVar
	cp POISON
	jr nz, .no
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_POISON
	jr z, .yes
	cp EFFECT_TOXIC
	jr z, .yes
.no
	ld b, FALSE
	ret
.yes
	ld b, TRUE
	ret

GetUserItem_Core::
; Relocated GetUserItem: hl = item addr, bc = effect/param.
; A Klutz holder's item has no effect (b = 0), though it stays held.
	ld hl, wBattleMonItem
	ldh a, [hBattleTurn]
	and a
	jr z, .go
	ld hl, wEnemyMonItem
.go
	call GetTrueUserAbility
	cp KLUTZ
	jr z, .klutz
	ld b, [hl]
	push hl ; the farcall macro clobbers hl; callers need the item addr
	farcall GetItemHeldEffect
	pop hl
	ret
.klutz
	ld b, 0
	ld c, 0
	ret

GetOpponentItem_Core::
; Relocated GetOpponentItem: hl = item addr, bc = effect/param.
; A Klutz holder's item has no effect (b = 0), though it stays held.
	ld hl, wEnemyMonItem
	ldh a, [hBattleTurn]
	and a
	jr z, .go
	ld hl, wBattleMonItem
.go
	call GetOpponentAbility
	cp KLUTZ
	jr z, .klutz
	ld b, [hl]
	push hl ; the farcall macro clobbers hl; callers need the item addr
	farcall GetItemHeldEffect
	pop hl
	ret
.klutz
	ld b, 0
	ld c, 0
	ret

BerryThresholdCheck_Core::
; Farcalled from HandleHPHealingItem in place of its inline HP compare.
; The holder is the turn holder's OPPONENT (held-item convention).
; Returns carry when the Berry should be eaten: at or below 1/2 max HP.
; The supported HP Berries already use the half-HP threshold; Gluttony
; only advances quarter-HP pinch Berries, which are not in this item set.
; Doubles the heal amount (c) for Ripen, except for Berry Juice.
; Exit contract (the caller's heal code depends on it): hl = max HP ptr,
; de = current HP low-byte ptr, current HP mirrored into wBuffer3/4.
	ld de, wEnemyMonHP + 1
	ld hl, wEnemyMonMaxHP
	ldh a, [hBattleTurn]
	and a
	jr z, .got_ptrs
	ld de, wBattleMonHP + 1
	ld hl, wBattleMonMaxHP
.got_ptrs
	push hl
	push de
	push bc
	; current HP -> wBuffer3/4 and bc
	ld a, [de]
	ld [wBuffer3], a
	ld c, a
	dec de
	ld a, [de]
	ld [wBuffer4], a
	ld b, a
	; max HP -> de
	ld a, [hli]
	ld d, a
	ld e, [hl]
	; HELD_BERRY is also used by Berry Juice. Keep the actual item id so
	; Ripen only modifies real Berries.
	ldh a, [hBattleTurn]
	and a
	ld a, [wEnemyMonItem]
	jr z, .got_holder_item
	ld a, [wBattleMonItem]
.got_holder_item
	push af
	; eat when HP * 2 <= max
	sla c
	rl b
.compare
	ld a, b
	cp d
	jr c, .eat
	jr nz, .no
	ld a, c
	cp e
	jr c, .eat
	jr z, .eat
.no
	pop af ; actual held item
	pop bc
	pop de
	pop hl
	and a
	ret
.eat
	pop af ; actual held item
	ld h, a
	pop bc
	; Ripen doubles the restored amount
	call GetOpponentAbility
	cp RIPEN
	jr nz, .no_ripen
	ld a, h
	cp BERRY_JUICE
	jr z, .no_ripen
	sla c
.no_ripen
	pop de
	pop hl
	scf
	ret

SECTION "Mimikyu Broken Pics", ROMX

MimikyuBrokenFrontpic: INCBIN "gfx/pokemon/mimikyu-broken/front.animated.2bpp.lz"
MimikyuBrokenBackpic:  INCBIN "gfx/pokemon/mimikyu-broken/back.2bpp.lz"
