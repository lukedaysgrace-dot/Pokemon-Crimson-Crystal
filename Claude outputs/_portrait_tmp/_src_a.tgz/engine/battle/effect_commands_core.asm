; Effect Commands overflow (Battle Effect Overflow bank) — keeps Effect Commands bank under its limit.

BattleCurl_Core:
	ld a, BATTLE_VARS_SUBSTATUS2
	call GetBattleVarAddr
	set SUBSTATUS_CURLED, [hl]
	ret

BattleCheckRampage_Core:
	ld de, wPlayerRolloutCount
	ldh a, [hBattleTurn]
	and a
	jr z, .player
	ld de, wEnemyRolloutCount
.player
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVarAddr
	bit SUBSTATUS_RAMPAGE, [hl]
	ret z
	ld a, [de]
	dec a
	ld [de], a
	jr nz, .continue_rampage

	res SUBSTATUS_RAMPAGE, [hl]
	callfar BattleCommand_SwitchTurn
	callfar SafeCheckSafeguard
	push af
	callfar BattleCommand_SwitchTurn
	pop af
	jr nz, .continue_rampage

	; Own Tempo prevents fatigue confusion (silently, like Safeguard)
	farcall GetTrueUserAbility_b
	ld a, b
	cp OWN_TEMPO
	jr z, .continue_rampage

	; NOTE: the callfar/farcall macros above load their TARGET ADDRESS
	; into hl, so the SUBSTATUS3 pointer fetched at the top of this
	; routine is long gone by here - the old "set ..., [hl]" wrote bit 7
	; into a ROM address (an MBC register poke) and fatigue confusion
	; never landed on ANY rampage user (found 2026-08-09 by the battle
	; tester's Thrash probe). Re-fetch the address. de (ConfuseCount
	; pointer - 1) is not touched by these calls and survives.
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVarAddr
	set SUBSTATUS_CONFUSED, [hl]
	call BattleRandom
	and %00000001
	inc a
	inc a
	inc de ; ConfuseCount
	ld [de], a
.continue_rampage
	ld b, rampage_command
	callfar SkipToBattleCommand
	ret

BattleRampage_Core:
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and SLP
	ret nz

	ld de, wPlayerRolloutCount
	ldh a, [hBattleTurn]
	and a
	jr z, .ok
	ld de, wEnemyRolloutCount
.ok
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVarAddr
	set SUBSTATUS_RAMPAGE, [hl]
	call BattleRandom
	and %00000001
	inc a
	ld [de], a
	ld a, 1
	ld [wSomeoneIsRampaging], a
	ret

BattleRechargeNextTurn_Core:
	ld a, BATTLE_VARS_SUBSTATUS4
	call GetBattleVarAddr
	set SUBSTATUS_RECHARGE, [hl]
	ret

BattleSkipSunCharge_Core:
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	jr z, .skip_charge
	; Mega Sol: the user's Solar Beam acts as if the sun were shining
	farcall GetTrueUserAbility_b
	ld a, b
	cp MEGA_SOL
	ret nz
.skip_charge
	ld b, charge_command
	callfar SkipToBattleCommand
	ret

BattleUserHasLoadedDice_Core:
; Return z if the user holds Loaded Dice.
	push bc
	callfar GetUserItem
	ld a, b
	pop bc
	cp HELD_LOADED_DICE
	ret

BattleCheckHitLoadedDiceTripleKick_Core:
; Return z if Triple Kick/Axel hit 2+ with Loaded Dice or Skill Link.
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_TRIPLE_KICK
	ret nz
	ld a, [wKickCounter]
	and a
	jr z, .first_kick
	push bc
	farcall GetTrueUserAbility_b
	ld a, b
	pop bc
	cp SKILL_LINK
	ret z
	jp BattleUserHasLoadedDice_Core
.first_kick
	or 1
	ret

BattleMultiHitRoll_Core:
; Leave the final endloop loop count in wPredefTemp.
; Must not return it in a: callfar clobbers a while restoring the bank.
; NOTE: BattleRandom itself stores its result in wPredefTemp + 1 (see
; home/random.asm), so that byte can never carry flags out of here.
; (A previous version did exactly that - the "skip inc" flag came back
; as random garbage, loop counts of 0 underflowed to 255 in endloop,
; and multi-hit moves pummeled the target until it fainted.)
	; Skill Link always hits 5 times.
	; MUST preserve bc: EndLoop keeps its hit-counter pointer in bc across
	; this callfar, and farcall passes the callee's final bc back to the
	; caller (clobbering b here wrote the hit count to a stray address -
	; VRAM pixel garbage + "Hit 0 times!").
	push bc
	farcall GetTrueUserAbility_b
	ld a, b
	pop bc
	cp SKILL_LINK
	ld a, 4 ; loop count 4 (5 hits total)
	jr z, .store
	call BattleUserHasLoadedDice_Core
	jr z, .loaded_dice
	call BattleRandom
	and $3
	cp 2
	jr c, .got_roll
	call BattleRandom
	and $3
.got_roll
	inc a ; loop count 1-4 (2-5 hits total)
	jr .store

.loaded_dice
	call BattleRandom
	and 1
	add 3 ; loop count 3-4 (4-5 hits total)
.store
	ld [wPredefTemp], a
	ret



; ==== 2026-07 move expansion cores ====

BattleBanefulBunker_Core:
; Protect variant: also poisons attackers that make contact.
	callfar ProtectChance
	ret c

	; mark this side's protect as a Baneful Bunker
	ld hl, wBunkerFlags
	ldh a, [hBattleTurn]
	and a
	jr nz, .enemy
	set 0, [hl]
	jr .protect
.enemy
	set 1, [hl]
.protect
	ld a, BATTLE_VARS_SUBSTATUS1
	call GetBattleVarAddr
	set SUBSTATUS_PROTECT, [hl]

	callfar AnimateCurrentMove

	ld hl, ProtectedItselfText
	jp StdBattleTextbox

BanefulBunkerPunish_Core:
; Called from CheckHit's protect block: the current turn holder just got
; its contact move blocked. Poison it if the block was a Baneful Bunker.
	ld hl, wBunkerFlags
	ldh a, [hBattleTurn]
	and a
	jr z, .attacker_is_player
	bit 0, [hl] ; defender is the player
	ret z
	jr .bunkered
.attacker_is_player
	bit 1, [hl] ; defender is the enemy
	ret z
.bunkered
	farcall CheckContactMove
	ret nc

	; the victim here is the ATTACKER (the current turn holder)
	ld a, BATTLE_VARS_STATUS
	call GetBattleVarAddr
	ld a, [hl]
	and a
	ret nz ; already has a status

	ld de, wBattleMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld de, wEnemyMonType1
.got_types
	ld a, [de]
	cp POISON
	jr z, .immune_type
	cp STEEL
	jr z, .immune_type
	inc de
	ld a, [de]
	cp POISON
	jr z, .immune_type
	cp STEEL
	jr nz, .ability_check
.immune_type
	; The Bunker holder is the current user's opponent and is the source of
	; this poison; its Corrosion can poison an otherwise immune attacker.
	push hl
	push de
	farcall GetOpponentAbility_b
	ld a, b
	pop de
	pop hl
	cp CORROSION
	ret nz

.ability_check
	push hl
	farcall GetTrueUserAbility_b
	pop hl
	ld a, b
	cp IMMUNITY
	ret z
	cp PASTEL_VEIL
	ret z
	cp LEAF_GUARD
	jr nz, .ability_allows
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	ret z
.ability_allows

	; the attacker's own Safeguard protects it
	push hl
	ld hl, wPlayerScreens
	ldh a, [hBattleTurn]
	and a
	jr z, .got_safeguard
	ld hl, wEnemyScreens
.got_safeguard
	bit SCREENS_SAFEGUARD, [hl]
	pop hl
	ret nz

	set PSN, [hl]
	call UpdateUserInParty
	ld de, ANIM_PSN
	ld a, e
	ld [wFXAnimID], a
	ld a, d
	ld [wFXAnimID + 1], a
	xor a
	ld [wNumHits], a
	farcall PlayBattleAnim
	call RefreshBattleHuds
	ld hl, UserWasPoisonedText
	call StdBattleTextbox
	; The poisoned attacker is the current turn holder. Switch to the
	; Bunker user's perspective so Synchronize/Poison Puppeteer and the
	; shared held-item handler all see the poisoned mon as the opponent.
	farcall SwitchTurn
	farcall RunSynchronizePsn
	farcall UseHeldStatusHealingItem
	farcall SwitchTurn
	ret

BattleDireClaw_Core:
; 50% chance (the move's effect chance) of poison, paralysis or sleep.
	; Octazooka's DEFENSE + SPCL.DEF drop shares this command
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_DEF_SPDEF_DOWN_HIT
	jr nz, .dire_claw
	farcall BattleDefSpDefDownHit_Core
	ret
.dire_claw
	callfar BattleCommand_EffectChance
	ld a, [wEffectFailed]
	and a
	ret nz
.roll
	call BattleRandom
	swap a
	and %11
	jr z, .roll
	dec a
	jr z, .paralyze
	dec a
	jr z, .poison
	; sleep, applied silently on failure (unlike the sleeptarget command)
	ld a, [wAttackMissed]
	and a
	ret nz
	callfar CheckSubstituteOpp
	ret nz
	callfar SafeCheckSafeguard
	ret nz
	farcall AbilityPreventsSleep
	ret c
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	ld a, [hl]
	and a
	ret nz
.sleep_roll
	call BattleRandom
	swap a
	and %11
	jr z, .sleep_roll
	inc a ; 2-4 counter gives 1-3 sleeping turns (as SleepTarget)
	ld [hl], a
	call UpdateOpponentInParty
	ld de, ANIM_SLP
	farcall AbilityStatusAnim
	call RefreshBattleHuds
	ld hl, FellAsleepText
	call StdBattleTextbox
	farcall UseHeldStatusHealingItem
	ret

.paralyze
	callfar BattleCommand_ParalyzeTarget
	ret

.poison
	callfar BattleCommand_PoisonTarget
	ret

SetStealthRockSide:
; hl = the side's screens byte for the CURRENT TARGET
	ld hl, wEnemyScreens
	ldh a, [hBattleTurn]
	and a
	ret z
	ld hl, wPlayerScreens
	ret

BattleStealthRock_Core:
; Scatter pointed stones on the target's side. Fails if already set.
	call SetStealthRockSide
	bit SCREENS_STEALTH_ROCK, [hl]
	jr nz, .failed
	set SCREENS_STEALTH_ROCK, [hl]
	callfar AnimateCurrentMove
	ld hl, StealthRockText
	jp StdBattleTextbox
.failed
	callfar FailMove
	ret

BattleStealthRockHit_Core:
; Stone Axe: leave stealth rocks after a successful hit (silent if
; stones are already floating). Its guaranteed hazard is a removable
; secondary effect, so Sheer Force suppresses it on both ordinary hits
; and the KO hook. Do not use EffectChance here: Stone Axe intentionally
; lays rocks through Substitute, matching its after-sub-damage behavior.
	farcall GetTrueUserAbility_b
	ld a, b
	cp SHEER_FORCE
	jr nz, .apply
	farcall CurrentMoveHasSheerForceEffect
	ret c
.apply
	; Contact damage and Life Orb run from checkfaint before its Stone Axe
	; KO hook. The hazard is not placed if those reactions fainted the user.
	farcall UserHasFainted
	ret z
	ld a, [wAttackMissed]
	and a
	ret nz
	call SetStealthRockSide
	bit SCREENS_STEALTH_ROCK, [hl]
	ret nz
	set SCREENS_STEALTH_ROCK, [hl]
	ld hl, StealthRockText
	jp StdBattleTextbox

StealthRockEntryDamage:
; Hurt a mon switching in if pointed stones float on its side.
; Like SpikesDamage, the victim is the current turn holder.
	ld hl, wPlayerScreens
	ldh a, [hBattleTurn]
	and a
	jr z, .got_side
	ld hl, wEnemyScreens
.got_side
	bit SCREENS_STEALTH_ROCK, [hl]
	ret z

	; Magic Guard prevents hazard damage, but not the Toxic Spikes
	; processing that follows when this routine returns to its caller.
	call UserHasMagicGuard_Core
	ret z

	; damage = 1/8 max HP scaled by ROCK's effectiveness on the victim
	ld hl, wBattleMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wEnemyMonType1
.got_types
	; callfar clobbers a and hl, so CheckTypeMatchup never saw its inputs
	; and the scaling was dead (audit 2026-08-28 #3). Use the FarCall_de
	; trampoline into CheckTypeMatchupFar (b = type, hl = types).
	ld b, ROCK
	ld a, BANK(CheckTypeMatchupFar)
	ld de, CheckTypeMatchupFar
	call FarCall_de

	callfar GetEighthMaxHP
	ld a, [wTypeMatchup]
	cp 10
	jr z, .apply
	cp 20
	jr nz, .not_double
	sla c
	rl b
	jr .apply
.not_double
	cp 40
	jr nz, .not_quadruple
	sla c
	rl b
	sla c
	rl b
	jr .apply
.not_quadruple
	cp 5
	jr nz, .quarter
	srl b
	rr c
	jr .min_one
.quarter
	srl b
	rr c
	srl b
	rr c
.min_one
	ld a, b
	or c
	jr nz, .apply
	inc c
.apply
	push bc
	ld hl, StealthRockHurtText
	call StdBattleTextbox
	pop bc
	callfar SubtractHPFromTarget
	call RefreshBattleHuds
	ret

BattleDefog_Core:
; Blow away hazards on both sides and screens on the target's side.
	ld a, [wAttackMissed]
	and a
	ret nz
	ld e, 0 ; "cleared anything" flag

	ld hl, wPlayerScreens
	call .clear_hazards
	ld hl, wEnemyScreens
	call .clear_hazards

	ld hl, wEnemyScreens
	ld bc, wEnemyLightScreenCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_screens
	ld hl, wPlayerScreens
	ld bc, wPlayerLightScreenCount
.got_screens
	ld a, [hl]
	and 1 << SCREENS_LIGHT_SCREEN | 1 << SCREENS_REFLECT
	jr z, .no_screens
	ld e, 1
	ld a, [hl]
	and (1 << SCREENS_LIGHT_SCREEN | 1 << SCREENS_REFLECT) ^ $ff
	ld [hl], a
	xor a
	ld [bc], a ; light screen count
	inc bc
	ld [bc], a ; reflect count
.no_screens
	ld a, e
	and a
	ret z
	ld hl, DefogClearedText
	jp StdBattleTextbox

.clear_hazards
	ld a, [hl]
	ld d, a
	and SCREENS_HAZARDS_MASK ; spikes, toxic spikes, stealth rock, sticky web
	ret z
	ld e, 1
	ld a, d
	and SCREENS_HAZARDS_MASK ^ $ff
	ld [hl], a
	; both sides' hazards are being cleared; drop the spikes layer counts
	xor a
	ld [wPlayerSpikesLayers], a
	ld [wEnemySpikesLayers], a
	ret

BattleGlaiveRush_Core:
; After a landed Glaive Rush, the user can't avoid attacks and takes
; double damage until the start of its next turn.
	ld a, [wAttackMissed]
	and a
	ret nz
	ld hl, wPlayerGlaiveRush
	ldh a, [hBattleTurn]
	and a
	jr z, .got_flag
	inc hl ; wEnemyGlaiveRush
.got_flag
	ld [hl], 1
	ret

GlaiveRushIncomingDouble_Core:
; Double the computed damage if the DEFENDER is in Glaive Rush recoil.
	ld a, [wIsConfusionDamage]
	and a
	ret nz
	ldh a, [hBattleTurn]
	and a
	jr z, .player_attacking
	ld a, [wPlayerGlaiveRush]
	jr .check
.player_attacking
	ld a, [wEnemyGlaiveRush]
.check
	and a
	ret z
	jp DoubleDamage_Core

BattleFickleBeam_Core:
; 30% of the time Fickle Beam fires at double power.
	; runs after checkhit: don't roll (or print) once the move has missed
	ld a, [wAttackMissed]
	and a
	ret nz
	call BattleRandom
	cp 30 percent
	ret nc
	call DoubleDamage_Core
	ld hl, FickleBeamAllOutText
	jp StdBattleTextbox

BattleRageFistPower_Core:
; d = move power. Add 50 per hit the user has taken (capped at 250).
	ldh a, [hBattleTurn]
	and a
	jr z, .player
	ld a, [wEnemyRageFistHits]
	jr .got_hits
.player
	ld a, [wPlayerRageFistHits]
.got_hits
	cp 5
	jr c, .capped
	ld a, 4
.capped
	and a
	ret z
.loop
	push af
	ld a, d
	add 50
	ld d, a
	pop af
	dec a
	jr nz, .loop
	ret

BattleShellSideArm_Core:
; Become physical or special, whichever would hit harder:
; physical if Atk * target SpDef > SpAtk * target Def (ties go special).
; All four stats are halved together until they fit in 8 bits, which
; preserves the comparison. Uses the stats as modified by stat stages,
; like the games do.
	ldh a, [hBattleTurn]
	and a
	jr nz, .enemy_user
	ld a, [wBattleMonAttack]
	ld [wBuffer1], a
	ld a, [wBattleMonAttack + 1]
	ld [wBuffer2], a
	ld a, [wBattleMonSpclAtk]
	ld [wBuffer3], a
	ld a, [wBattleMonSpclAtk + 1]
	ld [wBuffer4], a
	ld a, [wEnemyMonDefense]
	ld [wBuffer5], a
	ld a, [wEnemyMonDefense + 1]
	ld [wBuffer6], a
	ld a, [wEnemyMonSpclDef]
	ld [wCurDamage], a
	ld a, [wEnemyMonSpclDef + 1]
	ld [wCurDamage + 1], a
	jr .shift_loop
.enemy_user
	ld a, [wEnemyMonAttack]
	ld [wBuffer1], a
	ld a, [wEnemyMonAttack + 1]
	ld [wBuffer2], a
	ld a, [wEnemyMonSpclAtk]
	ld [wBuffer3], a
	ld a, [wEnemyMonSpclAtk + 1]
	ld [wBuffer4], a
	ld a, [wBattleMonDefense]
	ld [wBuffer5], a
	ld a, [wBattleMonDefense + 1]
	ld [wBuffer6], a
	ld a, [wBattleMonSpclDef]
	ld [wCurDamage], a
	ld a, [wBattleMonSpclDef + 1]
	ld [wCurDamage + 1], a

.shift_loop
	ld a, [wBuffer1]
	ld b, a
	ld a, [wBuffer3]
	or b
	ld b, a
	ld a, [wBuffer5]
	or b
	ld b, a
	ld a, [wCurDamage]
	or b
	jr z, .small_enough
	ld hl, wBuffer1
	call .halve
	ld hl, wBuffer3
	call .halve
	ld hl, wBuffer5
	call .halve
	ld hl, wCurDamage
	call .halve
	jr .shift_loop

.halve
	ld a, [hl]
	srl a
	ld [hli], a
	ld a, [hl]
	rra
	ld [hld], a
	ret

.small_enough
	; m1 = Atk * target SpDef
	xor a
	ldh [hMultiplicand + 0], a
	ldh [hMultiplicand + 1], a
	ld a, [wBuffer2]
	ldh [hMultiplicand + 2], a
	ld a, [wCurDamage + 1]
	ldh [hMultiplier], a
	call Multiply
	ldh a, [hProduct + 2]
	ld d, a
	ldh a, [hProduct + 3]
	ld e, a
	; m2 = SpAtk * target Def
	xor a
	ldh [hMultiplicand + 0], a
	ldh [hMultiplicand + 1], a
	ld a, [wBuffer4]
	ldh [hMultiplicand + 2], a
	ld a, [wBuffer6]
	ldh [hMultiplier], a
	call Multiply
	ldh a, [hProduct + 2]
	ld b, a
	ldh a, [hProduct + 3]
	ld c, a
	; physical iff de > bc
	ld a, d
	cp b
	jr c, .special
	jr nz, .physical
	ld a, e
	cp c
	jr c, .special
	jr z, .special
.physical
	ld b, CATEGORIZE_PHYSICAL
	jr .store
.special
	ld b, CATEGORIZE_SPECIAL
.store
	ld hl, wPlayerMoveStructCategory
	ldh a, [hBattleTurn]
	and a
	jr z, .store_it
	ld hl, wEnemyMoveStructCategory
.store_it
	ld [hl], b
	; wCurDamage was used as scratch; damagestats resets it anyway
	xor a
	ld [wCurDamage], a
	ld [wCurDamage + 1], a
	ret

BattleEerieSpell_Core:
; Sap 3 PP from the target's last used move (silent when impossible).
; It is a guaranteed additional effect: Sheer Force boosts the hit and
; suppresses this PP loss. Keep the direct gate so Eerie Spell retains its
; intentional ability to affect a target behind Substitute.
	farcall GetTrueUserAbility_b
	ld a, b
	cp SHEER_FORCE
	jr nz, .apply
	farcall CurrentMoveHasSheerForceEffect
	ret c
.apply
	ld a, [wAttackMissed]
	and a
	ret nz
	ld bc, PARTYMON_STRUCT_LENGTH
	ld hl, wEnemyMonMoves
	ldh a, [hBattleTurn]
	and a
	jr z, .got_moves
	ld hl, wBattleMonMoves
.got_moves
	ld a, BATTLE_VARS_LAST_COUNTER_MOVE_OPP
	call GetBattleVar
	and a
	ret z
	ld b, a
	push bc
	push hl
	ld bc, STRUGGLE
	callfar CompareMove
	pop hl
	pop bc
	ret z
	ld c, -1
.loop
	inc c
	ld a, c
	cp NUM_MOVES
	ret nc ; not in the move list anymore (Mimic etc.) - no effect
	ld a, [hli]
	cp b
	jr nz, .loop
	ld [wNamedObjectIndexBuffer], a
	dec hl
	ld b, 0
	push bc
	ld c, wBattleMonPP - wBattleMonMoves
	add hl, bc
	pop bc
	ld a, [hl]
	and PP_MASK
	ret z
	push bc
	call GetMoveName
	ld b, 3 ; always saps 3 PP
	ld a, [hl]
	and PP_MASK
	cp b
	jr nc, .deplete_pp
	ld b, a
.deplete_pp
	ld a, [hl]
	sub b
	ld [hl], a
	push af
	ld a, MON_PP
	call OpponentPartyAttr
	ld d, b
	pop af
	pop bc
	add hl, bc
	ld e, a
	ld a, BATTLE_VARS_SUBSTATUS5_OPP
	call GetBattleVar
	bit SUBSTATUS_TRANSFORMED, a
	jr nz, .transformed
	ldh a, [hBattleTurn]
	and a
	jr nz, .not_wildmon
	ld a, [wBattleMode]
	dec a
	jr nz, .not_wildmon
	ld hl, wWildMonPP
	add hl, bc
.not_wildmon
	ld [hl], e
.transformed
	ld a, d
	ld [wDeciramBuffer], a
	ld hl, SpiteEffectText
	jp StdBattleTextbox

BattleTrapTarget_Core:
; Body of BattleCommand_TrapTarget (moved here for bank space).
	ld a, [wAttackMissed]
	and a
	ret nz
	ld hl, wEnemyWrapCount
	ld de, wEnemyTrappingMove
	ldh a, [hBattleTurn]
	and a
	jr z, .got_trap
	ld hl, wPlayerWrapCount
	ld de, wPlayerTrappingMove

.got_trap
	ld a, [hl]
	and a
	ret nz
	; Infiltrator's binding hit reaches the holder through its Substitute.
	push hl
	push de
	farcall CheckSubstituteOpp
	pop de
	pop hl
	ret nz
	call BattleRandom
	; Modern binding lasts 4-5 turns. The first end-of-turn tick consumes
	; one from this counter before applying damage.
	and 1
	add 5
	ld [hl], a
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVar
	ld [de], a
	call GetMoveIndexFromID
	ld b, h
	ld c, l
	ld hl, .Traps

.find_trap_text
	ld a, [hli]
	cp c
	ld a, [hli]
	jr nz, .next_trap_text
	cp b
	jr z, .found_trap_text
.next_trap_text
	inc hl
	inc hl
	jr .find_trap_text

.found_trap_text
	ld a, [hli]
	ld h, [hl]
	ld l, a
	jp StdBattleTextbox

.Traps:
	dw BIND,      UsedBindText      ; 'used BIND on'
	dw WRAP,      WrappedByText     ; 'was WRAPPED by'
	dw FIRE_SPIN, FireSpinTrapText  ; 'was trapped!'
	dw CLAMP,     ClampedByText     ; 'was CLAMPED by'
	dw WHIRLPOOL, WhirlpoolTrapText ; 'was trapped!'

BattleScaleShotKO_Core:
; Scale Shot still lowers the user's DEFENSE and raises its SPEED when
; the final hit KOs the target (the script's endloop tail never runs in
; that case). Called from BattleCommand_CheckFaint.
	callfar BattleCommand_SaveMiss
	callfar BattleCommand_SwitchTurn
	callfar BattleCommand_DefenseDown
	callfar BattleCommand_SwitchTurn
	callfar BattleCommand_SwitchTurn
	callfar BattleCommand_StatDownMessage
	callfar BattleCommand_SwitchTurn
	callfar BattleCommand_SpeedUp
	callfar BattleCommand_StatUpMessage
	callfar BattleCommand_RestoreMiss
	ret

BattleSuckerPunch_CheckCore:
; Returns carry if Sucker Punch should fail:
; - the target already acted this turn (moved, switched or used an item),
; - the target is recharging, or
; - the target chose a status move (or no move).
	ld a, [wEnemyGoesFirst] ; 0 if the player went first
	ld b, a
	ldh a, [hBattleTurn]    ; 0 if it's the player's turn
	xor b
	jr nz, .fail            ; target went first
	ld a, BATTLE_VARS_SUBSTATUS4_OPP
	call GetBattleVar
	bit SUBSTATUS_RECHARGE, a
	jr nz, .fail
	ld a, [wCurEnemyMove]
	ld b, a
	ldh a, [hBattleTurn]
	and a
	jr z, .got_move
	ld a, [wCurPlayerMove]
	ld b, a
.got_move
	ld a, b
	and a
	jr z, .fail
	ld l, a
	ld a, MOVE_CATEGORY
	call GetMoveAttribute
	cp CATEGORIZE_STATUS
	jr z, .fail
	and a
	ret
.fail
	scf
	ret

BattleBrickBreak_Core:
; Shatter Reflect and Light Screen on the target's side once the move is
; known to connect. (The damage itself already ignored them: see
; CheckDefScreenPierced.) If the target is immune to the move (e.g. a
; Ghost type against this Fighting move), protected, out of reach or
; simply dodged it, the screens are spared.
	ld a, [wAttackMissed]
	and a
	ret nz
	callfar BattleCheckTypeMatchup
	ld a, [wTypeMatchup]
	and a
	ret z

	ld hl, wEnemyScreens
	ld de, wEnemyLightScreenCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_screens
	ld hl, wPlayerScreens
	ld de, wPlayerLightScreenCount
.got_screens
	ld a, [hl]
	and 1 << SCREENS_LIGHT_SCREEN | 1 << SCREENS_REFLECT
	ret z

	ld a, [hl]
	and (1 << SCREENS_LIGHT_SCREEN | 1 << SCREENS_REFLECT) ^ $ff
	ld [hl], a
	xor a
	ld [de], a ; light screen count
	inc de
	ld [de], a ; reflect count
	ld hl, BrickBreakShatterText
	jp StdBattleTextbox

BattleCheckCharge_Core:
	ld a, BATTLE_VARS_SUBSTATUS3
	call GetBattleVarAddr
	bit SUBSTATUS_CHARGED, [hl]
	ret z
	res SUBSTATUS_CHARGED, [hl]
	res SUBSTATUS_UNDERGROUND, [hl]
	res SUBSTATUS_FLYING, [hl]
	ld b, charge_command
	callfar SkipToBattleCommand
	ret

BattleVenoshockDouble_Core:
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	and 1 << PSN
	ret z
	jr DoubleDamage_Core

BattleDoubleFlyingDamage_Core:
	ld a, BATTLE_VARS_SUBSTATUS3_OPP
	call GetBattleVar
	bit SUBSTATUS_FLYING, a
	ret z
	jr DoubleDamage_Core

BattleDoubleUndergroundDamage_Core:
	ld a, BATTLE_VARS_SUBSTATUS3_OPP
	call GetBattleVar
	bit SUBSTATUS_UNDERGROUND, a
	ret z
	jr DoubleDamage_Core

BattleDoubleMinimizeDamage_Core:
	ld hl, wEnemyMinimized
	ldh a, [hBattleTurn]
	and a
	jr z, .ok
	ld hl, wPlayerMinimized
.ok
	ld a, [hl]
	and a
	ret z
	jr DoubleDamage_Core

DoubleDamage_Core:
	ld hl, wCurDamage + 1
	sla [hl]
	dec hl
	rl [hl]
	jr nc, .quit

	ld a, $ff
	ld [hli], a
	ld [hl], a
.quit
	ret

DefendedStatCategory:
; Return in a which defense the current move hits: CATEGORIZE_PHYSICAL or
; CATEGORIZE_SPECIAL. That's the move's category, except for Psystrike,
; which is special but hits Defense. Preserves bc, de and hl.
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_PSYSTRIKE
	ld a, CATEGORIZE_PHYSICAL
	ret z
	push hl
	ld hl, wPlayerMoveStructCategory
	ldh a, [hBattleTurn]
	and a
	jr z, .got_category
	ld hl, wEnemyMoveStructCategory
.got_category
	ld a, [hl]
	pop hl
	ret

HeldDefenseBoost_Core:
; bc = defending stat. Returns boosted bc when applicable.
	push hl
	push de
	push bc
	callfar GetOpponentItem
	ld a, b
	cp HELD_ASSAULT_VEST
	jr z, .assault_vest
	cp HELD_EVIOLITE
	jr z, .eviolite
	pop bc
	jr .done
.assault_vest
	call .CurrentMoveCategory
	cp CATEGORIZE_SPECIAL
	pop bc
	jr nz, .done
	call .BoostBCx1_5
	jr .done
.eviolite
	call .OpponentCanEvolve
	pop bc
	jr nc, .done
	call .BoostBCx1_5
.done
	pop de
	pop hl
	ret

.CurrentMoveCategory
	jp DefendedStatCategory


.OpponentCanEvolve
	ld a, [wEnemyMonSpecies]
	ldh [hTemp], a
	ldh a, [hBattleTurn]
	and a
	jr z, .got_species
	ld a, [wBattleMonSpecies]
	ldh [hTemp], a
.got_species
	ldh a, [hTemp]
	call GetPokemonIndexFromID
	ld b, h
	ld c, l
	ld hl, EvosAttacksPointers
	ld a, BANK(EvosAttacksPointers)
	call LoadDoubleIndirectPointer
	call GetFarByte
	and a
	ret z
	scf
	ret

.BoostBCx1_5
	ld h, b
	ld l, c
	ld d, b
	ld e, c
	srl d
	rr e
	add hl, de
	jr nc, .store_boost
	ld hl, $ffff
.store_boost
	ld b, h
	ld c, l
	ret

DittoMetalPowder_Core::
; Apply Metal Powder's 1.5x defensive boost before the 16-to-8-bit stat
; truncation. Applying it afterwards can increase damage when Defense has
; already been scaled down, and the old bytewise math can overflow.
	ld a, MON_SPECIES
	call BattlePartyAttr
	ldh a, [hBattleTurn]
	and a
	ld a, [hl]
	jr nz, .got_species
	ld a, [wTempEnemyMonSpecies]
.got_species
	push hl
	call GetPokemonIndexFromID
	ld a, l
	sub LOW(DITTO)
	if HIGH(DITTO) == 0
		or h
		pop hl
	else
		ld a, h
		pop hl
		ret nz
		if HIGH(DITTO) == 1
			dec a
		else
			cp HIGH(DITTO)
		endc
	endc
	ret nz

	push bc
	callfar GetOpponentItem
	ld a, [hl]
	cp METAL_POWDER
	pop bc
	ret nz

	ld h, b
	ld l, c
	srl b
	rr c
	add hl, bc
	ld b, h
	ld c, l
	ld a, HIGH(MAX_STAT_VALUE)
	cp b
	jr c, .cap
	ret nz
	ld a, LOW(MAX_STAT_VALUE)
	cp c
	ret nc
.cap
	ld bc, MAX_STAT_VALUE
	ret

EndureFocusSashInEffect_Core:
; Carry if ApplyDamage should proceed to damage. b = survival message id.
	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVar
	bit SUBSTATUS_ENDURE, a
	jr z, .sturdy
	farcall BattleCommand_FalseSwipe
	ld b, 0
	jp nc, .go_damage
	ld b, 1
	jp .go_damage
.sturdy
	; Sturdy (Gen 5): survives any hit taken at full HP
	farcall GetOppIgnorableAbility_b
	ld a, b
	cp STURDY
	jr nz, .focus_sash
	ld de, wEnemyMonHP
	ld hl, wEnemyMonMaxHP
	ldh a, [hBattleTurn]
	and a
	jr z, .sturdy_got_hp
	ld de, wBattleMonHP
	ld hl, wBattleMonMaxHP
.sturdy_got_hp
	ld a, [de]
	cp [hl]
	jr nz, .focus_sash
	inc de
	inc hl
	ld a, [de]
	cp [hl]
	jr nz, .focus_sash
	farcall BattleCommand_FalseSwipe
	ld b, 0
	jr nc, .go_damage
	; it would have been KO'd: banner + "endured the hit"
	farcall ShowEnemyAbilityBannerBrief
	ld b, 1
	jr .go_damage
.focus_sash
	callfar GetOpponentItem
	ld a, b
	cp HELD_FOCUS_SASH
	jr nz, .not_sash
	ld de, wEnemyMonHP
	ld hl, wEnemyMonMaxHP
	ldh a, [hBattleTurn]
	and a
	jr z, .got_hp
	ld de, wBattleMonHP
	ld hl, wBattleMonMaxHP
.got_hp
	ld a, [de]
	cp [hl]
	jr nz, .no_trigger
	inc de
	inc hl
	ld a, [de]
	cp [hl]
	jr nz, .no_trigger
	farcall BattleCommand_FalseSwipe
	ld b, 0
	jr nc, .go_damage
	; buffer the Sash's name now: ConsumeHeldItem zeroes the item slot,
	; so the hung-on text in ApplyDamage can't re-read it after damage
	callfar GetOpponentItem
	ld a, [hl]
	ld [wNamedObjectIndexBuffer], a
	call GetItemName
	callfar ConsumeHeldItem
	ld b, 3
.go_damage
	scf
	ret
.no_trigger
	ld b, 0
	scf
	ret
.not_sash
	and a
	ret

BattleStartHail_Core:
	ld a, [wBattleWeather]
	and WEATHER_TYPE_MASK
	cp WEATHER_HAIL
	jr z, .failed

	ld b, WEATHER_HAIL
	farcall SetBattleWeatherFromB
	ld b, WEATHER_HAIL
	farcall SetWeatherDurationFromUserItem
	callfar AnimateCurrentMove
	ld hl, ItStartedToHailText
	jp StdBattleTextbox

.failed
	callfar AnimateFailedMove
	ld hl, ButItFailedText
	jp StdBattleTextbox

WeatherDefenseBoost_Core:
; Raise the defending Pokémon's defense stat in bc by 50%
; if its type benefits from the current weather:
; - Ice-types get 1.5x Defense against physical moves in hail.
; - Rock-types get 1.5x Sp.Def against special moves in a sandstorm.
	push de
	ld a, [wBattleWeather]
	cp WEATHER_HAIL
	jr z, .hail
	cp WEATHER_SANDSTORM
	jr nz, .done
; sandstorm
	ld d, CATEGORIZE_SPECIAL
	ld e, ROCK
	jr .got_weather
.hail
	ld d, CATEGORIZE_PHYSICAL
	ld e, ICE
.got_weather
	call DefendedStatCategory
	cp d
	jr nz, .done
	ld hl, wEnemyMonType1
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wBattleMonType1
.got_types
	ld a, [hli]
	cp e
	jr z, .boost
	ld a, [hl]
	cp e
	jr nz, .done
.boost
; bc = bc * 1.5
	ld h, b
	ld l, c
	srl h
	rr l
	add hl, bc
	ld b, h
	ld c, l
.done
	pop de
	ret

BattleUTurn_Core:
	ld a, [wAttackMissed]
	and a
	ret nz
	; Contact recoil can faint the user in CheckFaint's post-hit hook.
	; A fainted user must go through normal replacement, not pivot out.
	farcall UserHasFainted
	ret z

	ldh a, [hBattleTurn]
	and a
	jp nz, .enemy

	callfar CheckAnyOtherAlivePartyMons
	ret z

	; record the outgoing mon so switch-out abilities (Regenerator/
	; Natural Cure) heal the right party slot in BattleMonEntrance
	ld a, [wCurBattleMon]
	ld [wLastPlayerMon], a

	callfar UpdateBattleMonInParty
	call LoadStandardMenuHeader
	farcall SetUpBattlePartyMenu_NoLoop
	farcall ForcePickSwitchMonInBattle
	call ClearPalettes
	farcall _LoadBattleFontsHPBar
	call CloseWindow
	call ClearSprites
	hlcoord 1, 0
	lb bc, 4, 10
	call ClearBox
	ld b, SCGB_BATTLE_COLORS
	call GetSGBLayout
	call SetPalettes
	callfar BatonPass_LinkPlayerSwitch

	farcall CheckMobileBattleError
	ret c

	; ForcePickSwitchMonInBattle stored the chosen slot in wCurPartyMon, but
	; BattleMonEntrance keys off wCurBattleMon (and overwrites wCurPartyMon
	; from it). Without this copy it re-sends the U-turn user. The normal
	; switch path (TryPlayerSwitch) does the same copy before entering.
	ld a, [wCurPartyMon]
	ld [wCurBattleMon], a

	ld hl, BattleMonEntrance
	ld a, BANK("Battle Core")
	rst FarCall
	ret

.enemy
	ld a, [wBattleMode]
	dec a ; WILDMON
	ret z

	callfar CheckAnyOtherAliveEnemyMons
	ret z

	callfar UpdateEnemyMonInParty
	; switch-out abilities for the outgoing enemy mon
	farcall RunEnemySwitchOutAbilities
	callfar BatonPass_LinkEnemySwitch

	farcall CheckMobileBattleError
	ret c

	; Audit 2026-08-28 #2: this used to jump straight to EnemySwitch, which
	; only loads the mon. Do the full send-out bookkeeping every other enemy
	; entrance path does (EnemyPartyMonEntrance / AI_Switch / Baton Pass):
	; pick the replacement fresh (never reuse a stale wEnemySwitchMonIndex,
	; which could re-send the pivoting mon as itself), clear volatile
	; status and stat stages, and run hazards + entry abilities.
	; EnemySwitch_SetMode also avoids the Shift-mode prompt mid-script.
	callfar AIPickPostKOSwitchIn
	callfar NewEnemyMonStatus
	callfar ResetEnemyStatLevels
	callfar BreakAttraction
	ld hl, EnemySwitch_SetMode
	ld a, BANK("Battle Core")
	rst FarCall
	callfar ResetBattleParticipants
	callfar SetEnemyTurn
	callfar SpikesDamageAndEntryAbilities
	ret

BattleParalyze_Core:
; Relocated from effect_commands.asm; in-bank calls became callfar.
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	bit PAR, a
	jp nz, .paralyzed
	ld a, [wTypeModifier]
	and $7f
	jp z, .didnt_affect
	farcall OpponentIsElectricType
	jp z, .didnt_affect
	callfar GetOpponentItem
	ld a, b
	cp HELD_PREVENT_PARALYZE
	jr nz, .no_item_protection
	ld a, [hl]
	ld [wNamedObjectIndexBuffer], a
	call GetItemName
	callfar AnimateFailedMove
	ld hl, ProtectedByText
	jp StdBattleTextbox

.no_item_protection
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	and a
	jp nz, .failed
	ld a, [wAttackMissed]
	and a
	jp nz, .failed
	; Magic Bounce reflects a status move even from behind the bouncer's
	; own Substitute, and before the AI 25% fail roll (audit 2026-08-28 #14)
	farcall StatDropSubCheckExempt
	jr nc, .no_bounce
	farcall AbilityPreventsParalysis
	jp c, .failed
.no_bounce
	callfar CheckSubstituteOpp
	jp nz, .failed
	; ability check (Limber)
	farcall AbilityPreventsParalysis
	jp c, .failed
	ld c, 30
	call DelayFrames
	callfar AnimateCurrentMove
	ld a, $1
	ldh [hBGMapMode], a
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	set PAR, [hl]
	call UpdateOpponentInParty
	; CallBattleCore lives in the Effect Commands bank; this file is in the
	; Battle Effect Overflow bank, so a plain call to it jumps into garbage
	; and crashes (every move-inflicted paralysis that LANDED did this).
	; farcall does the same job with the target's own bank.
	farcall ApplyPrzEffectOnSpeed
	call UpdateBattleHuds
	callfar PrintParalyze
	; Synchronize passes move-inflicted paralysis back (this body covers
	; the pure status moves - Thunder Wave/Glare/Stun Spore - which were
	; the one paralysis path missing the hook)
	farcall RunSynchronizePar
	farcall UseHeldStatusHealingItem
	ret

.paralyzed
	callfar AnimateFailedMove
	ld hl, AlreadyParalyzedText
	jp StdBattleTextbox

.failed
	callfar PrintDidntAffect2
	ret

.didnt_affect
	callfar AnimateFailedMove
	callfar PrintDoesntAffect
	ret

; (BattleCommand_EffectChance_Core, BattleOHKO_Core and BattleRecoil_Core
; live in the Abilities Engine bank - this bank was full.)

BattleParalyzeTarget_Core:
; Relocated from effect_commands.asm. Adds the missing ability check
; (Limber - secondary paralysis used to bypass it) and Synchronize.
	xor a
	ld [wNumHits], a
	callfar CheckSubstituteOpp
	ret nz
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	and a
	ret nz
	ld a, [wTypeModifier]
	and $7f
	ret z
	farcall OpponentIsElectricType
	ret z
	callfar GetOpponentItem
	ld a, b
	cp HELD_PREVENT_PARALYZE
	ret z
	ld a, [wEffectFailed]
	and a
	ret nz
	callfar SafeCheckSafeguard
	ret nz
	farcall AbilityPreventsParalysis
	ret c
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVarAddr
	set PAR, [hl]
	call UpdateOpponentInParty
	farcall ApplyPrzEffectOnSpeed
	ld de, ANIM_PAR
	farcall AbilityStatusAnim
	call UpdateBattleHuds
	callfar PrintParalyze
	farcall RunSynchronizePar
	farcall UseHeldStatusHealingItem
	ret

HandleStatusOrbs_Core:
; FLAME ORB / TOXIC ORB: status the holder at the end of the turn.
; Self-inflicted, so Safeguard doesn't block it (canon).
; Farcalled from HandleBetweenTurnEffects (core.asm).
	ldh a, [hSerialConnectionStatus]
	cp USING_EXTERNAL_CLOCK
	jr z, .DoEnemyFirst
	call SetPlayerTurn
	call .do_it
	call SetEnemyTurn
	jp .do_it

.DoEnemyFirst:
	call SetEnemyTurn
	call .do_it
	call SetPlayerTurn

.do_it
	callfar GetUserItem
	ld a, b
	cp HELD_FLAME_ORB
	jr z, .flame_orb
	cp HELD_TOXIC_ORB
	jr z, .toxic_orb
	ret

.flame_orb
	call .GetHolderState
	ret c ; fainted or already statused
	; Fire-types can't be burned
	ld a, [de]
	cp FIRE
	ret z
	inc de
	ld a, [de]
	cp FIRE
	ret z
	; nor can mons whose ability prevents burns
	farcall GetTrueUserAbility_b
	ld a, b
	cp WATER_VEIL
	ret z
	cp THERMAL_EXCHANGE
	ret z
	cp LEAF_GUARD
	jr nz, .flame_allowed
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	ret z
.flame_allowed
	call .GetOrbName
	ld a, BATTLE_VARS_STATUS
	call GetBattleVarAddr
	set BRN, [hl]
	call UpdateUserInParty
	; burn halves Attack; ApplyBrnEffectOnAttack works on the
	; opponent of the turn holder, so flip perspective around it
	callfar BattleCommand_SwitchTurn
	farcall ApplyBrnEffectOnAttack
	callfar BattleCommand_SwitchTurn
	ld de, ANIM_BRN
	call .OrbAnim
	call RefreshBattleHuds
	ld hl, BattleText_BurnedByItem
	jp StdBattleTextbox

.toxic_orb
	call .GetHolderState
	ret c ; fainted or already statused
	; Poison- and Steel-types can't be poisoned
	ld a, [de]
	cp POISON
	ret z
	cp STEEL
	ret z
	inc de
	ld a, [de]
	cp POISON
	ret z
	cp STEEL
	ret z
	; nor can mons whose ability prevents poison
	farcall GetTrueUserAbility_b
	ld a, b
	cp IMMUNITY
	ret z
	cp PASTEL_VEIL
	ret z
	cp LEAF_GUARD
	jr nz, .poison_allowed
	ld a, [wBattleWeather]
	cp WEATHER_SUN
	ret z
.poison_allowed
	call .GetOrbName
	ld a, BATTLE_VARS_STATUS
	call GetBattleVarAddr
	set PSN, [hl]
	ld a, BATTLE_VARS_SUBSTATUS5
	call GetBattleVarAddr
	set SUBSTATUS_TOXIC, [hl]
	ld hl, wPlayerToxicCount
	ldh a, [hBattleTurn]
	and a
	jr z, .got_toxic_count
	ld hl, wEnemyToxicCount
.got_toxic_count
	xor a
	ld [hl], a
	call ToxicMarkUser_Core
	call UpdateUserInParty
	ld de, ANIM_PSN
	call .OrbAnim
	call RefreshBattleHuds
	ld hl, BattleText_BadlyPoisonedByItem
	jp StdBattleTextbox

.GetHolderState
; Carry if the holder can't take the orb's status
; (fainted or already statused). Returns de = holder's types.
	ld hl, wBattleMonHP
	ld de, wBattleMonType
	ldh a, [hBattleTurn]
	and a
	jr z, .got_hp
	ld hl, wEnemyMonHP
	ld de, wEnemyMonType
.got_hp
	ld a, [hli]
	or [hl]
	jr z, .cant
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	and a
	jr nz, .cant
	and a ; clear carry
	ret
.cant
	scf
	ret

.GetOrbName
	push de
	callfar GetUserItem
	ld a, [hl]
	ld [wNamedObjectIndexBuffer], a
	call GetItemName
	pop de
	ret

.OrbAnim
; de = anim id. Like ToxicSpikesPoison's poison_anim, the victim is the
; current turn holder, so PlayBattleAnim renders it on the right mon.
	ld a, e
	ld [wFXAnimID], a
	ld a, d
	ld [wFXAnimID + 1], a
	xor a
	ld [wNumHits], a
	farcall PlayBattleAnim
	ret

CheckSpikesUngrounded_Core:
; Carry if the turn holder avoids Spikes: Flying-type, Levitate,
; Air Balloon, or Magic Guard. Body lives here because
; the Battle Core bank is full. Clobbers b, hl.
	ld hl, wBattleMonType
	ldh a, [hBattleTurn]
	and a
	jr z, .got_types
	ld hl, wEnemyMonType
.got_types
	ld a, [hli]
	cp FLYING
	jr z, .ungrounded
	ld a, [hl]
	cp FLYING
	jr z, .ungrounded
	farcall GetTrueUserAbility_b
	ld a, b
	cp LEVITATE
	jr z, .ungrounded
	cp MAGIC_GUARD
	jr z, .ungrounded
	callfar GetUserItem
	ld a, b
	cp HELD_AIR_BALLOON
	jr z, .ungrounded
	and a
	ret
.ungrounded
	scf
	ret

UserHasMagicGuard_Core::
; Return z if the current turn holder's effective ability is Magic Guard.
	farcall GetTrueUserAbility_b
	ld a, b
	cp MAGIC_GUARD
	ret

; ==================================================================
; Stat change messages (moved here from the full Effect Commands bank).
;
; Normal (single-stat) moves behave as before: anim + "X went up!" per
; stat. Multi-stat moves (Bulk Up, Shell Smash, Close Combat, Curse,
; Ancient Power, ...) wrap their stat changes in deferstatmessages /
; flushstatmessages: each raise/drop is recorded in a bitmask, then the
; flush plays the stat up anim ONCE with one combined message listing
; every raised stat, and likewise the stat down anim once for the drops.
; ==================================================================

StatUpMessage_Core:
	ld a, [wFailedMessage]
	and a
	ret nz
	; bit 7 of wLoweredStat: Contrary already printed its own "fell"
	ld a, [wLoweredStat]
	bit 7, a
	jr z, .show
	and $7f
	ld [wLoweredStat], a
	ret
.show
	ld a, [wStatMsgDefer]
	and a
	jr nz, .defer
	call PlayStatUpAnim_Core
	ld a, [wLoweredStat]
	and $f
	ld b, a
	inc b
	callfar GetStatName
	ld hl, .stat
	jp BattleTextbox

.defer
	ld hl, wDeferredUps1
	ld de, wDeferredUpSide
	jp RecordDeferredStat

.stat
	text_far UnknownText_0x1c0cc6
	text_asm
	ld hl, .up
	ld a, [wLoweredStat]
	and $f0
	ret z
	ld hl, .wayup
	ret

.wayup
	text_far UnknownText_0x1c0cd0
	text_end

.up
	text_far UnknownText_0x1c0ce0
	text_end

StatDownMessage_Core:
	ld a, [wFailedMessage]
	and a
	ret nz
	ld a, [wStatMsgDefer]
	and a
	jr nz, .defer
	call PlayStatDownAnim_Core
	ld a, [wLoweredStat]
	and $f
	ld b, a
	inc b
	callfar GetStatName
	ld hl, .stat
	call BattleTextbox
	; Defiant / Competitive react to the drop
	farcall RunStatDropReaction
	ret

.defer
	ld hl, wDeferredDowns1
	ld de, wDeferredDownSide
	jp RecordDeferredStat

.stat
	text_far UnknownText_0x1c0ceb
	text_asm
	ld hl, .fell
	ld a, [wLoweredStat]
	and $f0
	ret z
	ld hl, .sharplyfell
	ret

.sharplyfell
	text_far UnknownText_0x1c0cf5
	text_end

.fell
	text_far UnknownText_0x1c0d06
	text_end

RecordDeferredStat:
; Record the stat change in wLoweredStat instead of printing it.
; hl = "+1" bitmask (the "sharply" bitmask follows it), de = side byte.
	ldh a, [hBattleTurn]
	ld [de], a
	ld a, [wLoweredStat]
	and $f0
	jr z, .got_mask
	inc hl ; sharply mask
.got_mask
	ld a, [wLoweredStat]
	and $f
	inc a
	ld c, a
	xor a
	scf
.shift
	rla
	dec c
	jr nz, .shift
	or [hl]
	ld [hl], a
	ret

DeferStatMessages_Core::
	xor a
	ld [wDeferredUps1], a
	ld [wDeferredUps2], a
	ld [wDeferredDowns1], a
	ld [wDeferredDowns2], a
	ld a, 1
	ld [wStatMsgDefer], a
	ret

FlushStatMessages_Core::
	xor a
	ld [wStatMsgDefer], a
; Raises first, then drops.
	ld a, [wDeferredUps1]
	ld b, a
	ld a, [wDeferredUps2]
	or b
	call nz, .DoUps
	ld a, [wDeferredDowns1]
	ld b, a
	ld a, [wDeferredDowns2]
	or b
	call nz, .DoDowns
	xor a
	ld [wDeferredUps1], a
	ld [wDeferredUps2], a
	ld [wDeferredDowns1], a
	ld [wDeferredDowns2], a
	ret

.DoUps:
	ldh a, [hBattleTurn]
	push af
	ld a, [wDeferredUpSide]
	ldh [hBattleTurn], a
	call .UpsBody
	pop af
	ldh [hBattleTurn], a
	ret

.UpsBody:
	; anim loops twice ("sharply") if any +2 was recorded
	ld b, $00
	ld a, [wDeferredUps2]
	and a
	jr z, .up_anim
	ld b, $10
.up_anim
	ld a, b
	or $0f ; several stats at once: no single color, stay gray
	ld [wLoweredStat], a
	call PlayStatUpAnim_Core
	ld a, [wDeferredUps2]
	and a
	jr z, .up_plain
	ld b, a
	ld de, SharplyRoseVerb
	ld hl, DeferredUpListText
	call PrintStatList
.up_plain
	ld a, [wDeferredUps1]
	and a
	ret z
	ld b, a
	ld de, RoseVerb
	ld hl, DeferredUpListText
	jp PrintStatList

.DoDowns:
	ldh a, [hBattleTurn]
	push af
	ld a, [wDeferredDownSide]
	ldh [hBattleTurn], a
	call .DownsBody
	pop af
	ldh [hBattleTurn], a
	ret

.DownsBody:
	ld b, $00
	ld a, [wDeferredDowns2]
	and a
	jr z, .down_anim
	ld b, $10
.down_anim
	ld a, b
	or $0f ; several stats at once: no single color, stay gray
	ld [wLoweredStat], a
	call PlayStatDownAnim_Core
	ld a, [wDeferredDowns2]
	and a
	jr z, .down_plain
	ld b, a
	ld de, SharplyFellVerb
	ld hl, DeferredDownListText
	call PrintStatList
.down_plain
	ld a, [wDeferredDowns1]
	and a
	jr z, .reaction
	ld b, a
	ld de, FellVerb
	ld hl, DeferredDownListText
	call PrintStatList
.reaction
	; Defiant / Competitive react to each stat actually lowered, even
	; when their messages are combined. A later capped/blocked stat must
	; not suppress the reaction to a successful earlier drop.
	ld a, [wDeferredDowns1]
	ld b, a
	ld a, [wDeferredDowns2]
	or b
	ld c, a
	xor a
	ld [wFailedMessage], a
.reaction_loop
	srl c
	jr nc, .next_reaction
	push bc
	farcall RunStatDropReaction
	pop bc
.next_reaction
	ld a, c
	and a
	jr nz, .reaction_loop
	ret

PrintStatList:
; b = bitmask of stat ids, de = verb string ("@"-terminated),
; hl = wrapper text (DeferredUpListText / DeferredDownListText)
	push hl
	ld a, e
	ld [wDeferredVerb], a
	ld a, d
	ld [wDeferredVerb + 1], a
	call BuildStatListString
	pop hl
	jp BattleTextbox

BuildStatListString:
; Build "NAME1,<CONT>NAME2 and<CONT>NAME3 verb!<PROMPT>" into wStringBuffer2.
; b = bitmask of stat ids (must be nonzero).
; Worst case ("ATTACK, DEFENSE, SPEED, SPCL.ATK and SPCL.DEF sharply rose!")
; is 54 bytes, which fits in wStringBuffer2-4 (57 contiguous bytes).
	; popcount of b -> wDeferredCount
	push bc
	ld c, 0
	ld a, b
.count
	srl a
	jr nc, .count_noinc
	inc c
.count_noinc
	and a
	jr nz, .count
	ld a, c
	ld [wDeferredCount], a
	pop bc

	ld hl, DeferredStatNames
	ld de, wStringBuffer2
.next_stat
	srl b
	jr c, .copy_name
.skip_name
	ld a, [hli]
	cp "@"
	jr nz, .skip_name
	jr .next_stat

.copy_name
	push bc
	ld c, 0
.copy_char
	ld a, [hli]
	cp "@"
	jr z, .copied
	ld [de], a
	inc de
	inc c
	jr .copy_char
.copied
	ld a, c
	ld [wDeferredLastLen], a
	pop bc
	ld a, [wDeferredCount]
	dec a
	ld [wDeferredCount], a
	jr z, .verb ; that was the last name
	cp 1
	jr z, .and_sep
	; "NAME,"
	ld a, ","
	ld [de], a
	inc de
	jr .newline
.and_sep
	; "NAME and"
	push hl
	ld hl, .AndSep
	call .Append
	pop hl
.newline
	ld a, "<CONT>"
	ld [de], a
	inc de
	jr .next_stat

.verb
	; measure the verb
	ld a, [wDeferredVerb]
	ld l, a
	ld a, [wDeferredVerb + 1]
	ld h, a
	push hl
	ld c, 0
.verb_len
	ld a, [hli]
	cp "@"
	jr z, .verb_measured
	inc c
	jr .verb_len
.verb_measured
	pop hl
	; last name + space + verb on one line if it fits (18 chars)
	ld a, [wDeferredLastLen]
	add c
	cp 18
	jr c, .use_space
	ld a, "<CONT>"
	jr .put_sep
.use_space
	ld a, " "
.put_sep
	ld [de], a
	inc de
	call .Append
	ld a, "<PROMPT>"
	ld [de], a
	inc de
	ld a, "@"
	ld [de], a
	ret

.Append
; copy "@"-terminated string from hl to de (terminator not copied)
	ld a, [hli]
	cp "@"
	ret z
	ld [de], a
	inc de
	jr .Append

.AndSep
	db " and@"

RoseVerb:        db "rose!@"
SharplyRoseVerb: db "sharply rose!@"
FellVerb:        db "fell!@"
SharplyFellVerb: db "sharply fell!@"

DeferredStatNames:
; copy of data/battle/stat_names.asm (that copy must stay in the
; Effect Commands bank for GetStatName)
	db "ATTACK@"
	db "DEFENSE@"
	db "SPEED@"
	db "SPCL.ATK@"
	db "SPCL.DEF@"
	db "ACCURACY@"
	db "EVASION@"

DeferredUpListText:
; "<USER>'s" <line> [list from wStringBuffer2]
	text_far UnknownText_0x1c0cc6
	text_end

DeferredDownListText:
; "<TARGET>'s" <line> [list from wStringBuffer2]
	text_far UnknownText_0x1c0ceb
	text_end

PlayStatUpAnim_Core:
; Play the generic stat raise animation on the user's side.
	ld de, ANIM_STAT_UP
	jr PlayStatChangeAnim_Core

PlayStatDownAnim_Core:
; Play the generic stat drop animation on the opponent's side
; (the same side StatDownMessage's text refers to).
	call .SwitchTurn
	ld de, ANIM_STAT_DOWN
	call PlayStatChangeAnim_Core
	; fallthrough
.SwitchTurn:
	ldh a, [hBattleTurn]
	xor 1
	ldh [hBattleTurn], a
	ret

PlayStatChangeAnim_Core:
	push de
	push bc
	farcall CheckBattleScene
	pop bc
	pop de
	ret c
	; Tell the animation which stat changed, so BattleAnimSub_StatChange can
	; tint the arrows with that stat's palette (ported from Polished Crystal).
	; The in-progress move's own anim param is saved and restored around it.
	ld a, [wBattleAnimParam]
	push af
	xor a
	ld [wNumHits], a
	; (wKickCounter is the same byte as wBattleAnimParam, so it's set by
	; the stat id below rather than zeroed after it)
	ld a, [wLoweredStat]
	and $f
	ld [wBattleAnimParam], a
	ld a, e
	ld [wFXAnimID], a
	ld a, d
	ld [wFXAnimID + 1], a
	ld c, 3
	call DelayFrames
	callfar PlayBattleAnim
	pop af
	ld [wBattleAnimParam], a
	ret

INCLUDE "engine/battle/move_effects/triple_kick.asm"
INCLUDE "engine/battle/move_effects/new_move_cores.asm"
INCLUDE "engine/battle/move_effects/thief.asm"

CheckDefScreenPierced:
; a = screens mask. z = the screen has no effect: either it isn't up, or
; the attacker's Infiltrator ignores it. Preserves de, hl; preserves bc.
	push af
	ld a, [wCriticalHit]
	and a
	jr z, .not_critical
	pop af
	xor a ; modern critical hits ignore both defensive screens
	ret
.not_critical
	pop af
	push hl
	push bc
	ld b, a
	ld hl, wEnemyScreens
	ldh a, [hBattleTurn]
	and a
	jr z, .got_side
	ld hl, wPlayerScreens
.got_side
	ld a, [hl]
	and b
	jr z, .done
	; Brick Break breaks the screens (after checkhit) and ignores them here
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_BRICK_BREAK
	jr z, .done
	farcall GetTrueUserAbility_b
	ld a, b
	sub INFILTRATOR ; z when the attacker infiltrates the screen
.done
	pop bc
	pop hl
	ret

UnawareStats_Player:
; Runs right before the held-item boost in the player's damage-stat core.
; hl = attacking stat ptr, bc = defending stat value, d = move power.
; - the defender's Unaware ignores the attacker's stat stages: swap hl to
;   the unmodified stat.
; - the attacker's Unaware ignores the defender's stat stages: reload bc
;   from the unmodified defense (re-applying any screen).
	push de
	push bc
	push hl
	farcall GetOppIgnorableAbility_b
	ld a, b
	pop hl
	pop bc
	cp UNAWARE
	jr nz, .no_defender_unaware
	call .SwapToUnboosted
.no_defender_unaware
	push bc
	push hl
	farcall GetTrueUserAbility_b
	ld a, b
	pop hl
	pop bc
	cp UNAWARE
	jr z, .ignore_def_stages
	; Sacred Sword ignores the target's defensive stat stages too
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_SACRED_SWORD
	jr nz, .done
.ignore_def_stages
	call .ReloadUnboostedDef
.done
	pop de
	ret

.SwapToUnboosted
	ld de, .swap_table
	jp UnawareSwapScan

.swap_table
	dw wBattleMonAttack,  wPlayerAttack
	dw wBattleMonSpclAtk, wPlayerSpAtk
	dw wBattleMonDefense, wPlayerDefense
	dw wEnemyMonAttack,   wEnemyAttack
	dw 0

.ReloadUnboostedDef
	; Psystrike is special but explicitly targets physical Defense.
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_PSYSTRIKE
	jr z, .physical
	; special when the attacking stat is a Sp.Atk pointer
	ld a, h
	cp HIGH(wPlayerSpAtk)
	jr nz, .check_raw_spatk
	ld a, l
	cp LOW(wPlayerSpAtk)
	jr z, .special
.check_raw_spatk
	ld a, h
	cp HIGH(wBattleMonSpclAtk)
	jr nz, .physical
	ld a, l
	cp LOW(wBattleMonSpclAtk)
	jr z, .special
.physical
	push hl
	ld hl, wEnemyDefense
	ld a, [hli]
	ld b, a
	ld c, [hl]
	pop hl
	ld a, 1 << SCREENS_REFLECT
	jr .rescreen
.special
	push hl
	ld hl, wEnemySpDef
	ld a, [hli]
	ld b, a
	ld c, [hl]
	pop hl
	ld a, 1 << SCREENS_LIGHT_SCREEN
.rescreen
	call CheckDefScreenPierced
	ret z
	sla c
	rl b
	ret

UnawareStats_Enemy:
; Enemy-core twin of UnawareStats_Player.
	push de
	push bc
	push hl
	farcall GetOppIgnorableAbility_b
	ld a, b
	pop hl
	pop bc
	cp UNAWARE
	jr nz, .no_defender_unaware
	call .SwapToUnboosted
.no_defender_unaware
	push bc
	push hl
	farcall GetTrueUserAbility_b
	ld a, b
	pop hl
	pop bc
	cp UNAWARE
	jr z, .ignore_def_stages
	; Sacred Sword ignores the target's defensive stat stages too
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_SACRED_SWORD
	jr nz, .done
.ignore_def_stages
	call .ReloadUnboostedDef
.done
	pop de
	ret

.SwapToUnboosted
	ld de, .swap_table
	jp UnawareSwapScan

.swap_table
	dw wEnemyMonAttack,   wEnemyAttack
	dw wEnemyMonSpclAtk,  wEnemySpAtk
	dw wEnemyMonDefense,  wEnemyDefense
	dw wBattleMonAttack,  wPlayerAttack
	dw 0

.ReloadUnboostedDef
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_PSYSTRIKE
	jr z, .physical
	ld a, h
	cp HIGH(wEnemySpAtk)
	jr nz, .check_raw_spatk
	ld a, l
	cp LOW(wEnemySpAtk)
	jr z, .special
.check_raw_spatk
	ld a, h
	cp HIGH(wEnemyMonSpclAtk)
	jr nz, .physical
	ld a, l
	cp LOW(wEnemyMonSpclAtk)
	jr z, .special
.physical
	push hl
	ld hl, wPlayerDefense
	ld a, [hli]
	ld b, a
	ld c, [hl]
	pop hl
	ld a, 1 << SCREENS_REFLECT
	jr .rescreen
.special
	push hl
	ld hl, wPlayerSpDef
	ld a, [hli]
	ld b, a
	ld c, [hl]
	pop hl
	ld a, 1 << SCREENS_LIGHT_SCREEN
.rescreen
	call CheckDefScreenPierced
	ret z
	sla c
	rl b
	ret

UnawareSwapScan:
; de = table of (boosted ptr, unboosted ptr) pairs, 0-terminated.
; If hl matches a boosted ptr, replace hl with its unboosted twin.
	push bc
.loop
	ld a, [de]
	ld c, a
	inc de
	ld a, [de]
	ld b, a
	inc de
	or c
	jr z, .no_match
	ld a, h
	cp b
	jr nz, .next
	ld a, l
	cp c
	jr z, .match
.next
	inc de
	inc de
	jr .loop
.match
	ld a, [de]
	ld l, a
	inc de
	ld a, [de]
	ld h, a
.no_match
	pop bc
	ret

BattleDamageStats_Core:
; damagestats (body; see the stub in effect_commands.asm)

	ldh a, [hBattleTurn]
	and a
	jp nz, EnemyAttackDamage_Core

	; fallthrough

PlayerAttackDamage_Core:
; Return power d, level e, defense c and attack b. Critical hits choose
; offense and defense independently: retain positive offense and negative
; defense, ignore negative offense and positive defense.
	call ResetDamage
	ld a, [wPlayerMoveStructPower]
	ld d, a
	and a
	ret z
	ld a, [wPlayerMoveStructCategory]
	cp CATEGORIZE_SPECIAL
	jr z, .special
	call .physical_defense
	push de
	ld hl, wBattleMonAttack
	ld de, wPlayerAttack
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_BODY_PRESS
	jr z, .body_press
	cp EFFECT_FOUL_PLAY
	jr z, .foul_play
	ld a, [wPlayerAtkLevel]
	jr .physical_offense
.body_press
	ld hl, wBattleMonDefense
	ld de, wPlayerDefense
	ld a, [wPlayerDefLevel]
	jr .physical_offense
.foul_play
	ld hl, wEnemyMonAttack
	ld de, wEnemyAttack
	ld a, [wEnemyAtkLevel]
.physical_offense
	call CriticalOffensePointer_Core
	pop de
	call UnawareStats_Player
	call ReadOffensiveStat_Core
	call ThickClubBoostValue_Core
	call LightBallBoostValue
	jr .done
.special
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_PSYSTRIKE
	jr z, .psystrike
	push de
	ld hl, wEnemyMonSpclDef
	ld de, wEnemySpDef
	ld a, [wEnemySDefLevel]
	call CriticalDefensePointer_Core
	pop de
	ld a, [hli]
	ld b, a
	ld c, [hl]
	ld a, 1 << SCREENS_LIGHT_SCREEN
	call .screen
	jr .special_offense
.psystrike
	call .physical_defense
.special_offense
	push de
	ld hl, wBattleMonSpclAtk
	ld de, wPlayerSpAtk
	ld a, [wPlayerSAtkLevel]
	call CriticalOffensePointer_Core
	pop de
	call UnawareStats_Player
	call ReadOffensiveStat_Core
	call LightBallBoostValue
.done
	push hl
	callfar WeatherDefenseBoost_Core
	pop hl
	push hl
	callfar HeldDefenseBoost_Core
	callfar DittoMetalPowder_Core
	pop hl
	call TruncateHLBC_Ovf
	ld a, [wBattleMonLevel]
	ld e, a
	ld a, 1
	and a
	ret
.physical_defense
	push de
	ld hl, wEnemyMonDefense
	ld de, wEnemyDefense
	ld a, [wEnemyDefLevel]
	call CriticalDefensePointer_Core
	pop de
	ld a, [hli]
	ld b, a
	ld c, [hl]
	ld a, 1 << SCREENS_REFLECT
.screen
	call CheckDefScreenPierced
	ret z
	sla c
	rl b
	ret

CriticalOffensePointer_Core:
; a = offensive stage, hl = staged stat, de = raw stat.
	push bc
	ld b, a
	ld a, [wCriticalHit]
	and a
	jr z, .done
	ld a, b
	cp BASE_STAT_LEVEL
	jr nc, .done
	ld h, d
	ld l, e
.done
	pop bc
	ret

CriticalDefensePointer_Core:
; a = defensive stage, hl = staged stat, de = raw stat.
	push bc
	ld b, a
	ld a, [wCriticalHit]
	and a
	jr z, .done
	ld a, b
	cp BASE_STAT_LEVEL + 1
	jr c, .done
	ld h, d
	ld l, e
.done
	pop bc
	ret

ReadOffensiveStat_Core:
; hl = selected attacking-stat pointer. Return its value in hl, applying
; the user's burn/frostbite even when critical hits or Unaware chose a raw
; stat. Foul Play borrows the target's Attack without borrowing its burn.
; Body Press still takes the user's physical burn penalty.
	push bc
	push de
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_BODY_PRESS
	jr z, .body_press
	cp EFFECT_FOUL_PLAY
	jr z, .foul_play
	cp EFFECT_FACADE
	jr z, .facade
	; A staged attack already contains its own status penalty. Raw stats
	; need that penalty applied explicitly after critical/Unaware selection.
	ld a, h
	cp HIGH(wPlayerAttack)
	jr nz, .check_enemy_raw
	ld a, l
	cp LOW(wPlayerAttack)
	jr z, .raw_physical
	cp LOW(wPlayerSpAtk)
	jr z, .raw_special
.check_enemy_raw
	ld a, h
	cp HIGH(wEnemyAttack)
	jr nz, .read_selected
	ld a, l
	cp LOW(wEnemyAttack)
	jr z, .raw_physical
	cp LOW(wEnemySpAtk)
	jr z, .raw_special
.read_selected
	call ReadStatValue_Core
	jr .done
.raw_physical
	call ReadStatValue_Core
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	bit BRN, a
	jr z, .done
	jr .halve
.raw_special
	call ReadStatValue_Core
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	bit FRZ, a
	jr z, .done
	jr .halve
.body_press
	call ReadStatValue_Core
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	bit BRN, a
	jr z, .done
	jr .halve
.foul_play
	; Recalculate the borrowed Attack from raw stats + its selected stage
	; instead of doubling the target's rounded, burn-halved stored stat.
	ld a, BATTLE_VARS_STATUS_OPP
	call GetBattleVar
	bit BRN, a
	jr z, .read_foul_play
	call RebuildUnburnedAttack_Core
	jr .foul_play_user_burn
.read_foul_play
	call ReadStatValue_Core
.foul_play_user_burn
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	bit BRN, a
	jr z, .done
	jr .halve
.facade
	ld a, BATTLE_VARS_STATUS
	call GetBattleVar
	bit BRN, a
	jr z, .read_selected
	call RebuildUnburnedAttack_Core
	jr .done
.halve
	srl h
	rr l
	ld a, h
	or l
	jr nz, .done
	inc l
.done
	pop de
	pop bc
	ret

ReadStatValue_Core:
; Read a big-endian stat at hl, returning its value in hl.
	ld a, [hli]
	ld l, [hl]
	ld h, a
	ret

RebuildUnburnedAttack_Core:
; hl = the selected raw or staged Attack pointer. Restore a burned
; Attack from its raw value and only the stage actually selected by
; critical-hit/Unaware handling. Doubling the halved stat loses odd HP
; rounding and cannot safely restore stats at the 999 cap.
	ld a, h
	cp HIGH(wBattleMonAttack)
	jr nz, .check_enemy
	ld a, l
	cp LOW(wBattleMonAttack)
	jr nz, .check_enemy
	ld de, wPlayerAttack
	ld a, [wPlayerAtkLevel]
	ld b, 1 ; preserve the player's existing staged-stat badge boost
	jr .rebuild
.check_enemy
	ld a, h
	cp HIGH(wEnemyMonAttack)
	jr nz, ReadStatValue_Core
	ld a, l
	cp LOW(wEnemyMonAttack)
	jr nz, ReadStatValue_Core
	ld de, wEnemyAttack
	ld a, [wEnemyAtkLevel]
	ld b, 0
.rebuild
	push bc
	dec a
	add a
	ld c, a
	ld b, 0
	ld hl, .stage_ratios
	add hl, bc
	xor a
	ldh [hMultiplicand + 0], a
	ld a, [de]
	ldh [hMultiplicand + 1], a
	inc de
	ld a, [de]
	ldh [hMultiplicand + 2], a
	ld a, [hli]
	ldh [hMultiplier], a
	call Multiply
	ld a, [hl]
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 2]
	ld h, a
	ldh a, [hQuotient + 3]
	ld l, a
	pop bc
	call .cap
	ld a, h
	or l
	jr nz, .badge
	inc l
.badge
	ld a, b
	and a
	ret z
	ld a, [wLinkMode]
	and a
	ret nz
	ld a, [wInBattleTowerBattle]
	and a
	ret nz
	ld a, [wJohtoBadges]
	bit ZEPHYRBADGE, a
	ret z
	; Mirror BadgeStatBoosts: +1/8 Attack, capped at 999. This applies
	; only to a selected staged player stat; raw-stat selections keep their
	; existing critical-hit/Unaware treatment of badges.
	ld d, h
	ld e, l
rept 3
	srl d
	rr e
endr
	add hl, de
.cap
	ld a, LOW(MAX_STAT_VALUE)
	cp l
	ld a, HIGH(MAX_STAT_VALUE)
	sbc h
	ret nc
	ld hl, MAX_STAT_VALUE
	ret
.stage_ratios
; Match ApplyStatLevelMultiplier's existing stat calculation exactly.
	db 25, 100, 28, 100, 33, 100, 40, 100, 50, 100, 66, 100
	db 1, 1, 15, 10, 2, 1, 25, 10, 3, 1, 35, 10, 4, 1

ThickClubBoostValue_Core:
; ReadOffensiveStat_Core already returned the value in hl.
	push bc
	push de
	ld bc, CUBONE
	ld d, THICK_CLUB
	call DoubleStatIfSpeciesHoldingItem
	ld bc, MAROWAK
	call DoubleStatIfSpeciesHoldingItem
	pop de
	pop bc
	ret
TruncateHLBC_Ovf:
.loop
; Truncate 16-bit values hl and bc to 8-bit values b and c respectively.
; b = hl, c = bc

	ld a, h
	or b
	jr z, .finish

	srl b
	rr c
	srl b
	rr c

	ld a, c
	or b
	jr nz, .done_bc
	inc c

.done_bc
	srl h
	rr l
	srl h
	rr l

	ld a, l
	or h
	jr nz, .finish
	inc l

.finish
; If we go back to the loop point,
; it's the same as doing this exact
; same check twice.
	ld a, h
	or b
	jr nz, .loop

	ld b, l
	ret

LightBallBoostValue:
; Double the stat value already in hl if the attacking monster is Pikachu
; holding a Light Ball. The physical path uses this after ThickClubBoost,
; which has already read the stat pointer into hl.
	push bc
	push de
	ld bc, PIKACHU
	ld d, LIGHT_BALL
	call DoubleStatIfSpeciesHoldingItem
	pop de
	pop bc
	ret

DoubleStatIfSpeciesHoldingItem:
; If the attacking monster is species bc and
; it's holding item d, double the stat in hl.

	push hl
	ld a, MON_SPECIES
	call BattlePartyAttr

	ldh a, [hBattleTurn]
	and a
	ld a, [hl]
	jr z, .CompareSpecies
	ld a, [wTempEnemyMonSpecies]
.CompareSpecies:

	call GetPokemonIndexFromID
	ld a, h
	cp b
	ld a, l
	pop hl
	ret nz
	cp c
	ret nz

	push hl
	callfar GetUserItem
	ld a, [hl]
	pop hl
	cp d
	ret nz

; Double the stat
	sla l
	rl h
	ld a, HIGH(MAX_STAT_VALUE)
	cp h
	jr c, .cap_boost
	ret nz
	ld a, LOW(MAX_STAT_VALUE)
	cp l
	ret nc
.cap_boost
	ld hl, MAX_STAT_VALUE
	ret

EnemyAttackDamage_Core:
; Return power d, level e, defense c and attack b. Critical hits choose
; offense and defense independently: retain positive offense and negative
; defense, ignore negative offense and positive defense.
	call ResetDamage
	ld a, [wEnemyMoveStructPower]
	ld d, a
	and a
	ret z
	ld a, [wEnemyMoveStructCategory]
	cp CATEGORIZE_SPECIAL
	jr z, .special
	call .physical_defense
	push de
	ld hl, wEnemyMonAttack
	ld de, wEnemyAttack
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_BODY_PRESS
	jr z, .body_press
	cp EFFECT_FOUL_PLAY
	jr z, .foul_play
	ld a, [wEnemyAtkLevel]
	jr .physical_offense
.body_press
	ld hl, wEnemyMonDefense
	ld de, wEnemyDefense
	ld a, [wEnemyDefLevel]
	jr .physical_offense
.foul_play
	ld hl, wBattleMonAttack
	ld de, wPlayerAttack
	ld a, [wPlayerAtkLevel]
.physical_offense
	call CriticalOffensePointer_Core
	pop de
	call UnawareStats_Enemy
	call ReadOffensiveStat_Core
	call ThickClubBoostValue_Core
	call LightBallBoostValue
	jr .done
.special
	ld a, BATTLE_VARS_MOVE_EFFECT
	call GetBattleVar
	cp EFFECT_PSYSTRIKE
	jr z, .psystrike
	push de
	ld hl, wBattleMonSpclDef
	ld de, wPlayerSpDef
	ld a, [wPlayerSDefLevel]
	call CriticalDefensePointer_Core
	pop de
	ld a, [hli]
	ld b, a
	ld c, [hl]
	ld a, 1 << SCREENS_LIGHT_SCREEN
	call .screen
	jr .special_offense
.psystrike
	call .physical_defense
.special_offense
	push de
	ld hl, wEnemyMonSpclAtk
	ld de, wEnemySpAtk
	ld a, [wEnemySAtkLevel]
	call CriticalOffensePointer_Core
	pop de
	call UnawareStats_Enemy
	call ReadOffensiveStat_Core
	call LightBallBoostValue
.done
	push hl
	callfar WeatherDefenseBoost_Core
	pop hl
	push hl
	callfar HeldDefenseBoost_Core
	callfar DittoMetalPowder_Core
	pop hl
	call TruncateHLBC_Ovf
	ld a, [wEnemyMonLevel]
	ld e, a
	ld a, 1
	and a
	ret
.physical_defense
	push de
	ld hl, wBattleMonDefense
	ld de, wPlayerDefense
	ld a, [wPlayerDefLevel]
	call CriticalDefensePointer_Core
	pop de
	ld a, [hli]
	ld b, a
	ld c, [hl]
	ld a, 1 << SCREENS_REFLECT
.screen
	call CheckDefScreenPierced
	ret z
	sla c
	rl b
	ret

; ==== Toxic slot tracking (modern badly-poison persistence) ==============
; Badly-poisoned state persists across switches (Gen 5+). One bit per party
; slot, set when Toxic is applied, cleared when poison is cured, restored
; (with a reset counter) when the mon re-enters. See wPlayerToxicSlots.

ToxicMarkUser_Core::
; Set the toxic slot bit for the side currently taking its turn.
	ldh a, [hBattleTurn]
	and a
	jr z, ToxicMarkPlayer_Core
	jr ToxicMarkEnemy_Core

ToxicMarkOpp_Core::
; Set the toxic slot bit for the opponent of the side taking its turn.
	ldh a, [hBattleTurn]
	and a
	jr z, ToxicMarkEnemy_Core
	; fallthrough

ToxicMarkPlayer_Core::
	ld a, [wCurBattleMon]
	call ToxicSlotMask
	ld hl, wPlayerToxicSlots
	or [hl]
	ld [hl], a
	ret

ToxicMarkEnemy_Core::
	ld a, [wCurOTMon]
	call ToxicSlotMask
	ld hl, wEnemyToxicSlots
	or [hl]
	ld [hl], a
	ret

ToxicClearUser_Core::
; Clear the toxic slot bit for the side currently taking its turn.
	ldh a, [hBattleTurn]
	and a
	jr z, ToxicClearPlayer_Core
	jr ToxicClearEnemy_Core

ToxicClearOpp_Core::
; Clear the toxic slot bit for the opponent of the side taking its turn.
	ldh a, [hBattleTurn]
	and a
	jr z, ToxicClearEnemy_Core
	; fallthrough

ToxicClearPlayer_Core::
	ld a, [wCurBattleMon]
	call ToxicSlotMask
	cpl
	ld hl, wPlayerToxicSlots
	and [hl]
	ld [hl], a
	ret

ToxicClearEnemy_Core::
	ld a, [wCurOTMon]
	call ToxicSlotMask
	cpl
	ld hl, wEnemyToxicSlots
	and [hl]
	ld [hl], a
	ret

ToxicSlotMask:
; a = party slot (0-5) -> a = 1 << slot
	push bc
	ld b, a
	ld a, 1
	inc b
	jr .start
.shift
	add a
.start
	dec b
	jr nz, .shift
	pop bc
	ret

ToxicRestorePlayer_Core::
; Called at the tail of NewBattleMonStatus, after the substatus wipe, with
; the incoming mon's data already in wBattleMon and wCurBattleMon updated.
; Also resets the per-mon Taunt and Yawn state for the incoming mon
; (Wish is per-side and deliberately NOT touched).
	xor a
	ld [wPlayerTauntCount], a
	ld [wPlayerYawnCount], a
; If this slot was badly poisoned and is still poisoned, restore
; SUBSTATUS_TOXIC and restart the toxic counter (canon: the counter
; resets on switching). If the poison was cured while benched, drop the
; stale slot bit instead.
	ld a, [wCurBattleMon]
	call ToxicSlotMask
	ld hl, wPlayerToxicSlots
	and [hl]
	ret z ; slot was never badly poisoned
	ld a, [wBattleMonStatus]
	bit PSN, a
	jr z, .stale
	ld hl, wPlayerSubStatus5
	set SUBSTATUS_TOXIC, [hl]
	xor a
	ld [wPlayerToxicCount], a
	ret
.stale
	jr ToxicClearPlayer_Core

PassedBattleMonFixups_Core::
; Farcalled from PassedBattleMonEntrance (the player's Baton Pass switch-in),
; after the stat stage multipliers were applied.
; - per-mon Taunt/Yawn state and the toxic slot, as a normal switch-in does
;   (the enemy's Baton Pass path already runs ToxicRestoreEnemy_Core)
; - the multipliers rebuild the stats from the unmodified ones: re-apply the
;   status penalties and badge boosts InitBattleMon had applied
	call ToxicRestorePlayer_Core
	callfar ApplyStatusEffectOnPlayerStats
	callfar BadgeStatBoosts
	ret

ToxicRestoreEnemy_Core::
; Enemy-side mirror of ToxicRestorePlayer_Core. Must run with the incoming
; mon already in wEnemyMon and wCurOTMon updated (called from
; Function_SetEnemyMonAndSendOutAnimation since audit 2026-08-28 #7).
; Also resets the per-mon Taunt and Yawn state for the incoming mon.
	xor a
	ld [wEnemyTauntCount], a
	ld [wEnemyYawnCount], a
	ld a, [wCurOTMon]
	call ToxicSlotMask
	ld hl, wEnemyToxicSlots
	and [hl]
	ret z
	ld a, [wEnemyMonStatus]
	bit PSN, a
	jr z, .stale
	ld hl, wEnemySubStatus5
	set SUBSTATUS_TOXIC, [hl]
	xor a
	ld [wEnemyToxicCount], a
	ret
.stale
	jr ToxicClearEnemy_Core
