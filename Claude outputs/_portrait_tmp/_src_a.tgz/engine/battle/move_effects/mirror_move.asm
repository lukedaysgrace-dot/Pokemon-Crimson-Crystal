BattleCommand_MirrorMove:
; mirrormove

	call ClearLastMove

	ld a, BATTLE_VARS_MOVE
	call GetBattleVarAddr

	ld a, BATTLE_VARS_LAST_COUNTER_MOVE_OPP
	call GetBattleVar
	and a
	jr z, .failed

	call CheckUserMove
	jr nz, .use

.failed
	call AnimateFailedMove

	ld hl, MirrorMoveFailedText
	call StdBattleTextbox
	jp EndMoveEffect

.use
	ld a, b
	ld [hl], a
	ld [wNamedObjectIndexBuffer], a

	push af
	ld a, BATTLE_VARS_MOVE_ANIM
	call GetBattleVarAddr
	ld d, h
	ld e, l
	pop af

	call GetMoveData
	; Weather Ball: its type and power from the current weather (as
	; UpdateMoveData does), before the -ate abilities look at the type
	farcall WeatherBallUpdateMoveStruct
	; -ate abilities (Pixilate & co.) convert the copied move's type, as
	; UpdateMoveData does for Metronome / Sleep Talk (audit 2026-08-28 #18)
	farcall AbilityConvertMoveType
	; Hidden Power: the user's own type/power/category (as UpdateMoveData does)
	farcall HiddenPowerUpdateMoveStruct
	call GetMoveName
	call CopyName1
	call CheckUserIsCharging
	jr nz, .done

	ld a, [wKickCounter]
	push af
	call BattleCommand_LowerSub
	pop af
	ld [wKickCounter], a

.done
	call BattleCommand_MoveDelay
	jp ResetTurn
