INCLUDE "engine/16/macros.asm"

ForceGarbageCollection::
	push bc
	ldh a, [rSVBK]
	push af
	ld a, BANK("16-bit WRAM tables")
	ldh [rSVBK], a
	call PokemonTableGarbageCollection
	call MoveTableGarbageCollection
	pop af
	ldh [rSVBK], a
	pop bc
	ret

; Note: ID = 8-bit ID used in memory, etc.; index = true 16-bit index into tables

_GetPokemonIndexFromID::
	___conversion_table_load wPokemonIndexTable, MON_TABLE

_GetPokemonIDFromIndex::
	___conversion_table_store wPokemonIndexTable, MON_TABLE
	; fallthrough - as required by the macro
PokemonTableGarbageCollection:
	; must preserve de and rSVBK
	push de
	ldh a, [rSVBK]
	push af
	___conversion_bitmap_initialize wPokemonIndexTable, MON_TABLE, .set_bit
	ld a, 1
	ldh [rSVBK], a
	___conversion_bitmap_check_structs wPartyMons, PARTYMON_STRUCT_LENGTH, PARTY_LENGTH, .set_bit
	___conversion_bitmap_check_structs wBreedMon1, wBreedMon2 - wBreedMon1, 2, .set_bit
	ld a, [wEggMonSpecies]
	call .set_bit
	; may or may not be valid, but marking them in use is free
	___conversion_bitmap_check_structs wOTPartyMons, PARTYMON_STRUCT_LENGTH, PARTY_LENGTH, .set_bit
	___conversion_bitmap_check_structs wRoamMon1, wRoamMon2 - wRoamMon1, 3, .set_bit
	___conversion_bitmap_check_structs wBugContestFirstPlaceMon, wBugContestSecondPlaceMon - wBugContestFirstPlaceMon, 3, .set_bit
	___conversion_bitmap_check_values .set_bit, wBufferMonSpecies, wTempMonSpecies, wContestMonSpecies, \
	                                            wBattleMonSpecies, wEnemyMonSpecies, wOddEggSpecies, wBaseSpecies
IF DEF(DEBUG_BATTLE)
	; the battle tester parks the real party in WRAM bank 2 while a test
	; party is out; its IDs must survive collections during the test
	ld a, BANK(wDebugPartyBackedUp)
	ldh [rSVBK], a
	ld a, [wDebugPartyBackedUp]
	and a
	jr z, .no_debug_backup
	___conversion_bitmap_check_structs wDebugPartyBackup + (wPartyMons - wPartyCount), PARTYMON_STRUCT_LENGTH, PARTY_LENGTH, .set_bit
.no_debug_backup
	ld a, 1
	ldh [rSVBK], a
ENDC
	pop af
	ldh [rSVBK], a
	; Stored (boxed) mons keep true 16-bit indexes in SRAM and are not roots.
	___conversion_bitmap_free_unused wPokemonIndexTable, MON_TABLE
	pop de
	ret

.set_bit
	___conversion_bitmap_set MON_TABLE

_LockPokemonID::
	___conversion_table_lock_ID wPokemonIndexTable, MON_TABLE

_GetMoveIndexFromID::
	___conversion_table_load wMoveIndexTable, MOVE_TABLE

_GetMoveIDFromIndex::
	___conversion_table_store wMoveIndexTable, MOVE_TABLE
	; fallthrough
MoveTableGarbageCollection:
	; must preserve de and rSVBK
	push de
	ldh a, [rSVBK]
	push af
	; clear the bitmap and mark the locked and recently allocated IDs, like
	; the Pokemon collector does (otherwise stale marks leak slots forever and
	; locked move IDs can be freed and reused)
	___conversion_bitmap_initialize wMoveIndexTable, MOVE_TABLE, .set_bit
	ld a, 1
	ldh [rSVBK], a
___move = 0
	rept NUM_MOVES
		___conversion_bitmap_check_structs wPartyMon1Moves + ___move, PARTYMON_STRUCT_LENGTH, PARTY_LENGTH, .set_bit
		___conversion_bitmap_check_structs wBreedMon1Moves + ___move, wBreedMon2 - wBreedMon1, 2, .set_bit
		ld a, [wEggMonMoves + ___move]
		call .set_bit
		; may or may not be valid
		___conversion_bitmap_check_structs wOTPartyMon1Moves + ___move, PARTYMON_STRUCT_LENGTH, PARTY_LENGTH, .set_bit
		___conversion_bitmap_check_values .set_bit, wBufferMonMoves + ___move, wTempMonMoves + ___move, wContestMonMoves + ___move, \
		                                            wBattleMonMoves + ___move, wEnemyMonMoves + ___move, wWildMonMoves + ___move, \
		                                            wPlayerUsedMoves + ___move, wOddEggMoves + ___move
___move = ___move + 1
	endr
	ld a, [wNamedObjectIndexBuffer] ;or any of its aliases...
	call .set_bit
	; only valid sometimes
	___conversion_bitmap_check_values .set_bit, wCurPlayerMove, wCurEnemyMove, wDisabledMove, wEnemyDisabledMove, wPlayerChoiceLockedMove, \
	                                            wEnemyChoiceLockedMove, wLastPlayerMove, wLastEnemyMove, wLastPlayerCounterMove, wLastEnemyCounterMove, \
	                                            wPlayerTrappingMove, wEnemyTrappingMove, wPlayerMoveStructAnimation, wEnemyMoveStructAnimation, \
	                                            wPutativeTMHMMove, wPlayerGigaHammerLock, wEnemyGigaHammerLock
IF DEF(DEBUG_BATTLE)
	ld a, BANK(wDebugPartyBackedUp)
	ldh [rSVBK], a
	ld a, [wDebugPartyBackedUp]
	and a
	jp z, .no_debug_backup
___move = 0
	rept NUM_MOVES
		___conversion_bitmap_check_structs wDebugPartyBackup + (wPartyMon1Moves - wPartyCount) + ___move, PARTYMON_STRUCT_LENGTH, PARTY_LENGTH, .set_bit
___move = ___move + 1
	endr
.no_debug_backup
	ld a, 1
	ldh [rSVBK], a
ENDC
	pop af
	ldh [rSVBK], a
	; Stored (boxed) mons keep true 14-bit move indexes in SRAM and are not roots.
	___conversion_bitmap_free_unused wMoveIndexTable, MOVE_TABLE
	pop de
	ret

.set_bit
	___conversion_bitmap_set MOVE_TABLE

_LockMoveID::
	___conversion_table_lock_ID wMoveIndexTable, MOVE_TABLE
