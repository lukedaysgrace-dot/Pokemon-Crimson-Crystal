EvolvePokemon:
	ld hl, wEvolvableFlags
	xor a
	ld [hl], a
	ld a, [wCurPartyMon]
	ld c, a
	ld b, SET_FLAG
	call EvoFlagAction
EvolveAfterBattle:
	xor a
	ld [wMonTriedToEvolve], a
	dec a
	ld [wCurPartyMon], a
	push hl
	push bc
	push de
	ld hl, wPartyCount

	push hl

EvolveAfterBattle_MasterLoop:
	ld hl, wCurPartyMon
	inc [hl]

	pop hl

	inc hl
	ld a, [hl]
	cp $ff
	jp z, .ReturnToMap

	ld [wEvolutionOldSpecies], a

	push hl
	ld a, [wCurPartyMon]
	ld c, a
	ld hl, wEvolvableFlags
	ld b, CHECK_FLAG
	call EvoFlagAction
	ld a, c
	and a
	jp z, EvolveAfterBattle_MasterLoop

	ld a, [wEvolutionOldSpecies]
	call GetPokemonIndexFromID
	ld b, h
	ld c, l
	ld hl, EvosAttacksPointers
	ld a, BANK(EvosAttacksPointers)
	call LoadDoubleIndirectPointer
	ldh [hTemp], a

	push hl
	xor a
	ld [wMonType], a
	predef CopyMonToTempMon
	pop hl

.loop
	call GetNextEvoAttackByte
	and a
	jr z, EvolveAfterBattle_MasterLoop

	ld b, a

	cp EVOLVE_TRADE
	jp z, .trade

	ld a, [wLinkMode]
	and a
	jp nz, .dont_evolve_check

	ld a, b
	cp EVOLVE_ITEM
	jp z, .item

	ld a, [wForceEvolution]
	and a
	jp nz, .dont_evolve_check

	ld a, b
	cp EVOLVE_LEVEL
	jp z, .level
	cp EVOLVE_LEVEL_MALE
	jp z, .level_male
	cp EVOLVE_LEVEL_FEMALE
	jp z, .level_female

	cp EVOLVE_HAPPINESS
	jr z, .happiness
	cp EVOLVE_MOVE
	jp z, .move
	cp EVOLVE_HOLDING
	jp z, .holding
	cp EVOLVE_PARTY
	jp z, .party

; EVOLVE_STAT
	call GetNextEvoAttackByte
	ld c, a
	ld a, [wTempMonLevel]
	cp c
	jp c, .skip_evolution_species_parameter

	call IsMonHoldingEverstone
	jp z, .skip_evolution_species_parameter

	push hl
	ld de, wTempMonAttack
	ld hl, wTempMonDefense
	ld c, 2
	call CompareBytes
	ld c, ATK_EQ_DEF
	jr z, .got_tyrogue_evo
	ld c, ATK_LT_DEF
	jr c, .got_tyrogue_evo
	ld c, ATK_GT_DEF
.got_tyrogue_evo
	pop hl

	call GetNextEvoAttackByte
	cp c
	jp nz, .skip_evolution_species
	jp .proceed

.happiness
	ld a, [wTempMonHappiness]
	cp HAPPINESS_TO_EVOLVE
	jp c, .skip_evolution_species_parameter

	call IsMonHoldingEverstone
	jp z, .skip_evolution_species_parameter

	call GetNextEvoAttackByte
	cp TR_ANYTIME
	jp z, .proceed
	cp TR_MORNDAY
	jr z, .happiness_daylight

; TR_NITE
	ld a, [wTimeOfDay]
	cp NITE_F
	jp nz, .skip_evolution_species
	jp .proceed

.happiness_daylight
	ld a, [wTimeOfDay]
	cp NITE_F
	jp z, .skip_evolution_species
	jp .proceed

.move
	call GetNextEvoAttackByte
	ld c, a
	push hl
	ld hl, wTempMonMoves
	ld b, NUM_MOVES
.move_loop
	ld a, [hli]
	cp c
	jr z, .move_found
	dec b
	jr nz, .move_loop
	pop hl
	jp .skip_evolution_species
.move_found
	pop hl
	call IsMonHoldingEverstone
	jp z, .skip_evolution_species
	jp .proceed

.holding
	call GetNextEvoAttackByte
	ld c, a
	ld a, [wTempMonLevel]
	cp c
	jp c, .skip_evolution_species_parameter
	call GetNextEvoAttackByte
	ld c, a
	ld a, [wTempMonItem]
	cp c
	jp nz, .skip_evolution_species
	xor a
	ld [wTempMonItem], a
	jp .proceed

.party
	call GetNextEvoAttackByte
	ld c, a
	push hl
	ld hl, wPartySpecies
	ld b, PARTY_LENGTH
.party_loop
	ld a, [hli]
	cp c
	jr z, .party_found
	dec b
	jr nz, .party_loop
	pop hl
	jp .skip_evolution_species
.party_found
	pop hl
	call IsMonHoldingEverstone
	jp z, .skip_evolution_species
	jp .proceed

.trade
	ld a, [wLinkMode]
	and a
	jp z, .skip_evolution_species_parameter

	call IsMonHoldingEverstone
	jp z, .skip_evolution_species_parameter

	call GetNextEvoAttackByte
	ld b, a
	inc a
	jp z, .proceed

	ld a, [wLinkMode]
	cp LINK_TIMECAPSULE
	jp z, .skip_evolution_species

	ld a, [wTempMonItem]
	cp b
	jp nz, .skip_evolution_species

	xor a
	ld [wTempMonItem], a
	jp .proceed

.item
	call GetNextEvoAttackByte
	ld b, a
	ld a, [wCurItem]
	cp b
	jp nz, .skip_evolution_species

	ld a, [wForceEvolution]
	and a
	jp z, .skip_evolution_species
	ld a, [wLinkMode]
	and a
	jp nz, .skip_evolution_species

	push hl
	ld a, [wEvolutionOldSpecies]
	call GetPokemonIndexFromID
	ld a, h
	cp HIGH(DIPPLIN)
	jr nz, .item_level_ok
	ld a, l
	cp LOW(DIPPLIN)
	jr nz, .item_level_ok
	ld a, [wTempMonLevel]
	cp 36
	jr nc, .item_level_ok
	pop hl
	jp .skip_evolution_species

.item_level_ok
	pop hl
	jp .proceed

.CheckLevelEvolution
	call GetNextEvoAttackByte
	ld b, a
	ld a, [wTempMonLevel]
	cp b
	ret

.CheckMaleEvolution
	push hl
	ldh a, [hTemp]
	push af
	ld a, [wEvolutionOldSpecies]
	ld [wCurPartySpecies], a
	xor a
	ld [wMonType], a
	farcall GetGender
	jr c, .male_genderless
	ld b, a
	pop af
	ldh [hTemp], a
	pop hl
	ld a, b
	cp 1
	jr z, .male_gender_ok
.male_gender_fail
	scf
	ret
.male_genderless
	pop af
	ldh [hTemp], a
	pop hl
	jr .male_gender_fail
.male_gender_ok
	and a
	ret

.CheckFemaleEvolution
	push hl
	ldh a, [hTemp]
	push af
	ld a, [wEvolutionOldSpecies]
	ld [wCurPartySpecies], a
	xor a
	ld [wMonType], a
	farcall GetGender
	jr c, .female_genderless
	ld b, a
	pop af
	ldh [hTemp], a
	pop hl
	ld a, b
	and a
	jr z, .female_gender_ok
.female_gender_fail
	scf
	ret
.female_genderless
	pop af
	ldh [hTemp], a
	pop hl
	jr .female_gender_fail
.female_gender_ok
	and a
	ret

.level
	call .CheckLevelEvolution
	jp c, .skip_evolution_species
	jr .level_after_gender

.level_male
	call .CheckLevelEvolution
	jp c, .skip_evolution_species
	call .CheckMaleEvolution
	jp c, .skip_evolution_species
	jr .level_after_gender

.level_female
	call .CheckLevelEvolution
	jp c, .skip_evolution_species
	call .CheckFemaleEvolution
	jp c, .skip_evolution_species

.level_after_gender
	call IsMonHoldingEverstone
	jp z, .skip_evolution_species

; Time-of-day gated level evolutions based on target species:
; Charcadet -> Ceruledge at night, Charcadet -> Armarouge by day.
	push hl
	ldh a, [hTemp]
	call GetFarHalfword
	ld d, h
	ld e, l
	pop hl
	ld a, d
	cp HIGH(CERULEDGE)
	jr nz, .check_armarouge_target
	ld a, e
	cp LOW(CERULEDGE)
	jp z, .target_nite
.check_armarouge_target
	ld a, d
	cp HIGH(ARMAROUGE)
	jr nz, .check_typhlosion_hisuian
	ld a, e
	cp LOW(ARMAROUGE)
	jp z, .target_day

; Quilava -> Hisuian Typhlosion only inside the Burned Tower.
; Cubone -> Alolan Marowak follows the same rule. Otherwise the regional
; evolution is skipped and the next, regular evolution is checked instead.
.check_typhlosion_hisuian
	ld a, d
	cp HIGH(TYPHLOSION_HISUIAN)
	jr nz, .check_marowak_alolan
	ld a, e
	cp LOW(TYPHLOSION_HISUIAN)
	jr z, .check_burned_tower

.check_marowak_alolan
	ld a, d
	cp HIGH(MAROWAK_ALOLAN)
	jr nz, .check_weezing_galarian
	ld a, e
	cp LOW(MAROWAK_ALOLAN)
	jr nz, .check_weezing_galarian

.check_burned_tower
	ld a, [wMapGroup]
	cp GROUP_BURNED_TOWER_1F
	jp nz, .skip_evolution_species
	ld a, [wMapNumber]
	cp MAP_BURNED_TOWER_1F
	jp z, .proceed
	cp MAP_BURNED_TOWER_B1F
	jp nz, .skip_evolution_species
	jp .proceed

.check_weezing_galarian
	ld a, d
	cp HIGH(WEEZING_GALARIAN)
	jr nz, .check_ursaring
	ld a, e
	cp LOW(WEEZING_GALARIAN)
	jr nz, .check_ursaring
	push hl
	ld hl, FAIRY_WIND
	call GetMoveIDFromIndex
	ld c, a
	ld hl, wTempMonMoves
	ld b, NUM_MOVES
.fairy_wind_loop
	ld a, [hli]
	cp c
	jr z, .fairy_wind_found
	dec b
	jr nz, .fairy_wind_loop
	pop hl
	jp .skip_evolution_species
.fairy_wind_found
	pop hl
	jp .proceed

.check_ursaring
	push hl
	ld a, [wEvolutionOldSpecies]
	call GetPokemonIndexFromID
	ld d, h
	ld e, l
	pop hl
	ld a, d
	cp HIGH(URSARING)
	jr nz, .check_ursaringbm
	ld a, e
	cp LOW(URSARING)
	jr z, .level_ursaring

.check_ursaringbm
	ld a, d
	cp HIGH(URSARINGBM)
	jr nz, .proceed
	ld a, e
	cp LOW(URSARINGBM)
	jr z, .level_ursaringbm
	jr .proceed

.level_ursaring
	ld a, [wTimeOfDay]
	cp NITE_F
	jp z, .skip_evolution_species
	jr .proceed

.level_ursaringbm
	ld a, [wTimeOfDay]
	cp NITE_F
	jp nz, .skip_evolution_species
	jr .proceed

.target_nite
	ld a, [wTimeOfDay]
	cp NITE_F
	jp nz, .skip_evolution_species
	jr .proceed

.target_day
	ld a, [wTimeOfDay]
	cp NITE_F
	jp z, .skip_evolution_species

.proceed
	ld a, [wTempMonLevel]
	ld [wCurPartyLevel], a
	ld a, $1
	ld [wMonTriedToEvolve], a

	ldh a, [hTemp]
	call GetFarHalfword
	call GetPokemonIDFromIndex
	ld [wEvolutionNewSpecies], a
	ld a, [wCurPartyMon]
	ld hl, wPartyMonNicknames
	call GetNick
	call CopyName1
	ld hl, Text_WhatEvolving
	call PrintText

	ld c, 50
	call DelayFrames

	xor a
	ldh [hBGMapMode], a
	hlcoord 0, 0
	lb bc, 12, 20
	call ClearBox

	ld a, $1
	ldh [hBGMapMode], a
	call ClearSprites

	farcall EvolutionAnimation

	push af
	call ClearSprites
	pop af
	jp c, CancelEvolution

	ld hl, Text_CongratulationsYourPokemon
	call PrintText

	ld a, [wEvolutionNewSpecies]
	ld [wCurSpecies], a
	ld [wTempMonSpecies], a
	ld [wNamedObjectIndexBuffer], a
	call GetPokemonName

	push hl
	ld hl, Text_EvolvedIntoPKMN
	call PrintTextboxText
	farcall StubbedTrainerRankings_MonsEvolved

	ld de, MUSIC_NONE
	call PlayMusic
	ld de, SFX_CAUGHT_MON
	call PlaySFX
	call WaitSFX

	ld c, 40
	call DelayFrames

	call ClearTileMap
	call UpdateSpeciesNameIfNotNicknamed
	call GetBaseData

	; A caught Magikarp keeps its wild DVs so its length means something at
	; the Lake of Rage. Its evolution gets the perfect DVs every other player
	; Pokemon has.
	ld a, [wEvolutionOldSpecies]
	call GetPokemonIndexFromID
	ld a, l
	cp LOW(MAGIKARP)
	jr nz, .not_magikarp
	ld a, h
	cp HIGH(MAGIKARP)
	jr nz, .not_magikarp
	ld a, PERFECT_ATKDEF_DV
	ld [wTempMonDVs], a
	ld a, PERFECT_SPDSPC_DV
	ld [wTempMonDVs + 1], a
.not_magikarp

	ld hl, wTempMonExp + 2
	ld de, wTempMonMaxHP
	ld b, TRUE
	predef CalcMonStats

	ld a, [wCurPartyMon]
	ld hl, wPartyMons
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld e, l
	ld d, h
	ld bc, MON_MAXHP
	add hl, bc
	ld a, [hli]
	ld b, a
	ld c, [hl]
	ld hl, wTempMonMaxHP + 1
	ld a, [hld]
	sub c
	ld c, a
	ld a, [hl]
	sbc b
	ld b, a
	ld hl, wTempMonHP + 1
	ld a, [hl]
	add c
	ld [hld], a
	ld a, [hl]
	adc b
	ld [hl], a

	ld hl, wTempMonSpecies
	ld bc, PARTYMON_STRUCT_LENGTH
	call CopyBytes

	ld a, [wCurSpecies]
	ld [wTempSpecies], a
	xor a
	ld [wMonType], a
	call LearnLevelMoves
	ld a, [wTempSpecies]
	call SetSeenAndCaughtMon

	ld a, [wTempSpecies]
	call GetPokemonIndexFromID
	ld a, l
	sub LOW(UNOWN)
	if HIGH(UNOWN) == 0
		or h
	else
		jr nz, .skip_unown
		if HIGH(UNOWN) == 1
			dec h
		else
			ld a, h
			cp HIGH(UNOWN)
		endc
	endc
	jr nz, .skip_unown
	ld hl, wTempMonDVs
	predef GetUnownLetter
	callfar UpdateUnownDex

.skip_unown
	pop de
	pop hl
	ld a, [wTempMonSpecies]
	ld [hl], a
	push hl
	ld l, e
	ld h, d
	jp EvolveAfterBattle_MasterLoop

.dont_evolve_check
	ld a, b
	cp EVOLVE_STAT
	jr z, .skip_extra_evolution_parameter
	cp EVOLVE_HOLDING
	jr nz, .skip_evolution_species_parameter
.skip_extra_evolution_parameter
	inc hl
.skip_evolution_species_parameter
	inc hl
.skip_evolution_species
	inc hl
	inc hl
	jp .loop

; unused
	pop hl
.ReturnToMap:
	pop de
	pop bc
	pop hl
	ld a, [wLinkMode]
	and a
	ret nz
	ld a, [wBattleMode]
	and a
	ret nz
	ld a, [wMonTriedToEvolve]
	and a
	call nz, RestartMapMusic
	ret

UpdateSpeciesNameIfNotNicknamed:
	ld a, [wCurSpecies]
	push af
	ld a, [wBaseSpecies]
	ld [wNamedObjectIndexBuffer], a
	call GetPokemonName
	pop af
	ld [wCurSpecies], a
	ld hl, wStringBuffer1
	ld de, wStringBuffer2
.loop
	ld a, [de]
	inc de
	cp [hl]
	inc hl
	ret nz
	cp "@"
	jr nz, .loop

	ld a, [wCurPartyMon]
	ld bc, MON_NAME_LENGTH
	ld hl, wPartyMonNicknames
	call AddNTimes
	push hl
	ld a, [wCurSpecies]
	ld [wNamedObjectIndexBuffer], a
	call GetPokemonName
	ld hl, wStringBuffer1
	pop de
	ld bc, MON_NAME_LENGTH
	jp CopyBytes

CancelEvolution:
	ld hl, Text_StoppedEvolving
	call PrintText
	call ClearTileMap
	jp EvolveAfterBattle_MasterLoop

IsMonHoldingEverstone:
	push hl
	ld a, [wCurPartyMon]
	ld hl, wPartyMon1Item
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld a, [hl]
	cp EVERSTONE
	pop hl
	ret

Text_CongratulationsYourPokemon:
	; Congratulations! Your @ @
	text_far UnknownText_0x1c4b92
	text_end

Text_EvolvedIntoPKMN:
	; evolved into @ !
	text_far UnknownText_0x1c4baf
	text_end

Text_StoppedEvolving:
	; Huh? @ stopped evolving!
	text_far UnknownText_0x1c4bc5
	text_end

Text_WhatEvolving:
	; What? @ is evolving!
	text_far UnknownText_0x1c4be3
	text_end

LearnLevelMoves:
	ld a, [wTempSpecies]
	ld [wCurPartySpecies], a
	call GetPokemonIndexFromID
	ld b, h
	ld c, l
	ld hl, EvosAttacksPointers
	ld a, BANK(EvosAttacksPointers)
	call LoadDoubleIndirectPointer
	ldh [hTemp], a
	call SkipEvolutions

.find_move
	call GetNextEvoAttackByte
	and a
	jr z, .done

	ld b, a
	ld a, [wCurPartyLevel]
	cp b
	call GetNextEvoAttackByte
	ld e, a
	call GetNextEvoAttackByte
	ld d, a
	jr nz, .find_move

	push hl
	ld h, d
	ld l, e
	call GetMoveIDFromIndex
	ld d, a
	ld hl, wPartyMon1Moves
	ld a, [wCurPartyMon]
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes

	ld b, NUM_MOVES
.check_move
	call GetNextEvoAttackByte
	cp d
	jr z, .has_move
	dec b
	jr nz, .check_move
	jr .learn
.has_move

	pop hl
	jr .find_move

.learn
	ld a, d
	ld [wPutativeTMHMMove], a
	ld [wNamedObjectIndexBuffer], a
	call GetMoveName
	call CopyName1
	predef LearnMove
	pop hl
	jr .find_move

.done
	ld a, [wCurPartySpecies]
	ld [wTempSpecies], a
	ret

FillMoves:
; Fill in moves at de for wCurPartySpecies at wCurPartyLevel

	push hl
	push de
	push bc
	ld a, [wCurPartySpecies]
	call GetPokemonIndexFromID
	ld b, h
	ld c, l
	ld hl, EvosAttacksPointers
	ld a, BANK(EvosAttacksPointers)
	call LoadDoubleIndirectPointer
	ldh [hTemp], a
	call SkipEvolutions
	jr .GetLevel

.NextMove:
	pop de
.GetMove:
	inc hl
	inc hl
.GetLevel:
	call GetNextEvoAttackByte
	and a
	jp z, .done
	ld b, a
	ld a, [wCurPartyLevel]
	cp b
	jp c, .done
	ld a, [wEvolutionOldSpecies]
	and a
	jr z, .CheckMove
	ld a, [wd002]
	cp b
	jr nc, .GetMove

.CheckMove:
	push de
	ld c, NUM_MOVES
	ldh a, [hTemp]
	push hl
	call GetFarHalfword
	call GetMoveIDFromIndex
	pop hl
	ld b, a
.CheckRepeat:
	ld a, [de]
	inc de
	cp b
	jr z, .NextMove
	dec c
	jr nz, .CheckRepeat
	pop de
	push de
	ld c, NUM_MOVES
.CheckSlot:
	ld a, [de]
	and a
	jr z, .LearnMove
	inc de
	dec c
	jr nz, .CheckSlot
	pop de
	push de
	push hl
	ld h, d
	ld l, e
	call ShiftMoves
	ld a, [wEvolutionOldSpecies]
	and a
	jr z, .ShiftedMove
	push de
	ld bc, wPartyMon1PP - (wPartyMon1Moves + NUM_MOVES - 1)
	add hl, bc
	ld d, h
	ld e, l
	call ShiftMoves
	pop de

.ShiftedMove:
	pop hl

.LearnMove:
	ldh a, [hTemp]
	push hl
	call GetFarHalfword
	call GetMoveIDFromIndex
	pop hl
	ld b, a
	ld [de], a
	ld a, [wEvolutionOldSpecies]
	and a
	jr z, .NextMove
	push hl
	ld a, b
	ld hl, MON_PP - MON_MOVES
	add hl, de
	push hl
	ld l, a
	ld a, MOVE_PP
	call GetMoveAttribute
	pop hl
	ld [hl], a
	pop hl
	jp .NextMove

.done
	pop bc
	pop de
	pop hl
	ret

ShiftMoves:
	ld c, NUM_MOVES - 1
.loop
	inc de
	ld a, [de]
	ld [hli], a
	dec c
	jr nz, .loop
	ret

EvoFlagAction:
	push de
	ld d, $0
	predef SmallFarFlagAction
	pop de
	ret

GetLowestEvolutionStage:
; Return the first mon to evolve into wCurPartySpecies.
; Instead of looking it up, we just load it from a table. This is a lot more efficient.
	ld a, [wCurPartySpecies]
	call GetPokemonIndexFromID
	ld bc, FirstEvoStages - 2
	add hl, hl
	add hl, bc
	ld a, BANK(FirstEvoStages)
	call GetFarHalfword
	call GetPokemonIDFromIndex
	ld [wCurPartySpecies], a
	ret

SkipEvolutions::
; Receives a pointer to the evos and attacks for a mon in b:hl, and skips to the attacks.
	ld a, b
	call GetFarByte
	inc hl
	and a
	ret z
	cp EVOLVE_STAT
	jr z, .extra_skip
	cp EVOLVE_HOLDING
	jr nz, .no_extra_skip
.extra_skip
	inc hl
.no_extra_skip
	inc hl
	inc hl
	inc hl
	jr SkipEvolutions

DetermineEvolutionItemResults::
; in: b:de: pointer to evos and attacks struct, wCurItem: item
; out: de: species ID or zero; a, b, hl: clobbered
	ld h, d
	ld l, e
	ld de, 0
	ld a, b
	ldh [hTemp], a
.loop
	call GetNextEvoAttackByte
	and a
	ret z
	cp EVOLVE_STAT
	jr z, .skip_species_two_parameters
	cp EVOLVE_HOLDING
	jr z, .skip_species_two_parameters
	cp EVOLVE_ITEM
	jr nz, .skip_species_parameter
	call GetNextEvoAttackByte
	ld b, a	
	ld a, [wCurItem]
	cp b
	jr nz, .skip_species
	ldh a, [hTemp]
	call GetFarHalfword
	ld d, h
	ld e, l
	ret

.skip_species_two_parameters
	inc hl
.skip_species_parameter
	inc hl
.skip_species
	inc hl
	inc hl
	jr .loop

GetNextEvoAttackByte:
	ldh a, [hTemp]
	call GetFarByte
	inc hl
	ret
